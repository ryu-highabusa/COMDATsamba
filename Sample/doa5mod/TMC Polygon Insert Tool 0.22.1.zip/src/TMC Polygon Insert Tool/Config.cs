﻿using System.IO;
using System.Text;
using System.Reflection;
using System.Xml.Serialization;

namespace TMC_Tool
{
  public class Config
  {
    public Config()
    {
      Assembly thisAssem = Assembly.GetExecutingAssembly();
      FilePath = Path.GetDirectoryName(thisAssem.Location) + "\\" + thisAssem.GetName().Name + ".xml";

      SaveConfigsEnabled = true;
    }

    public void LoadConfigs()
    {
      if (!File.Exists(FilePath)) return;

      Config config;
      XmlSerializer serializer = new XmlSerializer(typeof(Config));
      using (var sr = new StreamReader(FilePath, new UTF8Encoding(false)))
      {
        config = (Config)serializer.Deserialize(sr);
      }

      if (config == null) return;

      this.CheckConvertDifference = config.CheckConvertDifference;
      this.SetDeleteCurrent = config.SetDeleteCurrent;
    }

    public void SaveConfigs()
    {
      XmlSerializer serializer = new XmlSerializer(typeof(Config));
      using (var sw = new StreamWriter(FilePath, false, new UTF8Encoding(false)))
      {
        serializer.Serialize(sw, this);
      }
    }



    [XmlIgnore]
    public string FilePath { get; set; }

    [XmlIgnore]
    public bool SaveConfigsEnabled { get; set; }

    public bool CheckConvertDifference { get; set; }
    public bool SetDeleteCurrent { get; set; }
  }
}
