﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows.Media.Media3D;
using System.ComponentModel;
using System.Linq;

namespace TMC_Tool
{
  public class MeshData
  {
    public MeshData()
    {
      BlendIdx = new Dictionary<byte, BlendIndex>();
      Matrix = new Matrix3D();
    }

    public string Path { get; set; }
    public DateTime WriteTime { get; set; }

    public ushort VtxCount { get; set; }
    public int IdxCount { get; set; }
    public int Transparent1 { get; set; }
    public int Transparent2 { get; set; }
    public int DoubleSided { get; set; }

    public VertexGroup VtxGrp { get; set; }
    public IndexGroup IdxGrp { get; set; }
    public Dictionary<byte, BlendIndex> BlendIdx { get; private set; }
    public MtrColorGroup MtrColor { get; set; }
    public Matrix3D Matrix { get; set; }
  }

  public class BlendIndex
  {
    public BlendIndex()
    {
      NewIdx = -1;
    }

    public string Name { get; set; }
    public int NewIdx { get; set; }
  }

  public class MissingBlendIndexData
  {
    public MissingBlendIndexData()
    {
      BlendIdx = new List<byte>();
      NodeIdx = new List<int>();
    }

    public string ConfirmText { get; set; }
    public string NotFoundList { get; set; }
    public List<byte> BlendIdx { get; set; }
    public List<int> NodeIdx { get; set; }
  }

  public class MeshTables
  {
    public MeshTables()
    {
      Mesh = new ObservableCollection<MeshTable>();
    }

    public class MeshTable : INotifyPropertyChanged
    {
      public MeshTable(byte[] bin, MeshData data, bool neckEnabled)
      {
        if (bin != null)
        {
          Bin = bin.Take(bin.Length).ToArray();
          OriginalBin = bin.Take(bin.Length).ToArray();
        }

        if (bin != null)
        {
          Data = data;
          FileName = System.IO.Path.GetFileName(data.Path);
          FilePath = data.Path;
          DataSize = "0x" + data.VtxGrp.DataSize.ToString("X2");
          DeclInfo = MainWindow.BuildDeclInfo(data.VtxGrp);

          EnableAction = true;
          if (data.MtrColor != null)
          {
            EnableMtrCol = true;
          }
          EnableNormal = true;
          EnableNeck = neckEnabled;
        }

        Checked = true;
        Dest = -1;
        ObjList = new List<string>();
        ObjListDisplay = new ObservableCollection<string>();
        ObjListData = new List<int[]>();
      }

      public void SetObjList(TmcData tmcdata, bool convertSmall)
      {
        SetObjList(tmcdata, convertSmall, "");
      }
      public void SetObjList(TmcData tmcdata, bool convertDifference, string curObj)
      {
        if (ObjList.Count > 0)
        {
          if (curObj == "" && Dest != -1) curObj = ObjList[Dest];
          ObjList.Clear();
          ObjListDisplay.Clear();
          ObjListData.Clear();
        }

        for (int i = 0; i < tmcdata.ObjGrp.Count; i++)
        {
          for (int j = 0; j < tmcdata.ObjGrp[i].Obj.Count; j++)
          {
            string objname = tmcdata.ObjGrp[i].Name + "_" + tmcdata.ObjGrp[i].Obj[j].ID.ToString("x");
            string type = "";
            if (tmcdata.ObjGrp[i].Obj[j].MaterialType == "Skin")
              type = " (Skin)";
            else if (tmcdata.ObjGrp[i].Obj[j].MaterialType == "WetTex")
              type = " (Wet)";

            CompareDataLayers compare = null;
            if (Data != null)
            {
              compare = new CompareDataLayers(tmcdata.VtxGrp[tmcdata.ObjGrp[i].Obj[j].VtxGrpIndex], Data.VtxGrp);
            }
            if (Data == null || compare.Equal)
            {
              ObjList.Add(objname);
              ObjListDisplay.Add(objname + type);
              ObjListData.Add(new int[] { i, j });
            }
            else if (convertDifference == true && compare.Convertible)
            {
              ObjList.Add(objname);
              ObjListDisplay.Add(objname + type + " *");
              ObjListData.Add(new int[] { i, j });
            }
          }
        }

        Dest = ObjList.IndexOf(curObj);
      }

      public void ReSetMeshTable(byte[] bin, MeshData data)
      {
        Bin = bin.Take(bin.Length).ToArray();
        Data = data;
        DataSize = "0x" + data.VtxGrp.DataSize.ToString("X2");
        DeclInfo = MainWindow.BuildDeclInfo(data.VtxGrp);
        if (data.MtrColor != null)
        {
          EnableMtrCol = true;
        }
        else
        {
          EnableMtrCol = false;
        }
      }

      public byte[] Bin { get; set; }
      public byte[] OriginalBin { get; set; }
      public MeshData Data { get; set; }
      public string FileName { get; set; }
      public string FilePath { get; set; }
      private string _dataSize;
      public string DataSize
      {
        get { return _dataSize; }
        set
        {
          _dataSize = value;
          OnPropertyChanged(nameof(DataSize));
        }
      }
      public string DeclInfo { get; set; }

      private bool _checked;
      public bool Checked
      {
        get { return _checked; }
        set
        {
          _checked = value;
          OnPropertyChanged(nameof(Checked));
        }
      }

      private int _dest;
      public int Dest
      {
        get { return _dest; }
        set
        {
          _dest = value;
          OnPropertyChanged(nameof(Dest));
        }
      }
      private int _Current;
      public int Current
      {
        get { return _Current; }
        set
        {
          _Current = value;
          OnPropertyChanged(nameof(Current));
        }
      }
      private bool _mtrCol;
      public bool MtrCol
      {
        get { return _mtrCol; }
        set
        {
          _mtrCol = value;
          OnPropertyChanged(nameof(MtrCol));
        }
      }
      private bool _normal;
      public bool Normal
      {
        get { return _normal; }
        set
        {
          _normal = value;
          OnPropertyChanged(nameof(Normal));
        }
      }
      private bool _neck;
      public bool Neck
      {
        get { return _neck; }
        set
        {
          _neck = value;
          OnPropertyChanged(nameof(Neck));
        }
      }

      private bool _enableAction;
      public bool EnableAction
      {
        get { return _enableAction; }
        set
        {
          _enableAction = value;
          OnPropertyChanged(nameof(EnableAction));
        }
      }
      private bool _enableMtrCol;
      public bool EnableMtrCol
      {
        get { return _enableMtrCol; }
        set
        {
          _enableMtrCol = value;
          OnPropertyChanged(nameof(EnableMtrCol));
        }
      }
      private bool _enableNormal;
      public bool EnableNormal
      {
        get { return _enableNormal; }
        set
        {
          _enableNormal = value;
          OnPropertyChanged(nameof(EnableNormal));
        }
      }
      private bool _enableNeck;
      public bool EnableNeck
      {
        get { return _enableNeck; }
        set
        {
          _enableNeck = value;
          OnPropertyChanged(nameof(EnableNeck));
        }
      }

      private bool _isDragging;
      public bool IsDragging
      {
        get { return _isDragging; }
        set
        {
          _isDragging = value;
          OnPropertyChanged(nameof(IsDragging));
        }
      }

      public List<string> ObjList { get; set; }
      public ObservableCollection<string> ObjListDisplay { get; set; }
      public List<int[]> ObjListData { get; set; }
      
      public event PropertyChangedEventHandler PropertyChanged;
      private void OnPropertyChanged(string name)
      {
        if (PropertyChanged != null)
        {
          PropertyChanged(this, new PropertyChangedEventArgs(name));
        }
      }
    }



    public ObservableCollection<MeshTable> Mesh { get; set; }



    public MeshTable SetMeshData(byte[] bin, MeshData data, bool neckEnabled)
    {
      var newMesh = new MeshTable(bin, data, neckEnabled);
      Mesh.Add(newMesh);
      return newMesh;
    }
  }

  public class CompareDataLayers
  {
    public CompareDataLayers(VertexGroup tmcVtxGrp, VertexGroup meshVtxGrp)
    {
      bool notEqual = false;
      bool convertible = false;

      if (tmcVtxGrp.Position && meshVtxGrp.Position && tmcVtxGrp.PositionType != meshVtxGrp.PositionType)
      {
        convertible = true;
      }
      if (tmcVtxGrp.Normal != meshVtxGrp.Normal)
      {
        if (tmcVtxGrp.Normal)
          notEqual = true;
        else
          convertible = true;
      }
      if (tmcVtxGrp.Normal && meshVtxGrp.Normal && tmcVtxGrp.NormalType != meshVtxGrp.NormalType)
      {
        convertible = true;
      }
      if (tmcVtxGrp.BlendWeight != meshVtxGrp.BlendWeight)
      {
        if (tmcVtxGrp.BlendWeight)
        {
          BlendNothing = true;
          notEqual = true;
        }
        else
        {
          convertible = true;
        }
      }
      else if (tmcVtxGrp.BlendWeight && meshVtxGrp.BlendWeight && tmcVtxGrp.BlendWeightOffset != meshVtxGrp.BlendWeightOffset)
      {
        convertible = true;
      }
      if (tmcVtxGrp.BlendIndices != meshVtxGrp.BlendIndices)
      {
        if (tmcVtxGrp.BlendIndices)
          notEqual = true;
        else
          convertible = true;
      }
      if (tmcVtxGrp.Color != meshVtxGrp.Color)
      {
        if (tmcVtxGrp.Color)
          notEqual = true;
        else
          convertible = true;
      }
      if (tmcVtxGrp.Tangent != meshVtxGrp.Tangent)
      {
        if (tmcVtxGrp.Tangent)
          notEqual = true;
        else
          convertible = true;
      }

      if (tmcVtxGrp.UVCount > meshVtxGrp.UVCount)
      {
        notEqual = true;
      }
      else if (tmcVtxGrp.UVCount < meshVtxGrp.UVCount)
      {
        convertible = true;
      }

      if (notEqual)
      {
        Equal = false;
      }
      else if (convertible)
      {
        Convertible = true;
      }
      else
      {
        Equal = true;
      }
    }

    public bool Equal { get; set; }
    public bool Convertible { get; set; }
    public bool BlendNothing { get; set; }
  }

  public class DisplayType
  {
    private string _type;
    public string Type
    {
      get { return _type; }
      set { _type = value; }
    }
  }
}
