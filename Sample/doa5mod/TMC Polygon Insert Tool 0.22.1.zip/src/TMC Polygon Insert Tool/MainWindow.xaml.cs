﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Media3D;
using System.Windows.Data;
using System.Reflection;
using Microsoft.WindowsAPICodePack.Dialogs;
using Message;
using Hardcodet.Wpf.Util;

namespace TMC_Tool
{
  /// <summary>
  /// MainWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class MainWindow : Window
  {
    private static TmcData tmcData;
    private static MeshTables meshTables;

    private static byte[] bn;

    private static byte[] tempBn;

    private static string tmcInfo = "";

    private static string tmcPath = "";
    private static string curMeshPath = "";
    private static string currentFolder = "";

    ContextMenu menuDataGrid = new ContextMenu();
    MenuItem menuDummyInsert = new MenuItem();
    MenuItem menuItemRemove = new MenuItem();

    private static bool enableSave = false;

    private static bool dgMesh_ContextMenuOpened = false;

    public static Config config = new Config();

    private static bool appStarted = false;
    private static bool updateChecking = true;
    private static bool modified = false;
    private static bool exitConfirm = false;
    public static Dictionary<string, string> txt = new Dictionary<string, string>();
    public static string langType = "Jpn";



    public MainWindow()
    {
      InitializeComponent();

      MainWindowTitle();
      changeLanguage();
      MessageWindow.lang(txt);

      DisplayType[] ActionTypes = dgMesh.Resources["ActionTypes"] as DisplayType[];
      ActionTypes[0].Type = txt["Keep"];
      ActionTypes[1].Type = txt["Delete"];

      BuildContextMenu();
      SetCharaComboBox();
      SetNeckData();

      config.LoadConfigs();

      if (config.CheckConvertDifference) cbConvertDifference.IsChecked = true;

      Application.Current.ShutdownMode = ShutdownMode.OnMainWindowClose;
    }

    private void mainWindow_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      if (e.LeftButton == MouseButtonState.Pressed && !IsDragging) this.DragMove();
    }

    private void mainWindow_Loaded(object sender, RoutedEventArgs e)
    {
      List<string> cmds = System.Environment.GetCommandLineArgs().ToList();
      cmds.RemoveAt(0);
      openDorpFile(cmds);
    }

    private void mainWindow_DragOver(object sender, DragEventArgs e)
    {
      e.Handled = true;
      if (e.Data.GetDataPresent(DataFormats.FileDrop))
        e.Effects = DragDropEffects.Move;
      else
        e.Effects = DragDropEffects.None;
    }

    private void mainWindow_DragDrop(object sender, DragEventArgs e)
    {
      List<string> filePaths = ((string[])e.Data.GetData(DataFormats.FileDrop, false)).ToList();
      openDorpFile(filePaths);
    }

    private void openDorpFile(List<string> filePaths)
    {
      if (filePaths.Count < 1) return;

      string tmcpath = "";
      List<string> meshPaths = new List<string>();
      List<string> lnkPaths = new List<string>();
      foreach (string path in filePaths)
      {
        if (tmcpath == "" && System.IO.Path.GetExtension(path).ToUpper() == ".TMC")
        {
          tmcpath = path;
        }
        else if (System.IO.Path.GetExtension(path).ToLower() == ".tmcmesh")
        {
          meshPaths.Add(path);
        }
        else if (System.IO.Path.GetExtension(path).ToLower() == ".lnk")
        {
          lnkPaths.Add(path);
        }
      }

      if (lnkPaths.Count > 0)
      {
        Type t = Type.GetTypeFromCLSID(new Guid("72C24DD5-D70A-438B-8A42-98424B88AFB8"));
        dynamic shell = Activator.CreateInstance(t);
        List<string> shortcutPaths = new List<string>();
        foreach (string path in lnkPaths)
        {
          var shortcut = shell.CreateShortcut(path);
          shortcutPaths.Add(shortcut.TargetPath);
          System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shortcut);
        }
        System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shell);

        foreach (string path in shortcutPaths)
        {
          if (tmcpath == "" && System.IO.Path.GetExtension(path).ToUpper() == ".TMC")
          {
            tmcpath = path;
          }
          else if (System.IO.Path.GetExtension(path).ToLower() == ".tmcmesh")
          {
            meshPaths.Add(path);
          }
        }
      }

      if (tmcpath != "")
      {
        OpenFile(tmcpath);
        if (meshPaths.Count > 0)
        {
          meshPaths.Sort();
          foreach (var meshpath in meshPaths)
          {
            OpenMeshFile(meshpath);
          }
        }
      }
      else if (tmcPath != "" && meshPaths.Count > 0)
      {
        meshPaths.Sort();
        foreach (var meshpath in meshPaths)
        {
          OpenMeshFile(meshpath);
        }
      }
    }

    private void OpenFromClipboard()
    {
      var pathText = Clipboard.GetText();
      if (Clipboard.ContainsFileDropList())
      {
        //データを取得する（取得できなかった時はnull）
        System.Collections.Specialized.StringCollection files = Clipboard.GetFileDropList();
        if (files != null) pathText = files[0];
      }
      if (!string.IsNullOrEmpty(pathText) && File.Exists(pathText) && System.IO.Path.GetExtension(pathText).ToUpper() == ".TMC")
      {
        var result = MessageWindow.Show(this, pathText + "\r\n\r\n" + txt["ConfirmOpenFile"], txt["Info"], txt["btnOpen"], txt["Cancel"]);
        if (result == MessageWindow.Result.OK)
        {
          OpenFile(pathText);
        }
        Keyboard.Focus(mainWindow);
      }
    }

    private void openCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
      dlg.Filter = "TMC Files (.TMC)|*.TMC";
      if (tmcPath != "")
      {
        dlg.InitialDirectory = Path.GetDirectoryName(tmcPath);
        dlg.FileName = Path.GetFileName(tmcPath);
      }
      if (dlg.ShowDialog() == true)
      {
        OpenFile(dlg.FileName);
      }
    }

    private void menuOpenFolder_Click(object sender, RoutedEventArgs e)
    {
      var dlg = new CommonOpenFileDialog();
      dlg.IsFolderPicker = true;
      dlg.EnsureReadOnly = false;
      dlg.AllowNonFileSystemItems = false;
      dlg.InitialDirectory = currentFolder;

      if (dlg.ShowDialog() == CommonFileDialogResult.Ok)
      {
        OpenMeshDir(dlg.FileName);
      }
    }

    private void btnOpenMesh_Click(object sender, RoutedEventArgs e)
    {
      Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
      dlg.Filter = "tmcmesh Files (.tmcmesh)|*.tmcmesh";
      dlg.Multiselect = true;
      if (curMeshPath != "")
      {
        dlg.InitialDirectory = Path.GetDirectoryName(curMeshPath);
        dlg.FileName = Path.GetFileName(curMeshPath);
      }
      if (dlg.ShowDialog() == true)
      {
        foreach (var filename in dlg.FileNames)
        {
          OpenMeshFile(filename);
        }
      }
    }

    private void saveCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (enableSave)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void saveCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      if (!PreSaveCheck()) return;

      var result = MessageWindow.Show(this, txt["Overwrite"], txt["Confirm"], txt["OverwriteYes"], txt["Cancel"]);
      if (result == MessageWindow.Result.OK)
      {
        SaveFile(tmcPath);
      }
    }

    private void saveWithBackupCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (enableSave)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void saveWithBackupCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      if (!PreSaveCheck()) return;

      string newPath = CreateBackup();
      if (newPath != null)
      {
        if (!SaveFile(tmcPath))
        {
          if (File.Exists(newPath)) File.Move(newPath, tmcPath);
        }
      }
      else
      {
        MessageWindow.Show(this, txt["FailedToCreateBackup"], txt["Error"]);
      }
    }

    private void saveAsCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (enableSave)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void saveAsCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      if (!PreSaveCheck()) return;

      Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
      dlg.InitialDirectory = Path.GetDirectoryName(tmcPath);
      dlg.FileName = Path.GetFileName(tmcPath);
      dlg.DefaultExt = ".TMC";
      dlg.Filter = "TMC Files (.TMC)|*.TMC";

      if (dlg.ShowDialog() == true)
      {
        SaveFile(dlg.FileName);
      }
    }

    private void btnConfig_Click(object sender, RoutedEventArgs e)
    {
      ConfigWindow.Show(this);
    }

    private void delCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      e.CanExecute = true;
    }
    private void delCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      DeleteMeshData();
    }


    private void cmbChara_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (meshTables == null) return;

      if (cmbChara.SelectedIndex == 0)
      {
        foreach (var mesh in meshTables.Mesh)
        {
          mesh.EnableNeck = false;
        }
      }
      else
      {
        foreach (var mesh in meshTables.Mesh)
        {
          if (mesh.Data != null)
          {
            mesh.EnableNeck = true;
          }
        }
      }
    }

    private void cbConvertDifference_CheckChange(object sender, RoutedEventArgs e)
    {
      if (meshTables == null) return;

      var cb = sender as CheckBox;
      foreach (var mesh in meshTables.Mesh)
      {
        mesh.SetObjList(tmcData, (bool)cb.IsChecked);
      }
    }

    private void CheckBox_Click(object sender, RoutedEventArgs e)
    {
      CheckBox target = sender as CheckBox;

      DataGrid dataGrid = Common.Styles.FindVisualParent<DataGrid>(target);
      DataGridRow dataGridRow = Common.Styles.FindVisualParent<DataGridRow>(target);
      var data = meshTables.Mesh;
      var curItem = dataGridRow.Item as MeshTables.MeshTable;

      cbHeader.IsChecked = false;

      var b = BindingOperations.GetBinding(target, CheckBox.IsCheckedProperty) as Binding;
      if (b == null || b.Path == null)
      {
        return;
      }
      var p = b.Path.Path;
      if (string.IsNullOrEmpty(p)) return;
      var i = p.LastIndexOf('.');
      if (i < 0)
      {
        if (dataGrid.SelectedItems.Count > 1)
        {
          Type type = target.DataContext.GetType();
          PropertyInfo pi = type.GetProperty(p);

          foreach (MeshTables.MeshTable item in dataGrid.SelectedItems)
          {
            dynamic valDist = pi.GetValue(data[dataGrid.Items.IndexOf(item)]);
            if (valDist != null)
            {
              if (!(p == "MtrCol" && !item.EnableMtrCol))
              {
                pi.SetValue(data[dataGrid.Items.IndexOf(item)], (bool)target.IsChecked, null);
              }
            }
          }
        }
      }
      CheckEnableSave();

      IsDragging = false;
    }

    private void HeaderCheckBox_Click(object sender, RoutedEventArgs e)
    {
      CheckBox cb = sender as CheckBox;

      foreach (var mesh in meshTables.Mesh)
      {
        mesh.Checked = (bool)cb.IsChecked;
      }
      CheckEnableSave();
    }

    private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      ComboBox target = sender as ComboBox;

      if (!this.IsInitialized || !(target.IsMouseCaptured || target.IsKeyboardFocused)) return;

      DataGrid dataGrid = Common.Styles.FindVisualParent<DataGrid>(target);
      DataGridRow dataGridRow = Common.Styles.FindVisualParent<DataGridRow>(target);
      var data = meshTables.Mesh;
      var curItem = dataGridRow.Item as MeshTables.MeshTable;

      if (dataGrid.SelectedItems.Count > 1)
      {
        bool selIndex = false;
        var b = BindingOperations.GetBinding(target, ComboBox.SelectedItemProperty) as Binding;
        if (b == null || b.Path == null)
        {
          b = BindingOperations.GetBinding(target, ComboBox.SelectedIndexProperty) as Binding;
          if (b == null || b.Path == null)
          {
            return;
          }
          selIndex = true;
        }
        var p = b.Path.Path;
        if (string.IsNullOrEmpty(p)) return;
        var i = p.LastIndexOf('.');
        if (i < 0)
        {
          Type type = target.DataContext.GetType();
          PropertyInfo pi = type.GetProperty(p);

          dynamic val = target.SelectedItem;
          if (selIndex)
          {
            val = target.SelectedIndex;
          }

          foreach (MeshTables.MeshTable item in dataGrid.SelectedItems)
          {
            dynamic valDist = pi.GetValue(data[dataGrid.Items.IndexOf(item)]);
            if (valDist != null)
            {
              if (p == "Dest")
              {
                int idx = item.ObjList.IndexOf(curItem.ObjList[val]);
                if (idx != -1) pi.SetValue(data[dataGrid.Items.IndexOf(item)], idx, null);
              }
              else
              {
                pi.SetValue(data[dataGrid.Items.IndexOf(item)], val, null);
              }
            }
          }
        }
      }
      CheckEnableSave();
    }

    private void ComboBox_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
    {
      ComboBox target = sender as ComboBox;
      DataGrid dataGrid = Common.Styles.FindVisualParent<DataGrid>(target);
      DataGridRow row = Common.Styles.FindVisualParent<DataGridRow>(target);
      var item = row.Item;

      if (dataGrid.SelectedItems.IndexOf(item) == -1)
      {
        dataGrid.SelectedIndex = dataGrid.Items.IndexOf(item);
      }
    }


    private void dgMesh_ContextMenuOpening(object sender, ContextMenuEventArgs e)
    {
      menuItemRemove.IsEnabled = false;

      if (dgMesh.SelectedItems.Count > 0)
      {
        menuItemRemove.IsEnabled = true;
      }

      dgMesh_ContextMenuOpened = true;
    }

    private void dgMesh_ContextMenuClosing(object sender, ContextMenuEventArgs e)
    {
      dgMesh_ContextMenuOpened = false;
    }

    private void menuDummyInsert_Click(object sender, RoutedEventArgs e)
    {
      InsertDummyData();
    }

    private void menuItemRemove_Click(object sender, RoutedEventArgs e)
    {
      DeleteMeshData();
    }

    private void BuildContextMenu()
    {
      menuDummyInsert.Header = txt["InsertDummy"];
      menuItemRemove.Header = txt["Remove"];

      menuItemRemove.InputGestureText = "Delete";

      menuDataGrid.Items.Add(menuDummyInsert);
      menuDataGrid.Items.Add(menuItemRemove);

      menuDummyInsert.Click += new RoutedEventHandler(menuDummyInsert_Click);
      menuItemRemove.Click += new RoutedEventHandler(menuItemRemove_Click);

      dgMesh.ContextMenu = menuDataGrid;
    }

    private void InsertDummyData()
    {
      var newMesh = meshTables.SetMeshData(null, null, false);
      newMesh.FileName = txt["DummyMesh"];
      newMesh.Current = 1;
      newMesh.SetObjList(tmcData, (bool)cbConvertDifference.IsChecked);
    }

    private void DeleteMeshData()
    {
      try
      {
        int index = 0;
        while (dgMesh.SelectedItems.Count > 0)
        {
          var mesh = dgMesh.SelectedItem as MeshTables.MeshTable;
          index = meshTables.Mesh.IndexOf(mesh);
          if (mesh.ObjList.Count > 0) mesh.ObjList.Clear();
          meshTables.Mesh.Remove(mesh);
        }
        if (index < meshTables.Mesh.Count)
        {
          dgMesh.SelectedIndex = index;
        }
        else
        {
          dgMesh.SelectedIndex = meshTables.Mesh.Count - 1;
        }

        dgMesh.Focus();
      }
      catch (Exception ex)
      {
        MessageWindow.Show(this, ex.Message + "\r\n\r\n" + ex.StackTrace, txt["Error"]);
      }
    }

    private void CheckEnableSave()
    {
      enableSave = false;
      foreach (var mesh in meshTables.Mesh)
      {
        if (mesh.Checked && mesh.Dest != -1)
        {
          enableSave = true;
          break;
        }
      }
    }

    private bool PreSaveCheck()
    {
      string meshLists = "";
      foreach (var mesh in meshTables.Mesh)
      {
        if (mesh.Checked && mesh.Dest == -1)
        {
          meshLists += "\r\n" + mesh.FileName;
        }
      }
      if (meshLists != "")
      {
        var result = MessageWindow.Show(this, txt["UnsetDest"] + "\r\n" + meshLists, txt["Confirm"], txt["Continue"], txt["Cancel"]);
        if (result != MessageWindow.Result.OK)
        {
          return false;
        }
      }
      return true;
    }


    private void SetControlState(bool state)
    {
      btnOpenMesh.IsEnabled = state;
      tbInfo.IsEnabled = state;
    }

    private void OpenTmc(string filePath)
    {
      SetControlState(false);
      tbInfo.Text = "";

      var bin = System.IO.File.ReadAllBytes(filePath);
      char[] charsToTrim = { '\0' };
      string Name = Encoding.ASCII.GetString(bin, 0, 8).TrimEnd(charsToTrim);
      if (Name != "TMC")
      {
        MessageWindow.Show(this, txt["UnsupportedFile"] + "\r\n" + filePath, txt["Error"]);
        return;
      }
      if (BitConverter.ToUInt32(bin, 8) != 0x01010000)
      {
        MessageWindow.Show(this, txt["UnsupportedFile"] + "\r\n" + filePath, txt["Error"]);
        return;
      }
      tmcData = new TmcData(bin);

      if (tmcData == null) return;


      bn = bin;

      tmcData.Path = filePath;
      tmcData.WriteTime = System.IO.File.GetLastWriteTime(filePath);

      // for broken TMC
      tmcData.H.Size = bn.Length;
      if (tmcData.H.Count1 > 15 && tmcData.H.Offsets[15] != 0 && BitConverter.ToUInt32(bn, tmcData.H.Offsets[15] + 8) != 16842752)
      {
        tmcData.H.Offsets[15] = 0;
      }

      tmcData.ParseObjBaseData(bn);
      //tmcData.ParseTextureData(bn);
      tmcData.ParseMtrColor(bn);
      //tmcData.ParseMdlInfo(bn);
      tmcData.ParseHieLayer(bn);
      //tmcData.ParseBoneOffsetMatrices(bn);
      tmcData.ParseVertexData(bn);
      //if (tmcData.H.Count1 > 12 && tmcData.H.Offsets[12] != 0) tmcData.ParseMCAPack(bn);
      //if (tmcData.H.Count1 > 16 && tmcData.H.Offsets[16] != 0) tmcData.ParseACSCLS(bn);

      tmcData.H.Size = bn.Length;

      BuildTmcInfo();
      tbInfo.Text = tmcInfo;

      dgMesh.IsEnabled = true;
      dgMesh.Focus();

      SetControlState(true);
    }

    private void OpenFile(string filePath)
    {
      this.IsEnabled = false;
      DoEvents();

      try
      {
        if (meshTables != null) ResetDragDrop();

        OpenTmc(filePath);

        if (tmcData == null) return;


        if (meshTables != null)
        {
          foreach (var mesh in meshTables.Mesh)
          {
            if (mesh.ObjList.Count > 0) mesh.ObjList.Clear();
          }
        }
        meshTables = null;
        meshTables = new MeshTables();
        this.DataContext = meshTables;

        string[] fileNameSplit = Path.GetFileNameWithoutExtension(filePath).Replace('_', ' ').Split(' ');
        if (CharaList.Contains(fileNameSplit[0].ToUpper()))
        {
          cmbChara.SelectedValue = txt[fileNameSplit[0].ToUpper()];
        }
        else if (fileNameSplit[0] == "KAS")
        {
          cmbChara.SelectedValue = txt["KASUMI"];
        }
        else if (fileNameSplit[0] == "MAR")
        {
          cmbChara.SelectedValue = txt["MARIE"];
        }
        else if (fileNameSplit[0] == "HON")
        {
          cmbChara.SelectedValue = txt["HONOKA"];
        }
        else
        {
          cmbChara.SelectedIndex = 0;
        }

        tmcPath = filePath;
        textStatus.Path = filePath;
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }
      finally
      {
        this.IsEnabled = true;
        this.Activate();
        this.Focus();
      }
    }

    private void ReopenFile()
    {
      try
      {
        OpenTmc(tmcData.Path);
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }
    }

    private void OpenMeshFile(string filePath)
    {
      try
      {
        byte[] meshBn = System.IO.File.ReadAllBytes(filePath);

        HeaderData tmcMeshH = new HeaderData(0, meshBn);
        MeshData meshData = ParseMeshData(meshBn, tmcMeshH);

        if (meshData == null) return;


        meshData.Path = filePath;
        meshData.WriteTime = System.IO.File.GetLastWriteTime(filePath);

        var newMesh = meshTables.SetMeshData(meshBn, meshData, cmbChara.SelectedIndex != 0);
        newMesh.SetObjList(tmcData, (bool)cbConvertDifference.IsChecked);

        if (config.SetDeleteCurrent) newMesh.Current = 1;

        SetObjList(newMesh);

        curMeshPath = filePath;
        CheckEnableSave();

        this.Activate();
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }
    }

    private void ReopenMeshFiles()
    {
      string reopenError = "";

      foreach (var mesh in meshTables.Mesh)
      {
        if (mesh.FilePath != null)
        {
          byte[] meshBn = System.IO.File.ReadAllBytes(mesh.FilePath);

          HeaderData tmcMeshH = new HeaderData(0, meshBn);
          MeshData meshData = ParseMeshData(meshBn, tmcMeshH);

          if (meshData != null)
          {
            meshData.Path = mesh.FilePath;
            meshData.WriteTime = System.IO.File.GetLastWriteTime(mesh.FilePath);

            string curObj = "";
            if (mesh.Dest != -1) curObj = mesh.ObjList[mesh.Dest];

            mesh.ReSetMeshTable(meshBn, meshData);
            mesh.SetObjList(tmcData, (bool)cbConvertDifference.IsChecked, curObj);

            if (mesh.Dest == -1) SetObjList(mesh);
          }
          else
          {
            reopenError += "\r\n" + mesh.FilePath;
          }
        }
        else
        {
          string curObj = "";
          if (mesh.Dest != -1) curObj = mesh.ObjList[mesh.Dest];
          mesh.SetObjList(tmcData, (bool)cbConvertDifference.IsChecked, curObj);

          if (mesh.Dest == -1) SetObjList(mesh);
        }
      }

      if (reopenError != "")
      {
        MessageWindow.Show(this, txt["NotReopen"] + "\r\n" + reopenError, txt["Error"]);
      }
    }

    private void OpenMeshDir(string dirPath)
    {
      try
      {
        currentFolder = dirPath;

        string[] files;
        files = System.IO.Directory.GetFiles(dirPath, "*.tmcmesh", System.IO.SearchOption.TopDirectoryOnly);

        char[] charsToTrim = { '\0' };
        foreach (string filePath in files)
        {
          OpenMeshFile(filePath);
        }
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }
    }
    
    private void SetObjList(MeshTables.MeshTable mesh)
    {
      int idx = -1;
      string[] strs1 = System.IO.Path.GetFileNameWithoutExtension(mesh.FilePath).Split('-');
      foreach (var str1 in strs1)
      {
        string[] strs2 = str1.Split('.');
        foreach (var str2 in strs2)
        {
          string objName = str2;

          int length = str2.LastIndexOf('_');
          if (length > 1)
          {
            string grpName = str2.Substring(0, length);
            string objIndex = str2.Substring(length + 1);

            while (objIndex.Length > 1)
            {
              if (objIndex[0] == '0')
              {
                objIndex = objIndex.Substring(1);
              }
              else
              {
                break;
              }
            }

            objName = grpName + "_" + objIndex;
          }

          idx = mesh.ObjList.IndexOf(objName);
          if (idx == -1)
          {
            idx = mesh.ObjList.IndexOf(str2 + "_0");
          }
          if (idx != -1) break;
        }
      }
      if (idx != -1) mesh.Dest = idx;
    }

    private void ResetMeshData()
    {
      foreach (var mesh in meshTables.Mesh)
      {
        if (mesh.FilePath == null) continue;


        HeaderData tmcMeshH = new HeaderData(0, mesh.OriginalBin);
        MeshData meshData = ParseMeshData(mesh.OriginalBin, tmcMeshH);

        if (meshData != null)
        {
          meshData.Path = mesh.FilePath;
          meshData.WriteTime = System.IO.File.GetLastWriteTime(mesh.FilePath);

          mesh.ReSetMeshTable(mesh.OriginalBin, meshData);
        }
      }
    }

    private bool SaveFile(string filePath)
    {
      this.IsEnabled = false;
      DoEvents();

      try
      {
        updateChecking = false;

        // 各部バイナリ
        //  0 MdlGeo
        //  1 TTX
        //  2 VtxLay
        //  3 IdxLay
        //  4 MtrCol
        //  5 MdlInfo
        //  6 HieLay
        //  7 LHeader
        //  8 NodeLay
        //  9 GlblMtx
        // 10 BnOfsMtx
        // 11 cpf
        // 12 MCAPACK
        // 13 RENPACK
        // 14 GEOXTRAS
        // 15 
        // 16 ACSCLS
        Dictionary<int, List<byte>> partBn = new Dictionary<int, List<byte>>();

        int lastOffset = tmcData.H.Size;
        for (int i = tmcData.H.Count1 - 1; i >= 0; i--)
        {
          partBn[i] = new List<byte>();

          if (tmcData.H.Offsets[i] != 0)
          {
            partBn[i].AddRange(bn.Skip(tmcData.H.Offsets[i]).Take(lastOffset - tmcData.H.Offsets[i]));
            lastOffset = tmcData.H.Offsets[i];
          }
        }

        // for broken TMC
        if (tmcData.H.Count1 > 14 && tmcData.H.Offsets[14] != 0 && BitConverter.ToUInt32(bn, tmcData.H.Offsets[14] + 8) != 0x01010000 && partBn[14].Count > 0x40)
        {
          partBn[14] = new List<byte>(new byte[0x40]);
        }

        // Vtxバイナリ
        List<List<byte>> vtxBins = new List<List<byte>>();
        List<List<byte>> newVtxBins = new List<List<byte>>();
        foreach (var grp in tmcData.VtxGrp)
        {
          List<byte> bin = new List<byte>();
          bin = partBn[2].Skip(grp.Offset).Take(grp.Size).ToList();
          vtxBins.Add(bin);
          bin = new List<byte>();
          newVtxBins.Add(bin);
        }

        // Idxバイナリ
        List<List<byte>> idxBins = new List<List<byte>>();
        List<List<byte>> newIdxBins = new List<List<byte>>();
        foreach (var grp in tmcData.IdxGrp)
        {
          List<byte> bin = new List<byte>();
          bin = partBn[3].Skip(grp.Offset).Take(grp.Size).ToList();
          idxBins.Add(bin);
          bin = new List<byte>();
          newIdxBins.Add(bin);
        }



        #region Start
        List<int> targetVtxGrps = new List<int>();
        int insertCount = meshTables.Mesh.Count;
        int transferNeckVtxCount = 0;
        Dictionary<string, bool> replaceObjs = new Dictionary<string, bool>();
        foreach (var mesh in meshTables.Mesh)
        {
          if (mesh.Dest == -1 || !mesh.Checked)
          {
            insertCount--;
            continue;
          }
          int grp = mesh.ObjListData[mesh.Dest][0];
          int obj = mesh.ObjListData[mesh.Dest][1];
          targetVtxGrps.Add(tmcData.ObjGrp[grp].Obj[obj].VtxGrpIndex);
          if (mesh.Current == 1)
          {
            replaceObjs[grp + "_" + obj] = true;
          }
        }

        foreach (var mesh in meshTables.Mesh)
        {
          if (mesh.Dest == -1 || !mesh.Checked) continue;
          int grp = mesh.ObjListData[mesh.Dest][0];
          int obj = mesh.ObjListData[mesh.Dest][1];
          if (replaceObjs.ContainsKey(grp + "_" + obj) && replaceObjs[grp + "_" + obj])
          {
            mesh.Current = 1;
          }
        }

        List<List<int>> blendIdxs = new List<List<int>>();
        foreach (var node in tmcData.Node)
        {
          List<int> idxs = new List<int>();
          if (node.ChildCount > 0)
          {
            idxs.AddRange(tmcData.BlendIdxGrp[node.Index].Idx);
          }
          blendIdxs.Add(idxs);
        }

        foreach (var objGrp in tmcData.ObjGrp)
        {
          foreach (var dataObj in objGrp.Obj)
          {
            if (targetVtxGrps.Contains(dataObj.VtxGrpIndex))
            {
              int dataSize = objGrp.Decl[dataObj.DeclIndex].DataSize;
              int vtxgrp = objGrp.Decl[dataObj.DeclIndex].VtxGrpIndex;
              int idxgrp = objGrp.Decl[dataObj.DeclIndex].IdxGrpIndex;

              int shiftIndex = dataObj.VtxStartIndex - (newVtxBins[vtxgrp].Count / dataSize);

              ReplaceByteList(partBn[0], BitConverter.GetBytes(newVtxBins[vtxgrp].Count / dataSize), objGrp.Offset + dataObj.Offset + 0x78);
              ReplaceByteList(partBn[0], BitConverter.GetBytes(newIdxBins[idxgrp].Count / 2), objGrp.Offset + dataObj.Offset + 0x70);

              int vtxCount = 0;
              int idxCount = 0;
              bool add = true;
              bool added = false;
              foreach (var mesh in meshTables.Mesh)
              {
                if (mesh.Dest == -1 || tmcData.ObjGrp[mesh.ObjListData[mesh.Dest][0]] != objGrp) continue;
                ObjectPart obj = objGrp.Obj[mesh.ObjListData[mesh.Dest][1]];
                if (mesh.Checked && mesh.Current == 1 && dataObj == obj)
                {
                  add = false;
                }
                else if (mesh.Checked && mesh.Current == 0 && dataObj == obj && !added)
                {
                  vtxCount += obj.VtxCount;
                  idxCount += obj.IdxCount;
                  added = true;
                }
              }

              if (add)
              {
                moveVtxIdxData(newVtxBins[vtxgrp], vtxBins[vtxgrp], newIdxBins[idxgrp], idxgrp, dataObj, dataSize, shiftIndex);
              }

              foreach (var mesh in meshTables.Mesh)
              {
                if (mesh.Dest == -1 || tmcData.ObjGrp[mesh.ObjListData[mesh.Dest][0]] != objGrp) continue;
                ObjectPart obj = objGrp.Obj[mesh.ObjListData[mesh.Dest][1]];
                if (!mesh.Checked || dataObj != obj) continue;


                #region BlendIdx置換
                if (mesh.Data != null && mesh.Data.BlendIdx.Count != 0 && mesh.Data.VtxGrp.Vtx[0].BlendIdx.Length != 0)
                {
                  string meshName = System.IO.Path.GetFileName(mesh.FilePath);
                  bool deleteWeights = false;

                  // 挿入先にボーンウェイトが無い場合
                  var node = tmcData.Node[tmcData.ObjGrp[objGrp.ID].Node];
                  //if (node.ChildCount == 0)
                  if (!tmcData.VtxGrp[vtxgrp].BlendWeight)
                  {
                    var result = MessageWindow.Show(this, "[" + meshName + "]\r\n\r\n" + txt["BlendAllDelete"], txt["Confirm"], txt["Continue"], txt["Cancel"], txt["Skip"]);
                    if (result == MessageWindow.Result.Cancel)
                    {
                      return false;
                    }
                    else if (result == MessageWindow.Result.Other) // Skip
                    {
                      if (!add)
                      {
                        moveVtxIdxData(newVtxBins[vtxgrp], vtxBins[vtxgrp], newIdxBins[idxgrp], idxgrp, dataObj, dataSize, shiftIndex);
                      }
                      insertCount--;
                      continue;
                    }
                    else
                    {
                      deleteWeights = true;
                    }
                  }

                  if (!deleteWeights)
                  {
                    var missings = CheckBlendIdx(mesh, objGrp.ID, blendIdxs[node.Index].ToArray());

                    if (tmcData.BlendIdxGrp[node.Index].Idx.Length + missings.BlendIdx.Count > 256)
                    {
                      var result = MessageWindow.Show(this, "[" + meshName + "]\r\n\r\n" + txt["BlendIdxOverLimit"], txt["Confirm"], txt["Continue"], txt["Cancel"]);
                      if (result == MessageWindow.Result.Cancel)
                      {
                        return false;
                      }
                      else // Skip
                      {
                        if (!add)
                        {
                          moveVtxIdxData(newVtxBins[vtxgrp], vtxBins[vtxgrp], newIdxBins[idxgrp], idxgrp, dataObj, dataSize, shiftIndex);
                        }
                        insertCount--;
                        continue;
                      }
                    }

                    // 挿入先に見つからない場合
                    if (missings.NotFoundList != "")
                    {
                      string confirmText = missings.ConfirmText;

                      if (blendIdxs[node.Index].Count == 0)
                      {
                        if (missings.BlendIdx.Count == 0)
                        {
                          confirmText = txt["ContinueReplace0"].Replace("MOT00_Hips", tmcData.Node[node.Index].Name);
                          blendIdxs[node.Index].Add(node.Index);
                        }
                        else
                        {
                          confirmText = txt["ContinueReplace0"].Replace("MOT00_Hips", tmcData.Node[missings.NodeIdx[0]].Name);
                        }
                      }

                      var result = MessageWindow.Show(this, "[" + meshName + "]\r\n\r\n" + txt["BlendIdxNotFound"] + "\r\n" + confirmText + "\r\n" + missings.NotFoundList, txt["Confirm"], txt["Continue"], txt["Cancel"], txt["Skip"]);
                      if (result == MessageWindow.Result.Cancel)
                      {
                        return false;
                      }
                      else if (result == MessageWindow.Result.Other) // Skip
                      {
                        if (!add)
                        {
                          moveVtxIdxData(newVtxBins[vtxgrp], vtxBins[vtxgrp], newIdxBins[idxgrp], idxgrp, dataObj, dataSize, shiftIndex);
                        }
                        insertCount--;
                        continue;
                      }
                    }

                    ReplaceBlendIdx(mesh, blendIdxs[node.Index], missings.BlendIdx, missings.NodeIdx);
                  }
                }
                #endregion

                if (mesh.Data != null)
                {
                  if (mesh.Normal) TransferNormals(mesh, objGrp, obj, vtxgrp);
                  if (mesh.Neck) transferNeckVtxCount += TransferNeckData(mesh);
                  SetOtherData(mesh, partBn, objGrp.ID, obj);
                }

                // 最後に同じインデックスを追加
                int end = newIdxBins[idxgrp].Count - 1;
                if (idxCount > 1 && !(newIdxBins[idxgrp][end] == newIdxBins[idxgrp][end - 2] && newIdxBins[idxgrp][end - 1] == newIdxBins[idxgrp][end - 3]))
                {
                  newIdxBins[idxgrp].Add(newIdxBins[idxgrp][end - 1]);
                  newIdxBins[idxgrp].Add(newIdxBins[idxgrp][end]);
                  idxCount++;
                }

                var addedBins = InsertMeshData(mesh, objGrp.ID, obj, newVtxBins[vtxgrp].Count / dataSize, idxCount);

                vtxCount += (addedBins[0].Count / dataSize);
                idxCount += (addedBins[1].Count / 2);

                // Vtx数変更
                ReplaceByteList(partBn[0], BitConverter.GetBytes(vtxCount), objGrp.Offset + obj.Offset + 0x7C);

                // Idx数変更
                ReplaceByteList(partBn[0], BitConverter.GetBytes(idxCount), objGrp.Offset + obj.Offset + 0x74);

                newVtxBins[vtxgrp].AddRange(addedBins[0]);
                newIdxBins[idxgrp].AddRange(addedBins[1]);
              }

            }
          }

          // DeclのVtx数とIdx数を変更
          foreach (var decl in objGrp.Decl)
          {
            if (newVtxBins[decl.VtxGrpIndex].Count != 0)
            {
              ReplaceByteList(partBn[0], BitConverter.GetBytes(newVtxBins[decl.VtxGrpIndex].Count / decl.DataSize), objGrp.Offset + objGrp.DeclOffset + decl.Offset + 0x14);
            }
            if (newIdxBins[decl.IdxGrpIndex].Count != 0)
            {
              ReplaceByteList(partBn[0], BitConverter.GetBytes(newIdxBins[decl.IdxGrpIndex].Count / 2), objGrp.Offset + objGrp.DeclOffset + decl.Offset + 0x10);
            }
          }
        }

        if(insertCount == 0)
        {
          MessageWindow.Show(this, txt["InsertCanceled"], txt["Info"]);
          return false;
        }
        #endregion

        for (int i = 0; i < newVtxBins.Count; i++)
        {
          if (newVtxBins[i].Count != 0)
          {
            vtxBins[i].Clear();
            vtxBins[i].AddRange(newVtxBins[i]);
          }
          if (vtxBins[i].Count % 16 != 0) vtxBins[i].AddRange(new byte[16 - (vtxBins[i].Count % 16)]);
        }

        for (int i = 0; i < newIdxBins.Count; i++)
        {
          if (newIdxBins[i].Count != 0)
          {
            idxBins[i].Clear();
            idxBins[i].AddRange(newIdxBins[i]);
          }
          if (idxBins[i].Count % 16 != 0) idxBins[i].AddRange(new byte[16 - (idxBins[i].Count % 16)]);
        }

        // VtxLayバイナリパート再構築
        partBn[2] = BuildHeaderBaseBin("VtxLay");
        BuildBin(partBn[2], vtxBins, null, true, false);

        // IdxLayバイナリパート再構築
        partBn[3] = BuildHeaderBaseBin("IdxLay");
        BuildBin(partBn[3], idxBins, null, true, false);

        // NodeLayバイナリパート再構築
        partBn[8] = buildNodeLay(blendIdxs);

        List<byte> exBn = new List<byte>();
        exBn.AddRange(bn.Take(tmcData.H.Offsets[0]));

        for (int i = 0; i < tmcData.H.Count1; i++)
        {
          if (partBn[i].Count != 0)
          {
            ReplaceByteList(exBn, BitConverter.GetBytes(exBn.Count), tmcData.H.Offset1 + (i * 4));
            exBn.AddRange(partBn[i]);
          }
          else
          {
            ReplaceByteList(exBn, BitConverter.GetBytes(0), 0x140 + (i * 4));
          }
        }

        // 全体サイズ変更
        ReplaceByteList(exBn, BitConverter.GetBytes(exBn.Count), 0x10);

        // 保存
        System.IO.File.WriteAllBytes(filePath, exBn.ToArray());

        if ((bool)cbKeepData.IsChecked)
        {
          tmcPath = filePath;
          textStatus.Path = filePath;
          tmcData.WriteTime = System.IO.File.GetLastWriteTime(tmcData.Path);
          ResetMeshData();
          this.IsEnabled = true;
        }
        else
        {
          OpenFile(filePath);
        }

        string addText = "";
        if (transferNeckVtxCount > 0)
        {
          addText = " [" + txt["TransferNeckVtxCount"] + " : " + transferNeckVtxCount + "]";
        }

        ShowTextBlockMessage(txt["Saved"] + addText);

        updateChecking = true;

        return true;
      }
      catch (Exception e)
      {
        updateChecking = true;
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
        this.IsEnabled = true;

        return false;
      }
      finally
      {
        this.Activate();
        this.Focus();
      }
    }

    private string CreateBackup()
    {
      try
      {
        if (!File.Exists(tmcPath)) return null;

        string dirPath = Path.GetDirectoryName(tmcPath);
        string name = Path.GetFileNameWithoutExtension(tmcPath);

        List<string> files = Directory.GetFiles(dirPath, name + "*.TMC", SearchOption.TopDirectoryOnly).ToList();
        string regStr = name + @" - ([0-9]+)";
        int count = 1;

        foreach (string file in files)
        {
          string fileName = Path.GetFileNameWithoutExtension(file);

          MatchCollection mc = Regex.Matches(fileName, regStr);
          foreach (Match m in mc)
          {
            int num = int.Parse(m.Groups[1].Value);
            if (count <= num) count = num + 1;
          }
        }

        string newPath;
        while (File.Exists(newPath = dirPath + @"/" + name + " - " + count + ".TMC"))
        {
          count++;
        }

        File.Move(tmcPath, newPath);

        return newPath;
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
        return null;
      }
    }

    private void moveVtxIdxData(List<byte> newVtxBin, List<byte> vtxBin, List<byte> newIdxBin, int idxgrp, ObjectPart obj, int dataSize, int shiftIndex)
    {
      // Vtx移動
      newVtxBin.AddRange(vtxBin.Skip(obj.VtxStartIndex * dataSize).Take(obj.VtxCount * dataSize).ToList());

      // Idx移動
      for (int i = obj.IdxStartIndex; i < obj.IdxStartIndex + obj.IdxCount; i++)
      {
        newIdxBin.AddRange(BitConverter.GetBytes((short)(tmcData.IdxGrp[idxgrp].Idx[i] - shiftIndex)));
      }
    }

    private List<List<byte>> InsertMeshData(MeshTables.MeshTable mesh, int objGrp, ObjectPart obj, int curVtxCount, int curObjIdxCount)
    {
      List<List<byte>> bins = new List<List<byte>>();

      if (mesh.Data == null)
      {
        bins.Add(InsertDummyVertexData(mesh, objGrp, obj));
        bins.Add(new byte[6].ToList());
      }
      else
      {
        bins.Add(InsertVertexData(mesh, objGrp, obj));
        bins.Add(InsertIndexData(mesh, curVtxCount, curObjIdxCount));
      }

      return bins;
    }

    private List<byte> InsertDummyVertexData(MeshTables.MeshTable mesh, int objGrp, ObjectPart obj)
    {
      var tmcVtxGrp = tmcData.VtxGrp[obj.VtxGrpIndex];
      byte[] vdata = new byte[tmcVtxGrp.DataSize];

      int byteCount = 12;
      if (tmcVtxGrp.PositionType == 3) byteCount = 16;
      Array.Copy(new byte[byteCount], 0, vdata, tmcVtxGrp.PositionOffset, byteCount);

      if (tmcVtxGrp.Normal)
      {
        byteCount = 12;
        if (tmcVtxGrp.NormalType == 3) byteCount = 16;
        Array.Copy(new byte[byteCount], 0, vdata, tmcVtxGrp.NormalOffset, byteCount);
      }

      if (tmcVtxGrp.BlendWeight)
      {
        byteCount = 4;
        if (tmcVtxGrp.BlendWeightType == 3) byteCount = 16;
        Array.Copy(new byte[byteCount], 0, vdata, tmcVtxGrp.BlendWeightOffset, byteCount);
      }

      if (tmcVtxGrp.BlendIndices)
      {
        Array.Copy(new byte[4], 0, vdata, tmcVtxGrp.BlendIndicesOffset, 4);
      }

      if (tmcVtxGrp.Color)
      {
        Array.Copy(new byte[4], 0, vdata, tmcVtxGrp.ColorOffset, 4);
      }

      if (tmcVtxGrp.Tangent)
      {
        var tempBin = new byte[16];
        tempBin[14] = 0x80;
        tempBin[15] = 0x3F;
        Array.Copy(tempBin, 0, vdata, tmcVtxGrp.TangentOffset, tempBin.Length);
      }

      if (tmcVtxGrp.UVCount > 0)
      {
        Array.Copy(new byte[4 * tmcVtxGrp.UVCount], 0, vdata, tmcVtxGrp.TexCoordOffsets[0], 4 * tmcVtxGrp.UVCount);
      }

      return vdata.ToList();
    }

    private List<byte> InsertVertexData(MeshTables.MeshTable mesh, int objGrp, ObjectPart obj)
    {
      List<byte> vtxBin = new List<byte>();
      var tmcVtxGrp = tmcData.VtxGrp[obj.VtxGrpIndex];
      int dataSize = tmcVtxGrp.DataSize;

      MatrixTransform3D objTransform = new MatrixTransform3D(tmcData.MtxGrp[tmcData.ObjGrp[objGrp].Node].Matrix);
      MatrixTransform3D objTransformInv = objTransform.Inverse as MatrixTransform3D;
      MatrixTransform3D meshTransform = new MatrixTransform3D(mesh.Data.Matrix);
      //MatrixTransform3D meshTransformInv = meshTransform.Inverse as MatrixTransform3D;
      bool matrixEqual = Matrix3D.Equals(tmcData.MtxGrp[tmcData.ObjGrp[objGrp].Node].Matrix, mesh.Data.Matrix);

      var compare = new CompareDataLayers(tmcVtxGrp, mesh.Data.VtxGrp);
      if (compare.Equal && matrixEqual)
      {
        vtxBin.AddRange(mesh.Bin.Skip(mesh.Data.VtxGrp.Start).Take(dataSize * mesh.Data.VtxCount).ToList());
      }
      else
      {
        int normalOffsetMesh = mesh.Data.VtxGrp.NormalOffset;
        int weightOffsetMesh = mesh.Data.VtxGrp.BlendWeightOffset;
        int blendIdxOffsetMesh = mesh.Data.VtxGrp.BlendIndicesOffset;
        int colorOffsetMesh = mesh.Data.VtxGrp.ColorOffset;
        int tangentOffsetMesh = mesh.Data.VtxGrp.TangentOffset;

        foreach (Vertex vtx in mesh.Data.VtxGrp.Vtx)
        {
          List<byte> positionBin = new List<byte>();
          List<byte> normalBin = new List<byte>();
          if (matrixEqual)
          {
            if (tmcVtxGrp.PositionType != mesh.Data.VtxGrp.PositionType)
            {
              positionBin.AddRange(BitConverter.GetBytes(vtx.X));
              positionBin.AddRange(BitConverter.GetBytes(vtx.Y));
              positionBin.AddRange(BitConverter.GetBytes(vtx.Z));
              if (tmcVtxGrp.PositionType == 3) positionBin.AddRange(BitConverter.GetBytes(1f));
            }
            else
            {
              int byteCount = 12;
              if (tmcVtxGrp.PositionType == 3) byteCount = 16;
              tempBn = new byte[byteCount];
              Array.Copy(mesh.Bin, vtx.Address, tempBn, 0, tempBn.Length);
              positionBin.AddRange(tempBn);
            }

            if (tmcVtxGrp.Normal)
            {
              if (tmcVtxGrp.NormalType != mesh.Data.VtxGrp.NormalType)
              {
                normalBin.AddRange(BitConverter.GetBytes(vtx.N1));
                normalBin.AddRange(BitConverter.GetBytes(vtx.N2));
                normalBin.AddRange(BitConverter.GetBytes(vtx.N3));
                if (tmcVtxGrp.NormalType == 3) normalBin.AddRange(BitConverter.GetBytes(0f));
              }
              else
              {
                int byteCount = 12;
                if (tmcVtxGrp.NormalType == 3) byteCount = 16;
                tempBn = new byte[byteCount];
                Array.Copy(mesh.Bin, vtx.Address + normalOffsetMesh, tempBn, 0, tempBn.Length);
                normalBin.AddRange(tempBn);
              }
            }
          }
          else
          {
            // Matrix対応
            
            if (tmcVtxGrp.PositionType == 3)
            {
              if (vtx.W == null) vtx.W = 1;
              Point4D newP = objTransformInv.Transform(meshTransform.Transform(new Point4D(vtx.X, vtx.Y, vtx.Z, (double)vtx.W)));
              positionBin.AddRange(BitConverter.GetBytes((float)newP.X));
              positionBin.AddRange(BitConverter.GetBytes((float)newP.Y));
              positionBin.AddRange(BitConverter.GetBytes((float)newP.Z));
              positionBin.AddRange(BitConverter.GetBytes((float)newP.W));
            }
            else
            {
              Point3D newP = objTransformInv.Transform(meshTransform.Transform(new Point3D(vtx.X, vtx.Y, vtx.Z)));
              positionBin.AddRange(BitConverter.GetBytes((float)newP.X));
              positionBin.AddRange(BitConverter.GetBytes((float)newP.Y));
              positionBin.AddRange(BitConverter.GetBytes((float)newP.Z));
            }

            if (tmcVtxGrp.Normal)
            {
              Vector3D newN = objTransformInv.Transform(meshTransform.Transform(new Vector3D(vtx.N1, vtx.N2, vtx.N3)));
              normalBin.AddRange(BitConverter.GetBytes((float)newN.X));
              normalBin.AddRange(BitConverter.GetBytes((float)newN.Y));
              normalBin.AddRange(BitConverter.GetBytes((float)newN.Z));
              if (tmcVtxGrp.NormalType == 3)
              {
                if (vtx.N4 == null) vtx.N4 = 0;
                normalBin.AddRange(BitConverter.GetBytes((float)vtx.N4));
              }
            }
          }

          List<byte> blendWeightBin = new List<byte>();
          if (tmcVtxGrp.BlendWeight)
          {
            if (tmcVtxGrp.BlendWeightType == 3)
            {
              tempBn = new byte[16];

              if (mesh.Data.VtxGrp.BlendWeightType == 3)
              {
                Array.Copy(mesh.Bin, vtx.Address + weightOffsetMesh, tempBn, 0, tempBn.Length);
                blendWeightBin.AddRange(tempBn);
              }
              else
              {
                byte totalWeight = 0;
                for (int i = 0; i < vtx.Weights.Length; i++)
                {
                  totalWeight += vtx.Weights[i];
                }
                for (int i = 0; i < vtx.Weights.Length; i++)
                {
                  byte[] bytes = new byte[4];
                  if (totalWeight > 0)
                  {
                    bytes = BitConverter.GetBytes((float)vtx.Weights[i] / totalWeight);
                  }
                  Array.Copy(bytes, 0, tempBn, 4 * i, 4);
                }
                blendWeightBin.AddRange(tempBn);
              }
            }
            else
            {
              tempBn = new byte[4];

              if (mesh.Data.VtxGrp.BlendWeightType == 3)
              {
                int totalWeightOffset = 255;
                // floatをbyteに変換
                for (int i = 0; i < vtx.WeightsF.Length; i++)
                {
                  tempBn[i] = (byte)Math.Round(vtx.WeightsF[i] * 255);
                  totalWeightOffset -= tempBn[i];
                }
                if (totalWeightOffset > 0)
                {
                  int wCount = 0;
                  while (totalWeightOffset != 0 && wCount < 16)
                  {
                    if (tempBn[wCount % 4] != 0)
                    {
                      tempBn[wCount % 4]++;
                      totalWeightOffset--;
                    }
                    wCount++;
                  }
                }
                else if (totalWeightOffset < 0)
                {
                  int wCount = 0;
                  while (totalWeightOffset != 0 && wCount < 16)
                  {
                    if (tempBn[3 - wCount % 4] != 0)
                    {
                      tempBn[3 - wCount % 4]++;
                      totalWeightOffset++;
                    }
                    wCount++;
                  }
                }
                blendWeightBin.AddRange(tempBn);
              }
              else
              {
                Array.Copy(mesh.Bin, vtx.Address + weightOffsetMesh, tempBn, 0, tempBn.Length);
                blendWeightBin.AddRange(tempBn);
              }
            }
          }

          List<byte> blendIndicesBin = new List<byte>();
          if (tmcVtxGrp.BlendIndices)
          {
            tempBn = new byte[4];
            Array.Copy(mesh.Bin, vtx.Address + blendIdxOffsetMesh, tempBn, 0, tempBn.Length);
            blendIndicesBin.AddRange(tempBn);
          }

          List<byte> colorBin = new List<byte>();
          if (tmcVtxGrp.Color)
          {
            tempBn = new byte[4];
            Array.Copy(mesh.Bin, vtx.Address + colorOffsetMesh, tempBn, 0, tempBn.Length);
            colorBin.AddRange(tempBn);
          }

          List<byte> tangentBin = new List<byte>();
          if (tmcVtxGrp.Tangent)
          {
            if (matrixEqual)
            {
              tempBn = new byte[16];
              Array.Copy(mesh.Bin, vtx.Address + tangentOffsetMesh, tempBn, 0, tempBn.Length);
              tangentBin.AddRange(tempBn);
            }
            else
            {
              // Matrix対応
              Vector3D newT = meshTransform.Transform(objTransformInv.Transform(new Vector3D(vtx.T1, vtx.T2, vtx.T3)));
              tangentBin.AddRange(BitConverter.GetBytes((float)newT.X));
              tangentBin.AddRange(BitConverter.GetBytes((float)newT.Y));
              tangentBin.AddRange(BitConverter.GetBytes((float)newT.Z));
              tangentBin.AddRange(BitConverter.GetBytes(vtx.T4));
            }
          }

          List<byte> uvBin = new List<byte>();
          for (int i = 0; i < tmcVtxGrp.UVCount; i++)
          {
            uvBin.AddRange(vtx.UV[i].U);
            uvBin.AddRange(vtx.UV[i].V);
          }


          byte[] vdata = new byte[dataSize];

          Array.Copy(positionBin.ToArray(), 0, vdata, tmcVtxGrp.PositionOffset, positionBin.Count);

          if (tmcVtxGrp.Normal)
          {
            Array.Copy(normalBin.ToArray(), 0, vdata, tmcVtxGrp.NormalOffset, normalBin.Count);
          }

          if (tmcVtxGrp.BlendWeight)
          {
            Array.Copy(blendWeightBin.ToArray(), 0, vdata, tmcVtxGrp.BlendWeightOffset, blendWeightBin.Count);
          }

          if (tmcVtxGrp.BlendIndices)
          {
            Array.Copy(blendIndicesBin.ToArray(), 0, vdata, tmcVtxGrp.BlendIndicesOffset, blendIndicesBin.Count);
          }

          if (tmcVtxGrp.Color)
          {
            Array.Copy(colorBin.ToArray(), 0, vdata, tmcVtxGrp.ColorOffset, colorBin.Count);
          }

          if (tmcVtxGrp.Tangent)
          {
            Array.Copy(tangentBin.ToArray(), 0, vdata, tmcVtxGrp.TangentOffset, tangentBin.Count);
          }

          if (tmcVtxGrp.UVCount > 0)
          {
            Array.Copy(uvBin.ToArray(), 0, vdata, tmcVtxGrp.TexCoordOffsets[0], uvBin.Count);
          }

          vtxBin.AddRange(vdata);
        }
      }

      return vtxBin;
    }

    private List<byte> InsertIndexData(MeshTables.MeshTable mesh, int curVtxCount, int curObjIdxCount)
    {
      List<byte> idxBin = new List<byte>();

      int startIndex = 0;
      int endIndex = mesh.Data.IdxGrp.Idx.Length;

      if (curObjIdxCount % 2 == 1)
      {
        if (mesh.Data.IdxGrp.Idx[0] != mesh.Data.IdxGrp.Idx[1])
        {
          idxBin.AddRange(BitConverter.GetBytes((short)(mesh.Data.IdxGrp.Idx[0] + curVtxCount)));
        }
        else if (mesh.Data.IdxGrp.Idx[0] == mesh.Data.IdxGrp.Idx[1] && mesh.Data.IdxGrp.Idx[0] != mesh.Data.IdxGrp.Idx[2])
        {
          idxBin.AddRange(BitConverter.GetBytes((short)(mesh.Data.IdxGrp.Idx[0] + curVtxCount)));
        }
        else if (mesh.Data.IdxGrp.Idx[0] == mesh.Data.IdxGrp.Idx[1] && mesh.Data.IdxGrp.Idx[0] == mesh.Data.IdxGrp.Idx[2])
        {
          startIndex = 1;
        }
      }
      else if (curObjIdxCount != 0 && mesh.Data.IdxGrp.Idx[0] != mesh.Data.IdxGrp.Idx[1])
      {
        idxBin.AddRange(BitConverter.GetBytes((short)(mesh.Data.IdxGrp.Idx[0] + curVtxCount)));
        idxBin.AddRange(BitConverter.GetBytes((short)(mesh.Data.IdxGrp.Idx[0] + curVtxCount)));
      }

      if (mesh.Data.IdxGrp.Idx[mesh.Data.IdxGrp.Idx.Length - 1] == mesh.Data.IdxGrp.Idx[mesh.Data.IdxGrp.Idx.Length - 2])
      {
        endIndex--;
      }

      for (int i = startIndex; i < endIndex; i++)
      {
        idxBin.AddRange(BitConverter.GetBytes((short)(mesh.Data.IdxGrp.Idx[i] + curVtxCount)));
      }

      return idxBin;
    }

    private float CalcDistance(Point3D a, Point3D b)
    {
      float distance = (float)Math.Sqrt(Math.Pow(a.X - b.X, 2) + Math.Pow(a.Y - b.Y, 2) + Math.Pow(a.Z - b.Z, 2));
      return distance;
    }

    private float CalcDistance(Point3D a, double[] b)
    {
      float distance = (float)Math.Sqrt(Math.Pow(a.X - b[0], 2) + Math.Pow(a.Y - b[1], 2) + Math.Pow(a.Z - b[2], 2));
      return distance;
    }

    private void TransferNormals(MeshTables.MeshTable mesh, ObjectGroup grp, ObjectPart obj, int vtxGrp)
    {
      // 近接頂点の法線をコピー
      float fudge = Math.Abs(Single.Parse(tbDistance.Text));
      MatrixTransform3D objTransform = new MatrixTransform3D(tmcData.MtxGrp[grp.Node].Matrix);
      MatrixTransform3D objTransformInv = objTransform.Inverse as MatrixTransform3D;
      MatrixTransform3D meshTransform = new MatrixTransform3D(mesh.Data.Matrix);
      MatrixTransform3D meshTransformInv = meshTransform.Inverse as MatrixTransform3D;

      foreach (var meshVtx in mesh.Data.VtxGrp.Vtx)
      {
        Point3D transformedMeshVtxPos = meshTransform.Transform(new Point3D(meshVtx.X, meshVtx.Y, meshVtx.Z));

        for (int i = obj.VtxStartIndex; i < obj.VtxStartIndex + obj.VtxCount; i++)
        {
          Vertex vtx = tmcData.VtxGrp[vtxGrp].Vtx[i];
          Point3D transformedObjVtxPos = objTransform.Transform(new Point3D(vtx.X, vtx.Y, vtx.Z));

          float distance = CalcDistance(transformedMeshVtxPos, transformedObjVtxPos);
          if (distance < fudge)
          {
            Vector3D newN = objTransformInv.Transform(meshTransform.Transform(new Vector3D(vtx.N1, vtx.N2, vtx.N3)));
            meshVtx.N1 = (float)newN.X;
            meshVtx.N2 = (float)newN.Y;
            meshVtx.N3 = (float)newN.Z;

            var newVtxNrmBin = new List<byte>();
            newVtxNrmBin.AddRange(BitConverter.GetBytes(meshVtx.N1));
            newVtxNrmBin.AddRange(BitConverter.GetBytes(meshVtx.N2));
            newVtxNrmBin.AddRange(BitConverter.GetBytes(meshVtx.N3));
            if (meshVtx.N4 != null) newVtxNrmBin.AddRange(BitConverter.GetBytes((float)meshVtx.N4));

            Array.Copy(newVtxNrmBin.ToArray(), 0, mesh.Bin, meshVtx.Address + mesh.Data.VtxGrp.NormalOffset, newVtxNrmBin.Count);
            break;
          }
        }
      }
    }

    private int TransferNeckData(MeshTables.MeshTable mesh)
    {
      // 首の近接頂点の法線を調整
      int count = 0;
      float fudge = Math.Abs(Single.Parse(tbDistance.Text));
      MatrixTransform3D meshTransform = new MatrixTransform3D(mesh.Data.Matrix);
      MatrixTransform3D meshTransformInv = meshTransform.Inverse as MatrixTransform3D;

      foreach (var meshVtx in mesh.Data.VtxGrp.Vtx)
      {
        Point3D transformedPos = meshTransform.Transform(new Point3D(meshVtx.X, meshVtx.Y, meshVtx.Z));

        if (cmbChara.SelectedIndex == 0) continue;

        foreach (var neckVtx in neckData[cmbChara.SelectedValue.ToString()])
        {
          float distance = CalcDistance(transformedPos, neckVtx);
          if (distance < fudge)
          {
            count++;

            Point3D newP = meshTransformInv.Transform(new Point3D(neckVtx[0], neckVtx[1], neckVtx[2]));
            meshVtx.X = (float)newP.X;
            meshVtx.Y = (float)newP.Y;
            meshVtx.Z = (float)newP.Z;

            Vector3D newN = meshTransformInv.Transform(new Vector3D(neckVtx[3], neckVtx[4], neckVtx[5]));
            meshVtx.N1 = (float)newN.X;
            meshVtx.N2 = (float)newN.Y;
            meshVtx.N3 = (float)newN.Z;

            var neckVtxBin = new List<byte>();
            neckVtxBin.AddRange(BitConverter.GetBytes(meshVtx.X));
            neckVtxBin.AddRange(BitConverter.GetBytes(meshVtx.Y));
            neckVtxBin.AddRange(BitConverter.GetBytes(meshVtx.Z));
            if (meshVtx.W != null) neckVtxBin.AddRange(BitConverter.GetBytes((float)meshVtx.W));

            neckVtxBin.AddRange(BitConverter.GetBytes(meshVtx.N1));
            neckVtxBin.AddRange(BitConverter.GetBytes(meshVtx.N2));
            neckVtxBin.AddRange(BitConverter.GetBytes(meshVtx.N3));
            if (meshVtx.N4 != null) neckVtxBin.AddRange(BitConverter.GetBytes((float)meshVtx.N4));

            Array.Copy(neckVtxBin.ToArray(), 0, mesh.Bin, meshVtx.Address, neckVtxBin.Count);

            int offset = meshVtx.Address + mesh.Data.VtxGrp.BlendWeightOffset;
            if (meshVtx.Weights != null)
            {
              meshVtx.Weights[0] = (byte)neckVtx[10];
              meshVtx.Weights[1] = (byte)neckVtx[11];
              meshVtx.Weights[2] = (byte)neckVtx[12];
              meshVtx.Weights[3] = (byte)neckVtx[13];

              Array.Copy(meshVtx.Weights, 0, mesh.Bin, offset, meshVtx.Weights.Length);
            }
            else if (meshVtx.WeightsF != null)
            {
              meshVtx.WeightsF[0] = (float)neckVtx[6];
              meshVtx.WeightsF[1] = (float)neckVtx[7];
              meshVtx.WeightsF[2] = (float)neckVtx[8];
              meshVtx.WeightsF[3] = (float)neckVtx[9];

              var neckVtxWeightsBin = new List<byte>();
              for (int i = 0; i < 4; i++)
              {
                neckVtxWeightsBin.AddRange(BitConverter.GetBytes(meshVtx.WeightsF[i]));
              }
              Array.Copy(neckVtxWeightsBin.ToArray(), 0, mesh.Bin, offset, neckVtxWeightsBin.Count);
            }

            break;
          }
        }
      }
      return count;
    }

    private void SetOtherData(MeshTables.MeshTable mesh, Dictionary<int, List<byte>> partBn, int grpID, ObjectPart obj)
    {
      int objOffset = tmcData.ObjGrp[grpID].Offset + obj.Offset;

      // MtrColのコピー
      if (mesh.EnableMtrCol && mesh.MtrCol)
      {
        int offset = tmcData.ColGrp[obj.MtrColor].Offset;
        for (int i = 0; i < mesh.Data.MtrColor.Color.Count; i++)
        {
          partBn[4].RemoveRange(offset + (0x10 * i), 16);
          partBn[4].InsertRange(offset + (0x10 * i), BitConverter.GetBytes(mesh.Data.MtrColor.Color[i][0]));
          partBn[4].InsertRange(offset + (0x10 * i) + 0x04, BitConverter.GetBytes(mesh.Data.MtrColor.Color[i][1]));
          partBn[4].InsertRange(offset + (0x10 * i) + 0x08, BitConverter.GetBytes(mesh.Data.MtrColor.Color[i][2]));
          partBn[4].InsertRange(offset + (0x10 * i) + 0x0C, BitConverter.GetBytes(mesh.Data.MtrColor.Color[i][3]));
        }
      }
    }

    private MissingBlendIndexData CheckBlendIdx(MeshTables.MeshTable mesh, int grpID, int[] idxs)
    {
      // BlendIdx置換前処理
      string notFoundList = "";
      List<byte> missingBlendIdx = new List<byte>();
      List<int> missingNodeIdx = new List<int>();

      // 見つからない場合の置換準備
      string[] replaceNodes = new string[] { "MOT01_Head", "OPT_head_dummy", "OPT_dummy_head", "OPT_dummyhead" };
      int blendIdxReplace = Array.FindIndex(idxs, tempNode => tmcData.Node[tempNode].Name == "MOT00_Hips");
      string confirmText = txt["ContinueReplace0"];
      int count = 0;
      while (blendIdxReplace == -1 && count < replaceNodes.Length)
      {
        blendIdxReplace = Array.FindIndex(idxs, tempNode => tmcData.Node[tempNode].Name.ToLower() == replaceNodes[count].ToLower());
        if (blendIdxReplace != -1) confirmText = txt["ContinueReplace0"].Replace("MOT00_Hips", replaceNodes[count]);
        count++;
      }

      // それでも見つからない場合は最初のものに置換
      if (blendIdxReplace == -1)
      {
        blendIdxReplace = 0;
        if (idxs.Length > 0) confirmText = txt["ContinueReplace0"].Replace("MOT00_Hips", tmcData.Node[idxs[0]].Name);
      }

      foreach (var blend in mesh.Data.BlendIdx)
      {
        bool missing = true;
        for (int i = 0; i < idxs.Length; i++)
        {
          if (
              tmcData.Node[idxs[i]].Name == blend.Value.Name ||
              (tmcData.Node[idxs[i]].Name == "MOT11_RightHand" && blend.Value.Name == "OPT_Hand_Right_Root") ||
              (tmcData.Node[idxs[i]].Name == "OPT_Hand_Right_Root" && blend.Value.Name == "MOT11_RightHand") ||
              (tmcData.Node[idxs[i]].Name == "MOT05_LeftHand" && blend.Value.Name == "OPT_Hand_Left_Root") ||
              (tmcData.Node[idxs[i]].Name == "OPT_Hand_Left_Root" && blend.Value.Name == "MOT05_LeftHand")
            )
          {
            blend.Value.NewIdx = i;
            missing = false;
            break;
          }
        }
        if (missing)
        {
          int idx = Array.FindIndex(tmcData.Node.ToArray(), tempNode => tempNode.Name == blend.Value.Name);

          if (idx != -1)
          {
            missingBlendIdx.Add(blend.Key);
            missingNodeIdx.Add(idx);
          }
          else
          {
            notFoundList += "\r\n" + blend.Key.ToString("X2") + " / " + blend.Value.Name;
            blend.Value.NewIdx = blendIdxReplace;
          }
        }
      }

      var missings = new MissingBlendIndexData();
      missings.ConfirmText = confirmText;
      missings.NotFoundList = notFoundList;
      missings.BlendIdx.AddRange(missingBlendIdx);
      missings.NodeIdx.AddRange(missingNodeIdx);

      return missings;
    }

    private void ReplaceBlendIdx(MeshTables.MeshTable mesh, List<int> Idx, List<byte> missingBlendIdx, List<int> missingNodeIdx)
    {
      for (int i = 0; i < missingBlendIdx.Count; i++)
      {
        mesh.Data.BlendIdx[missingBlendIdx[i]].NewIdx = Idx.Count;
        Idx.Add(missingNodeIdx[i]);
      }

      // BlendIdx置換
      for (int i = 0; i < mesh.Data.VtxCount; i++)
      {
        var indices = new byte[4];
        dynamic weights = mesh.Data.VtxGrp.Vtx[i].Weights;
        if (mesh.Data.VtxGrp.BlendWeightType == 3) weights = mesh.Data.VtxGrp.Vtx[i].WeightsF;
        for (int j = 0; j < 4; j++)
        {
          if (!mesh.Data.BlendIdx.ContainsKey(mesh.Data.VtxGrp.Vtx[i].BlendIdx[j]))
          {
            Console.WriteLine(mesh.Data.VtxGrp.Vtx[i].BlendIdx[j]);
          }

          //if (weights[j] == 0 && mesh.Data.VtxGrp.Vtx[i].BlendIdx[j] == 0)
          if (weights[j] == 0)
          {
            indices[j] = 0;
          }
          else if (mesh.Data.BlendIdx[mesh.Data.VtxGrp.Vtx[i].BlendIdx[j]].NewIdx != -1)
          {
            indices[j] = (byte)mesh.Data.BlendIdx[mesh.Data.VtxGrp.Vtx[i].BlendIdx[j]].NewIdx;
          }
          else
          {
            indices[j] = mesh.Data.VtxGrp.Vtx[i].BlendIdx[j];
          }
        }
        HashSet<byte> indicesSet = new HashSet<byte>(indices);

        if (indices.Length == indicesSet.Count)
        {
          Array.Copy(indices, 0, mesh.Bin, mesh.Data.VtxGrp.Vtx[i].Address + mesh.Data.VtxGrp.BlendIndicesOffset, 4);
        }
        else
        {
          byte[] newIndices = new byte[4];
          dynamic[] newWeights = new dynamic[4] { 0, 0, 0, 0 };

          int count = 0;
          foreach (var index in indicesSet)
          {
            newIndices[count] = index;
            for (byte j = 0; j < 4; j++)
            {
              if (index == indices[j])
              {
                newWeights[count] += weights[j];
              }
            }
            if (newWeights[count] > 255) newWeights[count] = 255;
            count++;
          }

          if (mesh.Data.VtxGrp.BlendWeightType == 3)
          {
            var newWeightsBin = new List<byte>();
            for (int j = 0; j < 4; j++)
            {
              newWeightsBin.AddRange(BitConverter.GetBytes((float)newWeights[j]));
            }
            Array.Copy(newWeightsBin.ToArray(), 0, mesh.Bin, mesh.Data.VtxGrp.Vtx[i].Address + mesh.Data.VtxGrp.BlendWeightOffset, 16);
          }
          else
          {
            byte[] newWeightsByte = new byte[4];
            for (int j = 0; j < 4; j++)
            {
              newWeightsByte[j] = (byte)newWeights[j];
            }
            Array.Copy(newWeightsByte, 0, mesh.Bin, mesh.Data.VtxGrp.Vtx[i].Address + mesh.Data.VtxGrp.BlendWeightOffset, 4);
          }

          Array.Copy(newIndices, 0, mesh.Bin, mesh.Data.VtxGrp.Vtx[i].Address + mesh.Data.VtxGrp.BlendIndicesOffset, 4);
        }
      }
    }

    private List<byte> buildNodeLay(List<List<int>> blendIdxs)
    {
      var nodeLayBin = BuildHeaderBaseBin("NodeLay");
      nodeLayBin.AddRange(new byte[0x10]);
      nodeLayBin[0x30] = 1;
      nodeLayBin[0x32] = 2;

      List<List<byte>> nodeObjBins = new List<List<byte>>();

      foreach (var node in tmcData.Node)
      {
        var nodeObjBin = BuildHeaderBaseBin("NodeObj");
        nodeObjBin.AddRange(BitConverter.GetBytes(0));
        nodeObjBin.AddRange(BitConverter.GetBytes(node.Master));
        nodeObjBin.AddRange(BitConverter.GetBytes(node.Index));
        nodeObjBin.AddRange(BitConverter.GetBytes(0));
        nodeObjBin.AddRange(Encoding.ASCII.GetBytes(node.Name));
        nodeObjBin.AddRange(new byte[16 - (nodeObjBin.Count % 16)]);

        if (node.ObjIndex != -1)
        {
          ReplaceByteList(nodeObjBin, BitConverter.GetBytes(nodeObjBin.Count), 0x20);
          nodeObjBin[0x14] = 1;
          nodeObjBin[0x18] = 1;
          nodeObjBin.AddRange(BitConverter.GetBytes(nodeObjBin.Count + 0x10));
          nodeObjBin.AddRange(new byte[12]);

          nodeObjBin.AddRange(BitConverter.GetBytes(node.ObjIndex));
          nodeObjBin.AddRange(BitConverter.GetBytes(blendIdxs[node.Index].Count));
          nodeObjBin.AddRange(BitConverter.GetBytes(node.Index));
          nodeObjBin.AddRange(BitConverter.GetBytes(0));

          List<float> m = Matrix3DToList(node.Matrix);
          foreach (float f in m)
          {
            nodeObjBin.AddRange(BitConverter.GetBytes(f));
          }

          foreach (var idx in blendIdxs[node.Index])
          {
            nodeObjBin.AddRange(BitConverter.GetBytes(idx));
          }

          if (nodeObjBin.Count % 16 > 0) nodeObjBin.AddRange(new byte[16 - (nodeObjBin.Count % 16)]);
        }

        ReplaceByteList(nodeObjBin, BitConverter.GetBytes(nodeObjBin.Count), 0x10);

        nodeObjBins.Add(nodeObjBin);
      }
      BuildBin(nodeLayBin, nodeObjBins, null, false, false);

      return nodeLayBin;
    }

    private void BuildTmcInfo()
    {
      tmcInfo += txt["TmcData"];

      int grpNameMax = 0;
      foreach (var grp in tmcData.ObjGrp)
      {
        foreach (var obj in grp.Obj)
        {
          string type = "";
          if (obj.MaterialType == "Skin")
            type = " (Skin)";
          else if (obj.MaterialType == "WetTex")
            type = " (Wet)";

          if (grpNameMax < grp.Name.Length + obj.ID.ToString("x").Length + type.Length + 1)
          {
            grpNameMax = grp.Name.Length + obj.ID.ToString("x").Length + type.Length + 1;
          }
        }
      }

      foreach (var grp in tmcData.ObjGrp)
      {
        foreach (var obj in grp.Obj)
        {
          string type = "";
          if (obj.MaterialType == "Skin")
            type = " (Skin)";
          else if (obj.MaterialType == "WetTex")
            type = " (Wet)";

          tmcInfo += String.Format("\r\n{0, -" + grpNameMax + "}", grp.Name + "_" + obj.ID.ToString("x") + type);
          tmcInfo += String.Format(" / {0} {1, 5}", txt["VertexCount"], obj.VtxCount);
          tmcInfo += String.Format(" / MtrCol {0, 2}", obj.MtrColor);
          tmcInfo += String.Format(" / {0} - {1} : 0x{2, 0:X2}", txt["VertexData"], txt["Size"], tmcData.VtxGrp[obj.VtxGrpIndex].DataSize);
          tmcInfo += String.Format(" - {0} :{1}", txt["Contents"], BuildDeclInfo(tmcData.VtxGrp[obj.VtxGrpIndex]));
        }
      }
    }

    public static string BuildDeclInfo(VertexGroup grp)
    {
      string text = "";

      if (grp.Position)
      {
        text += " Position";
        text += "(" + GetDeclTypeText(grp.PositionType) + ")";
      }

      if (grp.Normal)
      {
        text += " Normal";
        text += "(" + GetDeclTypeText(grp.NormalType) + ")";
      }

      if (grp.BlendWeight)
      {
        text += " BlendWeight";
        text += "(" + GetDeclTypeText(grp.BlendWeightType) + ")";
      }

      if (grp.BlendIndices)
      {
        text += " BlendIndices";
        text += "(" + GetDeclTypeText(grp.BlendIndicesType) + ")";
      }

      if (grp.Color)
      {
        text += " Color";
        text += "(" + GetDeclTypeText(grp.ColorType) + ")";
      }

      if (grp.Tangent)
      {
        text += " Tangent";
        text += "(" + GetDeclTypeText(grp.TangentType) + ")";
      }

      if (grp.UVCount > 0)
      {
        text += " UV ";
        text += grp.UVCount;
      }

      return text;
    }

    private static string GetDeclTypeText(int num)
    {
      switch (num)
      {
        case 2:
          return "Float3";
        case 3:
          return "Float4";
        case 5:
          return "Byte4";
        case 13:
          return "Dec4";
        default:
          return "Other";
      }
    }

    private MeshData ParseMeshData(byte[] bin, HeaderData h)
    {
      MeshData meshData = new MeshData();


      // オブジェクトデータ読み込み
      HeaderData geoH = new HeaderData(h.Offsets[0], bin);
      meshData.Transparent1 = BitConverter.ToInt32(bin, geoH.Start + geoH.Offsets[1] + 0x40);
      meshData.Transparent2 = BitConverter.ToInt32(bin, geoH.Start + geoH.Offsets[1] + 0x48);
      meshData.DoubleSided = BitConverter.ToInt32(bin, geoH.Start + geoH.Offsets[1] + 0x6C);
      meshData.IdxCount = BitConverter.ToInt32(bin, geoH.Start + geoH.Offsets[1] + 0x74);
      meshData.VtxCount = BitConverter.ToUInt16(bin, geoH.Start + geoH.Offsets[1] + 0x7C);


      // 頂点データ読み込み
      var newVtxGrp = new VertexGroup(h.Offsets[2], 0, h.Sizes[2]);
      newVtxGrp.DataSize = BitConverter.ToInt32(bin, geoH.Start + geoH.Offsets[0] + 0x04);
      int vtxDataLayersCount = BitConverter.ToInt32(bin, geoH.Start + geoH.Offsets[0] + 0x08);
      TmcData.ParseVertexDataLayers(bin, newVtxGrp, geoH.Start + geoH.Offsets[0] + 0x10, vtxDataLayersCount);
      TmcData.ParseVertexGrp(bin, newVtxGrp, 0);
      meshData.VtxGrp = newVtxGrp;


      // 面データ読み込み
      var newIdxGrp = new IndexGroup(h.Offsets[3], 0, h.Sizes[3], bin);
      meshData.IdxGrp = newIdxGrp;
      meshData.IdxGrp.AddIdx(meshData.IdxCount, bin);


      // マテリアルカラー読み込み
      if (h.Offsets[4] != 0)
      {
        var newMtrCol = new MtrColorGroup(h.Offsets[4], 0, bin);
        meshData.MtrColor = newMtrCol;
      }


      // Matrixデータ読み込み
      if (h.Offsets[9] != 0)
      {
        double[] m = new double[16];
        for (int i = 0; i < 16; i++)
        {
          m[i] = BitConverter.ToSingle(bin, h.Offsets[9] + (0x04 * i));
        }
        meshData.Matrix = new Matrix3D(m[0], m[1], m[2], m[3], m[4], m[5], m[6], m[7], m[8], m[9], m[10], m[11], m[12], m[13], m[14], m[15]);
      }


      // ブレンドインデックス読み込み
      HeaderData blendIdxH = new HeaderData(h.Offsets[15], bin);

      for (int i = 0; i < blendIdxH.Count1; i++)
      {
        var newBlendIdx = new BlendIndex();
        byte idx = bin[blendIdxH.Start + blendIdxH.Offsets[i]];
        newBlendIdx.Name = Encoding.ASCII.GetString(bin, blendIdxH.Start + blendIdxH.Offsets[i] + 0x10, bin[blendIdxH.Start + blendIdxH.Offsets[i] + 0x04]);
        meshData.BlendIdx[idx] = newBlendIdx;
      }

      return meshData;
    }

    private void SetCharaComboBox()
    {
      var CharaNames = new List<string>();
      foreach(var chara in CharaList)
      {
        CharaNames.Add(txt[chara]);
      }
      if (langType != "Jpn") CharaNames.Sort();

      cmbChara.Items.Add(txt["DisableNeckOption"]);

      foreach (var name in CharaNames)
      {
        cmbChara.Items.Add(name);
      }
      cmbChara.SelectedIndex = 0;
    }



    #region Drag and Drop

    public static readonly DependencyProperty DraggedItemProperty = DependencyProperty.Register("DraggedItem", typeof(MeshTables.MeshTable), typeof(MainWindow));

    public MeshTables.MeshTable DraggedItem
    {
      get { return (MeshTables.MeshTable)GetValue(DraggedItemProperty); }
      set { SetValue(DraggedItemProperty, value); }
    }

    public bool IsEditing { get; set; }

    public bool IsDragging { get; set; }


    private void OnBeginEdit(object sender, DataGridBeginningEditEventArgs e)
    {
      IsEditing = true;
      if (IsDragging) ResetDragDrop();
    }

    private void OnEndEdit(object sender, DataGridCellEditEndingEventArgs e)
    {
      IsEditing = false;
    }


    private void OnMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      if (IsEditing) return;

      var row = UIHelpers.TryFindFromPoint<DataGridRow>((UIElement)sender, e.GetPosition(dgMesh));
      if (row == null || row.IsEditing) return;
      IsDragging = true;
      DraggedItem = (MeshTables.MeshTable)row.Item;
      if (Keyboard.Modifiers == ModifierKeys.Shift || Keyboard.Modifiers == ModifierKeys.Control)
      {
        IsDragging = false;
      }
    }

    private void OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
      if (!IsDragging || IsEditing || dgMesh.SelectedItems.Count > 1)
      {
        ResetDragDrop();
        return;
      }

      var targetItem = (MeshTables.MeshTable)dgMesh.SelectedItem;
      if (!ReferenceEquals(DraggedItem, targetItem))
      {
        meshTables.Mesh.Remove(DraggedItem);
        if (targetItem != null)
        {
          var targetIndex = meshTables.Mesh.IndexOf(targetItem);
          meshTables.Mesh.Insert(targetIndex, DraggedItem);
        }
        else
        {
          meshTables.Mesh.Add(DraggedItem);
        }
        dgMesh.SelectedItem = DraggedItem;
      }
      ResetDragDrop();
    }
    
    private void ResetDragDrop()
    {
      IsDragging = false;
      popup1.IsOpen = false;
      dgMesh.IsReadOnly = false;
      dgMesh.SelectionMode = DataGridSelectionMode.Extended;

      if (meshTables == null) return;

      foreach (var mesh in meshTables.Mesh)
      {
        mesh.IsDragging = false;
      }
    }
    
    private void OnMouseMove(object sender, MouseEventArgs e)
    {
      if (!IsDragging || e.LeftButton != MouseButtonState.Pressed || dgMesh_ContextMenuOpened) return;

      if (!popup1.IsOpen)
      {
        dgMesh.IsReadOnly = true;
        dgMesh.SelectionMode = DataGridSelectionMode.Single;

        popup1.IsOpen = true;
      }
      
      Size popupSize = new Size(popup1.ActualWidth, popup1.ActualHeight);
      popup1.PlacementRectangle = new Rect(e.GetPosition(this), popupSize);

      Point position = e.GetPosition(dgMesh);
      var row = UIHelpers.TryFindFromPoint<DataGridRow>(dgMesh, position);
      if (row != null)
      {
        dgMesh.SelectedItem = row.Item;
        var item = dgMesh.SelectedItem as MeshTables.MeshTable;
        item.IsDragging = true;
      }
      else
      {
        dgMesh.SelectedItem = null;
      }
    }
    
    private void OnMouseRightButtonUp(object sender, MouseButtonEventArgs e)
    {
      if (!IsDragging) return;

      ResetDragDrop();
    }

    private void cancelDragDropCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      if (!IsDragging) return;

      ResetDragDrop();
    }

    private void ComboBox_DropDownOpened(object sender, EventArgs e)
    {
      IsEditing = true;
      if (IsDragging) ResetDragDrop();
    }

    private void ComboBox_DropDownClosed(object sender, EventArgs e)
    {
      IsEditing = false;
    }

    #endregion

    private void CheckUpdated()
    {
      try
      {
        if (tmcData == null || !System.IO.File.Exists(tmcData.Path)) return;

        var lastWriteTimeTmc = System.IO.File.GetLastWriteTime(tmcData.Path);

        bool updatedTmc = false;
        bool updatedMesh = false;
        string updateFiles = "";

        if (tmcData.WriteTime.CompareTo(lastWriteTimeTmc) != 0)
        {
          updatedTmc = true;
          updateFiles += "\r\n" + tmcData.Path;
        }

        if (meshTables != null)
        {
          foreach (var mesh in meshTables.Mesh)
          {
            if (mesh.FilePath == null || !System.IO.File.Exists(mesh.FilePath)) continue;

            var lastWriteTime = System.IO.File.GetLastWriteTime(mesh.FilePath);

            if (mesh.Data.WriteTime.CompareTo(lastWriteTime) != 0)
            {
              updatedMesh = true;
              updateFiles += "\r\n" + mesh.FilePath;
            }
          }
        }

        if (!updatedTmc && !updatedMesh) return;

        if (MessageWindow.Show(this, txt["ConfirmFileUpdated"] + "\r\n" + updateFiles, txt["Confirm"], txt["Yes"], txt["No"]) == MessageWindow.Result.OK)
        {
          if (updatedTmc)
          {
            ReopenFile();
          }
          else if (updatedMesh)
          {
            ReopenMeshFiles();
          }
        }
        else
        {
          if (updatedTmc) tmcData.WriteTime = lastWriteTimeTmc;
          if (updatedMesh)
          {
            foreach (var mesh in meshTables.Mesh)
            {
              mesh.Data.WriteTime = System.IO.File.GetLastWriteTime(mesh.FilePath);
            }
          }
        }
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }
    }
  }
}
