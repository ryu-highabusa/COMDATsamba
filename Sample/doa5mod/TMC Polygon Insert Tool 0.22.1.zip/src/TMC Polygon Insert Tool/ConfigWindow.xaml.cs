﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Input;
using System.ComponentModel;

namespace TMC_Tool
{
  /// <summary>
  /// ConfigWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class ConfigWindow : Window
  {
    private static Dictionary<string, string> txt = new Dictionary<string, string>();

    private static ConfigWindow dlg;

    private static bool modified;

    private static bool IsActivated = false;

    public ConfigWindow()
    {
      InitializeComponent();

      this.MouseLeftButtonDown += (sender, e) => this.DragMove();
      this.ShowInTaskbar = false;

      txt = MainWindow.txt;

      title.Text = txt["Config"];
      cbCheckConvertDifference.Content = txt["cbCheckConvertDifference"];
      cbSetDeleteCurrent.Content = txt["cbSetDeleteCurrent"];
      cbSaveConfigs.Content = txt["cbSaveConfigs"];
    }

    private void okCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (modified)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void okCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      MainWindow.config.CheckConvertDifference = (bool)cbCheckConvertDifference.IsChecked;
      MainWindow.config.SetDeleteCurrent = (bool)cbSetDeleteCurrent.IsChecked;

      MainWindow.config.SaveConfigsEnabled = (bool)cbSaveConfigs.IsChecked;

      if (cbSaveConfigs.IsChecked == true)
      {
        MainWindow.config.SaveConfigs();
      }

      this.Close();
    }

    private void cancelCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      this.Close();
    }

    private void CheckBox_CheckChanged(object sender, RoutedEventArgs e)
    {
      modified = true;
    }

    public static void Show(Window owner)
    {
      dlg = new ConfigWindow();
      dlg.Owner = owner;
      dlg.Owner.IsEnabled = false;

      dlg.cbCheckConvertDifference.IsChecked = MainWindow.config.CheckConvertDifference;
      dlg.cbSetDeleteCurrent.IsChecked = MainWindow.config.SetDeleteCurrent;

      dlg.cbSaveConfigs.IsChecked = MainWindow.config.SaveConfigsEnabled;

      modified = false;

      dlg.ShowDialog();

      dlg.Owner.IsEnabled = true;
      dlg.Owner.Focus();
    }



    private void Window_Activated(object sender, EventArgs e)
    {
      if (!IsActivated) IsActivated = true;
    }

    private void Window_Closing(object sender, CancelEventArgs e)
    {
      e.Cancel = true;
      IsActivated = false;
      this.Hide();
      if (this.Owner != null) this.Owner.Activate();
    }
  }
}
