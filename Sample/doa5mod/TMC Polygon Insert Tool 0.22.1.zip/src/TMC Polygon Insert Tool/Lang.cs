﻿using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows;

namespace TMC_Tool
{
  public partial class MainWindow : Window
  {

    private void changeLanguage()
    {
      Dictionary<string, string> language = new Dictionary<string, string>();
      txt["btnOpen"] = "開く";
      txt["OK"] = "OK";
      txt["Cancel"] = "キャンセル";
      txt["Yes"] = "はい";
      txt["No"] = "いいえ";
      txt["Info"] = "情報";
      txt["Error"] = "エラー";
      txt["Caution"] = "注意";
      txt["Confirm"] = "確認";
      txt["Message"] = "メッセージ";
      txt["textStatus"] = "ファイルを開いて下さい";
      txt["ExitWithoutSave"] = "変更後保存されていません。このまま終了しますか？";
      txt["Exit"] = "終了する";
      txt["UnsupportedArea"] = "";
      txt["Overwrite"] = "ファイルを上書きしますか？";
      txt["OverwriteYes"] = "上書きする";
      txt["Saved"] = "保存しました";
      txt["FailedToCreateBackup"] = "バックアップの作成に失敗したため保存出来ませんでした";
      txt["UnsupportedFile"] = "対応しているファイルではありません";
      txt["FailedToReopen"] = "再読込に失敗しました";
      txt["ConfirmOpenFile"] = "このファイルを開きますか？";
      txt["ConfirmFileUpdated"] = "下記ファイルが更新されました。開きなおしますか？";

      txt["NotReopen"] = "下記ファイルは開けなかったため従来のデータを使用します";
      txt["Keep"] = "維持";
      txt["Delete"] = "削除";
      txt["Remove"] = "削除";
      txt["InsertDummy"] = "ダミーメッシュを挿入";
      txt["DummyMesh"] = "ダミーメッシュ";

      txt["UnsetDest"] = "チェックが入っているもので挿入先オブジェクトが設定されていないものがあります。\r\n無視して続行しますか？";
      txt["BlendIdxOverLimit"] = "このメッシュデータを挿入するとBlendIndex数が上限を超える為に挿入できません。\r\n残りのメッシュデータの挿入を続行しますか？";
      txt["BlendIdxNotFound"] = "次のBlendIndexが挿入先のTMCファイルに存在しません。";
      txt["ContinueReplace0"] = "見つからないBlendIndexはMOT00_Hipsのものに置換して続行しますか？";
      txt["ReplaceAndContinue"] = "置換して続行";
      txt["BlendAllDelete"] = "挿入先はボーンウェイトを保持できない為、全てのボーンウェイトは破棄されます。続行しますか？";
      txt["Continue"] = "続行";
      txt["Skip"] = "スキップ";

      txt["VtxLimitOver"] = "1つの頂点グループ内での頂点数の上限（65536個）を超えた為、処理を中止します";
      txt["InsertCanceled"] = "挿入するメッシュデータが無い為、処理を中止しました";
      txt["TransferNeckVtxCount"] = "調整した首の頂点数";

      txt["DisableNeckOption"] = "首の頂点調整無効";

      txt["TmcData"] = "TMCデータ";
      txt["VertexCount"] = "頂点数";
      txt["VertexData"] = "頂点データ";
      txt["Size"] = "サイズ";
      txt["Contents"] = "内容";

      txt["Config"] = "設定";
      txt["cbCheckConvertDifference"] = "起動時に「データ内容が異なるオブジェクトへの挿入」にチェックを入れる";
      txt["cbSetDeleteCurrent"] = "メッシュデータ追加時に「既存」の項目を「削除」に設定する";
      txt["cbSaveConfigs"] = "次回起動時以降もこの設定を使用する";

      txt["AYANE"] = "あやね";
      txt["HELENA"] = "エレナ";
      txt["KASUMI"] = "かすみ";
      txt["CHRISTIE"] = "クリスティ";
      txt["KOKORO"] = "こころ";
      txt["SARAH"] = "サラ";
      txt["TINA"] = "ティナ";
      txt["NYOTENGU"] = "女天狗";
      txt["PAI"] = "パイ・チェン";
      txt["HITOMI"] = "ヒトミ";
      txt["PHASE4"] = "PHASE-4";
      txt["HONOKA"] = "ほのか";
      txt["LISA"] = "リサ";
      txt["RACHEL"] = "レイチェル";
      txt["LEIFANG"] = "レイファン";
      txt["MARIE"] = "マリー・ローズ";
      txt["MILA"] = "ミラ";
      txt["MOMIJI"] = "紅葉";
      txt["NAOTORA"] = "井伊直虎";
      txt["MAI"] = "不知火舞";



      string filePath = System.AppDomain.CurrentDomain.BaseDirectory + @"\Language.dat";
      if (!File.Exists(filePath))
      {
        return;
      }

      using (var sr = new StreamReader(filePath))
      {
        while (!sr.EndOfStream)
        {
          string[] inLine = sr.ReadLine().Split('\t');
          if (inLine.Length == 0)
          {
            continue;
          }
          else if (inLine[0] == "Type")
          {
            langType = inLine[2].Trim();
          }
          else if (inLine[0] == langType)
          {
            language[inLine[1].Trim()] = inLine[2].Trim();
          }
        }

        List<string> keys = new List<string>();
        foreach (var key in txt.Keys)
        {
          keys.Add(key);
        }
        foreach (string key in keys)
        {
          if (language.ContainsKey(key)) txt[key] = Regex.Unescape(language[key]);
        }

        if (language.ContainsKey("btnOpen")) btnOpen.Content = language["btnOpen"];
        if (language.ContainsKey("btnOpenMesh"))
        {
          btnOpenMesh.Content = language["btnOpenMesh"];
          menuOpenMesh.Header = language["btnOpenMesh"];
        }
        if (language.ContainsKey("btnSave"))
        {
          btnSave.Content = language["btnSave"];
          cmdSave.Header = language["btnSave"];
        }
        if (language.ContainsKey("SaveWithBackup")) cmdSaveWithBackup.Header = language["SaveWithBackup"];
        if (language.ContainsKey("btnSaveAs")) btnSaveAs.Content = language["btnSaveAs"];
        if (language.ContainsKey("Config")) btnConfig.Content = language["Config"];
        if (language.ContainsKey("textStatus")) textStatus.Path = language["textStatus"];
        if (language.ContainsKey("cbKeepData")) cbKeepData.Content = language["cbKeepData"];
        if (language.ContainsKey("menuOpenFolder")) menuOpenFolder.Header = language["menuOpenFolder"];

        if (language.ContainsKey("cbConvertDifference")) cbConvertDifference.Content = language["cbConvertDifference"];
        if (language.ContainsKey("labelDistance")) labelDistance.Content = language["labelDistance"];
        if (language.ContainsKey("dgcFileName")) dgcFileName.Header = language["dgcFileName"];
        if (language.ContainsKey("dgcDataSize")) dgcDataSize.Header = language["dgcDataSize"];
        if (language.ContainsKey("dgcDest")) dgcDest.Header = language["dgcDest"];
        if (language.ContainsKey("dgcCurrent")) dgcCurrent.Header = language["dgcCurrent"];
        if (language.ContainsKey("dgcNormal")) dgcNormal.Header = language["dgcNormal"];
        if (language.ContainsKey("dgcNeck")) dgcNeck.Header = language["dgcNeck"];

        if (language.ContainsKey("noteOnlyNeckAndNrm")) panelDistance.ToolTip = language["noteOnlyNeckAndNrm"];
        if (language.ContainsKey("noteOnlyNeck")) cmbChara.ToolTip = language["noteOnlyNeck"];
      }
    }

  }
}
