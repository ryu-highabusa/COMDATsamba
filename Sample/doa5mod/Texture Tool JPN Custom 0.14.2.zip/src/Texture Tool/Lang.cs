﻿using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows;

namespace Texture_Tool
{
  public partial class MainWindow : Window
  {

    private void changeLanguage()
    {
      Dictionary<string, string> language = new Dictionary<string, string>();
      txt["OK"] = "OK";
      txt["Cancel"] = "キャンセル";
      txt["Yes"] = "はい";
      txt["No"] = "いいえ";
      txt["Info"] = "情報";
      txt["Error"] = "エラー";
      txt["Caution"] = "注意";
      txt["Confirm"] = "確認";
      txt["Message"] = "メッセージ";
      txt["textStatus"] = "ファイルを開いて下さい";
      txt["ExitWithoutSave"] = "変更後保存されていません。このまま終了しますか？";
      txt["Exit"] = "終了する";

      txt["Saved"] = "保存しました";
      txt["Extracted"] = "書き出しました";
      txt["UnsupportedFile"] = "対応しているファイルではありません";
      txt["FailedToReopen"] = "再読込に失敗しました";
      txt["ConfirmOpenFile"] = "このファイルを開きますか？";
      txt["ConfirmOverwrite"] = "ファイルを上書きしますか？";
      txt["ConfirmFileUpdated"] = "下記ファイルが更新されました。開きなおしますか？";
      txt["ConfirmPasteDifferent"] = "コピーしている数と選択している数が違います。\r\n数が多い分は無視されますが、このまま貼り付けますか？";
      txt["ConfirmOpenMany"] = "個のファイルを開こうとしています。このまま開きますか？";

      txt["OverwriteYes"] = "上書きする";
      txt["AlreadyExists"] = "同じ名前のファイルが既にあります。別名で保存しますか？";
      txt["Open"] = "開く";
      txt["SaveAs"] = "別名で保存する";
      txt["NotFound"] = "ファイルが見つかりません";
      txt["TexNotFound"] = "テクスチャファイルが含まれていません";
      txt["NotExtracted"] = "書き出すファイルがありませんでした";
      txt["FileOpeningSuspended"] = "ファイルの読み込みは中止されました";

      txt["Swap"] = "差し替え";
      txt["Extract"] = "書き出し";
      txt["SaveAsPng"] = "表示状態をPNGで保存";
      txt["Add"] = "追加...";
      txt["Delete"] = "削除";
      txt["Copy"] = "コピー";
      txt["Paste"] = "貼り付け";
      txt["Clear"] = "空にする";
      txt["RevertTex"] = "元に戻す";

      txt["MoveToTMCL"] = "TMCからTMCLへ全て移動";
      txt["MoveToHL"] = "--Hから--HLへ全て移動";

      txt["Option"] = "設定";
      txt["FullScale"] = "原寸で表示";
      txt["FixedWindowSize"] = "ウィンドウサイズを固定";
      txt["UsePalette"] = "カラーパレットを使用（抽出時には適用されません）";

      txt["AddDestination"] = "追加先";
      txt["AddCount"] = "追加数";
      txt["AddContent"] = "内容";
      txt["Top"] = "最初";
      txt["Bottom"] = "最後";
      txt["OverID"] = "指定IDの上";
      txt["UnderID"] = "指定IDの下";
      txt["AddNew"] = "新規";
      txt["AddFile"] = "ファイル";


      string filePath = System.AppDomain.CurrentDomain.BaseDirectory + "Language.dat";
      if (!File.Exists(filePath))
      {
        return;
      }

      using (var sr = new StreamReader(filePath))
      {
        while (!sr.EndOfStream)
        {
          string[] inLine = sr.ReadLine().Split('\t');
          if (inLine.Length == 0)
          {
            continue;
          }
          else if (inLine[0] == "Type")
          {
            langType = inLine[2].Trim();
          }
          else if (inLine[0] == langType)
          {
            language[inLine[1].Trim()] = inLine[2];
          }
        }

        List<string> keys = new List<string>();
        foreach (var key in txt.Keys)
        {
          keys.Add(key);
        }
        foreach (string key in keys)
        {
          if (language.ContainsKey(key)) txt[key] = Regex.Unescape(language[key]);
        }

        if (language.ContainsKey("Open"))
        {
          btnOpen.Content = language["Open"];
          cmdOpen.Header = language["Open"];
        }
        if (language.ContainsKey("Revert")) cmdRevert.Header = language["Revert"];
        if (language.ContainsKey("Cancel")) btnCancel.Content = language["Cancel"];
        if (language.ContainsKey("Save")) btnSave.Content = language["Save"];
        if (language.ContainsKey("SaveAs")) btnSaveAs.Content = language["SaveAs"];
        if (language.ContainsKey("Other")) btnOther.Content = language["Other"];
        if (language.ContainsKey("ExtractAll")) menuExtractAll.Header = language["ExtractAll"] + "...";
        if (language.ContainsKey("ExtractAllFolder")) menuExtractAllFolder.Header = language["ExtractAllFolder"] + "...";
        if (language.ContainsKey("ExtFolder")) labelExtFolder.Content = language["ExtFolder"];
        if (language.ContainsKey("Preview")) cbPreview.Content = language["Preview"];

        if (language.ContainsKey("Type")) dgcType.Header = language["Type"];
        if (language.ContainsKey("Width")) dgcW.Header = language["Width"];
        if (language.ContainsKey("Height")) dgcH.Header = language["Height"];
        if (language.ContainsKey("Size")) dgcSize.Header = language["Size"];
      }
    }

  }
}
