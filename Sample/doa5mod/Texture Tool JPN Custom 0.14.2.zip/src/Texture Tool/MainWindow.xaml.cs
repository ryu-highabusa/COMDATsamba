﻿using System;
using System.IO;
using System.Globalization;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows.Input;
using System.Windows.Media;
using Microsoft.WindowsAPICodePack.Dialogs;
using Message;
using Hardcodet.Wpf.Util;

namespace Texture_Tool
{
  /// <summary>
  /// MainWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class MainWindow : Window
  {
    private static ContainerData containerData;

    private static TexturesTable texTable;

    static byte[] bn;
    static byte[] bnL;

    private static string containerPath = "";
    private static string ddsPath = "";
    private static string extractPath = "";
    private static string extractBasePath = "";

    private static readonly string[] SupportedFormats = new string[] { "TMC", "texch", "dlicon", "SCENE", "sprpack" };
    public static readonly List<string> SupportedFiles = new List<string> { ".TMC", ".--H", ".--P", ".SCN", ".SPR" };
    public static readonly List<string> AssociatedFiles = new List<string> { "TMCL", "--HL", "", "TTGL", "LTF" };

    private static List<TexturesTable.TextureData> selectedTextures;
    private static List<int> selectedTextureIndices;
    private static object clipboardData;

    ContextMenu menuTextures = new ContextMenu();
    MenuItem menuItemSwap = new MenuItem();
    MenuItem menuItemExtract = new MenuItem();
    MenuItem menuItemSaveAsPng = new MenuItem();
    MenuItem menuItemAdd = new MenuItem();
    MenuItem menuItemDelete = new MenuItem();
    MenuItem menuItemCopy = new MenuItem();
    MenuItem menuItemPaste = new MenuItem();
    MenuItem menuItemEmpty = new MenuItem();
    MenuItem menuItemCancel = new MenuItem();

    private static Brush alertBg;

    public static Brush textBrush;
    public static Brush disabledBrush;
    public static Brush errorBrush;

    private static bool dragFlag;
    private static Point offset;
    private static bool togetherMove = true;
    private static bool appStarted = false;
    public bool updateChecking = true;
    private static bool modified = false;
    private static bool exitConfirm = false;
    private static bool addDragDrop = false;
    public static Dictionary<string, string> txt = new Dictionary<string, string>();
    public static string langType = "Jpn";

    bool isDraggingTex = false;

    PreviewWindow previewWindow;



    public MainWindow()
    {
      InitializeComponent();

      MainWindowTitle();
      changeLanguage();
      MessageWindow.lang(txt);

      previewWindow = new PreviewWindow();

      alertBg = new SolidColorBrush(Color.FromRgb(0xFF, 0x55, 0x55));

      textBrush = mainWindow.Resources["ForegroundBrush"] as Brush;
      disabledBrush = mainWindow.Resources["DisabledForegroundBrush"] as Brush;
      errorBrush = new SolidColorBrush(Color.FromRgb(0xFF, 0x66, 0x66));

      BuildContextMenu();

      Application.Current.ShutdownMode = ShutdownMode.OnMainWindowClose;
    }

    private void mainWindow_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      if (e.LeftButton == MouseButtonState.Released) return;

      dragFlag = true; // ドラッグ開始
      offset = e.GetPosition(this); // 開始位置の記録

      if (mainWindow.Left + mainWindow.ActualWidth == previewWindow.Left && mainWindow.Top == previewWindow.Top)
        togetherMove = true;
      else
        togetherMove = false;

      mainWindow.CaptureMouse();
    }

    private void mainWindow_MouseMove(object sender, MouseEventArgs e)
    {
      if (dragFlag) // ドラッグ時のみ
      {
        Point p = e.GetPosition(this); // 現在のマウス座標
        // ウィンドウを移動
        this.Left += p.X - offset.X;
        this.Top += p.Y - offset.Y;
        // ウィンドウを追従
        if (togetherMove)
        {
          previewWindow.Left += p.X - offset.X;
          previewWindow.Top += p.Y - offset.Y;
        }
      }
    }

    private void mainWindow_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
      dragFlag = false; // ドラッグ終了
      mainWindow.ReleaseMouseCapture();
    }

    private void mainWindow_MouseLeave(object sender, MouseEventArgs e)
    {
      dragFlag = false; // ドラッグ終了
      mainWindow.ReleaseMouseCapture();
    }

    private void mainWindow_Loaded(object sender, RoutedEventArgs e)
    {
      texTable = new TexturesTable();
      texTable.TextStatus = txt["textStatus"];
      this.DataContext = texTable;

      List<string> cmds = System.Environment.GetCommandLineArgs().ToList();
      cmds.RemoveAt(0);
      OpenDorpFile(cmds);
    }

    private void mainWindow_DragOver(object sender, DragEventArgs e)
    {
      e.Handled = true;
      if (e.Data.GetDataPresent(DataFormats.FileDrop))
      {
        if (addDragDrop && (e.KeyStates & DragDropKeyStates.ControlKey) != 0)
          e.Effects = DragDropEffects.Copy;
        else
          e.Effects = DragDropEffects.Move;
      }
      else
      {
        e.Effects = DragDropEffects.None;
      }
    }

    private void mainWindow_DragDrop(object sender, DragEventArgs e)
    {
      if (isDraggingTex) return;

      List<string> filePaths = ((string[])e.Data.GetData(DataFormats.FileDrop, false)).ToList();
      OpenDorpFile(filePaths);
    }

    public async void OpenDorpFile(List<string> filePaths)
    {
      if (filePaths.Count < 1) return;

      List<string> openPaths = new List<string>();
      List<string> ddsPaths = new List<string>();
      List<string> lnkPaths = new List<string>();
      foreach (string path in filePaths)
      {
        if (SupportedFiles.Contains(System.IO.Path.GetExtension(path).ToUpper()))
        {
          openPaths.Add(path);
        }
        else if (System.IO.Path.GetExtension(path).ToUpper() == ".DDS")
        {
          ddsPaths.Add(path);
        }
        else if (System.IO.Path.GetExtension(path).ToLower() == ".lnk")
        {
          lnkPaths.Add(path);
        }
      }

      if (lnkPaths.Count > 0)
      {
        Type t = Type.GetTypeFromCLSID(new Guid("72C24DD5-D70A-438B-8A42-98424B88AFB8"));
        dynamic shell = Activator.CreateInstance(t);
        List<string> shortcutPaths = new List<string>();
        foreach (string path in lnkPaths)
        {
          var shortcut = shell.CreateShortcut(path);
          shortcutPaths.Add(shortcut.TargetPath);
          System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shortcut);
        }
        System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shell);

        foreach (string path in shortcutPaths)
        {
          if (SupportedFiles.Contains(System.IO.Path.GetExtension(path).ToUpper()))
          {
            openPaths.Add(path);
          }
          else if (System.IO.Path.GetExtension(path).ToUpper() == ".DDS")
          {
            ddsPaths.Add(path);
          }
        }
      }

      if (openPaths.Count > 0)
      {
        string appPath = System.Reflection.Assembly.GetExecutingAssembly().Location;

        if (openPaths.Count >= 5)
        {
          if (MessageWindow.Show(this, openPaths.Count + " " + txt["ConfirmOpenMany"], txt["Confirm"], txt["Open"], txt["Cancel"]) == MessageWindow.Result.Cancel)
          {
            return;
          }
        }

        for (int i = 0; i < openPaths.Count; i++)
        {
          if (i == 0)
          {
            if (texTable == null || texTable.IsEnabled)
            {
              OpenFile(openPaths[i]);
            }
            else if (!texTable.IsEnabled)
            {
              texTable.IsCancel = true;
              texTable.OpenOtherFilePath = openPaths[i];
            }

            await Task.Delay(100);
          }
          else
          {
            System.Diagnostics.Process.Start(appPath, "\"" + openPaths[i] + "\"");
          }
        }
      }
      else if (ddsPaths.Count > 0 && containerData != null)
      {
        SwapTexture(ddsPaths[0]);
      }
    }

    private void OpenFromClipboard()
    {
      if (texTable != null && !texTable.IsEnabled) return;

      var pathText = Clipboard.GetText();
      if (Clipboard.ContainsFileDropList())
      {
        //データを取得する（取得できなかった時はnull）
        System.Collections.Specialized.StringCollection files = Clipboard.GetFileDropList();
        if (files != null) pathText = files[0];
      }
      if (!string.IsNullOrEmpty(pathText) && File.Exists(pathText) && SupportedFiles.IndexOf(Path.GetExtension(pathText).ToUpper()) != -1)
      {
        var result = MessageWindow.Show(this, pathText + "\r\n\r\n" + txt["ConfirmOpenFile"], txt["Info"], txt["Open"], txt["Cancel"]);
        if (result == MessageWindow.Result.OK)
        {
          OpenFile(pathText);
        }
        Keyboard.Focus(mainWindow);
      }
    }

    private void openCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (texTable == null || texTable.IsEnabled)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    public void openCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var dlg = new Microsoft.Win32.OpenFileDialog();
      dlg.Filter = "Supported Files|*.TMC; *.--H; *.--P; *.SCN; *.SPR|TMC Files|*.TMC|--H Files|*.--H|--P Files|*.--P|SCN Files|*.SCN|SPR Files|*.SPR|All files|*.*";
      dlg.FilterIndex = 0;
      if (containerPath != "")
      {
        dlg.InitialDirectory = Path.GetDirectoryName(containerPath);
        dlg.FileName = Path.GetFileName(containerPath);
      }
      if (dlg.ShowDialog() == true)
      {
        OpenFile(dlg.FileName);
      }
    }

    private void revertCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (!String.IsNullOrEmpty(containerPath) && (modified || (texTable != null && texTable.IsSuspended)))
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void revertCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      OpenFile(containerPath);
    }

    private void cancelCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (texTable == null || texTable.InProgress)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    public void cancelCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      texTable.IsCancel = true;
    }

    public bool saveCommand_CanExecute_Check()
    {
      if (texTable == null || texTable.IsSuspended)
        return false;
      else if (texTable.IsEnabled && texTable.Tex.Count != 0 && containerPath != "" && modified)
        return true;
      else
        return false;
    }
    private void saveCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      e.CanExecute = saveCommand_CanExecute_Check();
    }
    public void saveCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var result = MessageWindow.Show(this, txt["ConfirmOverwrite"], txt["Confirm"], txt["OverwriteYes"], txt["Cancel"]);
      if (result == MessageWindow.Result.OK)
      {
        SaveFile(containerPath);
      }
    }

    public bool saveAsCommand_CanExecute_Check()
    {
      if (texTable == null || texTable.IsSuspended)
        return false;
      else if (texTable.IsEnabled && texTable.Tex.Count != 0)
        return true;
      else
        return false;
    }
    private void saveAsCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      e.CanExecute = saveAsCommand_CanExecute_Check();
    }
    public void saveAsCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var dlg = new Microsoft.Win32.SaveFileDialog();
      dlg.InitialDirectory = Path.GetDirectoryName(containerPath);
      dlg.FileName = Path.GetFileName(containerPath);
      if (containerData.FileType == 0)
        dlg.Filter = "TMC Files|*.TMC";
      else if (containerData.FileType == 1)
        dlg.Filter = "--H Files|*.--H";
      else if (containerData.FileType == 2)
        dlg.Filter = "--P Files|*.--P";
      else if (containerData.FileType == 3)
        dlg.Filter = "SCN Files|*.SCN";
      else if (containerData.FileType == 4)
        dlg.Filter = "SPR Files|*.SPR";

      if (dlg.ShowDialog() == true)
      {
        SaveFile(dlg.FileName);
      }
    }

    private void extractAllCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      e.CanExecute = saveAsCommand_CanExecute_Check();
    }
    public void extractAllCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      try
      {
        int extractCount = 0;
        bool createFolder = Convert.ToBoolean(e.Parameter);

        if (texTable.Tex.Count == 1)
        {
          string filePath = ExtractSingleTexture(texTable.Tex[0]);
          if (string.IsNullOrEmpty(filePath))
          {
            return;
          }
          else
          {
            extractCount++;
          }
        }
        else
        {
          var dlg = new CommonOpenFileDialog();
          dlg.IsFolderPicker = true;
          dlg.EnsureReadOnly = false;
          dlg.AllowNonFileSystemItems = false;
          if (extractBasePath == "")
          {
            extractBasePath = Path.GetDirectoryName(containerPath);
          }
          dlg.InitialDirectory = extractBasePath;

          if (dlg.ShowDialog() == CommonFileDialogResult.Ok)
          {
            if (createFolder)
            {
              extractBasePath = dlg.FileName;
              extractPath = dlg.FileName;
              string[] folderNames = texTable.ExtFolder.Split(new Char[] { '\\' });
              foreach (var folderName in folderNames)
              {
                if (!string.IsNullOrEmpty(folderName.Trim())) extractPath += @"\" + folderName;
              }
            }
            else
            {
              extractPath = dlg.FileName;
            }
            foreach (var tex in texTable.Tex)
            {
              string fileName = ExtractFileName(tex);
              if (!tex.IsEmpty && ExtractTexture(tex, extractPath + @"\" + fileName))
              {
                extractCount++;
              }
            }
          }
          else
          {
            return;
          }
        }

        if (extractCount > 0)
          ShowTextBlockMessage(txt["Extracted"]);
        else
          ShowTextBlockMessage(txt["NotExtracted"], alertBg);
      }
      catch (Exception ex)
      {
        MessageWindow.Show(this, ex.Message + "\r\n\r\n" + ex.StackTrace, txt["Error"]);
      }
    }

    private void moveToLCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      foreach (var tex in texTable.Tex)
      {
        if (tex.In == "TMC" || tex.In == "--H")
        {
          e.CanExecute = true;
          return;
        }
      }

      e.CanExecute = false;
    }
    public void moveToLCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      foreach (var tex in texTable.Tex)
      {
        if (string.IsNullOrEmpty(tex.In) || containerData.FileType == 2)
          continue;
        else
          tex.In = AssociatedFiles[containerData.FileType];
      }

      modified = true;
    }



    private void TextBoxExtFolder_LostFocus(object sender, RoutedEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (target == null || string.IsNullOrEmpty(target.Text)) return;

      target.Text = target.Text.Replace('/', '\\');

      var invalidChars = Path.GetInvalidFileNameChars().ToList();
      invalidChars.Remove('\\');

      target.Text = invalidChars.Aggregate(target.Text, (s, c) => s.Replace(c.ToString(), "")).Trim();
    }

    private void cbPreview_Checked(object sender, RoutedEventArgs e)
    {
      if (!this.IsInitialized) return;

      if (dgTextures.SelectedItem != null)
      {
        var tex = dgTextures.SelectedItem as TexturesTable.TextureData;
        previewWindow.ShowPreview(tex);
      }

      previewWindow.Show(this);
    }

    private void cbPreview_Unchecked(object sender, RoutedEventArgs e)
    {
      previewWindow.Hide();
    }

    private void dgTextures_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (!this.IsInitialized) return;

      if (cbPreview.IsChecked == true && dgTextures.SelectedItem != null)
      {
        var tex = dgTextures.SelectedItem as TexturesTable.TextureData;
        previewWindow.ShowPreview(tex);
      }
    }



    public void dgTextures_ContextMenuOpening(object sender, ContextMenuEventArgs e)
    {
      menuItemSwap.IsEnabled = false;
      menuItemExtract.IsEnabled = false;
      menuItemSaveAsPng.Visibility = Visibility.Collapsed;
      menuItemAdd.IsEnabled = false;
      menuItemDelete.IsEnabled = false;
      menuItemCopy.IsEnabled = false;
      menuItemPaste.IsEnabled = false;
      menuItemEmpty.IsEnabled = false;
      menuItemCancel.IsEnabled = false;

      if (containerData == null) return;

      if (dgTextures.SelectedItems.Count == 1)
      {
        var tex = dgTextures.SelectedItem as TexturesTable.TextureData;

        menuItemSwap.IsEnabled = true;
      }

      if (containerData.FileType == 0 || (containerData.FileType == 1 && texTable.Tex.Count < 64))
      {
        menuItemAdd.IsEnabled = true;
      }

      var type = sender.GetType();
      if (type.Name == "PreviewWindow")
      {
        menuItemSaveAsPng.Visibility = Visibility.Visible;
      }

      foreach (var item in dgTextures.SelectedItems)
      {
        var tex = item as TexturesTable.TextureData;

        if (!tex.IsEmpty)
        {
          menuItemExtract.IsEnabled = true;
          if (containerData.FileType == 1) menuItemEmpty.IsEnabled = true;
        }
        if (containerData.FileType == 0 || containerData.FileType == 1)
        {
          if (tex.Use < 1 && texTable.Tex.Count > 1)
          {
            menuItemDelete.IsEnabled = true;
          }
          if (tex.IsChanged && tex.OriginalID != -1)
          {
            menuItemCancel.IsEnabled = true;
          }
        }
      }


      selectedTextures = dgTextures.SelectedItems.Cast<TexturesTable.TextureData>().ToList();

      if (selectedTextures.Count > 0)
        menuItemCopy.IsEnabled = true;


      clipboardData = GetDataFromClipboard();

      if (clipboardData is string || clipboardData is List<byte[]>)
        menuItemPaste.IsEnabled = true;


      if (texTable.IsSuspended)
      {
        menuItemSwap.IsEnabled = false;
        menuItemAdd.IsEnabled = false;
        menuItemDelete.IsEnabled = false;
        menuItemPaste.IsEnabled = false;
        menuItemEmpty.IsEnabled = false;
        menuItemCancel.IsEnabled = false;
      }
    }

    private void menuItemSwap_Click(object sender, RoutedEventArgs e)
    {
      var dlg = new Microsoft.Win32.OpenFileDialog();
      dlg.Filter = "DDS Images (*.DDS)|*.DDS";
      if (!string.IsNullOrEmpty(ddsPath))
      {
        dlg.InitialDirectory = Path.GetDirectoryName(ddsPath);
        dlg.FileName = Path.GetFileName(ddsPath);
      }
      if (dlg.ShowDialog() == true)
      {
        SwapTexture(dlg.FileName);
      }
    }

    private void menuItemExtract_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        int extractCount = 0;
        if (extractPath == "")
        {
          extractPath = Path.GetDirectoryName(containerPath);
        }

        if (dgTextures.SelectedItems.Count == 1)
        {
          var tex = dgTextures.SelectedItem as TexturesTable.TextureData;

          string filePath = ExtractSingleTexture(tex);
          if (string.IsNullOrEmpty(filePath))
          {
            return;
          }
          else
          {
            extractCount++;
          }
        }
        else if (dgTextures.SelectedItems.Count > 1)
        {
          var dlg = new CommonOpenFileDialog();
          dlg.IsFolderPicker = true;
          dlg.EnsureReadOnly = false;
          dlg.AllowNonFileSystemItems = false;
          if (extractBasePath == "")
          {
            extractBasePath = Path.GetDirectoryName(containerPath);
          }
          dlg.InitialDirectory = extractBasePath;

          if (dlg.ShowDialog() == CommonFileDialogResult.Ok)
          {
            foreach (var item in dgTextures.SelectedItems)
            {
              var tex = item as TexturesTable.TextureData;
              string fileName = ExtractFileName(tex);
              if (!tex.IsEmpty && ExtractTexture(tex, dlg.FileName + @"\" + fileName))
              {
                extractCount++;
              }
            }
            extractBasePath = dlg.FileName;
          }
          else
          {
            return;
          }
        }
        else
        {
          return;
        }
        if (extractCount > 0)
          ShowTextBlockMessage(txt["Extracted"]);
        else
          ShowTextBlockMessage(txt["NotExtracted"], alertBg);
      }
      catch (Exception ex)
      {
        MessageWindow.Show(this, ex.Message + "\r\n\r\n" + ex.StackTrace, txt["Error"]);
      }
    }

    private void menuItemSaveAsPng_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        var tex = dgTextures.SelectedItem as TexturesTable.TextureData;

        var dlg = new Microsoft.Win32.SaveFileDialog();
        dlg.InitialDirectory = Path.GetDirectoryName(containerPath);
        dlg.FileName = ExtractFileName(tex, "png");

        dlg.Filter = "PNG Files|*.png";

        if (dlg.ShowDialog() != true) return;

        var bitmap = previewWindow.GetBitmap(tex);
        bitmap.Save(dlg.FileName, System.Drawing.Imaging.ImageFormat.Png);
      }
      catch (Exception ex)
      {
        MessageWindow.Show(this, ex.Message + "\r\n\r\n" + ex.StackTrace, txt["Error"]);
      }
    }

    private void menuItemAdd_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        if (containerData.FileType == 1 && texTable.Tex.Count >= 64) return;

        var data = new AddTextureData();

        for (int i = 0; i < texTable.Tex.Count; i++)
        {
          data.Ids.Add(i);
        }

        data.SelectedId = dgTextures.SelectedIndex;

        data.SelectedCount = dgTextures.SelectedItems.Count;

        data.CurrentPath = ddsPath;

        data = AddTextureWindow.Show(this, data);

        if (data == null) return;


        if (dgTextures.SelectedItems.Count > 0)
          dgTextures.SelectedItems.Clear();


        if (data.IsBottom)
        {
          // 最後に追加
          for (int i = 0; i < data.AddCount; i++)
          {
            string filePath = null;
            if (data.Files.Count > i) filePath = data.Files[i];

            AddTexture(texTable.Tex.Count, filePath);

            if (containerData.FileType == 1 && texTable.Tex.Count >= 64) break;
          }
        }
        else
        {
          int insertIndex = 0;

          if (data.IsOverID)
            insertIndex = data.SelectedId;
          else if (data.IsUnderID)
            insertIndex = data.SelectedId + 1;

          for (int i = 0; i < data.AddCount; i++)
          {
            string filePath = null;
            if (data.Files.Count > i) filePath = data.Files[i];

            AddTexture(insertIndex, filePath);
            insertIndex++;

            if (containerData.FileType == 1 && texTable.Tex.Count >= 64) break;
          }

          // IDを再設定
          for (int i = 0; i < texTable.Tex.Count; i++)
          {
            texTable.Tex[i].ID = i;
          }
        }


        dgTextures.ScrollIntoView(dgTextures.SelectedItem);
        var selTex = dgTextures.SelectedItem as TexturesTable.TextureData;
        previewWindow.ShowPreview(selTex);
        modified = true;
      }
      catch (Exception ex)
      {
        MessageWindow.Show(this, ex.Message + "\r\n\r\n" + ex.StackTrace, txt["Error"]);
      }
    }

    private void AddTexture(int newIndex, string filePath)
    {
      texTable.AddTexture(newIndex);
      var tex = texTable.Tex[newIndex];
      dgTextures.SelectedItems.Add(tex);

      if (filePath != null)
      {
        var bin = GetTextureBin(filePath);

        SetTextureInit(tex, bin);

        tex.Use = 0;
      }
      else if (containerData.FileType == 0)
      {
        using (var ms = new MemoryStream(Texture_Tool.Properties.Resources.texStub))
        {
          SetTextureFromStream(ms);
          tex.Use = 0;
        }
      }
    }

    public void texDeleteCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      texDeleteCommand_CanExecute(e);
    }
    public void texDeleteCommand_CanExecute(CanExecuteRoutedEventArgs e)
    {
      e.CanExecute = false;

      if (texTable.IsSuspended) return;

      foreach (var item in dgTextures.SelectedItems)
      {
        var tex = item as TexturesTable.TextureData;
        if (containerData.FileType == 0 || containerData.FileType == 1)
        {
          if (tex.Use < 1 && texTable.Tex.Count > 1)
          {
            e.CanExecute = true;
          }
        }
      }
    }
    public void texDeleteCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      texDelete();
    }
    private void menuItemDelete_Click(object sender, RoutedEventArgs e)
    {
      texDelete();
    }
    public void texDelete()
    {
      try
      {
        while (dgTextures.SelectedItems.Count > 0)
        {
          var tex = dgTextures.SelectedItem as TexturesTable.TextureData;
          if (tex.Use == 0 || containerData.FileType != 0)
            texTable.Tex.Remove(tex);
          else
            dgTextures.SelectedItems.Remove(tex);
        }
        previewWindow.image.Source = null;
        modified = true;

        if (texTable.Tex.Count == 0) AddTexture(0, null);

        // ID再設定
        for (int i = 0; i < texTable.Tex.Count; i++)
        {
          texTable.Tex[i].ID = i;
        }

        modified = true;

        dgTextures.Focus();
      }
      catch (Exception ex)
      {
        MessageWindow.Show(this, ex.Message + "\r\n\r\n" + ex.StackTrace, txt["Error"]);
      }
    }

    private void texCopyCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      texCopyCommand_CanExecute(e);
    }
    public void texCopyCommand_CanExecute(CanExecuteRoutedEventArgs e)
    {
      selectedTextures = dgTextures.SelectedItems.Cast<TexturesTable.TextureData>().ToList();

      if (selectedTextures.Count > 0)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void texCopyCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      texCopy();
    }
    private void menuItemCopy_Click(object sender, RoutedEventArgs e)
    {
      texCopy();
    }
    public void texCopy()
    {
      var dataList = new List<byte[]>();

      foreach (var tex in selectedTextures.OrderBy(p => p.ID))
      {
        dataList.Add(tex.Data);
      }

      if (selectedTextures.Count > 0)
      {
        BinaryFormatter bf = new BinaryFormatter();
        MemoryStream ms = new MemoryStream();
        bf.Serialize(ms, dataList);
        Clipboard.SetDataObject(ms);
      }
    }

    public void texPasteCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      texPasteCommand_CanExecute(e);
    }
    public void texPasteCommand_CanExecute(CanExecuteRoutedEventArgs e)
    {
      clipboardData = GetDataFromClipboard();

      if (!texTable.IsSuspended && (clipboardData is string || clipboardData is List<byte[]>))
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    public void texPasteCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      texPaste();
    }
    private void menuItemPaste_Click(object sender, RoutedEventArgs e)
    {
      texPaste();
    }
    public void texPaste()
    {
      try
      {
        if (clipboardData is List<byte[]>)
        {
          var pasteTexsData = clipboardData as List<byte[]>;

          var selectedTexs = dgTextures.SelectedItems.Cast<TexturesTable.TextureData>().OrderBy(p => p.ID).ToList();

          if (pasteTexsData.Count == 1)
          {
            foreach (var tex in selectedTexs)
            {
              SetTextureInit(tex, pasteTexsData[0]);
            }
          }
          else if (pasteTexsData.Count == selectedTexs.Count)
          {
            foreach (var pair in Enumerable.Zip(pasteTexsData, selectedTexs, (a, b) => new { a, b }))
            {
              SetTextureInit(pair.b, pair.a);
            }
          }
          else if (pasteTexsData.Count != selectedTexs.Count)
          {
            var result = MessageWindow.Show(this, txt["ConfirmPasteDifferent"], txt["Confirm"], txt["Paste"], txt["Cancel"]);
            if (result != MessageWindow.Result.OK) return;


            for (int i = 0; i < pasteTexsData.Count || i < selectedTexs.Count; i++)
            {
              if (i >= pasteTexsData.Count)
              {
                dgTextures.SelectedItems.Remove(selectedTexs[i]);
              }
              else if (i >= selectedTexs.Count)
              {
                break;
              }
              else
              {
                SetTextureInit(selectedTexs[i], pasteTexsData[i]);
              }
            }
          }

          var selTex = dgTextures.SelectedItem as TexturesTable.TextureData;
          previewWindow.ShowPreview(selTex);
          modified = true;
        }
        else if (clipboardData is string)
        {
          string pathText = (string)clipboardData;

          if (SupportedFiles.IndexOf(Path.GetExtension(pathText).ToUpper()) != -1)
          {
            var result = MessageWindow.Show(this, pathText + "\r\n\r\n" + txt["ConfirmOpenFile"], txt["Info"], txt["Open"], txt["Cancel"]);
            if (result == MessageWindow.Result.OK)
            {
              OpenFile(pathText);
            }
            Keyboard.Focus(mainWindow);
          }
          else
          {
            SwapTexture(pathText);
          }
        }
      }
      catch (Exception ex)
      {
        MessageWindow.Show(this, ex.Message + "\r\n\r\n" + ex.StackTrace, txt["Error"]);
      }
    }

    private object GetDataFromClipboard()
    {
      try
      {
        IDataObject data = Clipboard.GetDataObject();
        if (data != null)
        {
          if (data.GetDataPresent(typeof(MemoryStream)))
          {
            using (MemoryStream stream = data.GetData(typeof(MemoryStream)) as MemoryStream)
            {
              BinaryFormatter bf = new BinaryFormatter();
              var pasteData = bf.Deserialize(stream);

              if (pasteData is List<byte[]> == false) return null;


              var pasteTexsData = pasteData as List<byte[]>;

              if (pasteTexsData.Count == 0 || dgTextures.SelectedItems.Count == 0) return null;


              return pasteTexsData;
            }
          }
          else
          {
            string pathText = "";
            if (Clipboard.ContainsFileDropList())
            {
              System.Collections.Specialized.StringCollection files = Clipboard.GetFileDropList();
              if (files != null) pathText = files[0];
            }

            if (!string.IsNullOrEmpty(pathText) && File.Exists(pathText))
            {
              return pathText;
            }
          }
        }
        return null;
      }
      catch (Exception ex)
      {
        MessageWindow.Show(this, ex.Message + "\r\n\r\n" + ex.StackTrace, txt["Error"]);
        return null;
      }
    }


    private void menuItemEmpty_Click(object sender, RoutedEventArgs e)
    {
      foreach (var item in dgTextures.SelectedItems)
      {
        var tex = item as TexturesTable.TextureData;
        if (!tex.IsEmpty)
        {
          tex.IsEmpty = true;
          tex.IsChanged = true;
          modified = true;
        }
      }
      var selTex = dgTextures.SelectedItem as TexturesTable.TextureData;
      previewWindow.ShowPreview(selTex);
    }

    private void menuItemCancel_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        foreach (var item in dgTextures.SelectedItems)
        {
          var tex = item as TexturesTable.TextureData;

          if (tex.IsChanged && tex.OriginalID != -1)
          {
            texTable.ResetTexture(containerData, tex, bn, bnL);
          }
        }
        var selTex = dgTextures.SelectedItem as TexturesTable.TextureData;
        previewWindow.ShowPreview(selTex);
      }
      catch (Exception ex)
      {
        MessageWindow.Show(this, ex.Message + "\r\n\r\n" + ex.StackTrace, txt["Error"]);
      }
    }

    private void BuildContextMenu()
    {
      menuItemSwap.Header = txt["Swap"] + "...";
      menuItemExtract.Header = txt["Extract"] + "...";
      menuItemSaveAsPng.Header = txt["SaveAsPng"] + "...";
      menuItemAdd.Header = txt["Add"];
      menuItemDelete.Header = txt["Delete"];
      menuItemCopy.Header = txt["Copy"];
      menuItemPaste.Header = txt["Paste"];
      menuItemEmpty.Header = txt["Clear"];
      menuItemCancel.Header = txt["RevertTex"];

      menuItemDelete.InputGestureText = "Delete";
      menuItemCopy.InputGestureText = "Ctrl+C";
      menuItemPaste.InputGestureText = "Ctrl+V";

      menuTextures.Items.Add(menuItemSwap);
      menuTextures.Items.Add(menuItemExtract);
      menuTextures.Items.Add(menuItemSaveAsPng);
      menuTextures.Items.Add(menuItemAdd);
      menuTextures.Items.Add(menuItemDelete);
      menuTextures.Items.Add(menuItemCopy);
      menuTextures.Items.Add(menuItemPaste);
      menuTextures.Items.Add(menuItemEmpty);
      menuTextures.Items.Add(menuItemCancel);

      menuItemSwap.Click += new RoutedEventHandler(menuItemSwap_Click);
      menuItemExtract.Click += new RoutedEventHandler(menuItemExtract_Click);
      menuItemSaveAsPng.Click += new RoutedEventHandler(menuItemSaveAsPng_Click);
      menuItemAdd.Click += new RoutedEventHandler(menuItemAdd_Click);
      //menuItemDelete.Command = dgTextures.FindResource("TexDelete") as RoutedCommand;
      //menuItemCopy.Command = dgTextures.FindResource("TexCopy") as RoutedCommand;
      //menuItemPaste.Command = dgTextures.FindResource("TexPaste") as RoutedCommand;
      menuItemDelete.Click += new RoutedEventHandler(menuItemDelete_Click);
      menuItemCopy.Click += new RoutedEventHandler(menuItemCopy_Click);
      menuItemPaste.Click += new RoutedEventHandler(menuItemPaste_Click);
      menuItemEmpty.Click += new RoutedEventHandler(menuItemEmpty_Click);
      menuItemCancel.Click += new RoutedEventHandler(menuItemCancel_Click);

      dgTextures.ContextMenu = menuTextures;
      previewWindow.ContextMenu = menuTextures;
    }



    public async void OpenFile(string filePath)
    {
      bool errorMessage = false;

      texTable.IsEnabled = false;
      texTable.TextStatusBrush = disabledBrush;

      if (texTable.OpenOtherFilePath != null) texTable.OpenOtherFilePath = null;

      try
      {
        string fileExt = Path.GetExtension(filePath).ToUpper();
        int fileType = SupportedFiles.IndexOf(fileExt);
        if (fileType == -1)
        {
          ResetState();
          return;
        }

        previewWindow.image.Source = null;

        await Task.Run(() =>
        {
          updateChecking = false;

          var bin = System.IO.File.ReadAllBytes(filePath);
          char[] charsToTrim = { '\0' };
          string Name = Encoding.ASCII.GetString(bin, 0, 8).TrimEnd(charsToTrim);
          if (Name != SupportedFormats[fileType] || bin.Length < 0x200 || BitConverter.ToUInt32(bin, 0x08) != 0x01010000)
          {
            errorMessage = true;
            throw new NotSupportedException(txt["UnsupportedFile"] + "\r\n" + filePath);
          }

          modified = false;
          texTable.IsEnabledExtFolder = false;
          texTable.IsEnabledPanel2nd = false;
          texTable.IsEnabledExtractAllFolder = false;
          texTable.IsVisibleMoveToL = false;
          texTable.IsEnabledPreview = false;
          texTable.IsEnabledDgTextures = false;
          texTable.TextStatus = txt["textStatus"];
          texTable.TextStatusToolTip = "";
          texTable.IsSuspended = false;
          containerPath = "";
          containerData = new ContainerData();
          if (texTable != null && texTable.Tex.Count != 0) texTable.Tex.Clear();

          if (fileType == 0)
          {
            #region TMC
            // TMCファイルの場合
            string filePathL = CheckAssociatedFile(filePath, fileType);
            if (filePathL == null)
            {
              errorMessage = true;
              throw new Exception(AssociatedFiles[fileType] + txt["NotFound"]);
            }

            bnL = System.IO.File.ReadAllBytes(filePathL);

            containerData.ParseTextureTmcData(bin);
            texTable.IsVisibleMoveToL = true;
            texTable.HeaderMoveToL = txt["MoveToTMCL"];
            texTable.ExtFolder = Path.GetFileNameWithoutExtension(filePath);
            #endregion
          }
          else if (fileType == 1)
          {
            #region --H
            // --Hファイルの場合
            string filePathL = CheckAssociatedFile(filePath, fileType);
            if (filePathL == null)
            {
              errorMessage = true;
              throw new Exception(AssociatedFiles[fileType] + txt["NotFound"]);
            }

            bnL = System.IO.File.ReadAllBytes(filePathL);

            containerData.ParseTextureHData(bin);
            texTable.IsVisibleMoveToL = true;
            texTable.HeaderMoveToL = txt["MoveToHL"];


            System.Text.RegularExpressions.MatchCollection mc = System.Text.RegularExpressions.Regex.Matches(
              Path.GetFileNameWithoutExtension(filePath),
              @"(?<basename>.*)_(?<filenum>[0-9]{3})");
            if (mc.Count > 0)
            {
              texTable.ExtFolder = mc[0].Groups["basename"].Value;
              containerData.FileNum = mc[0].Groups["filenum"].Value;
            }
            else
            {
              texTable.ExtFolder = Path.GetFileNameWithoutExtension(filePath);
            }
            #endregion
          }
          else if (fileType == 2)
          {
            #region --P
            // --Pファイルの場合
            containerData.ParseTexturePData(bin);
            #endregion
          }
          else if (fileType == 3)
          {
            #region SCN
            // SCNファイルの場合
            string filePathL = CheckAssociatedFile(filePath, fileType);
            if (filePathL == null)
            {
              errorMessage = true;
              throw new Exception(AssociatedFiles[fileType] + txt["NotFound"]);
            }

            bnL = System.IO.File.ReadAllBytes(filePathL);

            containerData.ParseTextureScnData(bin);
            texTable.ExtFolder = Path.GetFileNameWithoutExtension(filePath);
            #endregion
          }
          else if (fileType == 4)
          {
            #region SPR
            // SPRファイルの場合
            string filePathL = CheckAssociatedFile(filePath, fileType);
            if (filePathL == null)
            {
              errorMessage = true;
              throw new Exception(AssociatedFiles[fileType] + txt["NotFound"]);
            }

            bnL = System.IO.File.ReadAllBytes(filePathL);

            containerData.ParseTextureSprData(bin);
            texTable.ExtFolder = Path.GetFileNameWithoutExtension(filePath);
            #endregion
          }

          if (containerData == null) return;

          bn = bin;

          containerData.Path = filePath;
          containerData.WriteTime = System.IO.File.GetLastWriteTime(filePath);

          texTable.TextStatus = filePath;
          texTable.TextStatusToolTip = filePath;

          texTable.SetTexture(containerData, bn, bnL);


          if (texTable.OpenOtherFilePath != null) return;


          if (texTable.Tex.Count > 1)
          {
            texTable.IsEnabledExtractAllFolder = true;
            texTable.IsEnabledExtFolder = true;
          }
          else
          {
            texTable.ExtFolder = "";
          }

          texTable.IsEnabledPreview = true;
          texTable.IsEnabledDgTextures = true;

          if (texTable.IsCancel)
          {
            texTable.IsEnabledPanel2nd = false;
            texTable.IsCancel = false;
            texTable.IsSuspended = true;
            texTable.TextStatusToolTip += " / " + txt["FileOpeningSuspended"];
          }
          else
          {
            texTable.IsEnabledPanel2nd = true;
          }

          texTable.ProgressBarValue = 0;

          containerPath = filePath;

          updateChecking = true;


          ResetState();
        });
      }
      catch (Exception e)
      {
        ResetState();

        if (errorMessage)
          MessageWindow.Show(this, e.Message, txt["Error"]);
        else
          MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }
      finally
      {
        if (texTable.OpenOtherFilePath != null)
        {
          texTable.IsCancel = false;
          OpenFile(texTable.OpenOtherFilePath);
        }
      }
    }

    private void ResetState()
    {
      texTable.IsEnabled = true;

      if (texTable.IsSuspended)
        texTable.TextStatusBrush = errorBrush;
      else
        texTable.TextStatusBrush = textBrush;
    }

    private async void mainGrid_IsEnabledChanged(object sender, DependencyPropertyChangedEventArgs e)
    {
      if (!mainGrid.IsEnabled) return;

      if (containerData == null || dgTextures.SelectedIndex != -1) return;

      if (containerData != null && containerData.Tex.Count == 0)
      {
        ShowTextBlockMessage(txt["TexNotFound"], alertBg);
        return;
      }

      if (cbPreview.IsChecked == true) previewWindow.Show(this);

      await Task.Delay(100);

      dgTextures.Focus();


      if (selectedTextureIndices == null || selectedTextureIndices.Count == 0)
      {
        dgTextures.SelectedIndex = 0;

        dgTextures.UpdateLayout();

        for (int i = 0; i < texTable.Tex.Count; i++)
        {
          if (texTable.Tex[i].Width > 0)
          {
            dgTextures.SelectedIndex = i;
            dgTextures.ScrollIntoView(dgTextures.Items[i]);
            DataGridCellInfo cellInfo = new DataGridCellInfo(dgTextures.Items[i], dgTextures.Columns[0]);
            dgTextures.CurrentCell = cellInfo;
            DataGridRow row = (DataGridRow)dgTextures.ItemContainerGenerator.ContainerFromItem(dgTextures.Items[i]);
            SetShiftSelectBase(dgTextures, row, 0);
            break;
          }
        }
      }
      else
      {
        dgTextures.SelectedIndex = selectedTextureIndices[0];

        dgTextures.UpdateLayout();

        dgTextures.ScrollIntoView(dgTextures.SelectedItem);
        DataGridCellInfo cellInfo = new DataGridCellInfo(dgTextures.SelectedItem, dgTextures.Columns[0]);
        dgTextures.CurrentCell = cellInfo;
        DataGridRow row = (DataGridRow)dgTextures.ItemContainerGenerator.ContainerFromItem(dgTextures.SelectedItem);
        SetShiftSelectBase(dgTextures, row, 0);

        foreach (var item in dgTextures.Items)
        {
          var tex = item as TexturesTable.TextureData;

          if (selectedTextureIndices.Contains(tex.ID))
          {
            dgTextures.SelectedItems.Add(item);
          }
        }

        selectedTextureIndices.Clear();
      }

      this.Activate();
      this.Focus();
    }

    private string CheckAssociatedFile(string filePath, int fileType)
    {
      string filePathL = Path.ChangeExtension(filePath, "." + AssociatedFiles[fileType]);
      if (!File.Exists(filePathL))
      {
        string[] separators = { " - " };
        filePathL = Path.ChangeExtension(filePath.Split(separators, StringSplitOptions.RemoveEmptyEntries)[0], "." + AssociatedFiles[fileType]);

        if (!File.Exists(filePathL))
        {
          return null;
        }
      }
      return filePathL;
    }

    public void SwapTexture(string filePath)
    {
      try
      {
        var texBin = GetTextureBin(filePath);

        if (texBin == null) return;

        foreach (var item in dgTextures.SelectedItems)
        {
          var tex = item as TexturesTable.TextureData;

          tex.Data = texBin;
          tex.Size = tex.Data.Length.ToString("N0", CultureInfo.InvariantCulture);

          if (string.IsNullOrEmpty(tex.In))
          {
            if (containerData.FileType == 0)
              tex.In = "TMCL";
            else if (containerData.FileType == 1)
              tex.In = "--HL";
            else if (containerData.FileType == 2)
              tex.In = "--P";
          }

          tex.IsEmpty = false;
          tex.IsChanged = true;

          texTable.SetTextureBuffer(tex);
        }

        ddsPath = filePath;
        var selTex = dgTextures.SelectedItem as TexturesTable.TextureData;
        previewWindow.ShowPreview(selTex);
        modified = true;
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }
    }

    public byte[] GetTextureBin(string filePath)
    {
      try
      {
        if (!string.IsNullOrEmpty(filePath) && File.Exists(filePath) && Path.GetExtension(filePath).ToUpper() != "DDS")
        {
          using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read))
          using (MemoryStream ms = new MemoryStream())
          {
            fs.CopyTo(ms);

            return GetTextureFromStream(ms);
          }
        }
        return null;
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
        return null;
      }
    }

    private byte[] GetTextureFromStream(MemoryStream ms)
    {
      var br = new BinaryReader(ms, new ASCIIEncoding());
      br.BaseStream.Position = 0;
      string name = new string(br.ReadChars(8)).TrimEnd(char.MinValue);
      if (name == "DDS |")
        return ms.ToArray();

      return null;
    }

    private bool SetTextureFromStream(MemoryStream ms)
    {
      var bin = GetTextureFromStream(ms);

      foreach (var item in dgTextures.SelectedItems)
      {
        var tex = item as TexturesTable.TextureData;

        SetTextureInit(tex, bin);
      }
      return true;
    }

    private void SetTextureInit(TexturesTable.TextureData tex, byte[] bin)
    {
      tex.Data = bin;
      tex.Size = tex.Data.Length.ToString("N0", CultureInfo.InvariantCulture);

      if (string.IsNullOrEmpty(tex.In))
      {
        if (containerData.FileType == 0)
          tex.In = "TMCL";
        else if (containerData.FileType == 1)
          tex.In = "--HL";
        else if (containerData.FileType == 2)
          tex.In = "--P";
      }

      tex.IsEmpty = false;
      tex.IsChanged = true;

      texTable.SetTextureBuffer(tex);
    }

    private void SaveFile(string filePath)
    {
      this.IsEnabled = false;
      DoEvents();

      try
      {
        List<byte> exBn = new List<byte>();
        List<byte> exBnL = new List<byte>();

        List<byte> ttdmBn = BuildTtdm(exBnL);

        if (containerData.FileType == 0)
        {
          #region TMC
          // TMCファイルの場合
          string filePathL = Path.ChangeExtension(filePath, "." + AssociatedFiles[containerData.FileType]);
          /*
          if (File.Exists(filePathL))
          {
            string result = MessageWindow.Show(this, filePathL + "が既にあります\r\n" + txt["ConfirmOverwrite"], txt["Confirm"], txt["OverwriteYes"], txt["Cancel"]);
            if (result == "Cancel") return;
          }
          */

          Dictionary<int, List<byte>> partBn = new Dictionary<int, List<byte>>();
          int lastOffset = containerData.Header.Size;
          for (int i = containerData.Header.Count1 - 1; i >= 0; i--)
          {
            partBn[i] = new List<byte>();

            if (containerData.Header.Offsets[i] != 0)
            {
              partBn[i].AddRange(bn.Skip(containerData.Header.Offsets[i]).Take(lastOffset - containerData.Header.Offsets[i]));
              lastOffset = containerData.Header.Offsets[i];
            }
          }

          // for broken TMC
          if (containerData.Header.Count1 > 14 && containerData.Header.Offsets[14] != 0 && BitConverter.ToUInt32(bn, (int)containerData.Header.Offsets[14] + 8) != 0x01010000 && partBn[14].Count > 0x40)
          {
            partBn[14] = new List<byte>(new byte[0x40]);
          }

          // LHeader変更
          ReplaceByteList(partBn[7], BitConverter.GetBytes(exBnL.Count), 0x90);

          if (containerData.FileType == 0)
          {
            if (exBnL.Count % 0x80 != 0) exBnL.AddRange(new byte[0x80 - exBnL.Count % 0x80]);
          }
          else if (containerData.FileType == 3 || containerData.FileType == 4)
          {
            if (exBnL.Count % 0x40 != 0) exBnL.AddRange(new byte[0x40 - exBnL.Count % 0x40]);
          }


          // TMCLの先頭から0x80を持ってくる
          exBnL.InsertRange(0, bnL.Take(0x80));

          // 0x0100より小さければ0x0100になるように
          if (exBnL.Count < 0x100) exBnL.AddRange(new byte[0x100 - exBnL.Count]);

          // exBnLのサイズ変更
          ReplaceByteList(exBnL, BitConverter.GetBytes(exBnL.Count), 4);

          // MdlGeo テクスチャインデックス変更
          foreach (var tex in texTable.Tex)
          {
            if (tex.Use != 0)
            {
              foreach (var offset in containerData.TexOffsets[tex.OriginalID])
              {
                ReplaceByteList(partBn[0], BitConverter.GetBytes(tex.ID), offset);
              }
            }
          }

          // LHeader変更
          ReplaceByteList(partBn[7], BitConverter.GetBytes(exBnL.Count), 0x44);

          // 全体データの構築とHeaderのオフセットを変更
          exBn.AddRange(bn.Take(containerData.Header.Offsets[0]));
          for (int i = 0; i < containerData.Header.Count1; i++)
          {
            if (partBn[i].Count != 0)
            {
              // オフセットを変更
              ReplaceByteList(exBn, BitConverter.GetBytes(exBn.Count), containerData.Header.Offset1 + (i * 4));
            }
            if (i == 1)
              exBn.AddRange(ttdmBn);
            else
              exBn.AddRange(partBn[i]);
          }

          // Headerの全体サイズを変更
          ReplaceByteList(exBn, BitConverter.GetBytes(exBn.Count), 0x10);

          updateChecking = false;

          File.WriteAllBytes(filePath, exBn.ToArray());
          File.WriteAllBytes(filePathL, exBnL.ToArray());
          #endregion
        }
        else if (containerData.FileType == 1)
        {
          #region --H
          // --Hファイルの場合
          string filePathL = Path.ChangeExtension(filePath, "." + AssociatedFiles[containerData.FileType]);
          /*
          if (File.Exists(filePathL))
          {
            string result = MessageWindow.Show(this, filePathL + "が既にあります\r\n" + txt["ConfirmOverwrite"], txt["Confirm"], txt["OverwriteYes"], txt["Cancel"]);
            if (result == "Cancel") return;
          }
          */

          exBn.AddRange(bn.Take(containerData.Header.Offsets[1]));
          ReplaceByteList(exBn, BitConverter.GetBytes(texTable.Tex.Count), 0x108);

          int count = 0;
          foreach (var tex in texTable.Tex)
          {
            if (tex.IsEmpty)
            {
              exBn.AddRange(BitConverter.GetBytes(-1));
            }
            else
            {
              exBn.AddRange(BitConverter.GetBytes(count));
              count++;
            }
          }
          exBn.AddRange(new byte[containerData.Header.Offsets[2] - exBn.Count]);

          exBn.AddRange(ttdmBn);

          // Headerの全体サイズを変更
          ReplaceByteList(exBn, BitConverter.GetBytes(exBn.Count), 0x10);

          updateChecking = false;

          File.WriteAllBytes(filePath, exBn.ToArray());
          File.WriteAllBytes(filePathL, exBnL.ToArray());
          #endregion
        }
        else if (containerData.FileType == 2)
        {
          #region --P
          // --Pファイルの場合
          exBn.AddRange(bn.Take(containerData.Header.Offsets[0]));
          exBn.AddRange(exBnL);
          if (exBn.Count < 0x6000)
          {
            exBn.AddRange(new byte[0x6000 - exBn.Count]);
          }
          // HeaderのOffsets変更
          ReplaceByteList(exBn, BitConverter.GetBytes(exBn.Count), 0x34);

          exBn.AddRange(ttdmBn);

          // Headerの全体サイズを変更
          ReplaceByteList(exBn, BitConverter.GetBytes(exBn.Count), 0x10);

          updateChecking = false;

          File.WriteAllBytes(filePath, exBn.ToArray());
          #endregion
        }
        else if (containerData.FileType == 3)
        {
          #region SCN
          // SCNファイルの場合
          string filePathL = Path.ChangeExtension(filePath, "." + AssociatedFiles[containerData.FileType]);

          List<List<byte>> partBn = new List<List<byte>>();
          for (int i = 0; i < containerData.Header.Count1; i++)
          {
            var bin = new List<byte>();
            if (containerData.Header.Offsets[i] != 0)
            {
              bin.AddRange(bn.Skip(containerData.Header.Offsets[i]).Take(containerData.Header.Sizes[i]));
            }
            partBn.Add(bin);
          }

          var iblpkH = new HeaderData(0, partBn[0].ToArray());

          partBn[0] = partBn[0].Take(iblpkH.Offsets[1]).ToList();
          partBn[0].AddRange(ttdmBn);

          ReplaceByteList(partBn[0], BitConverter.GetBytes(partBn[0].Count), 0x10);

          exBn = BuildHeaderBaseBin("SCENE");
          BuildBin(exBn, partBn, null, true, true);

          updateChecking = false;

          File.WriteAllBytes(filePath, exBn.ToArray());
          File.WriteAllBytes(filePathL, exBnL.ToArray());
          #endregion
        }
        else if (containerData.FileType == 4)
        {
          #region SPR
          // SPRファイルの場合
          string filePathL = Path.ChangeExtension(filePath, "." + AssociatedFiles[containerData.FileType]);

          List<List<byte>> partBn = new List<List<byte>>();
          for (int i = 0; i < containerData.Header.Count1; i++)
          {
            partBn.Add(new List<byte>());
          }
          int lastOffset = containerData.Header.Size;
          for (int i = containerData.Header.Count1 - 1; i >= 0; i--)
          {
            if (containerData.Header.Offsets[i] != 0)
            {
              partBn[i].AddRange(bn.Skip(containerData.Header.Offsets[i]).Take(lastOffset - containerData.Header.Offsets[i]));
              lastOffset = containerData.Header.Offsets[i];
            }
          }

          partBn[0] = ttdmBn;

          exBn = BuildHeaderBaseBin("sprpack");
          BuildBin(exBn, partBn, null, false, true, 0x1000);

          updateChecking = false;

          File.WriteAllBytes(filePath, exBn.ToArray());
          File.WriteAllBytes(filePathL, exBnL.ToArray());
          #endregion
        }


        selectedTextureIndices = new List<int>();

        foreach (var item in dgTextures.SelectedItems)
        {
          var tex = item as TexturesTable.TextureData;
          selectedTextureIndices.Add(tex.ID);
        }

        // 再読み込み
        OpenFile(filePath);

        ShowTextBlockMessage(txt["Saved"]);

        updateChecking = true;
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }
      finally
      {
        this.IsEnabled = true;
      }
    }

    private List<byte> BuildTtdm(List<byte> exBnL)
    {
      List<TexturesTable.TextureData> texList = new List<TexturesTable.TextureData>();
      List<TexturesTable.TextureData> texListL = new List<TexturesTable.TextureData>();

      foreach (var tex in texTable.Tex)
      {
        if (tex.IsEmpty) continue;

        if (tex.In == "TMC" || tex.In == "--H" || tex.In == "SCN")
          texList.Add(tex);
        else
          texListL.Add(tex);
      }

      // TTDL
      var ttdlBn = BuildHeaderBaseBin("TTDL");
      ttdlBn.AddRange(new byte[0x20]);
      ttdlBn[0xC] = 0x50;
      if (texListL.Count > 0)
      {
        ReplaceByteList(ttdlBn, BitConverter.GetBytes(texListL.Count), 0x14);
        ReplaceByteList(ttdlBn, BitConverter.GetBytes(texListL.Count), 0x18);
        ReplaceByteList(ttdlBn, BitConverter.GetBytes(ttdlBn.Count), 0x20);
        int offsetOffsets = ttdlBn.Count;
        ttdlBn.AddRange(new byte[4 * ((texListL.Count + 3) / 4 * 4)]);
        ReplaceByteList(ttdlBn, BitConverter.GetBytes(ttdlBn.Count), 0x24);
        int offsetSizes = ttdlBn.Count;
        ttdlBn.AddRange(new byte[4 * ((texListL.Count + 3) / 4 * 4)]);
        exBnL.AddRange(new byte[0x40]);
        for (int i = 0; i < texListL.Count; i++)
        {
          if (exBnL.Count % 0x40 != 0) exBnL.AddRange(new byte[0x40 - exBnL.Count % 0x40]);
          ReplaceByteList(ttdlBn, BitConverter.GetBytes(exBnL.Count), offsetOffsets + (4 * i));
          ReplaceByteList(ttdlBn, BitConverter.GetBytes(texListL[i].Data.Length), offsetSizes + (4 * i));
          exBnL.AddRange(texListL[i].Data);
        }
      }
      else
      {
        exBnL.AddRange(new byte[0x10]);
      }

      if (exBnL.Count % 0x10 != 0) exBnL.AddRange(new byte[0x10 - exBnL.Count % 0x10]);

      ReplaceByteList(ttdlBn, BitConverter.GetBytes(texListL.Count), 0x40);
      ReplaceByteList(exBnL, BitConverter.GetBytes(texListL.Count), 0);
      ReplaceByteList(ttdlBn, BitConverter.GetBytes(exBnL.Count), 0x44);
      ReplaceByteList(exBnL, BitConverter.GetBytes(exBnL.Count), 4);
      ReplaceByteList(ttdlBn, BitConverter.GetBytes(containerData.FileID), 0x48);
      ReplaceByteList(exBnL, BitConverter.GetBytes(containerData.FileID), 8);

      //if (containerData.FileType == 0)
      //{
      //  if (exBnL.Count % 0x80 != 0) exBnL.AddRange(new byte[0x80 - exBnL.Count % 0x80]);
      //}
      //else if (containerData.FileType == 3 || containerData.FileType == 4)
      //{
      //  if (exBnL.Count % 0x40 != 0) exBnL.AddRange(new byte[0x40 - exBnL.Count % 0x40]);
      //}

      ReplaceByteList(ttdlBn, BitConverter.GetBytes(ttdlBn.Count), 0x10);


      // TTDH
      var ttdhBn = BuildHeaderBaseBin("TTDH");
      ttdhBn.AddRange(BitConverter.GetBytes(1));
      ttdhBn.AddRange(new byte[0xC]);
      int enableTexCount = texList.Count + texListL.Count;
      if (enableTexCount > 0)
      {
        ReplaceByteList(ttdhBn, BitConverter.GetBytes(enableTexCount), 0x14);
        ReplaceByteList(ttdhBn, BitConverter.GetBytes(enableTexCount), 0x18);
        ttdhBn[0x20] = 0x40;
        ttdhBn.AddRange(new byte[4 * ((enableTexCount + 3) / 4 * 4)]);

        int count = 0;
        int countL = 0;
        foreach (var tex in texTable.Tex)
        {
          if (tex.IsEmpty) continue;

          ReplaceByteList(ttdhBn, BitConverter.GetBytes(ttdhBn.Count), 0x40 + (4 * (count + countL)));

          if (tex.In == "TMC" || tex.In == "--H")
          {
            ttdhBn.AddRange(BitConverter.GetBytes(0));
            ttdhBn.AddRange(BitConverter.GetBytes(count));
            count++;
          }
          else
          {
            ttdhBn.AddRange(BitConverter.GetBytes(1));
            ttdhBn.AddRange(BitConverter.GetBytes(countL));
            countL++;
          }
          ttdhBn.AddRange(new byte[8]);
        }
      }
      ReplaceByteList(ttdhBn, BitConverter.GetBytes(ttdhBn.Count), 0x10);


      // TTDM
      var ttdmBn = BuildHeaderBaseBin("TTDM");
      ttdmBn.AddRange(ttdhBn);
      if (texList.Count > 0)
      {
        ReplaceByteList(ttdmBn, BitConverter.GetBytes(texList.Count), 0x14);
        ReplaceByteList(ttdmBn, BitConverter.GetBytes(texList.Count), 0x18);
        ReplaceByteList(ttdmBn, BitConverter.GetBytes(ttdmBn.Count), 0x20);
        int offsetOffsets = ttdmBn.Count;
        ttdmBn.AddRange(new byte[4 * ((texList.Count + 3) / 4 * 4)]);
        ReplaceByteList(ttdmBn, BitConverter.GetBytes(ttdmBn.Count), 0x24);
        int offsetSizes = ttdmBn.Count;
        ttdmBn.AddRange(new byte[4 * ((texList.Count + 3) / 4 * 4)]);

        ReplaceByteList(ttdmBn, BitConverter.GetBytes(ttdmBn.Count), 0x28);
        ttdmBn.AddRange(ttdlBn);

        for (int i = 0; i < texList.Count; i++)
        {
          if (ttdmBn.Count % 0x40 != 0) ttdmBn.AddRange(new byte[0x40 - ttdmBn.Count % 0x40]);
          ReplaceByteList(ttdmBn, BitConverter.GetBytes(ttdmBn.Count), offsetOffsets + (4 * i));
          ReplaceByteList(ttdmBn, BitConverter.GetBytes(texList[i].Data.Length), offsetSizes + (4 * i));
          ttdmBn.AddRange(texList[i].Data);
        }

        ttdmBn.AddRange(new byte[(0x10 - (ttdmBn.Count % 0x10)) % 0x10]);
      }
      else
      {
        ReplaceByteList(ttdmBn, BitConverter.GetBytes(ttdmBn.Count), 0x28);
        ttdmBn.AddRange(ttdlBn);
      }

      ReplaceByteList(ttdmBn, BitConverter.GetBytes(ttdmBn.Count), 0x10);

      return ttdmBn;
    }

    private string ExtractFileName(TexturesTable.TextureData tex)
    {
      return ExtractFileName(tex, "dds");
    }
    private string ExtractFileName(TexturesTable.TextureData tex, string ext)
    {
      string fileName = "";

      int digit = 2;
      if (texTable.Tex.Count > 100) digit = 3;

      if (containerData.FileType == 1)
      {
        fileName = "Tex_" + tex.ID.ToString("D" + digit) + "_H" + containerData.FileNum + "." + ext;
      }
      else if (containerData.FileType == 2)
      {
        fileName = Path.GetFileNameWithoutExtension(containerPath) + "_P." + ext;
      }
      else
      {
        fileName = "Tex_" + tex.ID.ToString("D" + digit) + "." + ext;
      }
      return fileName;
    }

    private string ExtractSingleTexture(TexturesTable.TextureData tex)
    {
      Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
      dlg.Filter = "DDS Files (.dds)|*.dds";
      dlg.InitialDirectory = extractPath;

      dlg.FileName = ExtractFileName(tex);

      if (dlg.ShowDialog() == true && !tex.IsEmpty && ExtractTexture(tex, dlg.FileName))
      {
        extractPath = dlg.FileName;
        return dlg.FileName;
      }
      else
      {
        return null;
      }
    }

    private bool ExtractTexture(TexturesTable.TextureData tex, string filePath)
    {
      try
      {
        if (tex == null || tex.Data == null) return false;
        string exFolder = Path.GetDirectoryName(filePath);
        if (!Directory.Exists(exFolder))
        {
          Directory.CreateDirectory(exFolder);
        }
        File.WriteAllBytes(filePath, tex.Data);
        return true;
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
        return false;
      }
    }


    #region Drop Extract

    DataGridRow curRow;

    private void dgTextures_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      if (Keyboard.Modifiers == ModifierKeys.Shift || Keyboard.Modifiers == ModifierKeys.Control)
      {
        isDraggingTex = false;
        return;
      }
      curRow = UIHelpers.TryFindFromPoint<DataGridRow>((UIElement)sender, e.GetPosition(dgTextures));
      if (curRow == null) return;

      var tex = curRow.Item as TexturesTable.TextureData;
      if (tex.Data != null) isDraggingTex = true;

      if (!dgTextures.SelectedItems.Contains(curRow.Item))
      {
        dgTextures.SelectedItem = curRow.Item;
        SetShiftSelectBase(dgTextures, curRow, 0);
      }
      e.Handled = true;
      offset = e.GetPosition(null);
    }

    private void dgTextures_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
      dgTextures.Focus();

      if (dgTextures.SelectedItem == null || !isDraggingTex) return;

      DataGridCellInfo cellInfo = new DataGridCellInfo(dgTextures.SelectedItem, dgTextures.Columns[0]);
      dgTextures.CurrentCell = cellInfo;

      if (curRow != null)
      {
        dgTextures.SelectedItem = curRow.Item;
        SetShiftSelectBase(dgTextures, curRow, 0);
      }
      isDraggingTex = false;
    }

    private void dgTextures_MouseMove(object sender, MouseEventArgs e)
    {
      if (dgTextures.SelectedItems.Count == 0 || !isDraggingTex) return;

      Point mousePos = e.GetPosition(null);
      Vector diff = offset - mousePos;

      if (e.LeftButton != MouseButtonState.Pressed ||
          (Math.Abs(diff.X) <= SystemParameters.MinimumHorizontalDragDistance &&
           Math.Abs(diff.Y) <= SystemParameters.MinimumVerticalDragDistance))
      {
        return;
      }

      string tempDir = System.AppDomain.CurrentDomain.BaseDirectory + @"\temp";
      List<string> exPaths = new List<string>();
      try
      {
        int hash = 0;
        while (Directory.Exists(tempDir))
        {
          hash++;
          tempDir += hash.ToString();
        }
        Directory.CreateDirectory(tempDir);
        var directoryInfo = new DirectoryInfo(tempDir);
        directoryInfo.Attributes |= FileAttributes.Hidden;

        foreach (var item in dgTextures.SelectedItems)
        {
          var tex = item as TexturesTable.TextureData;
          string fileName = ExtractFileName(tex);
          string exPath = tempDir + @"\" + fileName;
          if (!tex.IsEmpty && ExtractTexture(tex, exPath))
          {
            exPaths.Add(exPath);
          }
        }

        DataObject dataObj = new DataObject(DataFormats.FileDrop, exPaths.ToArray());
        DragDropEffects effects = DragDropEffects.Move;
        if (DragDrop.DoDragDrop(dgTextures, dataObj, effects) == effects)
        {
        }
      }
      catch (Exception ex)
      {
        MessageWindow.Show(this, ex.Message + "\r\n\r\n" + ex.StackTrace, txt["Error"]);
      }
      finally
      {
        try
        {
          isDraggingTex = false;

          foreach (var path in exPaths)
          {
            if (File.Exists(path))
            {
              File.Delete(path);
            }
          }
          if (Directory.Exists(tempDir) && Directory.GetFiles(tempDir, "*", SearchOption.TopDirectoryOnly).Length == 0)
          {
            Directory.Delete(tempDir);
          }
        }
        catch (Exception ex)
        {
          MessageWindow.Show(this, ex.Message + "\r\n\r\n" + ex.StackTrace, txt["Error"]);
        }
      }
    }
    #endregion



    public void CheckUpdated()
    {
      try
      {
        if (containerData == null || !System.IO.File.Exists(containerData.Path)) return;

        var lastWriteTime = System.IO.File.GetLastWriteTime(containerData.Path);
        if (containerData.WriteTime.CompareTo(lastWriteTime) != 0)
        {
          if (MessageWindow.Show(this, txt["ConfirmFileUpdated"] + "\r\n\r\n" + containerData.Path, txt["Confirm"], txt["Yes"], txt["No"]) == MessageWindow.Result.OK)
          {
            int selIndex = dgTextures.SelectedIndex;
            OpenFile(containerData.Path);
            if (selIndex < texTable.Tex.Count && selIndex != -1) dgTextures.SelectedIndex = selIndex;
          }
          else
          {
            containerData.WriteTime = lastWriteTime;
          }
        }
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }
    }
  }

  public class BoolToVisibleConveter : IValueConverter
  {
    public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      if (value == null)
      {
        return Visibility.Collapsed;
      }
      else if ((bool)value)
      {
        return Visibility.Visible;
      }
      else
      {
        return Visibility.Collapsed;
      }
    }

    public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      throw new NotImplementedException();
    }
  }
}
