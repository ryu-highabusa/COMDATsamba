﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Data;
using System.ComponentModel;
using NaturalSort;

namespace Texture_Tool
{
  /// <summary>
  /// EditMaterialWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class AddTextureWindow : Window
  {
    private static Dictionary<string, string> txt = new Dictionary<string, string>();

    private static AddTextureData data;

    private static HashSet<string> files;

    private static bool dialogResult;

    private bool IsActivated = false;

    public AddTextureWindow()
    {
      InitializeComponent();

      this.MouseLeftButtonDown += (sender, e) => this.DragMove();
      this.ShowInTaskbar = false;

      txt = MainWindow.txt;

      btnOk.Content = txt["OK"];
      btnCancel.Content = txt["Cancel"];

      labelAddDestination.Content = txt["AddDestination"];
      labelAddCount.Content = txt["AddCount"];
      labelAddContent.Content = txt["AddContent"];
      rbTop.Content = txt["Top"];
      rbBottom.Content = txt["Bottom"];
      rbOverID.Content = txt["OverID"];
      rbUnderID.Content = txt["UnderID"];
      rbAddNew.Content = txt["AddNew"];
      rbAddFile.Content = txt["AddFile"];
    }

    private void Window_DragOver(object sender, DragEventArgs e)
    {
      e.Handled = true;
      if (e.Data.GetDataPresent(DataFormats.FileDrop))
      {
        if ((e.KeyStates & DragDropKeyStates.ControlKey) != 0)
          e.Effects = DragDropEffects.Copy;
        else
          e.Effects = DragDropEffects.Move;
      }
      else
      {
        e.Effects = DragDropEffects.None;
      }
    }

    private void Window_DragDrop(object sender, DragEventArgs e)
    {
      string[] filePaths = (string[])e.Data.GetData(DataFormats.FileDrop, false);

      if (files.Count > 0 && e.KeyStates != DragDropKeyStates.ControlKey) files.Clear();

      foreach (string filePath in filePaths)
      {
        if (Path.GetExtension(filePath).ToLower() != ".dds") continue;

        files.Add(filePath);
      }

      data.CurrentPath = files.ToList()[files.Count - 1];

      data.AddCount = (uint)files.Count;

      data.IsFile = true;
    }

    private void okCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (data != null && ((data.IsNew && data.AddCount > 0) || (data.IsFile && files.Count > 0)))
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    public void okCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      dialogResult = true;
      this.Close();
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = false;
    }

    private void tbName_KeyDown(object sender, KeyEventArgs e)
    {
      TextBox tb = sender as TextBox;
      ModifierKeys modifierKeys = Keyboard.Modifiers;

      if (e.Key == Key.System || e.Key == Key.Tab)
      {
        e.Handled = false;
      }
      else if ((Key.D0 <= e.Key && e.Key <= Key.D9) || (Key.NumPad0 <= e.Key && e.Key <= Key.NumPad9))
      {
        e.Handled = false;
      }
      else if (e.Key == Key.Enter && btnOk.IsEnabled)
      {
        e.Handled = true;
        dialogResult = true;
        this.Close();
      }
      else
      {
        e.Handled = true;
      }
    }

    private void tb_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (target == null) return;
      target.SelectAll();
    }

    private void referCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (data != null && data.IsFile)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    public void referCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var dlg = new Microsoft.Win32.OpenFileDialog();
      dlg.Filter = "DDS Images (*.DDS)|*.DDS";
      dlg.Multiselect = true;
      if (!string.IsNullOrEmpty(data.CurrentPath))
      {
        dlg.InitialDirectory = Path.GetDirectoryName(data.CurrentPath);
        dlg.FileName = Path.GetFileName(data.CurrentPath);
      }
      if (dlg.ShowDialog() != true) return;

      if (files.Count > 0) files.Clear();

      foreach (string filePath in dlg.FileNames)
      {
        files.Add(filePath);
      }

      data.CurrentPath = dlg.FileName;

      data.AddCount = (uint)files.Count;
    }



    public static AddTextureData Show(Window owner, AddTextureData addTextureData)
    {
      AddTextureWindow dlg = new AddTextureWindow();
      dlg.Owner = owner;
      dlg.Owner.IsEnabled = false;

      files = new HashSet<string>();

      data = addTextureData;
      dlg.DataContext = data;

      if (data.SelectedCount == 1)
      {
        data.IsUnderID = true;
        data.SingleSelected = true;
      }

      MainWindow.DoEvents();

      dlg.tbCount.Focus();
      dlg.tbCount.SelectAll();


      dlg.IsActivated = false;
      dlg.ShowDialog();

      if (data.IsFile)
        data.Files = files.OrderBy(f => f, new NaturalStringComparer()).ToList();
      else
        data.Files = new List<string>();

      dlg.Owner.IsEnabled = true;
      dlg.Owner.Focus();

      if (dialogResult)
      {
        return data;
      }
      else
      {
        return null;
      }
    }

    private void Window_Activated(object sender, EventArgs e)
    {
      if (!IsActivated) IsActivated = true;
    }

    private void Window_Closing(object sender, CancelEventArgs e)
    {
      e.Cancel = true;
      IsActivated = false;
      this.Hide();
      if (this.Owner != null) this.Owner.Activate();
    }
  }
}
