﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Windows.Data;
using System.Windows.Media;
using ImageUtilities;

namespace Texture_Tool
{
  public class HeaderData
  {
    public HeaderData(int Start, byte[] bin)
    {
      this.Start = Start;
      this.Offsets = new List<int>(0);
      this.Sizes = new List<int>(0);

      if (BitConverter.ToUInt32(bin, Start + 0x08) != 0x01010000) return;

      char[] charsToTrim = { '\0' };
      this.Name = Encoding.ASCII.GetString(bin, Start, 8).TrimEnd(charsToTrim);
      this.Flg1 = BitConverter.ToUInt32(bin, Start + 0x08);
      this.HSize = BitConverter.ToInt32(bin, Start + 0x0C);
      this.Size = BitConverter.ToInt32(bin, Start + 0x10);
      this.Count1 = BitConverter.ToInt32(bin, Start + 0x14);
      this.Count2 = BitConverter.ToInt32(bin, Start + 0x18);
      this.Count3 = BitConverter.ToInt32(bin, Start + 0x1C);
      this.Offset1 = BitConverter.ToInt32(bin, Start + 0x20);
      this.Offset2 = BitConverter.ToInt32(bin, Start + 0x24);
      this.Offset3 = BitConverter.ToInt32(bin, Start + 0x28);
      this.Flg2 = BitConverter.ToUInt32(bin, Start + 0x2C);

      for (int i = 0; i < this.Count1; i++)
      {
        this.Offsets.Add(BitConverter.ToInt32(bin, Start + this.Offset1 + (i * 0x04)));
      }

      if (this.Offset2 > 0)
      {
        for (int i = 0; i < this.Count1; i++)
        {
          this.Sizes.Add(BitConverter.ToInt32(bin, Start + this.Offset2 + (i * 0x04)));
        }
      }
    }

    public int Start { get; set; }
    public string Name { get; set; }
    public uint Flg1 { get; set; }
    public int HSize { get; set; }
    public int Size { get; set; }
    public int Count1 { get; set; }
    public int Count2 { get; set; }
    public int Count3 { get; set; }
    public int Offset1 { get; set; }
    public int Offset2 { get; set; }
    public int Offset3 { get; set; }
    public uint Flg2 { get; set; }

    public List<int> Offsets { get; private set; }
    public List<int> Sizes { get; private set; }
  }

  public class ContainerData
  {
    public ContainerData()
    {
      this.TexOffsets = new Dictionary<int, List<int>>();
      this.Tex = new List<Textures>();
    }

    public void ParseTextureTmcData(byte[] bin)
    {
      this.FileType = 0;
      this.Header = new HeaderData(0, bin);

      // for broken TMC
      this.Header.Size = bin.Length;
      if (this.Header.Count1 > 15 && this.Header.Offsets[15] != 0 && BitConverter.ToUInt32(bin, this.Header.Offsets[15] + 8) != 0x01010000)
      {
        this.Header.Offsets[15] = 0;
      }

      var mdlGeoH = new HeaderData(this.Header.Offsets[0], bin);
      for (int i = 0; i < mdlGeoH.Count1; i++)
      {
        var objGeoH = new HeaderData(mdlGeoH.Start + mdlGeoH.Offsets[i], bin);

        for (int j = 0; j < objGeoH.Count1; j++)
        {
          int start = objGeoH.Start + objGeoH.Offsets[j];
          int texCount = BitConverter.ToInt32(bin, start + 0xC);

          for (int k = 0; k < texCount; k++)
          {
            int texOffset = BitConverter.ToInt32(bin, start + 0x10 + (4 * k));
            int texNum = BitConverter.ToInt32(bin, start + texOffset + 8);
            if (TexOffsets.ContainsKey(texNum))
            {
              TexOffsets[texNum].Add(mdlGeoH.Offsets[i] + objGeoH.Offsets[j] + texOffset + 8);
            }
            else
            {
              List<int> offsets = new List<int>();
              offsets.Add(mdlGeoH.Offsets[i] + objGeoH.Offsets[j] + texOffset + 8);
              TexOffsets[texNum] = offsets;
            }
          }
        }
      }

      var lHeaderH = new HeaderData(this.Header.Offsets[7], bin);
      int lOffset = BitConverter.ToInt32(bin, lHeaderH.Start + lHeaderH.Offset1);

      var ttdmH = new HeaderData(this.Header.Offsets[1], bin);
      var ttdhH = new HeaderData(this.Header.Offsets[1] + ttdmH.HSize, bin);
      var ttdlH = new HeaderData(this.Header.Offsets[1] + ttdmH.Offset3, bin);

      this.FileID = BitConverter.ToUInt32(bin, ttdlH.Start + 0x48);

      for (int i = 0; i < ttdhH.Count1; i++)
      {
        var newTex = new Textures();

        newTex.ID = i;
        newTex.AbsoluteID = i;
        newTex.InL = (BitConverter.ToInt32(bin, ttdhH.Start + ttdhH.Offsets[i]) == 1) ? true : false;
        newTex.RelativeID = BitConverter.ToInt32(bin, ttdhH.Start + ttdhH.Offsets[i] + 4);

        if (newTex.InL)
        {
          newTex.Offset = ttdlH.Offsets[newTex.RelativeID];
          newTex.Start = lOffset + newTex.Offset;
          newTex.Size = ttdlH.Sizes[newTex.RelativeID];
        }
        else
        {
          newTex.Offset = ttdmH.Offsets[newTex.RelativeID];
          newTex.Start = ttdmH.Start + newTex.Offset;
          newTex.Size = ttdmH.Sizes[newTex.RelativeID];
        }

        this.Tex.Add(newTex);
      }
    }

    public void ParseTextureHData(byte[] bin)
    {
      this.FileType = 1;
      this.Header = new HeaderData(0, bin);

      int texCount = BitConverter.ToInt32(bin, this.Header.Offsets[0] + 8);

      var ttdmH = new HeaderData(this.Header.Offsets[2], bin);
      var ttdhH = new HeaderData(this.Header.Offsets[2] + ttdmH.HSize, bin);
      var ttdlH = new HeaderData(this.Header.Offsets[2] + ttdmH.Offset3, bin);

      this.FileID = BitConverter.ToUInt32(bin, ttdlH.Start + 0x48);

      for (int i = 0; i < texCount; i++)
      {
        var newTex = new Textures();

        newTex.ID = i;
        newTex.AbsoluteID = BitConverter.ToInt32(bin, this.Header.Offsets[1] + (4 * i));

        if (newTex.AbsoluteID != -1)
        {
          newTex.InL = (BitConverter.ToInt32(bin, ttdhH.Start + ttdhH.Offsets[newTex.AbsoluteID]) == 1) ? true : false;
          newTex.RelativeID = BitConverter.ToInt32(bin, ttdhH.Start + ttdhH.Offsets[newTex.AbsoluteID] + 4);

          if (newTex.InL)
          {
            newTex.Offset = ttdlH.Offsets[newTex.RelativeID];
            newTex.Start = newTex.Offset;
            newTex.Size = ttdlH.Sizes[newTex.RelativeID];
            if (ttdlH.Count1 < newTex.RelativeID)
            {
              int lSize = BitConverter.ToInt32(bin, ttdlH.Start + 0x44);
            }
          }
          else
          {
            newTex.Offset = ttdmH.Offsets[newTex.RelativeID];
            newTex.Start = ttdmH.Start + newTex.Offset;
            newTex.Size = ttdmH.Sizes[newTex.RelativeID];
          }
        }

        this.Tex.Add(newTex);
      }
    }

    public void ParseTexturePData(byte[] bin)
    {
      this.FileType = 2;
      this.Header = new HeaderData(0, bin);

      var ttdmH = new HeaderData(this.Header.Offsets[1], bin);
      var ttdhH = new HeaderData(this.Header.Offsets[1] + ttdmH.HSize, bin);
      var ttdlH = new HeaderData(this.Header.Offsets[1] + ttdmH.Offset3, bin);

      this.FileID = BitConverter.ToUInt32(bin, ttdlH.Start + 0x48);

      for (int i = 0; i < ttdhH.Count1; i++)
      {
        var newTex = new Textures();

        newTex.ID = i;
        newTex.AbsoluteID = i;
        newTex.InL = (BitConverter.ToInt32(bin, ttdhH.Start + ttdhH.Offsets[i]) == 1) ? true : false;
        newTex.RelativeID = BitConverter.ToInt32(bin, ttdhH.Start + ttdhH.Offsets[i] + 4);

        if (newTex.InL)
        {
          newTex.Offset = ttdlH.Offsets[newTex.RelativeID];
          newTex.Start = this.Header.Offsets[0] + newTex.Offset;
          newTex.Size = ttdlH.Sizes[newTex.RelativeID];
        }
        else
        {
          newTex.Offset = ttdmH.Offsets[newTex.RelativeID];
          newTex.Start = this.Header.Offsets[0] + newTex.Offset;
          newTex.Size = ttdmH.Sizes[newTex.RelativeID];
        }

        this.Tex.Add(newTex);
      }
    }

    public void ParseTextureScnData(byte[] bin)
    {
      this.FileType = 3;
      this.Header = new HeaderData(0, bin);

      var iblpkH = new HeaderData(this.Header.Offsets[0], bin);
      if (iblpkH.Count1 < 2 || iblpkH.Offsets[1] == 0) return;

      var ttdmH = new HeaderData(iblpkH.Start + iblpkH.Offsets[1], bin);
      var ttdhH = new HeaderData(iblpkH.Start + iblpkH.Offsets[1] + ttdmH.HSize, bin);
      var ttdlH = new HeaderData(iblpkH.Start + iblpkH.Offsets[1] + ttdmH.Offset3, bin);

      this.FileID = BitConverter.ToUInt32(bin, ttdlH.Start + 0x48);

      for (int i = 0; i < ttdhH.Count1; i++)
      {
        var newTex = new Textures();

        newTex.ID = i;
        newTex.AbsoluteID = i;
        newTex.InL = (BitConverter.ToInt32(bin, ttdhH.Start + ttdhH.Offsets[i]) == 1) ? true : false;
        newTex.RelativeID = BitConverter.ToInt32(bin, ttdhH.Start + ttdhH.Offsets[i] + 4);

        if (newTex.InL)
        {
          newTex.Offset = ttdlH.Offsets[newTex.RelativeID];
          newTex.Start = newTex.Offset;
          newTex.Size = ttdlH.Sizes[newTex.RelativeID];
        }
        else
        {
          newTex.Offset = ttdmH.Offsets[newTex.RelativeID];
          newTex.Start = ttdmH.Start + newTex.Offset;
          newTex.Size = ttdmH.Sizes[newTex.RelativeID];
        }

        this.Tex.Add(newTex);
      }
    }

    public void ParseTextureSprData(byte[] bin)
    {
      this.FileType = 4;
      this.Header = new HeaderData(0, bin);
      if (this.Header.Offsets[1] == 0) return;

      var ttdmH = new HeaderData(this.Header.Offsets[0], bin);
      var ttdhH = new HeaderData(this.Header.Offsets[0] + ttdmH.HSize, bin);
      var ttdlH = new HeaderData(this.Header.Offsets[0] + ttdmH.Offset3, bin);

      this.FileID = BitConverter.ToUInt32(bin, ttdlH.Start + 0x48);

      for (int i = 0; i < ttdhH.Count1; i++)
      {
        var newTex = new Textures();

        newTex.ID = i;
        newTex.AbsoluteID = i;
        newTex.InL = (BitConverter.ToInt32(bin, ttdhH.Start + ttdhH.Offsets[i]) == 1) ? true : false;
        newTex.RelativeID = BitConverter.ToInt32(bin, ttdhH.Start + ttdhH.Offsets[i] + 4);

        if (newTex.InL)
        {
          newTex.Offset = ttdlH.Offsets[newTex.RelativeID];
          newTex.Start = newTex.Offset;
          newTex.Size = ttdlH.Sizes[newTex.RelativeID];
        }
        else
        {
          newTex.Offset = ttdmH.Offsets[newTex.RelativeID];
          newTex.Start = ttdmH.Start + newTex.Offset;
          newTex.Size = ttdmH.Sizes[newTex.RelativeID];
        }

        this.Tex.Add(newTex);
      }

      if (Encoding.ASCII.GetString(bin, this.Header.Offsets[1], 7) == "texinfo")
      {
        this.InfoCount = BitConverter.ToInt32(bin, this.Header.Offsets[1] + 0x10);
        for (int i = 0; i < this.InfoCount; i++)
        {
          this.Tex[i].Palette = BitConverter.ToInt32(bin, this.Header.Offsets[1] + 0x20 + 0x0C * i + 4);
          this.Tex[i].PalettePos = BitConverter.ToSingle(bin, this.Header.Offsets[1] + 0x20 + 0x0C * i + 8);
        }
      }
    }

    public string Path { get; set; }
    public DateTime WriteTime { get; set; }

    public int FileType { get; private set; }
    public uint FileID { get; private set; }
    public string FileNum { get; set; }
    public int InfoCount { get; set; }

    public HeaderData Header { get; private set; }

    public Dictionary<int, List<int>> TexOffsets { get; private set; }

    public List<Textures> Tex { get; private set; }
  }

  public class Textures
  {
    public Textures()
    {
      this.Palette = -1;
      this.PalettePos = -1;
    }

    public int Offset { get; set; }
    public int Start { get; set; }
    public int Size { get; set; }
    public int ID { get; set; }
    public int AbsoluteID { get; set; }
    public int RelativeID { get; set; }
    public bool InL { get; set; }
    public int Palette { get; set; }
    public float PalettePos { get; set; }
  }



  public class TexturesTable : NotifyPropertyChangedBase
  {
    public TexturesTable()
    {
      this.Tex = new ObservableCollection<TextureData>();

      // 複数スレッドからコレクション操作できるようにする
      BindingOperations.EnableCollectionSynchronization(this.Tex, new object());

      IsEnabled = true;
      ProgressBarMaximum = 100;
      ProgressBarValue = 0;
      TextStatusBrush = MainWindow.textBrush;
    }

    public void SetTexture(ContainerData data, byte[] bin, byte[] binL)
    {
      if (data.FileType == 0)
      {
        int lSize = BitConverter.ToInt32(binL, 4);
        int lSizeTex = BitConverter.ToInt32(binL, 0x84);
      }

      ProgressBarMaximum = data.Tex.Count;
      ProgressBarValue = 0;

      foreach (var tex in data.Tex)
      {
        if (IsCancel)
        {
          return;
        }

        var newTex = new TextureData();
        newTex.ID = tex.ID;
        newTex.OriginalID = tex.ID;
        newTex.AbsoluteID = tex.AbsoluteID;
        newTex.RelativeID = tex.RelativeID;
        if (data.TexOffsets.Count != 0)
        {
          if (data.TexOffsets.ContainsKey(tex.ID))
            newTex.Use = data.TexOffsets[tex.ID].Count;
          else
            newTex.Use = 0;
        }

        if (newTex.AbsoluteID == -1)
        {
          newTex.IsEmpty = true;
          this.Tex.Add(newTex);
          ProgressBarValue += 1;
          continue;
        }

        newTex.Size = tex.Size.ToString("N0", CultureInfo.InvariantCulture);

        newTex.In = MainWindow.SupportedFiles[data.FileType].Replace(".", "");

        if (tex.InL && data.FileType != 2)
        {
          newTex.In = MainWindow.AssociatedFiles[data.FileType];
          newTex.Data = binL.Skip(tex.Start).Take(tex.Size).ToArray();
        }
        else
        {
          newTex.Data = bin.Skip(tex.Start).Take(tex.Size).ToArray();
        }

        SetTextureBuffer(newTex);

        this.Tex.Add(newTex);
        ProgressBarValue += 1;
      }

      if (data.InfoCount > 0)
      {
        this.BuildPaletteSets(data.InfoCount);

        if (this.PaletteSets == null) return;

        for (int i = 0; i < this.Tex.Count; i++)
        {
          if (data.Tex[i].Palette == -1 || data.Tex[i].PalettePos == -1) continue;

          int line = (int)Math.Floor(this.Tex[data.Tex[i].Palette].Height * data.Tex[i].PalettePos);
          this.Tex[i].Palette = this.PaletteSets[data.Tex[i].Palette - data.InfoCount][line];
        }
      }
    }

    public void SetTextureBuffer(TextureData tex)
    {
      if (tex.Data != null)
      {
        int dwFourCC = BitConverter.ToInt32(tex.Data, 0x54);
        if (dwFourCC == 0)
        {
          int bitCount = BitConverter.ToInt32(tex.Data, 0x58);
          if (bitCount == 0x18)
            tex.Type = "RGB24";
          else if (bitCount == 0x20)
            tex.Type = "RGBA32";
          else if (bitCount == 0x08)
            tex.Type = "RGB8";
        }
        else if (dwFourCC < 256)
        {
          tex.Type = "0x" + BitConverter.ToInt32(tex.Data, 0x54).ToString("X2");
        }
        else
        {
          char[] charsToTrim = { '\0' };
          tex.Type = Encoding.ASCII.GetString(tex.Data, 0x54, 4).TrimEnd(charsToTrim);
        }

        tex.Width = BitConverter.ToInt32(tex.Data, 0x10);
        tex.Height = BitConverter.ToInt32(tex.Data, 0x0C);
        tex.Depth = BitConverter.ToInt32(tex.Data, 0x18);
      }
    }

    public void ResetTexture(ContainerData data, TextureData texData, byte[] bin, byte[] binL)
    {
      Textures tex = data.Tex[texData.OriginalID];

      texData.IsChanged = false;

      if (tex.AbsoluteID == -1)
      {
        texData.In = "";
        texData.Type = "";
        texData.Size = "";
        texData.Width = -1;
        texData.Height = -1;
        texData.IsEmpty = true;
        texData.Data = null;
        return;
      }

      texData.Size = tex.Size.ToString("N0", CultureInfo.InvariantCulture);

      if (tex.InL)
      {
        if (data.FileType == 0 || data.FileType == 1)
          texData.Data = binL.Skip(tex.Start).Take(tex.Size).ToArray();
        else
          texData.Data = bin.Skip(tex.Start).Take(tex.Size).ToArray();
      }
      else
      {
        texData.Data = bin.Skip(tex.Start).Take(tex.Size).ToArray();
      }

      texData.IsEmpty = false;
      SetTextureBuffer(texData);
    }

    public void AddTexture(int newID)
    {
      var newTex = new TextureData();
      newTex.ID = newID;
      newTex.IsEmpty = true;
      newTex.IsChanged = true;
      this.Tex.Insert(newID, newTex);
    }

    public void BuildPaletteSets(int infoCount)
    {
      this.PaletteSets = new List<List<byte[][]>>();

      for (int i = infoCount; i < this.Tex.Count; i++)
      {
        if (this.Tex[i].Type != "RGBA32")
        {
          this.PaletteSets.Add(null);
          continue;
        }

        System.Drawing.Bitmap bitmap = null;
        try
        {
          bitmap = DDS.GetBitmapArray(this.Tex[i].Data)[0];

          System.Drawing.Imaging.BitmapData data = bitmap.LockBits(
              new System.Drawing.Rectangle(0, 0, bitmap.Width, bitmap.Height),
              System.Drawing.Imaging.ImageLockMode.ReadWrite,
              System.Drawing.Imaging.PixelFormat.Format32bppArgb);
          byte[] buf = new byte[bitmap.Width * bitmap.Height * 4];
          System.Runtime.InteropServices.Marshal.Copy(data.Scan0, buf, 0, buf.Length);

          var paletteSet = new List<byte[][]>();

          for (int j = 0; j < this.Tex[i].Height; j++)
          {
            var palette = new byte[256][];

            int x = 0;
            for (int k = bitmap.Width * j * 4; k < bitmap.Width * (j + 1) * 4; k += 4)
            {
              palette[x] = new byte[4] { buf[k], buf[k + 1], buf[k + 2], buf[k + 3] };
              x++;
            }

            paletteSet.Add(palette);
          }

          bitmap.UnlockBits(data);

          this.PaletteSets.Add(paletteSet);
        }
        catch (Exception e)
        {
          Console.WriteLine(e);
          this.PaletteSets.Add(null);
          continue;
        }
      }
    }



    private bool _IsEnabled;
    public bool IsEnabled
    {
      get { return _IsEnabled; }
      set
      {
        _IsEnabled = value;
        OnPropertyChanged(nameof(IsEnabled));

        InProgress = !value;
      }
    }

    private bool _IsEnabledExtFolder;
    public bool IsEnabledExtFolder
    {
      get { return _IsEnabledExtFolder; }
      set
      {
        _IsEnabledExtFolder = value;
        OnPropertyChanged(nameof(IsEnabledExtFolder));
      }
    }

    private bool _IsEnabledPanel2nd;
    public bool IsEnabledPanel2nd
    {
      get { return _IsEnabledPanel2nd; }
      set
      {
        _IsEnabledPanel2nd = value;
        OnPropertyChanged(nameof(IsEnabledPanel2nd));
      }
    }

    private bool _IsEnabledExtractAllFolder;
    public bool IsEnabledExtractAllFolder
    {
      get { return _IsEnabledExtractAllFolder; }
      set
      {
        _IsEnabledExtractAllFolder = value;
        OnPropertyChanged(nameof(IsEnabledExtractAllFolder));
      }
    }

    private bool _IsVisibleMoveToL;
    public bool IsVisibleMoveToL
    {
      get { return _IsVisibleMoveToL; }
      set
      {
        _IsVisibleMoveToL = value;
        OnPropertyChanged(nameof(IsVisibleMoveToL));
      }
    }

    private bool _IsEnabledPreview;
    public bool IsEnabledPreview
    {
      get { return _IsEnabledPreview; }
      set
      {
        _IsEnabledPreview = value;
        OnPropertyChanged(nameof(IsEnabledPreview));
      }
    }

    private bool _IsEnabledDgTextures;
    public bool IsEnabledDgTextures
    {
      get { return _IsEnabledDgTextures; }
      set
      {
        _IsEnabledDgTextures = value;
        OnPropertyChanged(nameof(IsEnabledDgTextures));
      }
    }


    private bool _InProgress;
    public bool InProgress
    {
      get { return _InProgress; }
      set
      {
        _InProgress = value;
        OnPropertyChanged(nameof(InProgress));
      }
    }

    private bool _IsCancel;
    public bool IsCancel
    {
      get { return _IsCancel; }
      set
      {
        _IsCancel = value;
        OnPropertyChanged(nameof(IsCancel));
      }
    }

    private bool _IsSuspended;
    public bool IsSuspended
    {
      get { return _IsSuspended; }
      set
      {
        _IsSuspended = value;
        OnPropertyChanged(nameof(IsSuspended));
      }
    }

    private string _OpenOtherFilePath;
    public string OpenOtherFilePath
    {
      get { return _OpenOtherFilePath; }
      set
      {
        _OpenOtherFilePath = value;
        OnPropertyChanged(nameof(OpenOtherFilePath));
      }
    }


    private string _ExtFolder;
    public string ExtFolder
    {
      get { return _ExtFolder; }
      set
      {
        _ExtFolder = value;
        OnPropertyChanged(nameof(ExtFolder));
      }
    }

    private string _HeaderMoveToL;
    public string HeaderMoveToL
    {
      get { return _HeaderMoveToL; }
      set
      {
        _HeaderMoveToL = value;
        OnPropertyChanged(nameof(HeaderMoveToL));
      }
    }

    private string _TextStatus;
    public string TextStatus
    {
      get { return _TextStatus; }
      set
      {
        _TextStatus = value;
        OnPropertyChanged(nameof(TextStatus));
      }
    }

    private string _TextStatusToolTip;
    public string TextStatusToolTip
    {
      get { return _TextStatusToolTip; }
      set
      {
        _TextStatusToolTip = value;
        OnPropertyChanged(nameof(TextStatusToolTip));
      }
    }

    private Brush _TextStatusBrush;
    public Brush TextStatusBrush
    {
      get { return _TextStatusBrush; }
      set
      {
        _TextStatusBrush = value;
        OnPropertyChanged(nameof(TextStatusBrush));
      }
    }

    private int _ProgressBarMaximum;
    public int ProgressBarMaximum
    {
      get { return _ProgressBarMaximum; }
      set
      {
        _ProgressBarMaximum = value;
        OnPropertyChanged(nameof(ProgressBarMaximum));
      }
    }

    private int _ProgressBarValue;
    public int ProgressBarValue
    {
      get { return _ProgressBarValue; }
      set
      {
        _ProgressBarValue = value;
        OnPropertyChanged(nameof(ProgressBarValue));
      }
    }



    public ObservableCollection<TextureData> Tex { get; set; }

    public List<List<byte[][]>> PaletteSets { get; private set; }

    public class TextureData : NotifyPropertyChangedBase
    {
      public TextureData()
      {
        this.ID = -1;
        this.OriginalID = -1;
        this.AbsoluteID = -1;
        this.RelativeID = -1;
        this.Use = -1;
        this.Width = -1;
        this.Height = -1;
        this.Depth = -1;
        this.Palette = null;
      }

      private int _ID;
      public int ID
      {
        get { return _ID; }
        set
        {
          _ID = value;
          OnPropertyChanged(nameof(ID));
        }
      }
      public int OriginalID { get; set; }
      public int AbsoluteID { get; set; }
      public int RelativeID { get; set; }

      private int _Use;
      public int Use
      {
        get { return _Use; }
        set
        {
          _Use = value;
          OnPropertyChanged(nameof(Use));
        }
      }
      private string _In;
      public string In
      {
        get { return _In; }
        set
        {
          _In = value;
          OnPropertyChanged(nameof(In));
        }
      }
      private string _Type;
      public string Type
      {
        get { return _Type; }
        set
        {
          _Type = value;
          OnPropertyChanged(nameof(Type));
        }
      }
      private int _Width;
      public int Width
      {
        get { return _Width; }
        set
        {
          _Width = value;
          OnPropertyChanged(nameof(Width));
        }
      }
      private int _Height;
      public int Height
      {
        get { return _Height; }
        set
        {
          _Height = value;
          OnPropertyChanged(nameof(Height));
        }
      }
      public int Depth { get; set; }
      private string _Size;
      public string Size
      {
        get { return _Size; }
        set
        {
          _Size = value;
          OnPropertyChanged(nameof(Size));
        }
      }

      private bool _IsChanged;
      public bool IsChanged
      {
        get { return _IsChanged; }
        set
        {
          _IsChanged = value;
          OnPropertyChanged(nameof(IsChanged));
        }
      }
      private bool _IsEmpty;
      public bool IsEmpty
      {
        get { return _IsEmpty; }
        set
        {
          _IsEmpty = value;
          OnPropertyChanged(nameof(IsEmpty));
        }
      }

      public byte[] Data { get; set; }
      public byte[][] Palette { get; set; }
    }
  }



  public class AddTextureData : NotifyPropertyChangedBase
  {
    public AddTextureData()
    {
      Ids = new ObservableCollection<int>();
      Files = new List<string>();

      IsBottom = true;
      IsNew = true;
      AddCount = 1;
    }

    private void ChangeStateOverUnder()
    {
      if (IsOverID || IsUnderID)
        IsSelectableID = true;
      else
        IsSelectableID = false;
    }


    private bool _IsTop;
    public bool IsTop
    {
      get { return _IsTop; }
      set
      {
        _IsTop = value;
        OnPropertyChanged(nameof(IsTop));
      }
    }

    private bool _IsBottom;
    public bool IsBottom
    {
      get { return _IsBottom; }
      set
      {
        _IsBottom = value;
        OnPropertyChanged(nameof(IsBottom));
      }
    }

    private bool _IsOverID;
    public bool IsOverID
    {
      get { return _IsOverID; }
      set
      {
        _IsOverID = value;
        OnPropertyChanged(nameof(IsOverID));
        ChangeStateOverUnder();
      }
    }

    private bool _IsUnderID;
    public bool IsUnderID
    {
      get { return _IsUnderID; }
      set
      {
        _IsUnderID = value;
        OnPropertyChanged(nameof(IsUnderID));
        ChangeStateOverUnder();
      }
    }

    private bool _SingleSelected;
    public bool SingleSelected
    {
      get { return _SingleSelected; }
      set
      {
        _SingleSelected = value;
        OnPropertyChanged(nameof(SingleSelected));
      }
    }

    private bool _IsSelectableID;
    public bool IsSelectableID
    {
      get { return _IsSelectableID; }
      set
      {
        _IsSelectableID = value;
        OnPropertyChanged(nameof(IsSelectableID));
      }
    }

    private int _SelectedId;
    public int SelectedId
    {
      get { return _SelectedId; }
      set
      {
        _SelectedId = value;
        OnPropertyChanged(nameof(SelectedId));
      }
    }

    public ObservableCollection<int> Ids { get; set; }

    public int SelectedCount { get; set; }


    private uint _AddCount;
    public uint AddCount
    {
      get { return _AddCount; }
      set
      {
        _AddCount = value;
        OnPropertyChanged(nameof(AddCount));
      }
    }


    private bool _IsNew;
    public bool IsNew
    {
      get { return _IsNew; }
      set
      {
        _IsNew = value;
        OnPropertyChanged(nameof(IsNew));
      }
    }

    private bool _IsFile;
    public bool IsFile
    {
      get { return _IsFile; }
      set
      {
        _IsFile = value;
        OnPropertyChanged(nameof(IsFile));
      }
    }

    public List<string> Files { get; set; }

    public string CurrentPath { get; set; }
  }



  public class NotifyPropertyChangedBase : INotifyPropertyChanged
  {
    public event PropertyChangedEventHandler PropertyChanged;
    public void OnPropertyChanged(string name)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(name));
      }
    }
  }
}
