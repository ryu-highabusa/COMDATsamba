﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.ComponentModel;
using System.Collections.ObjectModel;


namespace Texture_Tool
{
  /// <summary>
  /// OptionWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class PreviewWindow : Window
  {
    private static Dictionary<string, string> txt = new Dictionary<string, string>();


    private bool IsActivated = false;



    public PreviewWindow()
    {
      InitializeComponent();

      this.MouseLeftButtonDown += (sender, e) => this.DragMove();
      this.ShowInTaskbar = false;

    }

    public static void lang(Dictionary<string, string> langText)
    {
      txt = langText;
    }

    //public static bool? Show(Window Owner, string Message, string Title, string OkText, string CancelText)
    public bool Show(Window owner)
    {
      this.Owner = owner;

      if (this.ActualHeight != 0)
      {
        this.Top = owner.Top + (owner.ActualHeight / 2) - (this.ActualHeight / 2);
        this.Left = owner.Left + (owner.ActualWidth / 2) - (this.ActualWidth / 2);
      }

      this.Show();
      return true;
    }



    private void Window_Activated(object sender, EventArgs e)
    {
      if (!IsActivated)
      {
        var story = (System.Windows.Media.Animation.Storyboard)this.FindResource("fadeIn");
        story.Begin();
        IsActivated = true;

        this.SizeToContent = SizeToContent.Height;
        if (this.ActualHeight > this.Owner.ActualHeight - 10)
        {
          this.MaxHeight = this.Owner.ActualHeight - 10;
          this.SizeToContent = SizeToContent.Manual;
        }
        this.Top = this.Owner.Top + (this.Owner.ActualHeight / 2) - (this.ActualHeight / 2);
        this.Left = this.Owner.Left + (this.Owner.ActualWidth / 2) - (this.ActualWidth / 2);
        this.MaxHeight = Double.PositiveInfinity;
      }
    }

    private void FadeInAnimation_Completed(object sender, EventArgs e)
    {
      var story = (System.Windows.Media.Animation.Storyboard)this.FindResource("fadeIn");
      story.Stop();
    }

    private void Window_Closing(object sender, CancelEventArgs e)
    {
      e.Cancel = true;

      var story = (System.Windows.Media.Animation.Storyboard)this.FindResource("fadeOut");
      story.Begin();
    }

    private void Window_Hide()
    {
      var story = (System.Windows.Media.Animation.Storyboard)this.FindResource("fadeOut");
      story.Begin();
    }

    private void FadeOutAnimation_Completed(object sender, EventArgs e)
    {
      var story = (System.Windows.Media.Animation.Storyboard)this.FindResource("fadeOut");
      story.Stop();

      this.Hide();
      this.Owner.Activate();
    }
  }
}
