﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using ImageUtilities;
using Message;

namespace Texture_Tool
{
  /// <summary>
  /// EditMaterialWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class PreviewWindow : Window
  {
    private static Dictionary<string, string> txt = new Dictionary<string, string>();

    private static int texWidth;
    private static int texHeight;
    private static Point _startPoint;
    private static Point _startPosition;

    private static bool dragFlag;

    private MainWindow mainWindow;

    public PreviewWindow()
    {
      InitializeComponent();

      this.MouseLeftButtonDown += (sender, e) => this.DragMove();
      this.ShowInTaskbar = false;

      txt = MainWindow.txt;

      btnOption.Content = txt["Option"];
      cbFullScale.Header = txt["FullScale"];
      cbFixedWindowSize.Header = txt["FixedWindowSize"];
      cbUsePalette.Header = txt["UsePalette"];
    }

    private void previewWindow_Loaded(object sender, RoutedEventArgs e)
    {
      this.Width = mainWindow.ActualHeight - 30;
      this.Height = mainWindow.ActualHeight;
    }

    private void previewWindow_Activated(object sender, EventArgs e)
    {
      if (mainWindow.updateChecking)
      {
        mainWindow.updateChecking = false;
        mainWindow.CheckUpdated();
        mainWindow.updateChecking = true;
      }
    }

    private void Window_DragOver(object sender, DragEventArgs e)
    {
      e.Handled = true;
      if (e.Data.GetDataPresent(DataFormats.FileDrop))
      {
        e.Effects = DragDropEffects.Copy;
      }
      else
      {
        e.Effects = DragDropEffects.None;
      }
    }

    private void Window_Drop(object sender, DragEventArgs e)
    {
      List<string> filePaths = ((string[])e.Data.GetData(DataFormats.FileDrop, false)).ToList();
      mainWindow.OpenDorpFile(filePaths);
      this.Activate();
      mainWindow.Focus();
    }

    private void previewWindow_SizeChanged(object sender, SizeChangedEventArgs e)
    {
      if (cbFullScale.IsChecked == true)
      {
        if (svImage.ActualWidth < image.ActualWidth || svImage.ActualHeight < image.ActualHeight)
        {
          svImage.IsHitTestVisible = true;
        }
        else
        {
          svImage.IsHitTestVisible = false;
        }
      }
      else
      {
        if (svImage.ActualWidth >= texWidth && svImage.ActualHeight >= texHeight)
        {
          image.Width = texWidth;
          image.Height = texHeight;
        }
        else
        {
          svImage.HorizontalScrollBarVisibility = ScrollBarVisibility.Hidden;
          svImage.VerticalScrollBarVisibility = ScrollBarVisibility.Hidden;
          image.Width = svImage.ActualWidth;
          image.Height = svImage.ActualHeight;
          svImage.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
          svImage.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
        }
        svImage.IsHitTestVisible = false;
      }
    }

    private void previewWindow_ContextMenuOpening(object sender, ContextMenuEventArgs e)
    {
      mainWindow.dgTextures_ContextMenuOpening(sender, e);
    }

    private void exitCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      e.CanExecute = true;
    }
    private void exitCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      mainWindow.Close();
    }

    private void openCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      e.CanExecute = true;
    }
    private void openCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      mainWindow.openCommand_Executed(sender, e);
    }

    private void saveCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      e.CanExecute = mainWindow.saveCommand_CanExecute_Check();
    }
    private void saveCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      mainWindow.saveCommand_Executed(sender, e);
    }

    private void saveAsCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      e.CanExecute = mainWindow.saveAsCommand_CanExecute_Check();
    }
    private void saveAsCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      mainWindow.saveAsCommand_Executed(sender, e);
    }

    private void extractAllCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      e.CanExecute = mainWindow.saveAsCommand_CanExecute_Check();
    }
    private void extractAllCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      mainWindow.extractAllCommand_Executed(sender, e);
    }

    private void texDeleteCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      mainWindow.texDeleteCommand_CanExecute(e);
    }
    private void texDeleteCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      mainWindow.texDelete();
    }

    private void texCopyCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      mainWindow.texCopyCommand_CanExecute(e);
    }
    private void texCopyCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      mainWindow.texCopy();
    }

    private void texPasteCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      mainWindow.texPasteCommand_CanExecute(e);
    }
    public void texPasteCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      mainWindow.texPaste();
    }


    
    private void Button_Click(object sender, RoutedEventArgs e)
    {
      this.Hide();
      if (this.Owner != null) this.Owner.Activate();

      var mainWindow = this.Owner as MainWindow;
      mainWindow.cbPreview.IsChecked = false;
    }

    private void cbFullScale_Checked(object sender, RoutedEventArgs e)
    {
      if (!this.IsInitialized) return;

      image.Width = texWidth;
      image.Height = texHeight;
      if (cbFixedWindowSize.IsChecked == false)
        this.SizeToContent = SizeToContent.WidthAndHeight;
      else
      {
        this.SizeToContent = SizeToContent.Manual;
        svImage.IsHitTestVisible = true;
      }
    }

    private void cbFullScale_Unchecked(object sender, RoutedEventArgs e)
    {
      if (svImage.ActualWidth >= texWidth && svImage.ActualHeight >= texHeight)
      {
        image.Width = texWidth;
        image.Height = texHeight;
      }
      else
      {
        svImage.HorizontalScrollBarVisibility = ScrollBarVisibility.Hidden;
        svImage.VerticalScrollBarVisibility = ScrollBarVisibility.Hidden;
        image.Width = svImage.ActualWidth;
        image.Height = svImage.ActualHeight;
        svImage.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
        svImage.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
      }
      this.SizeToContent = SizeToContent.Manual;
      svImage.IsHitTestVisible = false;
    }

    private void ScrollViewer_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      if (!(e.Source is Image)) return;

      dragFlag = true; // ドラッグ開始
      _startPoint = e.GetPosition((ScrollViewer)sender);

      ScrollViewer scrollViewer = (ScrollViewer)sender;
      _startPosition = new Point(scrollViewer.HorizontalOffset, scrollViewer.VerticalOffset);

      scrollViewer.CaptureMouse();
    }

    private void ScrollViewer_MouseMove(object sender, MouseEventArgs e)
    {
      if (dragFlag)
      {
        ScrollViewer scrollViewer = (ScrollViewer)sender;
        Point point = e.GetPosition((ScrollViewer)sender);
        if (scrollViewer.PanningMode == PanningMode.Both)
        {
          scrollViewer.ScrollToVerticalOffset(_startPosition.Y + (point.Y - _startPoint.Y) * -1);
          scrollViewer.ScrollToHorizontalOffset(_startPosition.X + (point.X - _startPoint.X) * -1);
        }
        else if (scrollViewer.PanningMode == PanningMode.VerticalFirst | scrollViewer.PanningMode == PanningMode.VerticalOnly)
        {
          scrollViewer.ScrollToVerticalOffset(_startPosition.Y + (point.Y - _startPoint.Y) * -1);
        }
        else if (scrollViewer.PanningMode == PanningMode.HorizontalFirst | scrollViewer.PanningMode == PanningMode.HorizontalOnly)
        {
          scrollViewer.ScrollToHorizontalOffset(_startPosition.X + (point.X - _startPoint.X) * -1);
        }
      }
    }

    private void ScrollViewer_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
      dragFlag = false; // ドラッグ終了
      svImage.ReleaseMouseCapture();
    }

    private void cb_StatusChanged(object sender, RoutedEventArgs e)
    {
      if (!this.IsInitialized) return;

      if (mainWindow.cbPreview.IsChecked == true && mainWindow.dgTextures.SelectedItem != null)
      {
        var tex = mainWindow.dgTextures.SelectedItem as TexturesTable.TextureData;
        previewWindow.ShowPreview(tex);
      }
    }

    private void cmbChannel_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (!this.IsInitialized) return;

      if (mainWindow.cbPreview.IsChecked == true && mainWindow.dgTextures.SelectedItem != null)
      {
        var tex = mainWindow.dgTextures.SelectedItem as TexturesTable.TextureData;
        previewWindow.ShowPreview(tex);
      }
    }



    public void Show(Window owner)
    {
      this.Owner = owner;
      mainWindow = owner as MainWindow;

      this.Top = owner.Top;
      this.Left = owner.Left + owner.ActualWidth;

      this.Show();
    }

    public void ShowPreview(TexturesTable.TextureData tex)
    {
      var bitmap = GetBitmap(tex);

      if (bitmap == null) return;

      var format = System.Drawing.Imaging.ImageFormat.Png;
      //var format = System.Drawing.Imaging.ImageFormat.Bmp;
      //if (channel == "RGBA") format = System.Drawing.Imaging.ImageFormat.Png;

      using (Stream st = new MemoryStream())
      {
        bitmap.Save(st, format);
        st.Seek(0, SeekOrigin.Begin);
        image.Source = BitmapFrame.Create(st, BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
      }

      bitmap.Dispose();

      if (svImage.ActualWidth >= tex.Width && svImage.ActualHeight >= tex.Height)
      {
        image.Width = tex.Width;
        image.Height = tex.Height;
      }
      else
      {
        image.Width = svImage.ActualWidth;
        image.Height = svImage.ActualHeight;
      }

      svImage.IsHitTestVisible = false;
      if (cbFullScale.IsChecked == true)
      {
        image.Width = tex.Width;
        image.Height = tex.Height;
        if (cbFixedWindowSize.IsChecked == true)
        {
          this.SizeToContent = SizeToContent.Manual;
          svImage.IsHitTestVisible = true;
        }
        else
        {
          this.SizeToContent = SizeToContent.WidthAndHeight;
        }
      }
      else
      {
        this.SizeToContent = SizeToContent.Manual;
      }
    }

    public System.Drawing.Bitmap GetBitmap(TexturesTable.TextureData tex)
    {
      if (tex.IsEmpty)
      {
        image.Source = null;
        return null;
      }

      texWidth = tex.Width;
      texHeight = tex.Height;

      if (tex.Depth >= 2)
      {
        cbVolumeMap2nd.IsEnabled = true;
      }
      else
      {
        cbVolumeMap2nd.IsEnabled = false;
      }

      int z = 0;
      if (cbVolumeMap2nd.IsEnabled && cbVolumeMap2nd.IsChecked == true) z = 1;
      System.Drawing.Bitmap bitmap = null;
      try
      {
        bitmap = DDS.GetBitmapArray(tex.Data)[z];
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }

      if (bitmap == null)
      {
        image.Source = null;
        return null;
      }

      cbUsePalette.IsEnabled = false;

      var itemChannel = cmbChannel.SelectedItem as ComboBoxItem;
      var channel = itemChannel.Content.ToString();

      if (bitmap.PixelFormat == System.Drawing.Imaging.PixelFormat.Format24bppRgb)
      {
        cmbItemAlpha.IsEnabled = false;
        if (channel == "A")
        {
          image.Source = null;
          return null;
        }
      }
      else if (bitmap.PixelFormat == System.Drawing.Imaging.PixelFormat.Format8bppIndexed && tex.Palette != null)
      {
        cbUsePalette.IsEnabled = true;

        if (cbUsePalette.IsChecked == true)
        {
          System.Drawing.Imaging.ColorPalette palette = bitmap.Palette;
          for (int i = 0; i < palette.Entries.Length; ++i)
          {
            var clr = System.Drawing.Color.FromArgb(tex.Palette[i][3], tex.Palette[i][2], tex.Palette[i][1], tex.Palette[i][0]);
            palette.Entries[i] = clr;
          }
          bitmap.Palette = palette;
        }
      }
      else
      {
        cmbItemAlpha.IsEnabled = true;
      }

      bitmap = ChangeToChannel(bitmap, channel);

      return bitmap;
    }

    private System.Drawing.Bitmap ChangeToChannel(System.Drawing.Bitmap bitmap, string channel)
    {
      //描画先とするImageオブジェクトを作成する
      var newBitmap = new System.Drawing.Bitmap(bitmap.Width, bitmap.Height);

      //ImageオブジェクトのGraphicsオブジェクトを作成する
      var g = System.Drawing.Graphics.FromImage(newBitmap);

      float[][] matrixElement =
        {
          new float[]{1, 0, 0, 0, 0},
          new float[]{0, 1, 0, 0, 0},
          new float[]{0, 0, 1, 0, 0},
          new float[]{0, 0, 0, 1, 0},
          new float[]{0, 0, 0, 1, 1}
        };
      switch (channel)
      {
        case "RGB":
          matrixElement[3] = new float[] { 0, 0, 0, 0, 0 };
          break;
        case "RGBAW":
          matrixElement[4][3] = 0;
          break;
        case "R":
          matrixElement[0] = new float[] { 1, 1, 1, 1, 0 };
          matrixElement[1][1] = 0;
          matrixElement[2][2] = 0;
          matrixElement[3][3] = 0;
          break;
        case "G":
          matrixElement[0][0] = 0;
          matrixElement[1] = new float[] { 1, 1, 1, 1, 0 };
          matrixElement[2][2] = 0;
          matrixElement[3][3] = 0;
          break;
        case "B":
          matrixElement[0][0] = 0;
          matrixElement[1][1] = 0;
          matrixElement[2] = new float[] { 1, 1, 1, 1, 0 };
          matrixElement[3][3] = 0;
          break;
        case "A":
          matrixElement[0][0] = 0;
          matrixElement[1][1] = 0;
          matrixElement[2][2] = 0;
          matrixElement[3] = new float[] { 1, 1, 1, 1, 0 };
          break;
        default:
          g.Dispose();
          return bitmap;
      }

      //ColorMatrixオブジェクトの作成
      var cm = new System.Drawing.Imaging.ColorMatrix(matrixElement);

      //ImageAttributesオブジェクトの作成
      var ia = new System.Drawing.Imaging.ImageAttributes();

      //ColorMatrixを設定する
      ia.SetColorMatrix(cm);

      var rect = new System.Drawing.Rectangle(0, 0, bitmap.Width, bitmap.Height);
      if (channel == "RGBAW") g.FillRectangle(System.Drawing.Brushes.White, rect);

      //ImageAttributesを使用して画像を描画
      g.DrawImage(bitmap, rect, 0, 0, bitmap.Width, bitmap.Height, System.Drawing.GraphicsUnit.Pixel, ia);

      //リソースを解放する
      bitmap.Dispose();
      g.Dispose();

      return newBitmap;
    }
  }
}
