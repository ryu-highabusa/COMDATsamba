
!!! Caution !!!

If you downloaded from direct url, this might be old version.
Check this url.
https://www.mediafire.com/folder/9zi2gt8dyllaj/doa5mod

You are not permitted to use this tool without your agreement of the following document.
https://www.mediafire.com/folder/rbhtrb7pjlrgr/License -> License.txt

You need to install .NET Framework 4.5.x or 4.6.x.
https://msdn.microsoft.com/library/5a4x27ek.aspx



How to enable Language.dat (Delete file extension.)

Language.dat.disable => Language.dat



Table

Changed -> Green
Empty   -> Grey Text

ID   : ID
Use  : Use Count (TMC File Only)
In   : Texture is in the File
Type : Type of Texture
W    : Width of Texture
H    : Height of Texture
Size : Data Size of Texture



Context Menu

Swap...             : Swap DDS File
Extract...          : Extract DDS File(s)
Save View as PNG... : Save View Image as PNG File (Vissible when Preview Window)
Add...              : Add Texture Slot (Enabled when TMC/--H File)
Delete              : Delete Texture Slot (Enabled when Unused and TMC/--H File)
Copy                : Copy Data
Paste               : Paste Data
Clear               : Clear Texture (Enabled when --H File)
Cancel Changed      : Cancel Changed



Preview Window Menu

Option
- Full Scale
- Fixed Window Size
- Use Palette(Not Applied When Extracting) ... SPR File Only

RGB   : Display RGB Channel(Without Transparent)
A     : Display Alpha Channel Only
R     : Display Red Channel Only
G     : Display Green Channel Only
B     : Display Blue Channel Only
RGBA  : Display RGB and Alpha Channel
RGBAW : Display RGB and Alpha Channel(Background is white)

2nd : For Volume Map



Sorry, more detailed information is not in English.

Please forgive me my lousy English.
(I was using Google a lot.)





Copyright 2015-now, dtk mnr

Released under the GPL v3.0 License.
http://www.gnu.org/licenses/gpl-3.0.txt
