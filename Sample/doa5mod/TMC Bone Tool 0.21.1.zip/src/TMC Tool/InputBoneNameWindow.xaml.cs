﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.ComponentModel;

namespace TMC_Tool
{
  /// <summary>
  /// EditMaterialWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class InputBoneNameWindow : Window
  {
    private static Dictionary<string, string> txt = new Dictionary<string, string>();

    private static bool dialogResult;

    private bool IsActivated = false;

    public InputBoneNameWindow()
    {
      InitializeComponent();

      this.MouseLeftButtonDown += (sender, e) => this.DragMove();
      this.ShowInTaskbar = false;

      txt = MainWindow.txt;

      title.Text = txt["inputBoneNameTitle"];
      labelReferenceBone.Content = txt["labelReferenceBone"];
      btnOk.Content = txt["OK"];
      btnCancel.Content = txt["Cancel"];
    }

    private void btnOk_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = true;
      this.Close();
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = false;
    }

    private void tbName_KeyDown(object sender, KeyEventArgs e)
    {
      TextBox tb = sender as TextBox;

      if (e.Key == Key.Enter && btnOk.IsEnabled == true)
      {
        dialogResult = true;
        this.Close();
      }
      if (e.Key == Key.System || e.Key == Key.Tab)
      {
        e.Handled = false;
      }
      else if ((Key.D0 <= e.Key && e.Key <= Key.D9) || (Key.NumPad0 <= e.Key && e.Key <= Key.NumPad9))
      {
        e.Handled = false;
      }
      else if (e.Key.GetHashCode() >= 44 && e.Key.GetHashCode() <= 69)
      {
        e.Handled = false;
      }
      else if (e.Key == Key.OemBackslash && (Keyboard.Modifiers & ModifierKeys.Shift) != ModifierKeys.None)
      {
        e.Handled = false;
      }
      else
      {
        e.Handled = true;
      }
    }

    private void tbName_KeyUp(object sender, KeyEventArgs e)
    {
      CheckObjGrpName();
    }

    private void tb_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (target == null) return;
      target.SelectAll();
    }



    public static string Show(Window owner, MainViewModel.BoneData bone)
    {
      var dlg = new InputBoneNameWindow();
      dlg.Owner = owner;
      dlg.Owner.IsEnabled = false;
      dlg.btnOk.IsEnabled = false;

      if (dlg.ActualHeight != 0)
      {
        dlg.Top = owner.Top + (owner.ActualHeight / 2) - (dlg.ActualHeight / 2);
        dlg.Left = owner.Left + (owner.ActualWidth / 2) - (dlg.ActualWidth / 2);
      }

      dlg.tbName.Focus();
      dlg.tbName.SelectionStart = dlg.tbName.Text.Length;

      if (bone != null) dlg.textReferenceBone.Text = bone.Name;

      dlg.IsActivated = false;
      dlg.ShowDialog();

      dlg.Owner.IsEnabled = true;
      dlg.Owner.Focus();

      if (dialogResult)
      {
        return dlg.tbName.Text;
      }
      else
      {
        return null;
      }
    }

    public void CheckObjGrpName()
    {
      var bones = new List<MainViewModel.BoneData>(MainWindow.vm.Bones);
      int idx = Array.FindIndex(bones.ToArray(), node => node.Name == tbName.Text);

      if (idx == -1)
        btnOk.IsEnabled = true;
      else
        btnOk.IsEnabled = false;
    }



    private void Window_Activated(object sender, EventArgs e)
    {
      if (!IsActivated) IsActivated = true;
    }

    private void Window_Closing(object sender, CancelEventArgs e)
    {
      e.Cancel = true;
      IsActivated = false;
      this.Hide();
      if (this.Owner != null) this.Owner.Activate();
    }
  }
}
