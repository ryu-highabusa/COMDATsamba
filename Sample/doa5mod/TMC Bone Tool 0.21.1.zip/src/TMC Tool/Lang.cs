﻿using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows;

namespace TMC_Tool
{
  public partial class MainWindow : Window
  {

    private void changeLanguage()
    {
      Dictionary<string, string> language = new Dictionary<string, string>();
      txt["btnOpen"] = "開く";
      txt["OK"] = "OK";
      txt["Cancel"] = "キャンセル";
      txt["Yes"] = "はい";
      txt["No"] = "いいえ";
      txt["Info"] = "情報";
      txt["Error"] = "エラー";
      txt["Caution"] = "注意";
      txt["Confirm"] = "確認";
      txt["Message"] = "メッセージ";
      txt["textStatus"] = "ファイルを開いて下さい";
      txt["ExitWithoutSave"] = "変更後保存されていません。このまま終了しますか？";
      txt["Exit"] = "終了する";
      txt["UnsupportedArea"] = "";
      txt["Overwrite"] = "ファイルを上書きしますか？";
      txt["OverwriteYes"] = "上書きする";
      txt["Saved"] = "保存しました";
      txt["UnsupportedFile"] = "対応しているファイルではありません";
      txt["FailedToReopen"] = "再読込に失敗しました";
      txt["ConfirmOpenFile"] = "このファイルを開きますか？";
      txt["ConfirmFileUpdated"] = "下記ファイルが更新されました。開きなおしますか？";

      txt["textOpenBone"] = "ボーンデータを開いて下さい";
      txt["textRootNotExist"] = "保存できません　親が無いボーンを設定するか「親子関係を変更」のチェックを外して下さい";

      txt["Export"] = "エクスポート";
      txt["Exported"] = "ボーンデータをエクスポートしました";

      txt["ErrorCheckNothing"] = "チェックが入った項目がありません。リストにチェックを入れて下さい。";

      txt["AlreadyExists"] = "同じ名前のファイルが既にあります。別名で保存しますか？";
      txt["SaveAs"] = "別名で保存する";

      txt["Delete"] = "削除";
      txt["TmcData"] = "TMCデータ";
      txt["BoneData"] = "ボーンデータ";
      txt["CustomData"] = "カスタム";

      txt["dgcPhysicsBonesName"] = "ボーン名";
      txt["dgcPhysicsBonesParent"] = "親ボーン名";
      txt["dgcPhysicsBonesSpring"] = "速度減衰";
      txt["dgcPhysicsBonesElastic"] = "弾性係数";
      txt["dgcPhysicsBonesFriction"] = "摩擦係数";
      txt["dgcPhysicsBonesBending"] = "癖係数";

      txt["Weight"] = "重さ";
      txt["Unknown"] = "不明";

      txt["dgcPhysicsCollisionsCode"] = "コリジョン コード";

      txt["FillDown"] = "下方向へコピー";

      txt["ErrorSameCode"] = "同じコードは設定できません。";

      //txt["ReferenceNode"] = "参照するノード";
      txt["ReferenceNode"] = "補正先MOT";
      txt["ReferenceAxis"] = "参照軸";
      txt["Coefficient"] = "回転補正係数";
      //txt["ParentNode"] = "親ノード";
      txt["ParentNode"] = "補正元MOT";
      txt["FlagDisplay"] = "表示フラグ";
      txt["FlagGlasses"] = "眼鏡フラグ";

      txt["inputBoneNameTitle"] = "ボーン名を入力";
      txt["labelReferenceBone"] = "元にするボーン :";



      string filePath = System.AppDomain.CurrentDomain.BaseDirectory + @"\Language.dat";
      if (!File.Exists(filePath))
      {
        return;
      }

      using (var sr = new StreamReader(filePath))
      {
        while (!sr.EndOfStream)
        {
          string[] inLine = sr.ReadLine().Split('\t');
          if (inLine.Length == 0)
          {
            continue;
          }
          else if (inLine[0] == "Type")
          {
            langType = inLine[2].Trim();
          }
          else if (inLine[0] == langType)
          {
            language[inLine[1].Trim()] = inLine[2].Trim();
          }
        }

        List<string> keys = new List<string>();
        foreach (var key in txt.Keys)
        {
          keys.Add(key);
        }
        foreach (string key in keys)
        {
          if (language.ContainsKey(key)) txt[key] = Regex.Unescape(language[key]);
        }

        if (language.ContainsKey("btnOpen")) btnOpen.Content = btnOpenBone.Content = language["btnOpen"];
        if (language.ContainsKey("btnSave"))
        {
          btnSave.Content = language["btnSave"];
          cmdSave.Header = language["btnSave"];
        }
        if (language.ContainsKey("SaveWithBackup")) cmdSaveWithBackup.Header = language["SaveWithBackup"];
        if (language.ContainsKey("btnSaveAs")) btnSaveAs.Content = language["btnSaveAs"];
        if (language.ContainsKey("Export")) btnExport.Content = language["Export"];
        if (language.ContainsKey("Clear")) btnClearBoneData.Content = language["Clear"];

        if (language.ContainsKey("Copy")) menuCustompCopy.Header = language["Copy"];
        if (language.ContainsKey("Paste")) menuCustompPaste.Header = language["Paste"];

        if (language.ContainsKey("Add")) btnCustompAdd.Content = language["Add"];
        if (language.ContainsKey("Delete"))
        {
          menuBoneDelete.Header = language["Delete"];
          btnCustompDelete.Content = language["Delete"];
        }
        if (language.ContainsKey("Undelete")) menuBoneUndelete.Header = language["Undelete"];

        if (language.ContainsKey("Type"))
        {
          dgcCollisionType.Header = language["Type"];
          dgcPhysicsType.Header = language["Type"];
          dgcCustompType.Header = language["Type"];
        }

        if (language.ContainsKey("Code"))
        {
          dgcCollisionCode.Header = language["Code"];
          dgcCustompCode.Header = language["Code"];
        }


        if (language.ContainsKey("gbTMC")) gbTMC.Header = language["gbTMC"];
        if (language.ContainsKey("gbBone")) gbBone.Header = language["gbBone"];

        if (language.ContainsKey("tabHeaderBone")) tabHeaderBone.Text = language["tabHeaderBone"];
        if (language.ContainsKey("tabHeaderCollision")) tabHeaderCollision.Text = language["tabHeaderCollision"];
        if (language.ContainsKey("tabHeaderPhysics")) tabHeaderPhysics.Text = language["tabHeaderPhysics"];

        if (language.ContainsKey("gbTarget")) gbTarget.Header = language["gbTarget"];
        if (language.ContainsKey("gbReCalc")) gbReCalc.Header = language["gbReCalc"];
        if (language.ContainsKey("rbHie")) rbHie.Content = language["rbHie"];
        if (language.ContainsKey("rbGlbl")) rbGlbl.Content = language["rbGlbl"];
        if (language.ContainsKey("cbParentage")) cbParentage.Content = language["cbParentage"];
        if (language.ContainsKey("AddBoneBased")) menuBoneAdd.Header = language["AddBoneBased"];

        if (language.ContainsKey("labelPreset"))
        {
          labelPreset.Content = language["labelPreset"];
          labelPresetCollision.Content = language["labelPreset"];
        }
        if (language.ContainsKey("cmbItemManual"))
        {
          cmbItemManual.Content = language["cmbItemManual"];
          cmbColItemManual.Content = language["cmbItemManual"];
        }
        if (language.ContainsKey("cmbItemAll")) cmbItemAll.Content = language["cmbItemAll"];
        if (language.ContainsKey("cmbItemBase")) cmbItemBase.Content = language["cmbItemBase"];
        if (language.ContainsKey("cmbItemOther")) cmbItemOther.Content = language["cmbItemOther"];
        if (language.ContainsKey("cmbItemDeselect")) cmbItemDeselect.Content = language["cmbItemDeselect"];
        if (language.ContainsKey("cmbColItemReplace")) cmbColItemReplace.Content = language["cmbColItemReplace"];
        if (language.ContainsKey("cmbColItemMerge")) cmbColItemMerge.Content = language["cmbColItemMerge"];
        if (language.ContainsKey("cmbColItemOrigin")) cmbColItemOrigin.Content = language["cmbColItemOrigin"];

        if (language.ContainsKey("dgcBone")) dgcBone.Header = language["dgcBone"];
        if (language.ContainsKey("dgcRefer")) dgcReferHeader.Text = language["dgcRefer"];
        if (language.ContainsKey("dgcParent")) dgcParent.Header = language["dgcParent"];

        if (language.ContainsKey("dgcCollision")) dgcCollision.Header = language["dgcCollision"];
        if (language.ContainsKey("dgcSetCollision")) dgcSetCollision.Header = language["dgcSetCollision"];

        if (language.ContainsKey("Rotation"))
        {
          vissibleRotation.Content = language["Rotation"];
          dgcColRotX.Header = language["Rotation"] + "X";
          dgcColRotY.Header = language["Rotation"] + "Y";
          dgcColRotZ.Header = language["Rotation"] + "Z";
        }
        if (language.ContainsKey("Size"))
        {
          vissibleSize.Content = language["Size"];
          dgcColSizeX.Header = language["Size"] + "X";
          dgcColSizeY.Header = language["Size"] + "Y";
          dgcColSizeZ.Header = language["Size"] + "Z";
        }
        if (language.ContainsKey("Position"))
        {
          vissiblePosition.Content = language["Position"];
          dgcColPosX.Header = language["Position"] + "X";
          dgcColPosY.Header = language["Position"] + "Y";
          dgcColPosZ.Header = language["Position"] + "Z";
        }


        if (language.ContainsKey("dgcRecalc")) dgcRecalc.Header = language["dgcRecalc"];
        if (language.ContainsKey("dgcPhysicsColType")) dgcPhysicsColType.Header = language["dgcPhysicsColType"];
        if (language.ContainsKey("Unknown"))
        {
          dgcParam1.Header = language["Unknown"];
          dgcParam2.Header = language["Unknown"];
          dgcParam4.Header = language["Unknown"];
          dgcParam5.Header = language["Unknown"];
        }
        if (language.ContainsKey("Weight")) dgcWeight.Header = language["Weight"];

        if (language.ContainsKey("FillDown")) PhysicsFillDown.Header = language["FillDown"];
        if (language.ContainsKey("ShowDetails")) PhysicsShowDetails.Header = language["ShowDetails"];
        if (language.ContainsKey("Import")) PhysicsImport.Header = language["Import"];
        if (language.ContainsKey("PhysicsDelete")) PhysicsDelete.Header = language["PhysicsDelete"];
        if (language.ContainsKey("PhysicsDeleteWithBones")) PhysicsDeleteWithBones.Header = language["PhysicsDeleteWithBones"];

        if (language.ContainsKey("Node")) dgcNodecpNode.Header = language["Node"];
        if (language.ContainsKey("Count")) dgcNodecpCount.Header = language["Count"];
        if (language.ContainsKey("Category")) dgcCustompCategory.Header = language["Category"];
        if (language.ContainsKey("Value")) dgcCustompValue.Header = language["Value"];

        if (language.ContainsKey("DisplayAll")) cbNodecpDisplayAll.Content = language["DisplayAll"];
        if (language.ContainsKey("DisplaySetted")) cbNodecpDisplaySetted.Content = language["DisplaySetted"];
        if (language.ContainsKey("DisplayBreast")) cbNodecpDisplayBreast.Content = language["DisplayBreast"];
      }
    }

  }
}
