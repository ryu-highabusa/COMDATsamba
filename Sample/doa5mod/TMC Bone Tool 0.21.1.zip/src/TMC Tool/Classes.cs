﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows.Media.Media3D;

namespace TMC_Tool
{
  public class MainViewModel : NotifyPropertyChangedBase
  {
    private static Dictionary<string, string> txt = new Dictionary<string, string>();

    public MainViewModel()
    {
      Bones = new ObservableCollection<BoneData>();
      Collisions = new ObservableCollection<CollisionData>();
      Physics = new ObservableCollection<PhysicsData>();
      Nodecps = new ObservableCollection<NodecpData>();
      ParentBones = new ObservableCollection<string>();
      IsEnabledBone = true;
      TextStatus = txt["textStatus"];
      ChangeHieLay = true;
      ChangeGlblMtx = true;
      ChangeBnOfsMtx = true;
      IsRelative = true;
    }

    public void Init(TmcData data)
    {
      if (Bones.Count > 0) Bones.Clear();
      if (Collisions.Count > 0) Collisions.Clear();
      if (Physics.Count > 0) Physics.Clear();
      if (Nodecps.Count > 0) Nodecps.Clear();

      SetBones(data);
      SetCollisions(data);

      if (data.Physics != null)
      {
        foreach (var physics in data.Physics)
        {
          PhysicsData newPhysics = new PhysicsData(data, physics);
          newPhysics.CheckDeletable(data, physics);
          Physics.Add(newPhysics);
        }
      }

      if (data.NodeCp != null)
      {
        for (int i = 0; i < data.Node.Count; i++)
        {
          NodecpData newNodecp = new NodecpData(data, data.Node[i]);
          newNodecp.ID = i;
          Nodecps.Add(newNodecp);
        }
      }

      IsChangedBone = false;
    }

    public void SetBones(TmcData data)
    {
      if (ParentBones.Count > 0) ParentBones.Clear();
      ParentBones.Add("----------");

      foreach (var node in data.Node)
      {
        BoneData newBone = new BoneData(node);
        newBone.BoneLevel = data.Hie[node.Index].BoneLevel;
        newBone.Parent = data.Hie[node.Index].Parent + 1;
        newBone.OriginalParent = data.Hie[node.Index].Parent + 1;
        foreach (var child in data.Hie[node.Index].Children)
        {
          newBone.Children.Add(child);
        }
        Bones.Add(newBone);
        ParentBones.Add(newBone.Name);
      }

      ReferBones = new ObservableCollection<string>();
      ReferBones.Add("----------");

      IsSettedBoneData = false;

      if (IsEnabledBone)
        IsChangeableBone = true;
      else
        IsChangeableBone = false;

      if (IsEnabledCollision && data.Collisions != null)
        IsChangeableCollision = true;
      else
        IsChangeableCollision = false;

      if (IsEnabledPhysics && data.Physics != null)
        IsChangeablePhysics = true;
      else
        IsChangeablePhysics = false;

      if (IsEnabledNodecp && data.NodeCp != null)
        IsChangeableNodecp = true;
      else
        IsChangeableNodecp = false;

      if (Parentage) CheckRootExist();
    }

    public void SetReferBones(TmcData boneData)
    {
      if (ReferBones != null) ReferBones.Clear();
      ReferBones.Add("----------");

      foreach (var node in boneData.Node)
      {
        ReferBones.Add(node.Name);
      }

      foreach (var bone in Bones)
      {
        bone.Refer = ReferBones.IndexOf(bone.Name);

        bone.Selectable = true;

        if (bone.Refer == -1)
        {
          bone.Refer = 0;
        }
        else
        {
          int parent = 0;

          int parentIndex = boneData.Hie[bone.Refer - 1].Parent;

          if (parentIndex != -1)
          {
            string parentName = boneData.Node[parentIndex].Name;
            parent = ParentBones.IndexOf(parentName);
          }

          if (parent != -1)
          {
            bone.Parent = parent;

            if (Parentage && bone.Parent != bone.OriginalParent)
              bone.ChangedParent = true;
            else
              bone.ChangedParent = false;
          }
        }

        if (bone.IsBone && bone.Refer != 0)
        {
          bone.Selected = true;
        }
        else
        {
          bone.Selected = false;
        }
      }

      IsSettedBoneData = true;
    }

    public void ChangeChangeableParent()
    {
      foreach (var bone in Bones)
      {
        bone.ChangeableParent = Parentage;
        bone.ChangedParent = false;
      }

      if (Parentage)
      {
        foreach (var bone in Bones)
        {
          if (Parentage && bone.Parent != bone.OriginalParent) bone.ChangedParent = true;
        }
      }
    }

    public void CheckRootExist()
    {
      bool root = false;

      if (Parentage)
      {
        foreach (var bone in Bones)
        {
          if (bone.Parent == 0)
          {
            root = true;
            break;
          }
        }
      }
      else
      {
        root = true;
      }

      if (root)
      {
        RootExist = true;
        TextStatus = "";
      }
      else
      {
        RootExist = false;
        TextStatus = txt["textRootNotExist"];
      }
    }

    public BoneData AddBone(string baseName, BoneData bone)
    {
      BoneData newBone = new BoneData();

      if (bone != null)
      {
        newBone.IsBone = bone.IsBone;
        newBone.BoneLevel = bone.BoneLevel;
        newBone.Parent = bone.Parent;
        newBone.OriginalParent = bone.OriginalParent;
        newBone.OriginalIndex = bone.OriginalIndex;
        newBone.Refer = bone.Refer;
      }
      else
      {
        newBone.IsBone = true;
        newBone.BoneLevel = 0;
        newBone.Parent = 0;
        newBone.OriginalParent = 0;
        newBone.OriginalIndex = -1;
      }

      newBone.IsAdded = true;
      if (MainWindow.boneData != null) newBone.Selectable = true;
      if (Parentage) newBone.ChangeableParent = true;

      string name = baseName;

      int count = 1;
      while (Array.FindIndex(Bones.ToArray(), elem => elem.Name == name) != -1)
      {
        name = baseName + count;
        count++;
      }

      newBone.Name = name;

      Bones.Add(newBone);
      ParentBones.Add(name);

      // nodecp追加
      var newNodecp = new NodecpData();
      newNodecp.Node = name;
      newNodecp.ID = Nodecps.Count;
      Nodecps.Add(newNodecp);

      return newBone;
    }

    public void DeleteBones(List<string> deleteBoneList, bool inPhysics)
    {
      if (deleteBoneList.Count == 0) return;

      int index = 0;
      while (Bones.Count > index)
      {
        if (deleteBoneList.Contains(Bones[index].Name))
        {
          if (Bones[index].ObjIndex > -1)
          {
            deleteBoneList.Remove(Bones[index].Name);
            index++;
            continue;
          }

          int deleteIndex = Array.FindIndex(Collisions.ToArray(), elem => elem.Name == Bones[index].Name);
          if (deleteIndex != -1) Collisions[deleteIndex].Data = txt["Delete"];

          if (Bones[index].IsAdded)
          {
            Bones.RemoveAt(index);
          }
          else
          {
            Bones[index].IsDeleted = true;
            if (inPhysics) Bones[index].InPhysics = true;
            deleteBoneList.Remove(Bones[index].Name);
            index++;
          }
        }
        else
        {
          if (deleteBoneList.Contains(ParentBones[Bones[index].Parent]))
          {
            Bones[index].Parent = Bones[index].OriginalParent;
          }

          index++;
        }
      }

      foreach (var bone in deleteBoneList)
      {
        ParentBones.Remove(bone);

        int deleteIndex = Array.FindIndex(Nodecps.ToArray(), elem => elem.Node == bone);
        if (deleteIndex != -1) Nodecps.RemoveAt(deleteIndex);
      }
    }


    public void SetCollisions(TmcData data)
    {
      if (data.Collisions != null)
      {
        foreach (var collision in data.Collisions)
        {
          CollisionData newCollision = new CollisionData(data, collision);
          newCollision.DataList.Add(txt["TmcData"]);
          newCollision.Data = txt["TmcData"];
          newCollision.CurrentData = txt["TmcData"];
          newCollision.TmcIndex = collision.Index;
          Collisions.Add(newCollision);
        }
      }
    }
    public void SetCollisions(TmcData tmcData, TmcData boneData)
    {
      if (tmcData.Collisions == null) return;

      ResetCollisions();

      if (boneData.Collisions == null) return; 

      List<string> names = new List<string>();
      foreach (var collision in Collisions)
      {
        names.Add(collision.Name);
        collision.Data = txt["Delete"];
        collision.DataChanged();
      }
      List<string> tempNames = new List<string>();
      tempNames.AddRange(names);

      foreach (var boneCollision in boneData.Collisions)
      {
        int insertIndex = -1;

        int idx = names.IndexOf(boneData.Node[boneCollision.Node].Name);

        if (idx == -1)
        {
          tempNames.Add(boneData.Node[boneCollision.Node].Name);
          tempNames.Sort(StringComparer.Ordinal);
          insertIndex = tempNames.LastIndexOf(boneData.Node[boneCollision.Node].Name);
        }
        else
        {
          idx = tempNames.IndexOf(boneData.Node[boneCollision.Node].Name);
          for (int i = idx; i < Collisions.Count; i++)
          {
            insertIndex = i;

            if (Collisions[i].Name != boneData.Node[boneCollision.Node].Name || Collisions[i].Code > boneCollision.Code)
            {
              break;
            }
            else if (Collisions[i].Code == boneCollision.Code)
            {
              if (Collisions[i].DataList.Contains(txt["CustomData"]))
                Collisions[i].DataList.Insert(Collisions[i].DataList.Count -2, txt["BoneData"]);
              else
                Collisions[i].DataList.Add(txt["BoneData"]);

              Collisions[i].Data = txt["BoneData"];
              Collisions[i].CurrentData = txt["BoneData"];
              Collisions[i].SetTransforms(boneCollision);

              Collisions[i].BoneIndex = boneCollision.Index;
              insertIndex = -1;
              break;
            }
          }
          if (insertIndex != -1)
          {
            tempNames.Add(boneData.Node[boneCollision.Node].Name);
            tempNames.Sort(StringComparer.Ordinal);
          }
        }

        if (insertIndex != -1)
        {
          CollisionData newCollision = new CollisionData(boneData, boneCollision);
          newCollision.DataList.Add(txt["BoneData"]);
          newCollision.Data = txt["BoneData"];
          newCollision.CurrentData = txt["BoneData"];
          newCollision.BoneIndex = boneCollision.Index;
          Collisions.Insert(insertIndex, newCollision);
        }
      }
    }

    public void ResetCollisions()
    {
      List<int> deleteList = new List<int>();

      int index = -1;
      foreach (var collision in Collisions)
      {
        index++;

        if (collision.TmcIndex == -1)
        {
          deleteList.Add(index);
          continue;
        }

        if (collision.Data == txt["BoneData"] || collision.Data == txt["Delete"])
        {
          collision.Data = txt["TmcData"];
          collision.CurrentData = txt["TmcData"];
          collision.SetTransforms(MainWindow.tmcData.Collisions[collision.TmcIndex]);
        }

        if (collision.DataList.Contains(txt["BoneData"]))
        {
          collision.DataList.Remove(txt["BoneData"]);
        }
      }

      deleteList.Reverse();
      foreach (var idx in deleteList)
      {
        Collisions.RemoveAt(idx);
      }
    }


    public void AddPhysics(TmcData boneData)
    {
      if (boneData.Physics == null) return;

      foreach (var physics in boneData.Physics)
      {
        PhysicsData newPhysics = new PhysicsData(boneData, physics);
        newPhysics.InBoneData = true;
        newPhysics.IsIncluded = false;
        newPhysics.IsDeletable = true;

        Physics.Add(newPhysics);
      }
    }

    public void AddBonesInPhysics(PhysicsData physics)
    {
      var bones = new List<BoneData>(Bones);
      if (physics.InBoneData)
      {
        var data = MainWindow.boneData;

        // Root追加
        var rootNode = data.Node[physics.RootIndex];
        BoneData newRootBone = new BoneData(rootNode);
        newRootBone.BoneLevel = data.Hie[rootNode.Index].BoneLevel;
        newRootBone.IsAdded = true;
        newRootBone.InPhysics = true;
        if (Parentage) newRootBone.ChangeableParent = true;

        // 親の設定
        var parent = data.Hie[rootNode.Index].Parent;

        int parentIndex = GetParentIndex(data, bones, parent);

        if (parentIndex != -1)
          newRootBone.Parent = parentIndex;
        else
          newRootBone.Parent = 0;

        newRootBone.OriginalParent = newRootBone.Parent;

        string beforeName = rootNode.Name;
        newRootBone.Name = physics.Root;

        foreach (var child in data.Hie[rootNode.Index].Children)
        {
          newRootBone.Children.Add(child);
        }
        Bones.Add(newRootBone);
        ParentBones.Add(newRootBone.Name);

        // nodecp追加
        var newRootBoneNodecp = new NodecpData();
        newRootBoneNodecp.Node = newRootBone.Name;
        newRootBoneNodecp.ID = Nodecps.Count;
        Nodecps.Add(newRootBoneNodecp);

        // 追加
        var addChar = new Dictionary<int, int>();
        bool exist = false;

        var physicsData = data.Physics[physics.Index];

        foreach (var block1 in physicsData.Block1)
        {
          if (Array.FindIndex(bones.ToArray(), elem => elem.Name == data.Node[block1.NodeIndex].Name) != -1)
          {
            exist = true;
          }
        }

        foreach (var type2 in physicsData.Type2)
        {
          foreach (var type2data in type2)
          {
            if (Array.FindIndex(bones.ToArray(), elem => elem.Name == data.Node[type2data.NodeIndex].Name) != -1)
            {
              exist = true;
            }
          }
        }

        int charCode = 0x61;
        while (exist)
        {
          foreach (var block1 in physicsData.Block1)
          {
            exist = PreCheckNodeNameExist(data.Node[block1.NodeIndex].Name, charCode);
            addChar[block1.NodeIndex] = charCode;
          }

          foreach (var type2 in physicsData.Type2)
          {
            foreach (var type2data in type2)
            {
              exist = PreCheckNodeNameExist(data.Node[type2data.NodeIndex].Name, charCode);
              addChar[type2data.NodeIndex] = charCode;
            }
          }

          charCode++;
        }

        foreach (var childData in physics.Bones)
        {
          var node = data.Node[childData.NodeIndex];
          BoneData newBone = new BoneData(node);
          newBone.BoneLevel = data.Hie[node.Index].BoneLevel;
          newBone.IsAdded = true;
          newBone.InPhysics = true;
          if (Parentage) newBone.ChangeableParent = true;

          // 親の設定
          parent = data.Hie[node.Index].Parent;

          if (data.Node[parent].Name == beforeName)
          {
            parentIndex = ParentBones.IndexOf(newRootBone.Name);
          }
          else
          {
            parentIndex = GetParentIndex(data, bones, parent);
          }

          if (parentIndex != -1)
            newBone.Parent = parentIndex;
          else
            newBone.Parent = 0;

          newBone.OriginalParent = newBone.Parent;

          charCode = -1;
          if (addChar.ContainsKey(childData.NodeIndex))
          {
            charCode = addChar[childData.NodeIndex];
          }
          newBone.Name = CheckNodeNameExist(newBone.Name, charCode);

          foreach (var child in data.Hie[node.Index].Children)
          {
            newBone.Children.Add(child);
          }
          Bones.Add(newBone);
          ParentBones.Add(newBone.Name);

          // nodecp追加
          var newNodecp = new NodecpData();
          newNodecp.Node = newBone.Name;
          newNodecp.ID = Nodecps.Count;
          Nodecps.Add(newNodecp);

          // 名前を変更
          if (physics.BaseNode == childData.Name) physics.BaseNode = newBone.Name;
          childData.Name = newBone.Name;
        }
      }
      else
      {
        var data = MainWindow.tmcData;

        var rootNode = data.Node[physics.RootIndex];

        int idx = Array.FindIndex(bones.ToArray(), elem => elem.Name == rootNode.Name);

        bones[idx].IsDeleted = false;

        foreach (var childData in physics.Bones)
        {
          var node = data.Node[childData.NodeIndex];

          idx = Array.FindIndex(bones.ToArray(), elem => elem.Name == node.Name);

          bones[idx].IsDeleted = false;
        }
      }
    }

    private int GetParentIndex(TmcData data, List<BoneData> bones, int parent)
    {
      int index = -1;

      while (index == -1 && parent != -1)
      {
        index = ParentBones.IndexOf(data.Node[parent].Name);
        parent = data.Hie[parent].Parent;
      }

      if (index == -1)
      {
        int rootIndex = Array.FindIndex(bones.ToArray(), elem => elem.Parent == -1);
        index = ParentBones.IndexOf(data.Node[rootIndex].Name);
      }

      return index;
    }

    public void ResetPhysics()
    {
      List<string> deleteBoneList = new List<string>();
      int index = 0;

      while (Physics.Count > index)
      {
        if (Physics[index].InBoneData)
        {
          if (Physics[index].IsIncluded)
          {
            deleteBoneList.Add(Physics[index].Root);
            foreach (var child in Physics[index].Bones)
            {
              deleteBoneList.Add(child.Name);
            }
          }

          Physics.RemoveAt(index);
        }
        else
        {
          index++;
        }
      }

      DeleteBones(deleteBoneList, true);
    }


    public bool PreCheckNodeNameExist(string curName, int charCode)
    {
      bool parsableNum = true;
      int num = 0;
      int numLength = 0;
      do
      {
        numLength++;
        parsableNum = Int32.TryParse(curName.Substring(curName.Length - numLength), out num);
      } while (parsableNum);
      numLength--;

      int countUp = 1;
      if (numLength > 0)
      {
        num = Int32.Parse(curName.Substring(curName.Length - numLength));
      }
      else
      {
        countUp++;
      }

      string name;
      if (numLength == 0)
      {
        name = curName + "_" + Convert.ToChar(charCode);
      }
      else
      {
        name = curName.Substring(0, curName.Length - numLength) + "_" + Convert.ToChar(charCode) + num.ToString("D");
      }
      int idx = Array.FindIndex(Bones.ToArray(), node => node.Name == name);

      return idx != -1;
    }

    public string CheckNodeNameExist(string curName, int charCode)
    {
      if (Array.FindIndex(Bones.ToArray(), node => node.Name == curName) == -1)
      {
        return curName;
      }

      bool parsableNum = true;
      int num = 0;
      int numLength = 0;
      do
      {
        numLength++;
        parsableNum = Int32.TryParse(curName.Substring(curName.Length - numLength), out num);
      } while (parsableNum);
      numLength--;

      int countUp = 1;
      if (numLength > 0)
      {
        num = Int32.Parse(curName.Substring(curName.Length - numLength));
      }
      else
      {
        countUp++;
      }

      string name = "";

      if (charCode != -1)
      {
        if (numLength == 0)
        {
          name = curName + "_" + Convert.ToChar(charCode);
        }
        else
        {
          name = curName.Substring(0, curName.Length - numLength) + "_" + Convert.ToChar(charCode) + num.ToString("D");
        }
      }
      else
      {
        int idx = -1;
        do
        {
          name = curName.Substring(0, curName.Length - numLength) + (num + countUp).ToString("D" + numLength);
          idx = Array.FindIndex(Bones.ToArray(), node => node.Name == name);
          countUp++;
        } while (idx != -1);
      }

      return name;
    }



    public class BoneData : NotifyPropertyChangedBase
    {
      public BoneData()
      {
        Children = new List<int>();
        ObjIndex = -1;
      }
      public BoneData(Nodes node)
      {
        Children = new List<int>();
        Name = node.Name;
        OriginalIndex = node.Index;
        ObjIndex = node.ObjIndex;
        if (node.ObjIndex == -1 || System.Text.RegularExpressions.Regex.IsMatch(Name, @"^MOT[0-9]{2}")) IsBone = true;
      }

      private bool _Selected;
      public bool Selected
      {
        get { return _Selected; }
        set
        {
          _Selected = value;
          OnPropertyChanged(nameof(Selected));
        }
      }
      private bool _Selectable;
      public bool Selectable
      {
        get { return _Selectable; }
        set
        {
          _Selectable = value;
          OnPropertyChanged(nameof(Selectable));
        }
      }
      private bool _ChangeableParent;
      public bool ChangeableParent
      {
        get { return _ChangeableParent; }
        set
        {
          _ChangeableParent = value;
          OnPropertyChanged(nameof(ChangeableParent));
        }
      }
      private bool _ChangedParent;
      public bool ChangedParent
      {
        get { return _ChangedParent; }
        set
        {
          _ChangedParent = value;
          OnPropertyChanged(nameof(ChangedParent));
        }
      }
      private bool _IsAdded;
      public bool IsAdded
      {
        get { return _IsAdded; }
        set
        {
          _IsAdded = value;
          OnPropertyChanged(nameof(IsAdded));
        }
      }
      private bool _IsDeleted;
      public bool IsDeleted
      {
        get { return _IsDeleted; }
        set
        {
          _IsDeleted = value;
          OnPropertyChanged(nameof(IsDeleted));
        }
      }
      private string _Name;
      public string Name
      {
        get { return _Name; }
        set
        {
          _Name = value;
          OnPropertyChanged(nameof(Name));
        }
      }
      private int _Refer;
      public int Refer
      {
        get { return _Refer; }
        set
        {
          _Refer = value;
          OnPropertyChanged(nameof(Refer));
        }
      }
      private int _Parent;
      public int Parent
      {
        get { return _Parent; }
        set
        {
          _Parent = value;
          OnPropertyChanged(nameof(Parent));
        }
      }
      public int OriginalIndex { get; set; }
      public int OriginalParent { get; set; }
      public int ObjIndex { get; set; }
      public int BoneLevel { get; set; }
      public bool IsBone { get; set; }
      public bool InPhysics { get; set; }
      public List<int> Children { get; set; }
    }

    public class CollisionData : NotifyPropertyChangedBase
    {
      public CollisionData(TmcData data, Collision collision)
      {
        TmcIndex = -1;
        BoneIndex = -1;
        Rotation = new ObservableCollection<decimal>() { 0, 0, 0 };
        Size = new ObservableCollection<decimal>() { 0, 0, 0 };
        Position = new ObservableCollection<decimal>() { 0, 0, 0 };
        CustomRotation = new decimal[3];
        CustomSize = new decimal[3];
        CustomPosition = new decimal[3];

        Name = data.Node[collision.Node].Name;
        Type = collision.Type;
        Code = collision.Code;
        CodeText = "0x" + collision.Code.ToString("X8");

        SetTransforms(collision);

        DataList = new ObservableCollection<string>();
        DataList.Add(txt["Delete"]);
        Data = txt["Delete"];
      }

      public void SetTransforms()
      {
        for (int i = 0; i < 3; i++)
          Rotation[i] = CustomRotation[i];

        for (int i = 0; i < 3; i++)
          Size[i] = CustomSize[i];

        for (int i = 0; i < 3; i++)
          Position[i] = CustomPosition[i];
      }
      public void SetTransforms(Collision collision)
      {
        for (int i = 0; i < 3; i++)
          Rotation[i] = (decimal)Math.Round(collision.Rotation[i] * 180 / Math.PI, 4, MidpointRounding.AwayFromZero);

        for (int i = 0; i < 3; i++)
          Size[i] = (decimal)collision.Size[i];

        for (int i = 0; i < 3; i++)
          Position[i] = (decimal)collision.Position[i];
      }

      public void SetTransformsToCustoms()
      {
        for (int i = 0; i < 3; i++)
          CustomRotation[i] = Rotation[i];

        for (int i = 0; i < 3; i++)
          CustomSize[i] = Size[i];

        for (int i = 0; i < 3; i++)
          CustomPosition[i] = Position[i];
      }

      public void DataChanged()
      {
        if (CurrentData == txt["CustomData"])
          SetTransformsToCustoms();

        if (Data == txt["Delete"]) return;

        if (Data == txt["TmcData"])
        {
          SetTransforms(MainWindow.tmcData.Collisions[TmcIndex]);
        }
        else if (Data == txt["BoneData"])
        {
          SetTransforms(MainWindow.boneData.Collisions[BoneIndex]);
        }
        else if (Data == txt["CustomData"])
        {
          BaseData = CurrentData;
          SetTransforms();
        }

        CurrentData = Data;
      }


      public int TmcIndex { get; set; }
      public int BoneIndex { get; set; }
      private string _Name;
      public string Name
      {
        get { return _Name; }
        set
        {
          _Name = value;
          OnPropertyChanged(nameof(Name));
        }
      }
      private int _Type;
      public int Type
      {
        get { return _Type; }
        set
        {
          _Type = value;
          OnPropertyChanged(nameof(Type));
        }
      }
      private uint _Code;
      public uint Code
      {
        get { return _Code; }
        set
        {
          _Code = value;
          OnPropertyChanged(nameof(Code));
        }
      }
      private string _CodeText;
      public string CodeText
      {
        get { return _CodeText; }
        set
        {
          _CodeText = value;
          OnPropertyChanged(nameof(CodeText));
        }
      }
      private string _Data;
      public string Data
      {
        get { return _Data; }
        set
        {
          _Data = value;
          OnPropertyChanged(nameof(Data));
        }
      }
      public string CurrentData { get; set; }
      public string BaseData { get; set; }

      public ObservableCollection<decimal> Rotation { get; set; }
      public ObservableCollection<decimal> Size { get; set; }
      public ObservableCollection<decimal> Position { get; set; }

      public decimal[] CustomRotation { get; set; }
      public decimal[] CustomSize { get; set; }
      public decimal[] CustomPosition { get; set; }

      public ObservableCollection<string> DataList { get; set; }
    }

    public class PhysicsData : NotifyPropertyChangedBase
    {
      public PhysicsData(TmcData data, TMC_Tool.PhysicsData physics)
      {
        Bones = new ObservableCollection<PhysicsChildrenData>();
        Params = new ObservableCollection<float?>();
        Collisions = new ObservableCollection<PhysicsCollisionData>();

        IsIncluded = true;

        InUse = physics.InUse;
        Index = physics.Index;
        Root = data.Node[physics.RootNode].Name;
        RootIndex = physics.RootNode;
        BaseNode = data.Node[data.AcsclsIndices[0][physics.BaseNode]].Name;
        Recalc = false;
        if (physics.Block1 == null) Recalc = null;
        CollisionType = -1;

        switch (physics.Type)
        {
          case 0:
            Type = "Cloth";
            Recalcable = true;
            break;
          case 1:
            Type = "String";
            Recalcable = true;
            break;
          case 2:
            Type = "Type2";
            Recalcable = false;
            break;
          case 3:
            Type = "Hair";
            Recalcable = true;
            break;
          case 5:
            Type = "String(5)";
            Recalcable = true;
            break;
        }

        TypeID = physics.Type;

        if (physics.Type != 2)
        {
          foreach (var bone in physics.Block1)
          {
            var newBone = new PhysicsChildrenData(data, physics.Block1, bone);
            Bones.Add(newBone);
          }
        }
        else
        {
          foreach (var type2 in physics.Type2)
          {
            foreach (var type2data in type2)
            {
              var newBone = new PhysicsChildrenData(data, type2data.NodeIndex);
              Bones.Add(newBone);
            }
          }
        }

        if (physics.Params != null)
        {
          for (int i = 0; i < 6; i++)
          {
            Params.Add(physics.Params[4 * i]);
          }
        }

        if (physics.Collisions.Count > 0)
        {
          for (int i = 0; i < 2; i++)
          {
            if (physics.Collisions[i].Count == 0) continue;

            CollisionType = i;
            foreach (var collisionCode in physics.Collisions[i])
            {
              var newCollision = new PhysicsCollisionData();
              newCollision.Code = collisionCode;

              Collisions.Add(newCollision);
            }
          }
        }

        if (CollisionType == -1)
          CurCollisionType = 0;
        else
          CurCollisionType = CollisionType;
      }

      public void SetBaseNode(ObservableCollection<CollisionData> collisions)
      {
        foreach (var physCollision in Collisions)
        {
          string baseNode = "";

          foreach (var collision in collisions)
          {
            if (collision.Code == physCollision.Code)
            {
              baseNode += " " + collision.Name;
            }
          }

          if (baseNode.Length == 0)
          {
            baseNode = "Unknown";
          }
          else
          {
            baseNode = baseNode.Trim();
          }

          physCollision.BaseNode = baseNode;
        }
      }

      public void CheckDeletable(TmcData tmcData, TMC_Tool.PhysicsData physics)
      {
        foreach (var node in tmcData.Node)
        {
          List<int> checkIndeices = new List<int>();

          if (node.ObjIndex != -1)
          {
            checkIndeices.Add(node.ObjIndex);
          }

          if (tmcData.BlendIdxGrp.ContainsKey(node.Index))
          {
            checkIndeices.AddRange(tmcData.BlendIdxGrp[node.Index].Idx);
          }

          if (checkIndeices.Count == 0) continue;


          if (checkIndeices.Contains(physics.Node)) return;

          if (physics.Type != 2)
          {
            foreach (var block in physics.Block1)
            {
              if (checkIndeices.Contains(block.NodeIndex)) return;
            }
          }
          else
          {
            foreach (var blocks in physics.Type2)
            {
              foreach (var block in blocks)
              {
                if (checkIndeices.Contains(block.NodeIndex)) return;
              }
            }
          }
        }

        IsDeletable = true;
      }

      public PhysicsData Clone()
      {
        PhysicsData cloned = (PhysicsData)MemberwiseClone();

        cloned.Bones = new ObservableCollection<PhysicsChildrenData>();
        foreach (var bone in Bones)
        {
          cloned.Bones.Add(bone.Clone());
        }
        cloned.Params = new ObservableCollection<float?>();
        foreach (var param in Params)
        {
          cloned.Params.Add(param);
        }
        cloned.Collisions = new ObservableCollection<PhysicsCollisionData>();
        foreach (var collision in Collisions)
        {
          cloned.Collisions.Add(collision.Clone());
        }

        return cloned;
      }

      public int Index { get; set; }
      private string _Root;
      public string Root
      {
        get { return _Root; }
        set
        {
          _Root = value;
          OnPropertyChanged(nameof(Root));
        }
      }
      public int RootIndex { get; set; }
      public string BaseNode { get; set; }

      private bool _InUse;
      public bool InUse
      {
        get { return _InUse; }
        set
        {
          _InUse = value;
          OnPropertyChanged(nameof(InUse));
        }
      }

      public string Type { get; set; }
      public int TypeID { get; set; }
      public bool IsEdited { get; set; }

      private bool? _Recalc;
      public bool? Recalc
      {
        get { return _Recalc; }
        set
        {
          _Recalc = value;
          OnPropertyChanged(nameof(Recalc));
        }
      }
      private bool _Recalcable;
      public bool Recalcable
      {
        get { return _Recalcable; }
        set
        {
          _Recalcable = value;
          OnPropertyChanged(nameof(Recalcable));
        }
      }

      private int _CollisionType;
      public int CollisionType
      {
        get { return _CollisionType; }
        set
        {
          _CollisionType = value;
          OnPropertyChanged(nameof(CollisionType));
        }
      }
      public int CurCollisionType;

      private bool _InBoneData;
      public bool InBoneData
      {
        get { return _InBoneData; }
        set
        {
          _InBoneData = value;
          OnPropertyChanged(nameof(InBoneData));
        }
      }
      private bool _IsDeletable;
      public bool IsDeletable
      {
        get { return _IsDeletable; }
        set
        {
          _IsDeletable = value;
          OnPropertyChanged(nameof(IsDeletable));
        }
      }
      private bool _IsIncluded;
      public bool IsIncluded
      {
        get { return _IsIncluded; }
        set
        {
          _IsIncluded = value;
          OnPropertyChanged(nameof(IsIncluded));
        }
      }

      public ObservableCollection<float?> Params { get; set; }
      public ObservableCollection<PhysicsChildrenData> Bones { get; set; }
      public ObservableCollection<PhysicsCollisionData> Collisions { get; set; }
    }

    public class PhysicsChildrenData : NotifyPropertyChangedBase
    {
      public PhysicsChildrenData(TmcData data, List<PhysicsBlock1Data> block1, PhysicsBlock1Data bone)
      {
        Name = data.Node[bone.NodeIndex].Name;
        Parent = data.Node[block1[bone.Parent].NodeIndex].Name;
        NodeIndex = bone.NodeIndex;

        Spring = bone.Spring[0];
        Elastic = bone.Elastic[0];
        Friction = bone.Friction[0];
        Unknown = bone.Unknown[0];
        Bending = bone.Bending[0];
      }

      public PhysicsChildrenData(TmcData data, int nodeIndex)
      {
        Name = data.Node[nodeIndex].Name;
        NodeIndex = nodeIndex;
      }

      public PhysicsChildrenData Clone()
      {
        PhysicsChildrenData cloned = (PhysicsChildrenData)MemberwiseClone();
        return cloned;
      }

      public string Name { get; set; }
      public string Parent { get; set; }
      public int NodeIndex { get; set; }

      private float _Spring;
      public float Spring
      {
        get { return _Spring; }
        set
        {
          _Spring = value;
          OnPropertyChanged(nameof(Spring));
        }
      }
      private float _Elastic;
      public float Elastic
      {
        get { return _Elastic; }
        set
        {
          _Elastic = value;
          OnPropertyChanged(nameof(Elastic));
        }
      }
      private float _Friction;
      public float Friction
      {
        get { return _Friction; }
        set
        {
          _Friction = value;
          OnPropertyChanged(nameof(Friction));
        }
      }
      private float _Unknown;
      public float Unknown
      {
        get { return _Unknown; }
        set
        {
          _Unknown = value;
          OnPropertyChanged(nameof(Unknown));
        }
      }
      private float _Bending;
      public float Bending
      {
        get { return _Bending; }
        set
        {
          _Bending = value;
          OnPropertyChanged(nameof(Bending));
        }
      }
    }

    public class PhysicsCollisionData : NotifyPropertyChangedBase
    {
      public PhysicsCollisionData()
      {
      }

      public PhysicsCollisionData Clone()
      {
        PhysicsCollisionData cloned = (PhysicsCollisionData)MemberwiseClone();
        return cloned;
      }

      private uint _Code;
      public uint Code
      {
        get { return _Code; }
        set
        {
          _Code = value;
          OnPropertyChanged(nameof(Code));
        }
      }
      private string _BaseNode;
      public string BaseNode
      {
        get { return _BaseNode; }
        set
        {
          _BaseNode = value;
          OnPropertyChanged(nameof(BaseNode));
        }
      }
    }

    [Serializable]
    public class NodecpData : NotifyPropertyChangedBase
    {
      public NodecpData()
      {
        Customps = new ObservableCollection<CustompData>();
      }
      public NodecpData(TmcData data, Nodes node)
      {
        Customps = new ObservableCollection<CustompData>();

        Node = node.Name;

        int index = Array.FindIndex(data.NodeCp.ToArray(), elem => elem.Index == node.Index);
        if (index != -1)
        {
          var customp = data.NodeCp[index];
          Count = customp.Cp.Count;

          foreach (var cp in customp.Cp)
          {
            CustompData newCustomp = new CustompData(cp);
            Customps.Add(newCustomp);
          }
        }
      }

      private int _ID;
      public int ID
      {
        get { return _ID; }
        set
        {
          _ID = value;
          OnPropertyChanged(nameof(ID));
        }
      }
      private string _Node;
      public string Node
      {
        get { return _Node; }
        set
        {
          _Node = value;
          OnPropertyChanged(nameof(Node));
        }
      }
      private int _Count;
      public int Count
      {
        get { return _Count; }
        set
        {
          _Count = value;
          OnPropertyChanged(nameof(Count));
        }
      }
      private bool _IsEdited;
      public bool IsEdited
      {
        get { return _IsEdited; }
        set
        {
          _IsEdited = value;
          OnPropertyChanged(nameof(IsEdited));
        }
      }

      public ObservableCollection<CustompData> Customps { get; set; }
    }

    [Serializable]
    public class CustompData : NotifyPropertyChangedBase
    {
      public CustompData()
      {

      }
      public CustompData(CustompParam cp)
      {
        Code = cp.Data1;
        Type = cp.Data2;
        Value = cp.Param.ToString();
        CheckCategory();
      }

      public void CheckCategory()
      {
        switch (Code)
        {
          case 0x0EEC72A1:
            Category = txt["ReferenceNode"];
            break;
          case 0x50892C3C:
            Category = txt["ReferenceAxis"];
            break;
          case 0x5B1A5207:
            Category = txt["Coefficient"];
            break;
          case 0xC32CEE4A:
            Category = txt["ParentNode"];
            break;
          case 0xBB474F4B:
            Category = txt["FlagDisplay"];
            break;
          case 0xA50A10E2:
            Category = txt["FlagGlasses"];
            break;
        }
      }

      private uint _Code;
      public uint Code
      {
        get { return _Code; }
        set
        {
          _Code = value;
          OnPropertyChanged(nameof(Code));
        }
      }
      private string _Category;
      public string Category
      {
        get { return _Category; }
        set
        {
          _Category = value;
          OnPropertyChanged(nameof(Category));
        }
      }
      private int _Type;
      public int Type
      {
        get { return _Type; }
        set
        {
          _Type = value;
          OnPropertyChanged(nameof(Type));
        }
      }
      private string _Value;
      public string Value
      {
        get { return _Value; }
        set
        {
          _Value = value;
          OnPropertyChanged(nameof(Value));
        }
      }
    }

    public static void lang(Dictionary<string, string> langText)
    {
      txt = langText;
    }


    private bool _IsSettedBoneData;
    public bool IsSettedBoneData
    {
      get { return _IsSettedBoneData; }
      set
      {
        _IsSettedBoneData = value;
        OnPropertyChanged(nameof(IsSettedBoneData));
        if (_IsSettedBoneData && MainWindow.boneData != null && MainWindow.boneData.Collisions != null)
          IsSettedBoneDataCollision = true;
        else
          IsSettedBoneDataCollision = false;
      }
    }

    private bool _IsSettedBoneDataCollision;
    public bool IsSettedBoneDataCollision
    {
      get { return _IsSettedBoneDataCollision; }
      set
      {
        _IsSettedBoneDataCollision = value;
        OnPropertyChanged(nameof(IsSettedBoneDataCollision));
      }
    }


    private bool _ChangeHieLay;
    public bool ChangeHieLay
    {
      get { return _ChangeHieLay; }
      set
      {
        _ChangeHieLay = value;
        OnPropertyChanged(nameof(ChangeHieLay));
      }
    }

    private bool _ChangeGlblMtx;
    public bool ChangeGlblMtx
    {
      get { return _ChangeGlblMtx; }
      set
      {
        _ChangeGlblMtx = value;
        OnPropertyChanged(nameof(ChangeGlblMtx));
      }
    }

    private bool _ChangeBnOfsMtx;
    public bool ChangeBnOfsMtx
    {
      get { return _ChangeBnOfsMtx; }
      set
      {
        _ChangeBnOfsMtx = value;
        OnPropertyChanged(nameof(ChangeBnOfsMtx));
      }
    }

    private bool _IsRelative;
    public bool IsRelative
    {
      get { return _IsRelative; }
      set
      {
        _IsRelative = value;
        OnPropertyChanged(nameof(IsRelative));
      }
    }

    private bool _IsAbsolute;
    public bool IsAbsolute
    {
      get { return _IsAbsolute; }
      set
      {
        _IsAbsolute = value;
        OnPropertyChanged(nameof(IsAbsolute));
      }
    }

    private bool _RootExist;
    public bool RootExist
    {
      get { return _RootExist; }
      set
      {
        _RootExist = value;
        OnPropertyChanged(nameof(RootExist));
      }
    }

    private bool _Parentage;
    public bool Parentage
    {
      get { return _Parentage; }
      set
      {
        _Parentage = value;
        OnPropertyChanged(nameof(Parentage));
        ChangeChangeableParent();
        CheckRootExist();
      }
    }


    private bool _IsEnabledBone;
    public bool IsEnabledBone
    {
      get { return _IsEnabledBone; }
      set
      {
        _IsEnabledBone = value;
        OnPropertyChanged(nameof(IsEnabledBone));
        if (_IsEnabledBone && MainWindow.tmcData != null)
          IsChangeableBone = true;
        else
          IsChangeableBone = false;
      }
    }

    private bool _IsChangeableBone;
    public bool IsChangeableBone
    {
      get { return _IsChangeableBone; }
      set
      {
        _IsChangeableBone = value;
        OnPropertyChanged(nameof(IsChangeableBone));
      }
    }

    private bool _IsEnabledCollision;
    public bool IsEnabledCollision
    {
      get { return _IsEnabledCollision; }
      set
      {
        _IsEnabledCollision = value;
        OnPropertyChanged(nameof(IsEnabledCollision));
        if (_IsEnabledCollision && MainWindow.tmcData != null && MainWindow.tmcData.Collisions != null)
          IsChangeableCollision = true;
        else
          IsChangeableCollision = false;
      }
    }

    private bool _IsChangeableCollision;
    public bool IsChangeableCollision
    {
      get { return _IsChangeableCollision; }
      set
      {
        _IsChangeableCollision = value;
        OnPropertyChanged(nameof(IsChangeableCollision));
      }
    }

    private bool _IsEnabledPhysics;
    public bool IsEnabledPhysics
    {
      get { return _IsEnabledPhysics; }
      set
      {
        _IsEnabledPhysics = value;
        OnPropertyChanged(nameof(IsEnabledPhysics));
        if (_IsEnabledPhysics && MainWindow.tmcData != null && MainWindow.tmcData.Physics != null)
          IsChangeablePhysics = true;
        else
          IsChangeablePhysics = false;
      }
    }

    private bool _IsChangeablePhysics;
    public bool IsChangeablePhysics
    {
      get { return _IsChangeablePhysics; }
      set
      {
        _IsChangeablePhysics = value;
        OnPropertyChanged(nameof(IsChangeablePhysics));
      }
    }

    private bool _IsEnabledNodecp;
    public bool IsEnabledNodecp
    {
      get { return _IsEnabledNodecp; }
      set
      {
        _IsEnabledNodecp = value;
        OnPropertyChanged(nameof(IsEnabledNodecp));
        if (_IsEnabledNodecp && MainWindow.tmcData != null && MainWindow.tmcData.NodeCp != null)
          IsChangeableNodecp = true;
        else
          IsChangeableNodecp = false;
      }
    }

    private bool _IsChangeableNodecp;
    public bool IsChangeableNodecp
    {
      get { return _IsChangeableNodecp; }
      set
      {
        _IsChangeableNodecp = value;
        OnPropertyChanged(nameof(IsChangeableNodecp));
      }
    }


    private string _TextStatus;
    public string TextStatus
    {
      get { return _TextStatus; }
      set
      {
        _TextStatus = value;
        OnPropertyChanged(nameof(TextStatus));
      }
    }


    public bool IsChangedBone { get; set; }


    private NodecpData _Nodecp;
    public NodecpData Nodecp
    {
      get { return _Nodecp; }
      set
      {
        _Nodecp = value;
        OnPropertyChanged(nameof(Nodecp));
      }
    }

    public ObservableCollection<string> ReferBones { get; set; }
    public ObservableCollection<string> ParentBones { get; set; }
    public ObservableCollection<BoneData> Bones { get; set; }
    public ObservableCollection<CollisionData> Collisions { get; set; }
    public ObservableCollection<PhysicsData> Physics { get; set; }
    public ObservableCollection<NodecpData> Nodecps { get; set; }
  }

  public class DisplayType
  {
    private string _Type;
    public string Type
    {
      get { return _Type; }
      set { _Type = value; }
    }
  }



  public class ExBone
  {
    public ExBone()
    {
      Children = new List<int>();
    }

    public MainViewModel.BoneData BoneData { get; set; }
    public string Name { get; set; }
    public string ParentName { get; set; }
    public int Parent { get; set; }
    public int BoneLevel { get; set; }

    public Matrix3D HieMtx { get; set; }
    public Matrix3D GlblMtx { get; set; }
    public Matrix3D BnOfsMtx { get; set; }
    public Matrix3D HieMtxLayered { get; set; }

    public List<int> Children { get; set; }
  }



  [Serializable]
  public class NotifyPropertyChangedBase : INotifyPropertyChanged
  {
    [field: NonSerialized]
    public event PropertyChangedEventHandler PropertyChanged;
    public void OnPropertyChanged(string name)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(name));
      }
    }
  }
}
