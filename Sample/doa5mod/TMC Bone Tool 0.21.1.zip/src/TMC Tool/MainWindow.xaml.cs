﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Runtime.Serialization.Formatters.Binary;
using Message;

namespace TMC_Tool
{
  /// <summary>
  /// MainWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class MainWindow : Window
  {
    public static TmcData tmcData;
    public static TmcData boneData;

    public static MainViewModel vm;

    private static byte[] bn;
    private static byte[] boneBn;

    private static string curCellText = "";
    private static SortedSet<int> selectedColumns = new SortedSet<int>();
    private static int currentColumnIndex = -1;
    private static Dictionary<int, SortedSet<int>> selCellIndices;

    private static List<string> deleteBoneList;

    private static MainViewModel.NodecpData clipboardNodecpData;

    private static bool autoSetComboBox = false;

    private static bool dropOpened = false;

    private static bool modifiedBone = false;
    private static bool modifiedCollision = false;
    private static bool modifiedPhysics = false;
    private static bool modifiedNodecp = false;

    private static bool appStarted = false;
    private static bool updateChecking = true;
    private static bool modified = false;
    private static bool exitConfirm = false;
    public static Dictionary<string, string> txt = new Dictionary<string, string>();
    public static string langType = "Jpn";

    ContextMenu menuDataGridPhysics = new ContextMenu();



    public MainWindow()
    {
      InitializeComponent();

      MainWindowTitle();
      changeLanguage();
      MessageWindow.lang(txt);
      MainViewModel.lang(txt);

      Application.Current.ShutdownMode = ShutdownMode.OnMainWindowClose;
    }

    private void mainWindow_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      if (e.LeftButton == MouseButtonState.Pressed) this.DragMove();
    }

    private void mainWindow_Loaded(object sender, RoutedEventArgs e)
    {
      vm = new MainViewModel();
      this.DataContext = vm;

      List<string> cmds = System.Environment.GetCommandLineArgs().ToList();
      cmds.RemoveAt(0);
      openDorpFile(cmds, null);

      vissiblePosition.IsChecked = true;
    }

    private void mainWindow_DragOver(object sender, DragEventArgs e)
    {
      e.Handled = true;
      if (e.Data.GetDataPresent(DataFormats.FileDrop))
        e.Effects = DragDropEffects.Move;
      else
        e.Effects = DragDropEffects.None;
    }

    private void mainWindow_DragDrop(object sender, DragEventArgs e)
    {
      if (!dropOpened)
      {
        List<string> filePaths = ((string[])e.Data.GetData(DataFormats.FileDrop, false)).ToList();
        openDorpFile(filePaths, null);
      }
      dropOpened = false;
    }

    private void gbTMC_Drop(object sender, DragEventArgs e)
    {
      List<string> filePaths = ((string[])e.Data.GetData(DataFormats.FileDrop, false)).ToList();
      openDorpFile(filePaths, "TMC");
      dropOpened = true;
    }

    private void gbBone_Drop(object sender, DragEventArgs e)
    {
      List<string> filePaths = ((string[])e.Data.GetData(DataFormats.FileDrop, false)).ToList();
      openDorpFile(filePaths, "Bone");
      dropOpened = true;
    }

    private void openDorpFile(List<string> filePaths, string type)
    {
      if (filePaths.Count < 1) return;

      string tmcPath = "";
      string bonePath = "";
      List<string> lnkPaths = new List<string>();
      foreach (string path in filePaths)
      {
        if (tmcPath == "" && Path.GetExtension(path).ToUpper() == ".TMC" &&
          (type == "TMC" || (type == null && (tbTMC.Path == "" || tbBone.Path != ""))))
        {
          tmcPath = path;
        }
        else if (bonePath == "" && (Path.GetExtension(path).ToUpper() == ".TMC" ||
          Path.GetExtension(path).ToLower() == ".tmcbone"))
        {
          bonePath = path;
        }
        else if (Path.GetExtension(path).ToLower() == ".lnk")
        {
          lnkPaths.Add(path);
        }
      }

      if (lnkPaths.Count > 0)
      {
        Type t = Type.GetTypeFromCLSID(new Guid("72C24DD5-D70A-438B-8A42-98424B88AFB8"));
        dynamic shell = Activator.CreateInstance(t);
        List<string> shortcutPaths = new List<string>();
        foreach (string path in lnkPaths)
        {
          var shortcut = shell.CreateShortcut(path);
          shortcutPaths.Add(shortcut.TargetPath);
          System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shortcut);
        }
        System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shell);

        foreach (string path in shortcutPaths)
        {
          if (tmcPath == "" && Path.GetExtension(path).ToUpper() == ".TMC" &&
          (type == "TMC" || (type == null && (tbTMC.Path == "" || tbBone.Path != ""))))
          {
            tmcPath = path;
          }
          else if (bonePath == "" && (Path.GetExtension(path).ToUpper() == ".TMC" ||
            Path.GetExtension(path).ToLower() == ".tmcbone"))
          {
            bonePath = path;
          }
          if (tmcPath != "" && bonePath != "") break;
        }
      }

      if (tmcPath != "")
      {
        if (tbBone.Path != "" && bonePath == "") bonePath = tbBone.Path;
        OpenFile(tmcPath);
        if (bonePath != "") OpenBoneFile(bonePath);
      }
      else if (tbTMC.Path != "" && bonePath != "")
      {
        OpenBoneFile(bonePath);
      }
    }

    private void OpenFromClipboard()
    {
      var pathText = Clipboard.GetText();
      if (Clipboard.ContainsFileDropList())
      {
        //データを取得する（取得できなかった時はnull）
        System.Collections.Specialized.StringCollection files = Clipboard.GetFileDropList();
        if (files != null) pathText = files[0];
      }
      if (!string.IsNullOrEmpty(pathText) && File.Exists(pathText) && Path.GetExtension(pathText).ToUpper() == ".TMC")
      {
        var result = MessageWindow.Show(this, pathText + "\r\n\r\n" + txt["ConfirmOpenFile"], txt["Info"], txt["btnOpen"], txt["Cancel"]);
        if (result == MessageWindow.Result.OK)
        {
          var bonedataPath = "";
          if (tbBone.Path != "") bonedataPath = tbBone.Path;
          OpenFile(pathText);
          if (bonedataPath != "") OpenBoneFile(bonedataPath);
        }
        Keyboard.Focus(mainWindow);
      }
    }

    private void openCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
      dlg.Filter = "TMC Files|*.TMC";
      if (tbTMC.Path != "")
      {
        dlg.InitialDirectory = Path.GetDirectoryName(tbTMC.Path);
        dlg.FileName = Path.GetFileName(tbTMC.Path);
      }
      if (dlg.ShowDialog() == true)
      {
        var bonedataPath = "";
        if (tbBone.Path != "") bonedataPath = tbBone.Path;
        OpenFile(dlg.FileName);
        if (bonedataPath != "") OpenBoneFile(bonedataPath);
      }
    }

    private void btnOpenBone_Click(object sender, RoutedEventArgs e)
    {
      Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
      dlg.Filter = "Bone Data Files|*.TMC;*.tmcbone";
      if (tbBone.Path != "")
      {
        dlg.InitialDirectory = Path.GetDirectoryName(tbBone.Path);
        dlg.FileName = Path.GetFileName(tbBone.Path);
      }
      if (dlg.ShowDialog() == true)
      {
        OpenBoneFile(dlg.FileName);
      }
    }

    private void clearBoneDataCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (boneData != null)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void clearBoneDataCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      tbBone.Path = "";

      autoSetComboBox = true;
      cmbSelection.SelectedIndex = 1;
      cmbPresetCollision.SelectedIndex = 1;
      autoSetComboBox = false;

      // 追加したボーンを退避
      var addedBones = new List<MainViewModel.BoneData>();
      var addedBonesParents = new List<int>();
      foreach (var bone in vm.Bones)
      {
        if (!bone.IsAdded || bone.InPhysics) continue;

        addedBones.Add(bone);
        addedBonesParents.Add(bone.Parent);
      }

      if (vm.Bones.Count > 0) vm.Bones.Clear();

      vm.SetBones(tmcData);

      int boneCount = vm.Bones.Count;

      // 退避したボーンを追加
      foreach (var bone in addedBones)
      {
        vm.ParentBones.Add(bone.Name);
        bone.Refer = 0;
        vm.Bones.Add(bone);
      }
      for (int i = 0; i < addedBonesParents.Count; i++)
      {
        vm.Bones[boneCount + i].Parent = addedBonesParents[i];
      }

      vm.ResetCollisions();
      vm.ResetPhysics();
      vm.ChangeChangeableParent();
      boneData = null;
      boneBn = null;
      cbHeader.IsChecked = false;
      cbHeader.IsEnabled = false;
    }

    private void saveCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (
        tmcData != null &&
        (
          boneData != null ||
          (vm.IsEnabledBone && modifiedBone && (vm.Parentage || vm.IsChangedBone)) ||
          (vm.IsEnabledCollision && modifiedCollision) ||
          (vm.IsEnabledPhysics && modifiedPhysics) ||
          (vm.IsEnabledNodecp && modifiedNodecp)
        ) &&
        (vm.RootExist || !vm.Parentage)
      )
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void saveCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      DataGrid_CommitEdit();

      if (!PreSaveCheck())
      {
        MessageWindow.Show(this, txt["ErrorCheckNothing"], txt["Error"]);
        return;
      }

      var result = MessageWindow.Show(this, txt["Overwrite"], txt["Confirm"], txt["OverwriteYes"], txt["Cancel"]);
      if (result == MessageWindow.Result.OK)
      {
        SaveFile(tbTMC.Path);
      }
    }

    private void saveWithBackupCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      DataGrid_CommitEdit();

      if (!PreSaveCheck())
      {
        MessageWindow.Show(this, txt["ErrorCheckNothing"], txt["Error"]);
        return;
      }

      string newPath = CreateBackup(tbTMC.Path);
      if (newPath != null)
      {
        if (!SaveFile(tbTMC.Path))
        {
          if (File.Exists(newPath)) File.Move(newPath, tbTMC.Path);
        }
      }
      else
      {
        MessageWindow.Show(this, txt["FailedToCreateBackup"], txt["Error"]);
      }
    }

    private void saveAsCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (
        tmcData != null &&
        (
          boneData != null ||
          (vm.IsEnabledBone && modifiedBone && (vm.Parentage || vm.IsChangedBone)) ||
          vm.IsEnabledCollision ||
          (vm.IsEnabledPhysics && modifiedPhysics) ||
          (vm.IsEnabledNodecp && modifiedNodecp)
        ) &&
        (vm.RootExist || !vm.Parentage)
      )
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void saveAsCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      DataGrid_CommitEdit();

      if (!PreSaveCheck())
      {
        MessageWindow.Show(this, txt["ErrorCheckNothing"], txt["Error"]);
        return;
      }

      Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
      dlg.InitialDirectory = Path.GetDirectoryName(tbTMC.Path);
      dlg.FileName = Path.GetFileName(tbTMC.Path);
      dlg.DefaultExt = ".TMC";
      dlg.Filter = "TMC Files (.TMC)|*.TMC";

      Nullable<bool> result = dlg.ShowDialog();

      if (result == true)
      {
        this.IsEnabled = false;
        SaveFile(dlg.FileName);
      }
    }

    private void exportCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (tmcData != null)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void exportCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      DataGrid_CommitEdit();

      Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
      string targetPath = tbTMC.Path;
      if (tbBone.Path != "") targetPath = tbBone.Path;
      dlg.InitialDirectory = Path.GetDirectoryName(targetPath);
      dlg.FileName = Path.GetFileNameWithoutExtension(targetPath);
      dlg.DefaultExt = ".tmcbone";
      dlg.Filter = "tmcbone Files (.tmcbone)|*.tmcbone";
      dlg.Title = txt["Export"];

      Nullable<bool> result = dlg.ShowDialog();

      if (result == true)
      {
        this.IsEnabled = false;
        ExportTmcbone(dlg.FileName);
      }
    }


    private void CellComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      ComboBox target = sender as ComboBox;

      if (!modified && (target.IsMouseCaptured || target.IsKeyboardFocused))
      {
        modified = true;
        CommandManager.InvalidateRequerySuggested();
      }

      if (target.IsMouseCaptured || target.IsKeyboardFocused)
      {
        DataGrid dataGrid = Common.Styles.FindVisualParent<DataGrid>(target);
        DataGridRow dataGridRow = Common.Styles.FindVisualParent<DataGridRow>(target);
        var curItem = dataGridRow.Item as MainViewModel.PhysicsData;
        var data = vm.Physics;

        bool selIndex = false;

        var b = BindingOperations.GetBinding(target, ComboBox.SelectedItemProperty) as Binding;
        if (b == null || b.Path == null)
        {
          b = BindingOperations.GetBinding(target, ComboBox.SelectedIndexProperty) as Binding;
          if (b == null || b.Path == null)
          {
            return;
          }
          selIndex = true;
        }
        var p = b.Path.Path;
        if (string.IsNullOrEmpty(p)) return;
        var i = p.LastIndexOf('.');

        if (i < 0)
        {
          if (dataGrid.SelectedItems.Count > 1)
          {
            Type type = target.DataContext.GetType();
            PropertyInfo pi = type.GetProperty(p);

            dynamic val = target.SelectedItem;
            if (selIndex)
            {
              val = target.SelectedIndex;
            }

            foreach (var selItem in dataGrid.SelectedItems)
            {
              var item = selItem as MainViewModel.PhysicsData;

              dynamic valDist = pi.GetValue(data[dataGrid.Items.IndexOf(item)]);
              if (valDist != null && valDist != -1)
              {
                if (p == "CollisionType")
                {
                  pi.SetValue(data[dataGrid.Items.IndexOf(item)], val, null);
                  item.IsEdited = true;
                }
              }
            }
          }
        }

        if (dataGrid.Name == "dgPhysics")
        {
          curItem.IsEdited = true;
          modifiedPhysics = true;
        }
      }
    }

    private void CellComboBox_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
    {
      ComboBox target = sender as ComboBox;
      DataGrid dataGrid = Common.Styles.FindVisualParent<DataGrid>(target);
      DataGridRow row = Common.Styles.FindVisualParent<DataGridRow>(target);
      DataGridCell cell = Common.Styles.FindVisualParent<DataGridCell>(target);
      if (!cell.IsSelected)
      {
        if (dataGrid.SelectedCells.Count > 0) dataGrid.SelectedCells.Clear();
        dataGrid.SelectedIndex = -1;
        SetShiftSelectBase(dataGrid, row, cell.Column.DisplayIndex);
      }
    }

    private void CheckBox_Click(object sender, RoutedEventArgs e)
    {
      CheckBox target = sender as CheckBox;

      DataGrid dataGrid = Common.Styles.FindVisualParent<DataGrid>(target);
      DataGridRow dataGridRow = Common.Styles.FindVisualParent<DataGridRow>(target);
      string dataType = "bone";
      dynamic data = vm.Bones;
      dynamic curItem = dataGridRow.Item as MainViewModel.BoneData;
      if (dataGrid.Name == "dgPhysics")
      {
        dataType = "physics";
        data = vm.Physics;
        curItem = dataGridRow.Item as MainViewModel.PhysicsData;
        modifiedPhysics = true;
      }

      autoSetComboBox = true;
      cmbSelection.SelectedIndex = 0;
      autoSetComboBox = false;

      cbHeader.IsChecked = false;

      var b = BindingOperations.GetBinding(target, CheckBox.IsCheckedProperty) as Binding;
      if (b == null || b.Path == null)
      {
        return;
      }
      var p = b.Path.Path;
      if (string.IsNullOrEmpty(p)) return;
      var i = p.LastIndexOf('.');
      if (i < 0)
      {
        if (dataGrid.SelectedItems.Count > 1)
        {
          Type type = target.DataContext.GetType();
          PropertyInfo pi = type.GetProperty(p);

          if (dataType == "physics")
          {
            foreach (MainViewModel.PhysicsData item in dataGrid.SelectedItems)
            {
              if (!item.InUse && !item.Recalcable) continue;
              dynamic valDist = pi.GetValue(data[dataGrid.Items.IndexOf(item)]);
              if (valDist != null)
              {
                pi.SetValue(data[dataGrid.Items.IndexOf(item)], (bool)target.IsChecked, null);
              }
            }
          }
          else
          {
            foreach (MainViewModel.BoneData item in dataGrid.SelectedItems)
            {
              dynamic valDist = pi.GetValue(data[dataGrid.Items.IndexOf(item)]);
              if (valDist != null && item.Selectable)
              {
                pi.SetValue(data[dataGrid.Items.IndexOf(item)], (bool)target.IsChecked, null);
              }
            }
          }
        }
      }

      modified = true;
    }

    private void DataGrid_BeginningEdit(object sender, DataGridBeginningEditEventArgs e)
    {
      var dataGrid = sender as DataGrid;
      FrameworkElement contentElement = dataGrid.CurrentCell.Column.GetCellContent(dataGrid.CurrentCell.Item);
      var tb = contentElement as TextBlock;

      curCellText = tb.Text;
    }

    private void DataGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
    {
      var dataGrid = sender as DataGrid;
      if (dataGrid.SelectedCells.Count < 1) return;

      var tb = e.EditingElement as TextBox;

      if (tb.Text == curCellText) return;

      float val;
      if (!float.TryParse(tb.Text, out val))
      {
        tb.Text = curCellText;
        return;
      }

      DataGridRow dataGridRow = e.Row;

      if (dataGridRow == null)
      {
        tb.Text = curCellText;
        return;
      }

      modified = true;
      if (dataGrid.Name == "dgCollision")
      {
        var item = dataGridRow.Item as MainViewModel.CollisionData;
        modifiedCollision = true;

        if (e.Column.SortMemberPath != "Code" && item.Data != txt["CustomData"])
        {
          if (!item.DataList.Contains(txt["CustomData"]))
            item.DataList.Add(txt["CustomData"]);

          item.BaseData = item.CurrentData;
          item.Data = txt["CustomData"];
          item.CurrentData = txt["CustomData"];

          autoSetComboBox = true;
          cmbPresetCollision.SelectedIndex = 0;
          autoSetComboBox = false;
        }
      }
      else if (dataGrid.Name == "dgPhysics")
      {
        var item = dataGridRow.Item as MainViewModel.PhysicsData;
        item.IsEdited = true;
        modifiedPhysics = true;
      }
    }

    private void dgPhysicsColumnHeader_Click(object sender, RoutedEventArgs e)
    {
      var header = sender as DataGridColumnHeader;
      if (header == null || header.DisplayIndex < 2) return;
      currentColumnIndex = SelectColumnAllCells(dgPhysics, header.DisplayIndex, currentColumnIndex);
    }

    public static void ForceUpdate(DataGrid dataGrid)
    {
      TextBox textBox = Keyboard.FocusedElement as TextBox;

      if (dataGrid == null || textBox == null) return;

      BindingExpression ex = textBox.GetBindingExpression(TextBox.TextProperty);
      if (ex != null) ex.UpdateSource();

      Common.Styles.DataGridCommitEdit(dataGrid);
    }

    public static int SelectColumnAllCells(DataGrid dataGrid, int column, int curColIndex)
    {
      ForceUpdate(dataGrid);

      dataGrid.Focus();

      SortedSet<int> selected = new SortedSet<int>();

      if ((Keyboard.Modifiers & ModifierKeys.Shift) > 0 && curColIndex != -1)
      {
        if (curColIndex < column)
        {
          for (int i = curColIndex; i <= column; i++)
          {
            selected.Add(i);
          }
        }
        else
        {
          for (int i = column; i <= curColIndex; i++)
          {
            selected.Add(i);
          }
        }
      }
      else
      {
        selected.Add(column);
        curColIndex = column;
      }

      if ((Keyboard.Modifiers & ModifierKeys.Control) > 0)
      {
        if (selectedColumns.Contains(column))
        {
          selectedColumns.Remove(column);
          foreach (var row in dataGrid.Items)
          {
            var dataGridCellInfo = new DataGridCellInfo(row, dataGrid.Columns[column]);
            if (dataGrid.SelectedCells.Contains(dataGridCellInfo)) dataGrid.SelectedCells.Remove(dataGridCellInfo);
          }

          return curColIndex;
        }
      }
      else
      {
        if (dataGrid.SelectedCells.Count > 0) dataGrid.SelectedCells.Clear();
        if (selectedColumns.Count > 0) selectedColumns.Clear();
      }

      foreach (var col in selected)
      {
        foreach (var row in dataGrid.Items)
        {
          var dataGridCellInfo = new DataGridCellInfo(row, dataGrid.Columns[col]);
          if (!dataGrid.SelectedCells.Contains(dataGridCellInfo)) dataGrid.SelectedCells.Add(dataGridCellInfo);
        }
        selectedColumns.Add(col);
      }

      return curColIndex;
    }

    private void fillDownCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      var dataGrid = e.Source as DataGrid;
      selCellIndices = PreCheckFillDown(dataGrid);
      if (dataGrid != null && dataGrid.SelectedCells.Count > 0 && selCellIndices != null)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void fillDownCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var dataGrid = e.Source as DataGrid;
      FillDown(dataGrid);
    }

    public static Dictionary<int, SortedSet<int>> PreCheckFillDown(DataGrid dataGrid)
    {
      if (dataGrid == null) return null;

      var selIndices = new Dictionary<int, SortedSet<int>>();
      List<int> colSet = new List<int>();

      foreach (var cell in dataGrid.SelectedCells)
      {
        int selColIndex = cell.Column.DisplayIndex;

        if (
          (dataGrid.Name == "dgPhysics" && (selColIndex < 3 || selColIndex > 7)) ||
          (dataGrid.Name == "dgPhysicsBones" && (selColIndex < 2 || selColIndex > 6))
        )
        {
          continue;
        }

        colSet.Add(selColIndex);

        if (!selIndices.ContainsKey(selColIndex))
        {
          var selRowIndices = new SortedSet<int>();
          selIndices[selColIndex] = selRowIndices;
        }

        int selRowIndex = -1;
        if (dataGrid.Name == "dgPhysics")
        {
          var item = cell.Item as MainViewModel.PhysicsData;

          if (!item.Recalcable) return null;

          selRowIndex = dataGrid.Items.IndexOf(item);
        }
        else if (dataGrid.Name == "dgPhysicsBones")
        {
          var item = cell.Item as MainViewModel.PhysicsChildrenData;
          selRowIndex = dataGrid.Items.IndexOf(item);
        }

        if (selRowIndex != -1) selIndices[selColIndex].Add(selRowIndex);
      }

      if (colSet.Count == 0 || selIndices[colSet[0]].Count < 2)
      {
        return null;
      }

      SortedSet<int> checkSet = new SortedSet<int>();
      foreach (var set in selIndices)
      {
        checkSet.UnionWith(set.Value);
        if (checkSet.Count != set.Value.Count)
        {
          return null;
        }
      }

      int num = selIndices[colSet[0]].ToArray()[0];
      for (int i = 1; i < selIndices[colSet[0]].Count; i++)
      {
        num++;
        if (selIndices[colSet[0]].ToArray()[i] != num)
        {
          return null;
        }
      }

      return selIndices;
    }

    private void FillDown(DataGrid dataGrid)
    {
      DataGridCellInfo dataGridCellInfo;

      foreach (var set in selCellIndices)
      {
        var val = GetPhysicsData(vm.Physics[set.Value.ToArray()[0]], dataGrid.Columns[set.Key].SortMemberPath);
        if (val == null) continue;

        for (int i = 1; i < set.Value.Count; i++)
        {
          dataGridCellInfo = new DataGridCellInfo(dataGrid.Items[set.Value.ToArray()[i]], dataGrid.Columns[set.Key]);
          var item = dataGridCellInfo.Item as MainViewModel.PhysicsData;

          SetPhysicsData(item, dataGridCellInfo.Column.SortMemberPath, (float)val);
        }
      }

      modified = true;
      if (dataGrid.Name == "dgPhysics")
      {
        modifiedPhysics = true;
      }

      selCellIndices = null;
    }

    private float? GetPhysicsData(MainViewModel.PhysicsData data, string property)
    {
      switch (property)
      {
        case "Params[1]":
          return data.Params[1];
        case "Params[2]":
          return data.Params[2];
        case "Params[3]":
          return data.Params[3];
        case "Params[4]":
          return data.Params[4];
        case "Params[5]":
          return data.Params[5];
        default:
          return null;
      }
    }

    private void SetPhysicsData(MainViewModel.PhysicsData data, string property, float val)
    {
      switch (property)
      {
        case "Params[1]":
          data.Params[1] = val;
          break;
        case "Params[2]":
          data.Params[2] = val;
          break;
        case "Params[3]":
          data.Params[3] = val;
          break;
        case "Params[4]":
          data.Params[4] = val;
          break;
        case "Params[5]":
          data.Params[5] = val;
          break;
      }
    }

    private void DataGrid_CommitEdit()
    {
      if (tabPhysics.IsSelected)
        Common.Styles.DataGridCommitEdit(dgPhysics);
    }


    private void cmbSelection_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (!this.IsInitialized || autoSetComboBox) return;

      ComboBox target = sender as ComboBox;

      if (target.SelectedIndex == 1)
      {
        foreach (var bone in vm.Bones)
        {
          if (bone.IsBone && bone.Refer != 0)
          {
            bone.Selected = true;
          }
          else
          {
            bone.Selected = false;
          }
        }
      }
      else if (target.SelectedIndex == 2)
      {
        foreach (var bone in vm.Bones)
        {
          if (bone.IsBone && bone.Refer != 0 && (
            Regex.IsMatch(bone.Name, @"^MOT[0-9]{2}") ||
            Regex.IsMatch(bone.Name, @"^OPT_[^a-z]") ||
            bone.Name == "OPT_acs_ground"
            )
          )
          {
            bone.Selected = true;
          }
          else
          {
            bone.Selected = false;
          }
        }
      }
      else if (target.SelectedIndex == 3)
      {
        foreach (var bone in vm.Bones)
        {
          if (bone.IsBone && bone.Refer != 0 &&
            !Regex.IsMatch(bone.Name, @"^MOT[0-9]{2}") &&
            !Regex.IsMatch(bone.Name, @"^OPT_[^a-z]") &&
            bone.Name != "OPT_acs_ground"
          )
          {
            bone.Selected = true;
          }
          else
          {
            bone.Selected = false;
          }
        }
      }
      else if (target.SelectedIndex == 4)
      {
        foreach (var bone in vm.Bones)
        {
          bone.Selected = false;
        }
      }

      cbHeader.IsChecked = false;

      modified = true;
    }

    private void HeaderCheckBox_Click(object sender, RoutedEventArgs e)
    {
      CheckBox cb = sender as CheckBox;

      autoSetComboBox = true;
      cmbSelection.SelectedIndex = 0;
      autoSetComboBox = false;

      foreach (var bone in vm.Bones)
      {
        if (bone.Selectable) bone.Selected = (bool)cb.IsChecked;
      }

      modified = true;
    }

    private void ComboBoxRefer_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      ComboBox target = sender as ComboBox;

      if (!this.IsInitialized || !(target.IsMouseCaptured || target.IsKeyboardFocused)) return;

      DataGrid dataGrid = Common.Styles.FindVisualParent<DataGrid>(target);
      DataGridRow dataGridRow = Common.Styles.FindVisualParent<DataGridRow>(target);
      var data = vm.Bones;
      var curItem = dataGridRow.Item as MainViewModel.BoneData;

      if (target.SelectedIndex == 0)
      {
        autoSetComboBox = true;
        cmbSelection.SelectedIndex = 0;
        autoSetComboBox = false;
      }

      modified = true;
    }

    private void ComboBoxParent_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      ComboBox target = sender as ComboBox;

      if (!this.IsInitialized || !(target.IsMouseCaptured || target.IsKeyboardFocused)) return;

      DataGrid dataGrid = Common.Styles.FindVisualParent<DataGrid>(target);
      DataGridRow dataGridRow = Common.Styles.FindVisualParent<DataGridRow>(target);
      var data = vm.Bones;
      var curItem = dataGridRow.Item as MainViewModel.BoneData;

      if (curItem.Parent != curItem.OriginalParent)
        curItem.ChangedParent = true;
      else
        curItem.ChangedParent = false;

      vm.CheckRootExist();

      modified = true;
      modifiedBone = true;
    }

    private void addBoneCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      e.CanExecute = false;

      if (!this.IsInitialized) return;

      if (dgBone.SelectedItems.Count == 1)
        e.CanExecute = true;
    }
    private void addBoneCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      MainViewModel.BoneData newBone;
      MainViewModel.BoneData bone = null;

      var dataGrid = e.Source as DataGrid;
      if (dataGrid != null && dataGrid.Name == "dgBone" && dataGrid.SelectedItems.Count == 1)
      {
        bone = dataGrid.SelectedItem as MainViewModel.BoneData;
      }

      string boneNmae = InputBoneNameWindow.Show(this, bone);

      if (boneNmae == null) return;


      newBone = vm.AddBone(boneNmae, bone);

      dgBone.SelectedItem = newBone;
      dgBone.ScrollIntoView(dgBone.SelectedItem);
      DataGridRow row = (DataGridRow)dgBone.ItemContainerGenerator.ContainerFromItem(dgBone.SelectedItem);
      SetShiftSelectBase(dgBone, row, 0);

      vm.IsChangedBone = true;

      modified = true;
      modifiedBone = true;
    }

    private void deleteBoneCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (!this.IsInitialized) return;

      GetDeletableBones();

      if (deleteBoneList.Count > 0)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void deleteBoneCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      if (deleteBoneList == null) return;

      vm.DeleteBones(deleteBoneList, false);

      vm.IsChangedBone = true;

      modified = true;
      modifiedBone = true;
    }

    private void GetDeletableBones()
    {
      deleteBoneList = new List<string>();

      foreach (var item in dgBone.SelectedItems)
      {
        SetDeleteBone(item as MainViewModel.BoneData);
      }
    }

    private void SetDeleteBone(MainViewModel.BoneData bone)
    {
      // nullか 削除済みでないか 子を持っているか
      if (bone == null || bone.IsDeleted || deleteBoneList.Contains(bone.Name) ||
        vm.Bones.Where(elem => vm.ParentBones[elem.Parent] == bone.Name && !elem.IsDeleted && !deleteBoneList.Contains(elem.Name)).Count() > 0
      )
      {
        return;
      }


      // Physicsで使用されているか
      foreach (var physics in vm.Physics)
      {
        if (!physics.IsIncluded) continue;

        if (physics.Root == bone.Name)
        {
          return;
        }

        foreach (var physicsBone in physics.Bones)
        {
          if (physicsBone.Name == bone.Name)
          {
            return;
          }
        }
      }


      // BlendIndexで使用されているか
      if (!bone.IsAdded)
      {
        foreach (var node in tmcData.Node)
        {
          if (bone.OriginalIndex == node.Index && node.ObjIndex != -1)
          {
            return;
          }

          if (tmcData.BlendIdxGrp.ContainsKey(node.Index))
          {
            foreach (var index in tmcData.BlendIdxGrp[node.Index].Idx)
            {
              if (bone.OriginalIndex == index)
              {
                return;
              }
            }
          }
        }
      }


      deleteBoneList.Add(bone.Name);

      int parentIndex = Array.FindIndex(vm.Bones.ToArray(), elem => elem.Name == vm.ParentBones[bone.Parent]);
      if (parentIndex < 1) return;

      var parent = vm.Bones[parentIndex];

      foreach (var item in dgBone.SelectedItems)
      {
        var selected = item as MainViewModel.BoneData;

        if (selected.Name == parent.Name)
        {
          if (!deleteBoneList.Contains(parent.Name)) SetDeleteBone(parent);
        }
      }
    }


    private void undeleteBoneCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (!this.IsInitialized) return;

      e.CanExecute = false;

      foreach (var item in dgBone.SelectedItems)
      {
        var bone = item as MainViewModel.BoneData;

        if (bone.IsDeleted && !bone.InPhysics)
        {
          e.CanExecute = true;
          return;
        }
      }
    }
    private void undeleteBoneCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      foreach (var item in dgBone.SelectedItems)
      {
        var bone = item as MainViewModel.BoneData;

        if (bone.IsDeleted && !bone.InPhysics)
        {
          bone.IsDeleted = false;

          int deleteIndex = Array.FindIndex(vm.Collisions.ToArray(), elem => elem.Name == bone.Name);
          if (deleteIndex != -1) vm.Collisions[deleteIndex].Data = vm.Collisions[deleteIndex].CurrentData;
        }
      }
    }


    private void cmbPresetCollision_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (!this.IsInitialized || autoSetComboBox) return;

      ComboBox target = sender as ComboBox;

      if (target.SelectedIndex == 1)
      {
        foreach (var collision in vm.Collisions)
        {
          if (collision.DataList.Contains(txt["BoneData"]))
          {
            collision.Data = txt["BoneData"];
          }
          else
          {
            collision.Data = txt["Delete"];
          }

          collision.DataChanged();
        }
      }
      else if (target.SelectedIndex == 2)
      {
        foreach (var collision in vm.Collisions)
        {
          if (collision.DataList.Contains(txt["BoneData"]))
          {
            collision.Data = txt["BoneData"];
          }
          else
          {
            collision.Data = txt["TmcData"];
          }

          collision.DataChanged();
        }
      }
      else if (target.SelectedIndex == 3)
      {
        foreach (var collision in vm.Collisions)
        {
          if (!collision.DataList.Contains(txt["TmcData"]))
          {
            collision.Data = txt["Delete"];
          }
          else
          {
            collision.Data = txt["TmcData"];
          }

          collision.DataChanged();
        }
      }

      modified = true;
      modifiedCollision = true;
    }

    private void cmbCollisionData_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      ComboBox target = sender as ComboBox;

      if (!this.IsInitialized || !(target.IsMouseCaptured || target.IsKeyboardFocused)) return;

      DataGrid dataGrid = Common.Styles.FindVisualParent<DataGrid>(target);
      DataGridRow dataGridRow = Common.Styles.FindVisualParent<DataGridRow>(target);
      var data = vm.Bones;
      var curItem = dataGridRow.Item as MainViewModel.CollisionData;

      autoSetComboBox = true;
      cmbPresetCollision.SelectedIndex = 0;
      autoSetComboBox = false;

      modified = true;
      modifiedCollision = true;

      curItem.DataChanged();

      if (dataGrid.SelectedItems.Count > 1)
      {
        foreach (var selItem in dataGrid.SelectedItems)
        {
          var item = selItem as MainViewModel.CollisionData;
          if (item == curItem) continue;
          if (item.DataList.Contains(curItem.Data))
            item.Data = curItem.Data;
          else
            item.Data = txt["Delete"];

          item.DataChanged();
        }
      }
    }

    private void vissibleTransform_CheckeChanged(object sender, RoutedEventArgs e)
    {
      if (!this.IsInitialized) return;

      if (vissibleRotation.IsChecked == true)
      {
        dgcColRotX.Visibility = Visibility.Visible;
        dgcColRotY.Visibility = Visibility.Visible;
        dgcColRotZ.Visibility = Visibility.Visible;
      }
      else
      {
        dgcColRotX.Visibility = Visibility.Collapsed;
        dgcColRotY.Visibility = Visibility.Collapsed;
        dgcColRotZ.Visibility = Visibility.Collapsed;
      }

      if (vissibleSize.IsChecked == true)
      {
        dgcColSizeX.Visibility = Visibility.Visible;
        dgcColSizeY.Visibility = Visibility.Visible;
        dgcColSizeZ.Visibility = Visibility.Visible;
      }
      else
      {
        dgcColSizeX.Visibility = Visibility.Collapsed;
        dgcColSizeY.Visibility = Visibility.Collapsed;
        dgcColSizeZ.Visibility = Visibility.Collapsed;
      }

      if (vissiblePosition.IsChecked == true)
      {
        dgcColPosX.Visibility = Visibility.Visible;
        dgcColPosY.Visibility = Visibility.Visible;
        dgcColPosZ.Visibility = Visibility.Visible;
      }
      else
      {
        dgcColPosX.Visibility = Visibility.Collapsed;
        dgcColPosY.Visibility = Visibility.Collapsed;
        dgcColPosZ.Visibility = Visibility.Collapsed;
      }
    }


    private void showPhysicsDetailsCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      var items = GetSlectedPhysicsItems();

      if (items.Count == 1 && items.ToArray()[0].Type != "Type2")
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void showPhysicsDetailsCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var items = GetSlectedPhysicsItems();

      if (items.Count != 1) return;

      ShowPhysicsDetails(items.ToArray()[0]);
    }

    private void importPhysicsCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      var items = GetSlectedPhysicsItems();

      if (items.Count == 0)
      {
        e.CanExecute = false;
        return;
      }

      bool canExecute = true;

      foreach (var item in items)
      {
        if (item.IsIncluded)
        {
          canExecute = false;
          break;
        }
      }

      e.CanExecute = canExecute;
    }
    private void importPhysicsCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var items = GetSlectedPhysicsItems();

      foreach (var item in items)
      {
        item.IsIncluded = true;

        // 名前重複確認
        item.Root = vm.CheckNodeNameExist(item.Root, -1);

        // ボーン追加
        vm.AddBonesInPhysics(item);
      }

      vm.IsChangedBone = true;

      modified = true;
      modifiedBone = true;
      modifiedPhysics = true;
    }

    private void deletePhysicsCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      var items = GetSlectedPhysicsItems();

      if (items.Count == 0)
      {
        e.CanExecute = false;
        return;
      }

      bool canExecute = true;

      foreach (var item in items)
      {
        if (!item.IsIncluded)
        {
          canExecute = false;
          break;
        }
      }

      e.CanExecute = canExecute;
    }
    private void deletePhysicsCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var items = GetSlectedPhysicsItems();

      foreach (var item in items)
      {
        item.IsIncluded = false;
      }

      modified = true;
      modifiedPhysics = true;
    }

    private void deletePhysicsWithBonesCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      var items = GetSlectedPhysicsItems();

      if (items.Count == 0)
      {
        e.CanExecute = false;
        return;
      }

      bool canExecute = true;

      foreach (var item in items)
      {
        if (!item.IsDeletable || !item.IsIncluded)
        {
          canExecute = false;
          break;
        }
      }

      e.CanExecute = canExecute;
    }
    private void deletePhysicsWithBonesCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var items = GetSlectedPhysicsItems();

      deleteBoneList = new List<string>();

      foreach (var item in items)
      {
        item.IsIncluded = false;

        deleteBoneList.Add(item.Root);
        foreach (var child in item.Bones)
        {
          deleteBoneList.Add(child.Name);
        }
      }

      vm.DeleteBones(deleteBoneList, true);

      vm.IsChangedBone = true;

      modified = true;
      modifiedBone = true;
      modifiedPhysics = true;
    }

    private void dgPhysicsRowHeader_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
      if (e.LeftButton != MouseButtonState.Pressed) return;

      var target = sender as DataGridRowHeader;
      var curItem = target.DataContext as MainViewModel.PhysicsData;

      ShowPhysicsDetails(curItem);
    }

    private void ShowPhysicsDetails(MainViewModel.PhysicsData data)
    {
      if (data.Type == "Type2") return;

      data.SetBaseNode(vm.Collisions);

      if (data.CollisionType != -1)
      {
        data.CurCollisionType = data.CollisionType;
      }

      var physics = PhysicsWindow.Show(this, data, vm.Collisions.ToList());

      if (physics == null) return;

      int selIndex = dgPhysics.SelectedIndex;
      vm.Physics[selIndex] = physics;
      vm.Physics[selIndex].IsEdited = true;
      dgPhysics.SelectedIndex = selIndex;

      modified = true;
      modifiedPhysics = true;
    }

    private HashSet<MainViewModel.PhysicsData> GetSlectedPhysicsItems()
    {
      HashSet<MainViewModel.PhysicsData> items = new HashSet<MainViewModel.PhysicsData>();

      foreach (var cellInfo in dgPhysics.SelectedCells)
      {
        items.Add(cellInfo.Item as MainViewModel.PhysicsData);
      }

      return items;
    }


    private void cbNodecpDisplay_Checked(object sender, RoutedEventArgs e)
    {
      if (!this.IsInitialized) return;

      NodecpDisplay_Filter();
    }

    private void NodecpDisplay_Filter()
    {
      var viewSource = dgNodecp.ItemsSource as ListCollectionView;

      if (dgNodecp.SelectedItems.Count > 0) dgNodecp.SelectedItems.Clear();

      if (cbNodecpDisplayAll.IsChecked == true)
        viewSource.Filter = null;
      else if (cbNodecpDisplayBreast.IsChecked == true)
        viewSource.Filter = (object obj) => (obj as MainViewModel.NodecpData).Node.IndexOf("Breast") >= 0;
      else
        viewSource.Filter = (object obj) => (obj as MainViewModel.NodecpData).Count > 0;
    }

    private void dgNodecp_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (!this.IsInitialized) return;

      vm.Nodecp = null;

      if (dgNodecp.SelectedItems.Count != 1) return;

      var nodecp = dgNodecp.SelectedItem as MainViewModel.NodecpData;

      if (nodecp == null) return;


      nodecp.Customps = new ObservableCollection<MainViewModel.CustompData>(nodecp.Customps.OrderBy(elem => elem.Code));

      vm.Nodecp = nodecp;
    }

    private void custompCopyCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (vm.Nodecp != null && dgNodecp.SelectedItems.Count == 1)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void custompCopyCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      if (vm.Nodecp != null)
      {
        BinaryFormatter bf = new BinaryFormatter();
        MemoryStream ms = new MemoryStream();
        bf.Serialize(ms, vm.Nodecp);
        Clipboard.SetDataObject(ms);
      }
    }

    private void custompPasteCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      clipboardNodecpData = null;
      var data = GetDataFromClipboard();
      if (data is MainViewModel.NodecpData)
        clipboardNodecpData = data as MainViewModel.NodecpData;

      if (clipboardNodecpData != null)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void custompPasteCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      foreach (var item in dgNodecp.SelectedItems)
      {
        var nodecp = item as MainViewModel.NodecpData;

        nodecp.Count = clipboardNodecpData.Count;

        if (nodecp.Customps.Count > 0) nodecp.Customps.Clear();

        foreach (var customp in clipboardNodecpData.Customps)
        {
          nodecp.Customps.Add(customp);
        }

        nodecp.IsEdited = true;
      }

      modified = true;
      modifiedNodecp = true;
    }

    private object GetDataFromClipboard()
    {
      try
      {
        IDataObject clipboardData = Clipboard.GetDataObject();
        if (clipboardData != null)
        {
          if (clipboardData.GetDataPresent(typeof(MemoryStream)))
          {
            using (MemoryStream stream = clipboardData.GetData(typeof(MemoryStream)) as MemoryStream)
            {
              BinaryFormatter bf = new BinaryFormatter();
              return bf.Deserialize(stream);
            }
          }
        }
        return null;
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
        return null;
      }
    }

    private void addCustompParamCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (vm != null && vm.Nodecp != null)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void addCustompParamCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var newCustomp = new MainViewModel.CustompData();

      uint code = 0;
      while (Array.FindIndex(vm.Nodecp.Customps.ToArray(), elem => elem.Code == code) != -1)
      {
        code++;
      }

      newCustomp.Code = code;
      newCustomp.Type = 0;
      newCustomp.Value = "0";
      vm.Nodecp.Customps.Add(newCustomp);

      vm.Nodecp.Count = vm.Nodecp.Customps.Count;

      vm.Nodecp.IsEdited = true;
      modified = true;
      modifiedNodecp = true;
    }

    private void deleteCustompParamCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (dgCustomp.SelectedItems.Count > 0)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void deleteCustompParamCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      while (dgCustomp.SelectedItems.Count > 0)
      {
        var item = dgCustomp.SelectedItems[0] as MainViewModel.CustompData;
        vm.Nodecp.Customps.Remove(item);
      }

      vm.Nodecp.Count = vm.Nodecp.Customps.Count;

      vm.Nodecp.IsEdited = true;
      modified = true;
      modifiedNodecp = true;
    }

    private void TextBoxCustompValue_KeyDown(object sender, KeyEventArgs e)
    {
      TextBox target = sender as TextBox;
      DataGridRow dataGridRow = Common.Styles.FindVisualParent<DataGridRow>(target);

      var customp = dataGridRow.Item as MainViewModel.CustompData;

      if (customp.Type == 2)
      {
        // float
        if (e.Key == Key.System || e.Key == Key.Tab)
        {
          e.Handled = false;
        }
        else if ((Key.D0 <= e.Key && e.Key <= Key.D9) || (Key.NumPad0 <= e.Key && e.Key <= Key.NumPad9))
        {
          e.Handled = false;
        }
        else if (e.Key == Key.Decimal || e.Key == Key.OemPeriod)
        {
          if (target.Text.IndexOf(".") < 0 || target.SelectedText.IndexOf(".") >= 0)
          {
            e.Handled = false;
          }
          else
          {
            e.Handled = true;
          }
        }
        else if (e.Key == Key.Subtract || e.Key == Key.OemMinus)
        {
          if ((target.Text == target.SelectedText || target.SelectionStart == 0) &&
              (target.Text.IndexOf("-") < 0 || target.SelectedText.IndexOf("-") >= 0))
          {
            e.Handled = false;
          }
          else
          {
            e.Handled = true;
          }
        }
        else
        {
          e.Handled = true;
        }
      }
      else if (customp.Type == 3)
      {
        // string
        if (e.Key == Key.System || e.Key == Key.Tab)
        {
          e.Handled = false;
        }
        else if ((Key.D0 <= e.Key && e.Key <= Key.D9) || (Key.NumPad0 <= e.Key && e.Key <= Key.NumPad9))
        {
          e.Handled = false;
        }
        else if (e.Key.GetHashCode() >= 44 && e.Key.GetHashCode() <= 69)
        {
          e.Handled = false;
        }
        else if (e.Key == Key.OemBackslash && (Keyboard.Modifiers & ModifierKeys.Shift) != ModifierKeys.None)
        {
          e.Handled = false;
        }
        else
        {
          e.Handled = true;
        }
      }
      else
      {
        // uint
        if (e.Key == Key.System || e.Key == Key.Tab)
        {
          e.Handled = false;
        }
        else if ((Key.D0 <= e.Key && e.Key <= Key.D9) || (Key.NumPad0 <= e.Key && e.Key <= Key.NumPad9))
        {
          e.Handled = false;
        }
        else
        {
          e.Handled = true;
        }
      }
    }

    private void dgCustomp_BeginningEdit(object sender, DataGridBeginningEditEventArgs e)
    {
      var dataGrid = sender as DataGrid;
      FrameworkElement contentElement = dataGrid.CurrentCell.Column.GetCellContent(dataGrid.CurrentCell.Item);
      var tb = contentElement as TextBlock;

      curCellText = tb.Text;
    }

    private void dgCustomp_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
    {
      var dataGrid = sender as DataGrid;
      if (dataGrid.SelectedCells.Count < 1) return;

      var tb = e.EditingElement as TextBox;

      if (tb.Text == curCellText) return;


      if (e.Column.SortMemberPath == "Value")
      {
        var item = e.Row.Item as MainViewModel.CustompData;

        if (item.Type == 2)
        {
          float val;
          if (!float.TryParse(tb.Text, out val))
          {
            tb.Text = curCellText;
            return;
          }
          else
          {
            tb.Text = val.ToString();
          }
        }
        else if (item.Type != 3)
        {
          int val;
          if (!int.TryParse(tb.Text, out val))
          {
            tb.Text = curCellText;
            return;
          }
          else
          {
            tb.Text = val.ToString();
          }
        }
      }
      else if (e.Column.SortMemberPath == "Code")
      {
        uint val;
        if (!uint.TryParse(tb.Text, out val))
        {
          tb.Text = curCellText;
          return;
        }
        else
        {
          if (vm.Nodecp.Customps.Where(elem => elem.Code == val).Count() > 1)
          {
            MessageWindow.Show(this, txt["ErrorSameCode"], txt["Error"]);
            tb.Text = curCellText;
            return;
          }

          tb.Text = val.ToString();
        }
      }
      else
      {
        int val;
        if (!int.TryParse(tb.Text, out val))
        {
          tb.Text = curCellText;
          return;
        }
        else
        {
          tb.Text = val.ToString();
        }
      }


      vm.Nodecp.IsEdited = true;
      modified = true;
      modifiedNodecp = true;
    }



    private void OpenFile(string filePath)
    {
      this.IsEnabled = false;
      DoEvents();

      try
      {
        tbTMC.IsEnabled = false;
        gbBone.IsEnabled = false;

        cbHeader.IsChecked = false;
        cbHeader.IsEnabled = false;

        tbBone.Path = "";
        boneData = null;

        var bin = File.ReadAllBytes(filePath);
        char[] charsToTrim = { '\0' };
        string Name = Encoding.ASCII.GetString(bin, 0, 8).TrimEnd(charsToTrim);
        if (Name != "TMC")
        {
          MessageWindow.Show(this, txt["UnsupportedFile"] + "\r\n" + filePath, txt["Error"]);
          return;
        }
        if (BitConverter.ToUInt32(bin, 0x08) != 0x01010000)
        {
          MessageWindow.Show(this, txt["UnsupportedFile"] + "\r\n" + filePath, txt["Error"]);
          return;
        }
        tmcData = new TmcData(bin);

        if (tmcData == null) return;


        bn = bin;

        tmcData.Path = filePath;
        tmcData.WriteTime = File.GetLastWriteTime(filePath);

        // for broken TMC
        tmcData.H.Size = bn.Length;
        if (tmcData.H.Count1 > 15 && tmcData.H.Offsets[15] != 0 && BitConverter.ToUInt32(bn, tmcData.H.Offsets[15] + 8) != 0x01010000)
        {
          tmcData.H.Offsets[15] = 0;
        }

        tmcData.ParseCpf(bin);

        //tmcData.ParseObjBaseData(bn);
        //tmcData.ParseTextureData(bn);
        //tmcData.ParseMtrColor(bn);
        //tmcData.ParseMdlInfo(bn);
        tmcData.ParseHieLayer(bn);
        tmcData.ParseBoneOffsetMatrices(bn);
        //tmcData.ParseVertexData(bn);
        //if (tmcData.H.Count1 > 12 && tmcData.H.Offsets[12] != 0) tmcData.ParseMCAPack(bn);
        if (tmcData.H.Count1 > 16 && tmcData.H.Offsets[16] != 0) tmcData.ParseACSCLS(bn);

        vm.Init(tmcData);

        tbTMC.IsEnabled = true;
        panelBoneOption.IsEnabled = true;
        vm.ChangeChangeableParent();
        gbBone.IsEnabled = true;
        tbTMC.Path = filePath;
        vm.TextStatus = txt["textOpenBone"];

        autoSetComboBox = true;
        cmbPresetCollision.SelectedIndex = 3;
        autoSetComboBox = false;

        NodecpDisplay_Filter();

        modified = false;
        modifiedBone = false;
        modifiedCollision = false;
        modifiedPhysics = false;
        modifiedNodecp = false;
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }
      finally
      {
        this.IsEnabled = true;
        this.Activate();
        this.Focus();
      }
    }

    private void OpenBoneFile(string filePath)
    {
      this.IsEnabled = false;
      DoEvents();

      try
      {
        var bin = File.ReadAllBytes(filePath);

        boneData = new TmcData(bin);

        if (boneData == null) return;


        boneBn = bin;

        boneData.Path = filePath;
        boneData.WriteTime = File.GetLastWriteTime(filePath);

        if (boneData.H.Count1 > 11 && boneData.H.Offsets[11] != 0) boneData.ParseCpf(bin);

        boneData.ParseHieLayer(boneBn);
        boneData.ParseBoneOffsetMatrices(boneBn);
        if (boneData.H.Count1 > 16 && boneData.H.Offsets[16] != 0) boneData.ParseACSCLS(boneBn);

        vm.SetReferBones(boneData);
        vm.SetCollisions(tmcData, boneData);

        if (boneData.NodeCp != null)
        {
          vm.ResetPhysics();
          vm.AddPhysics(boneData);
        }

        autoSetComboBox = true;
        cmbSelection.SelectedIndex = 1;
        cmbPresetCollision.SelectedIndex = 1;
        autoSetComboBox = false;

        cbHeader.IsEnabled = true;

        tbBone.Path = filePath;
        vm.TextStatus = "";

        if (vm.Collisions.Count != 0)
        {
          if (boneData.Collisions == null)
          {
            autoSetComboBox = true;
            cmbPresetCollision.SelectedIndex = 3;
            autoSetComboBox = false;

            foreach (var collision in vm.Collisions)
            {
              collision.Data = txt["TmcData"];
            }
          }
        }

        CommandManager.InvalidateRequerySuggested();
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }
      finally
      {
        this.IsEnabled = true;
        this.Activate();
        this.Focus();
      }
    }

    private bool PreSaveCheck()
    {
      if (!vm.IsEnabledBone && !vm.IsEnabledCollision && !vm.IsEnabledPhysics && !vm.IsEnabledNodecp)
        return false;
      else if (!vm.IsEnabledBone || vm.IsEnabledCollision || vm.IsEnabledPhysics)
        return true;
      else if (vm.IsEnabledNodecp && modifiedNodecp)
        return true;
      else if (vm.IsEnabledBone && vm.Parentage)
        return true;
      else if (vm.IsEnabledBone && vm.IsChangedBone)
        return true;

      foreach (var bone in vm.Bones)
      {
        if (bone.Selected) return true;
      }
      return false;
    }

    private bool SaveFile(string filePath)
    {
      try
      {
        // 各部バイナリ
        //  0 MdlGeo
        //  1 TTX
        //  2 VtxLay
        //  3 IdxLay
        //  4 MtrCol
        //  5 MdlInfo
        //  6 HieLay
        //  7 LHeader
        //  8 NodeLay
        //  9 GlblMtx
        // 10 BnOfsMtx
        // 11 cpf
        // 12 MCAPACK
        // 13 RENPACK
        // 14 GEOXTRAS
        // 15 
        // 16 ACSCLS
        Dictionary<int, List<byte>> partBn = new Dictionary<int, List<byte>>();

        int lastOffset = tmcData.H.Size;
        for (int i = tmcData.H.Count1 - 1; i >= 0; i--)
        {
          partBn[i] = new List<byte>();

          if (tmcData.H.Offsets[i] != 0)
          {
            partBn[i].AddRange(bn.Skip(tmcData.H.Offsets[i]).Take(lastOffset - tmcData.H.Offsets[i]));
            lastOffset = tmcData.H.Offsets[i];
          }
        }

        // for broken TMC
        if (tmcData.H.Count1 > 14 && tmcData.H.Offsets[14] != 0 && BitConverter.ToUInt32(bn, tmcData.H.Offsets[14] + 8) != 16842752 && partBn[14].Count > 0x40)
        {
          partBn[14] = new List<byte>(new byte[0x40]);
        }

        var exBones = PrepareExBones();

        if (vm.IsEnabledBone || (vm.IsEnabledPhysics && vm.IsChangedBone))
        {
          if (boneData != null || vm.Parentage || vm.IsChangedBone)
          {
            partBn[6] = SetHieLayDataChanges(partBn[6], exBones);
          }

          if (boneData != null || vm.IsChangedBone)
          {
            partBn[8] = setNodeLayDataChanges(partBn[8], exBones);
            partBn[9] = SetMtxDataChanges(partBn[9], exBones, "GlblMtx");
            partBn[10] = SetMtxDataChanges(partBn[10], exBones, "BnOfsMtx");
            partBn[11] = SetCpfDataChanges(partBn[11], exBones);
          }
          else if (vm.IsEnabledNodecp && modifiedNodecp)
          {
            partBn[11] = SetCpfDataChanges(partBn[11], exBones);
          }
        }
        else if (vm.IsEnabledNodecp && modifiedNodecp)
        {
          partBn[11] = SetCpfDataChanges(partBn[11], exBones);
        }
        if (partBn.ContainsKey(16) && tmcData.H.Offsets[16] != 0) partBn[16] = SetAcsclsDataChanges(partBn[16], exBones);

        // 全体データの構築とHeaderのオフセットを変更
        List<byte> exBn = new List<byte>();
        exBn.AddRange(bn.Take(tmcData.H.Offsets[0]));

        for (int i = 0; i < tmcData.H.Count1; i++)
        {
          if (partBn[i].Count != 0)
          {
            // オフセットを変更
            ReplaceByteList(exBn, BitConverter.GetBytes(exBn.Count), tmcData.H.Offset1 + (i * 4));
          }
          exBn.AddRange(partBn[i]);
        }

        // Headerの全体サイズを変更
        ReplaceByteList(exBn, BitConverter.GetBytes(exBn.Count), 0x10);

        // 保存
        File.WriteAllBytes(filePath, exBn.ToArray());
        tbTMC.Path = filePath;

        OpenFile(filePath);

        this.IsEnabled = true;
        DoEvents();

        ShowTextBlockMessage(txt["Saved"]);

        return true;
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
        this.IsEnabled = true;
        return false;
      }
    }

    private string CreateBackup(string filePath)
    {
      try
      {
        if (!File.Exists(filePath)) return null;

        string dirPath = Path.GetDirectoryName(filePath);
        string name = Path.GetFileNameWithoutExtension(filePath);

        List<string> files = Directory.GetFiles(dirPath, name + "*.TMC", SearchOption.TopDirectoryOnly).ToList();
        string regStr = name + @" - ([0-9]+)";
        int count = 1;

        foreach (string file in files)
        {
          string fileName = Path.GetFileNameWithoutExtension(file);

          MatchCollection mc = Regex.Matches(fileName, regStr);
          foreach (Match m in mc)
          {
            int num = int.Parse(m.Groups[1].Value);
            if (count <= num) count = num + 1;
          }
        }

        string newPath;
        while (File.Exists(newPath = dirPath + @"/" + name + " - " + count + ".TMC"))
        {
          count++;
        }

        File.Move(filePath, newPath);

        return newPath;
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
        return null;
      }
    }



    private void ExportTmcbone(string filePath)
    {
      try
      {
        List<List<byte>> partBns = new List<List<byte>>();

        int lastOffset = tmcData.H.Size;
        for (int i = tmcData.H.Count1 - 1; i >= 0; i--)
        {
          List<byte> partBn = new List<byte>();

          if (tmcData.H.Offsets[i] != 0)
          {
            if (i == 6 || i == 8 || i == 9 || i == 10 || i == 11 || i == 16)
            {
              partBn = bn.Skip(tmcData.H.Offsets[i]).Take(lastOffset - tmcData.H.Offsets[i]).ToList();
            }

            lastOffset = tmcData.H.Offsets[i];
          }

          partBns.Add(partBn);
        }
        partBns.Reverse();

        partBns[8] = BuildTmcboneNodeLay(partBns[8]);

        partBns[11] = BuildTmcboneCpf(partBns[11]);

        List<byte> exBn = BuildHeaderBaseBin("tmcbone");

        BuildBin(exBn, partBns, null, true, true);

        // 保存
        File.WriteAllBytes(filePath, exBn.ToArray());

        this.IsEnabled = true;
        DoEvents();

        ShowTextBlockMessage(txt["Exported"]);
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
        this.IsEnabled = true;
      }
    }

    private List<byte> BuildTmcboneNodeLay(List<byte> bin)
    {
      List<byte> nodeLayBin = BuildHeaderBaseBin("NodeLay");
      nodeLayBin.AddRange(new byte[0x10]);
      nodeLayBin[0x30] = 1;
      nodeLayBin[0x32] = 2;

      List<List<byte>> nodeObjBins = new List<List<byte>>();

      foreach (var node in tmcData.Node)
      {
        List<byte> nodeObjBin = BuildHeaderBaseBin("NodeObj");
        nodeObjBin.AddRange(BitConverter.GetBytes(0));
        nodeObjBin.AddRange(BitConverter.GetBytes(node.Master));
        nodeObjBin.AddRange(BitConverter.GetBytes(node.Index));
        nodeObjBin.AddRange(BitConverter.GetBytes(0));
        nodeObjBin.AddRange(Encoding.ASCII.GetBytes(node.Name));
        nodeObjBin.AddRange(new byte[16 - (nodeObjBin.Count % 16)]);
        ReplaceByteList(nodeObjBin, BitConverter.GetBytes(nodeObjBin.Count), 0x10);

        nodeObjBins.Add(nodeObjBin);
      }
      BuildBin(nodeLayBin, nodeObjBins, null, false, false);

      return nodeLayBin;
    }

    private List<byte> BuildTmcboneCpf(List<byte> bin)
    {
      var h = new HeaderData(0, bin.ToArray());

      if (h.Offsets[0] == 0) return new List<byte>();

      int endOffset = h.Offsets[1];
      if (endOffset == 0) endOffset = h.Size;

      var nodecpBin = bin.Skip(h.Offsets[0]).Take(endOffset - h.Offsets[0]).ToList();

      List<byte> cpfBin = BuildHeaderBaseBin("cpf");
      List<List<byte>> cpfBins = new List<List<byte>>();
      cpfBins.Add(nodecpBin);
      cpfBins.Add(new List<byte>());

      BuildBin(cpfBin, cpfBins, null, false, true);

      return cpfBin;
    }



    private void CheckUpdated()
    {
      if (tmcData == null || !File.Exists(tmcData.Path)) return;

      var lastWriteTimeTmc = File.GetLastWriteTime(tmcData.Path);

      bool updatedTmc = false;
      bool updatedBone = false;
      string updateFiles = "";

      if (tmcData.WriteTime.CompareTo(lastWriteTimeTmc) != 0)
      {
        updatedTmc = true;
        updateFiles += "\r\n" + tmcData.Path;
      }

      DateTime lastWriteTimeBone = DateTime.Now;
      if (boneData != null && File.Exists(boneData.Path))
      {
        lastWriteTimeBone = File.GetLastWriteTime(boneData.Path);

        if (boneData.WriteTime.CompareTo(lastWriteTimeBone) != 0)
        {
          updatedBone = true;
          updateFiles += "\r\n" + boneData.Path;
        }
      }

      if (!updatedTmc && !updatedBone) return;

      if (MessageWindow.Show(this, txt["ConfirmFileUpdated"] + "\r\n" + updateFiles, txt["Confirm"], txt["Yes"], txt["No"]) == MessageWindow.Result.OK)
      {
        if (updatedTmc)
        {
          OpenFile(tmcData.Path);
          if (!updatedBone && tbBone.Path != "")
          {
            OpenBoneFile(tbBone.Path);
          }
        }
        if (updatedBone) OpenBoneFile(tbBone.Path);
      }
      else
      {
        if (updatedTmc) tmcData.WriteTime = lastWriteTimeTmc;
        if (updatedBone) boneData.WriteTime = lastWriteTimeBone;
      }
    }
  }
}
