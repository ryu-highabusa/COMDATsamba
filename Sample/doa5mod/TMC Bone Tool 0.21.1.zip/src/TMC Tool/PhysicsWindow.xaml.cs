﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.ComponentModel;

namespace TMC_Tool
{
  /// <summary>
  /// EditMaterialWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class PhysicsWindow : Window
  {
    private static Dictionary<string, string> txt = new Dictionary<string, string>();

    private static bool dialogResult;

    private static MainViewModel.PhysicsData physicsData;

    private static string curText = "";
    private static SortedSet<int> selectedColumns = new SortedSet<int>();
    private static int currentColumnIndex = -1;
    private static Dictionary<int, SortedSet<int>> selCellIndices;

    ContextMenu menuDataGridPhysics = new ContextMenu();

    private bool IsActivated = false;

    public PhysicsWindow()
    {
      InitializeComponent();

      this.MouseLeftButtonDown += (sender, e) => this.DragMove();
      this.ShowInTaskbar = false;

      txt = MainWindow.txt;

      dgcPhysicsBonesName.Header = txt["dgcPhysicsBonesName"];
      dgcPhysicsBonesParent.Header = txt["dgcPhysicsBonesParent"];
      dgcPhysicsBonesSpring.Header = txt["dgcPhysicsBonesSpring"];
      dgcPhysicsBonesElastic.Header = txt["dgcPhysicsBonesElastic"];
      dgcPhysicsBonesFriction.Header = txt["dgcPhysicsBonesFriction"];
      dgcPhysicsBonesBending.Header = txt["dgcPhysicsBonesBending"];
      dgcPhysicsCollisionsCode.Header = txt["dgcPhysicsCollisionsCode"];
      btnOk.Content = txt["OK"];
      btnCancel.Content = txt["Cancel"];

      BuildContextMenu();
    }

    private void BuildContextMenu()
    {
      MenuItem menuitemFillDown = new MenuItem();

      menuitemFillDown.Header = txt["FillDown"];
      menuitemFillDown.InputGestureText = "Ctrl+D";

      RoutedCommand fillDown = this.FindResource("FillDown") as RoutedCommand;
      menuitemFillDown.Command = fillDown;

      menuDataGridPhysics.Items.Add(menuitemFillDown);

      dgPhysicsBones.ContextMenu = menuDataGridPhysics;
    }

    private void btnOk_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = true;
      this.Close();
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = false;
    }
    
    private void TextBoxNum_KeyDown(object sender, KeyEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (e.Key == Key.System || e.Key == Key.Tab)
      {
        e.Handled = false;
      }
      else if ((Key.D0 <= e.Key && e.Key <= Key.D9) || (Key.NumPad0 <= e.Key && e.Key <= Key.NumPad9))
      {
        e.Handled = false;
      }
      else if (e.Key == Key.Decimal || e.Key == Key.OemPeriod)
      {
        if (target.Text.IndexOf(".") < 0 || target.SelectedText.IndexOf(".") >= 0)
        {
          e.Handled = false;
        }
        else
        {
          e.Handled = true;
        }
      }
      else if (e.Key == Key.Divide || e.Key == Key.Subtract)
      {
        if ((target.Text == target.SelectedText || target.SelectionStart == 0) &&
            (target.Text.IndexOf("-") < 0 || target.SelectedText.IndexOf("-") >= 0))
        {
          e.Handled = false;
        }
        else
        {
          e.Handled = true;
        }
      }
      else
      {
        e.Handled = true;
      }
    }

    private void DataGridCell_KeyUp(object sender, KeyEventArgs e)
    {
      btnOk.IsEnabled = true;
    }

    private void dgPhysicsWindow_BeginningEdit(object sender, System.Windows.Controls.DataGridBeginningEditEventArgs e)
    {
      var dataGrid = sender as DataGrid;
      FrameworkElement contentElement = dataGrid.CurrentCell.Column.GetCellContent(dataGrid.CurrentCell.Item);
      var tb = contentElement as TextBlock;

      curText = tb.Text;
    }

    private void dgPhysicsWindow_CellEditEnding(object sender, System.Windows.Controls.DataGridCellEditEndingEventArgs e)
    {
      var dataGrid = sender as DataGrid;
      if (dataGrid.SelectedCells.Count < 1) return;

      var tb = e.EditingElement as TextBox;

      if (tb.Text == curText) return;

      float val;
      if (!float.TryParse(tb.Text, out val))
      {
        tb.Text = curText;
        return;
      }
    }

    private void dgPhysicsWindowColumnHeader_Click(object sender, RoutedEventArgs e)
    {
      var header = sender as DataGridColumnHeader;
      if (header == null || header.DisplayIndex < 2) return;
      currentColumnIndex = MainWindow.SelectColumnAllCells(dgPhysicsBones, header.DisplayIndex, currentColumnIndex);
    }

    private void fillDownCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      var dataGrid = e.Source as DataGrid;
      selCellIndices = MainWindow.PreCheckFillDown(dataGrid);
      if (dataGrid != null && dataGrid.SelectedCells.Count > 0 && selCellIndices != null)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void fillDownCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var dataGrid = e.Source as DataGrid;
      FillDown(dataGrid);
    }

    private void FillDown(DataGrid dataGrid)
    {
      DataGridCellInfo dataGridCellInfo;

      foreach (var set in selCellIndices)
      {
        var val = GetPhysicsBoneData(physicsData.Bones[set.Value.ToArray()[0]], dataGrid.Columns[set.Key].SortMemberPath);
        if (val == null) continue;

        for (int i = 1; i < set.Value.Count; i++)
        {
          dataGridCellInfo = new DataGridCellInfo(dataGrid.Items[set.Value.ToArray()[i]], dataGrid.Columns[set.Key]);
          var item = dataGridCellInfo.Item as MainViewModel.PhysicsChildrenData;

          SetPhysicsBoneData(item, dataGridCellInfo.Column.SortMemberPath, (float)val);
        }
      }

      btnOk.IsEnabled = true;

      selCellIndices = null;
    }

    private float? GetPhysicsBoneData(MainViewModel.PhysicsChildrenData data, string property)
    {
      switch (property)
      {
        case "Spring":
          return data.Spring;
        case "Elastic":
          return data.Elastic;
        case "Friction":
          return data.Friction;
        case "Unknown":
          return data.Unknown;
        case "Bending":
          return data.Bending;
        default:
          return null;
      }
    }

    private void SetPhysicsBoneData(MainViewModel.PhysicsChildrenData data, string property, float val)
    {
      switch (property)
      {
        case "Spring":
          data.Spring = val;
          break;
        case "Elastic":
          data.Elastic = val;
          break;
        case "Friction":
          data.Friction = val;
          break;
        case "Unknown":
          data.Unknown = val;
          break;
        case "Bending":
          data.Bending = val;
          break;
      }
    }


    private void dgPhysicsCollisions_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (dgPhysicsCollisions.SelectedIndex == -1)
      {
        btnCollisionDel.IsEnabled = false;
        btnCollisionChange.IsEnabled = false;
      }
      else
      {
        btnCollisionDel.IsEnabled = true;
        btnCollisionChange.IsEnabled = true;
      }
    }

    private void btnCollisionAdd_Click(object sender, RoutedEventArgs e)
    {
      var newCollision = new MainViewModel.PhysicsCollisionData();
      newCollision.Code = 0;
      physicsData.Collisions.Add(newCollision);
      dgPhysicsCollisions.SelectedIndex = physicsData.Collisions.Count - 1;
      btnOk.IsEnabled = true;
    }

    private void btnCollisionDel_Click(object sender, RoutedEventArgs e)
    {
      physicsData.Collisions.RemoveAt(dgPhysicsCollisions.SelectedIndex);
      btnOk.IsEnabled = true;
    }

    private void InsertMenuCollisionChange(List<MainViewModel.CollisionData> collisions)
    {
      foreach (var collision in collisions)
      {
        var menuItem = new MenuItem();
        menuItem.Header = collision.Code + " : " + collision.Name;
        menuItem.Click += new RoutedEventHandler(menuItemCollisionChange_Click);
        menuCollisionChange.Items.Add(menuItem);
      }
    }

    private void menuItemCollisionChange_Click(object sender, RoutedEventArgs e)
    {
      if (dgPhysicsCollisions.SelectedIndex == -1) return;

      var item = sender as MenuItem;
      var param = item.Header.ToString().Split(new string[] { " : " }, StringSplitOptions.None);

      uint val;
      if (UInt32.TryParse(param[0], out val))
      {
        physicsData.Collisions[dgPhysicsCollisions.SelectedIndex].Code = val;
        physicsData.Collisions[dgPhysicsCollisions.SelectedIndex].BaseNode = param[1];
      }

      btnOk.IsEnabled = true;
    }



    public static MainViewModel.PhysicsData Show(Window owner, MainViewModel.PhysicsData data, List<MainViewModel.CollisionData> collisions)
    {
      var dlg = new PhysicsWindow();
      dlg.Owner = owner;
      dlg.Owner.IsEnabled = false;
      dlg.btnCollisionDel.IsEnabled = false;
      dlg.btnCollisionChange.IsEnabled = false;

      physicsData = data.Clone();

      dlg.InsertMenuCollisionChange(collisions);

      dlg.physicsWindow.DataContext = physicsData;

      dlg.btnOk.IsEnabled = false;

      dlg.IsActivated = false;
      dlg.ShowDialog();

      dlg.Owner.IsEnabled = true;
      dlg.Owner.Focus();

      if (!dialogResult)
      {
        physicsData = null;
      }
      else
      {
        physicsData.Collisions = new ObservableCollection<MainViewModel.PhysicsCollisionData>(physicsData.Collisions.OrderBy(elem => elem.Code));
        int index = 1;
        while (index < physicsData.Collisions.Count)
        {
          if (physicsData.Collisions[index].Code == physicsData.Collisions[index - 1].Code)
            physicsData.Collisions.RemoveAt(index);
          else
            index++;
        }

        if (physicsData.Collisions.Count > 0 && physicsData.CollisionType == -1)
        {
          physicsData.CollisionType = physicsData.CurCollisionType;
        }
        else if (physicsData.Collisions.Count == 0 && physicsData.CollisionType != -1)
        {
          physicsData.CollisionType = -1;
        }
      }
      return physicsData;
    }



    private void Window_Activated(object sender, EventArgs e)
    {
      if (!IsActivated) IsActivated = true;
    }

    private void Window_Closing(object sender, CancelEventArgs e)
    {
      e.Cancel = true;
      IsActivated = false;
      this.Hide();
      if (this.Owner != null) this.Owner.Activate();
    }
  }
}
