﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using System.Windows.Threading;
using Message;

namespace TMC_Tool
{
  public partial class MainWindow : Window
  {

    private void MainWindowTitle()
    {
      var thisAssem = Application.Current.GetType().Assembly;
      var assemblyTitle = thisAssem.GetCustomAttributes(typeof(AssemblyTitleAttribute), true).Single() as AssemblyTitleAttribute;
      var ver = thisAssem.GetName().Version;
      labelTitle.Content = assemblyTitle.Title + " " + ver.Major + "." + ver.Minor + "." + ver.Build;
    }

    private void exitCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      if (modified && exitConfirm)
      {
        if (MessageWindow.Show(this, txt["ExitWithoutSave"], txt["Confirm"], txt["Exit"], txt["Cancel"]) == MessageWindow.Result.Cancel)
        {
          return;
        }
      }
      Close();
    }

    private void pathPasteCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      OpenFromClipboard();
    }

    private void tb_OpenFromClipboard(object sender, KeyEventArgs e)
    {
      TextBox tb = sender as TextBox;
      if (tb.IsReadOnly && e.Key == Key.V && Keyboard.Modifiers == ModifierKeys.Control)
      {
        OpenFromClipboard();
      }
    }

    private void ButtonMinimized_Click(object sender, RoutedEventArgs e)
    {
      this.WindowState = System.Windows.WindowState.Minimized;
    }

    private void ButtonMaximized_Click(object sender, RoutedEventArgs e)
    {
      this.WindowState = System.Windows.WindowState.Maximized;
    }

    private void ButtonNormal_Click(object sender, RoutedEventArgs e)
    {
      this.WindowState = System.Windows.WindowState.Normal;
    }

    private void TextBox_LostFocus(object sender, RoutedEventArgs e)
    {
      TextBox tb = sender as TextBox;
      tb.Text = tb.Text.Trim();
    }

    private void TextBoxNum_KeyDown(object sender, KeyEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (e.Key == Key.System || e.Key == Key.Tab)
      {
        e.Handled = false;
      }
      else if ((Key.D0 <= e.Key && e.Key <= Key.D9) || (Key.NumPad0 <= e.Key && e.Key <= Key.NumPad9))
      {
        e.Handled = false;
      }
      else if (e.Key == Key.Decimal || e.Key == Key.OemPeriod)
      {
        if (target.Text.IndexOf(".") < 0 || target.SelectedText.IndexOf(".") >= 0)
        {
          e.Handled = false;
        }
        else
        {
          e.Handled = true;
        }
      }
      else if (e.Key == Key.Subtract || e.Key == Key.OemMinus)
      {
        if ((target.Text == target.SelectedText || target.SelectionStart == 0) &&
            (target.Text.IndexOf("-") < 0 || target.SelectedText.IndexOf("-") >= 0))
        {
          e.Handled = false;
        }
        else
        {
          e.Handled = true;
        }
      }
      else
      {
        e.Handled = true;
      }
    }

    private void TextBoxPositiveNum_KeyDown(object sender, KeyEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (e.Key == Key.System || e.Key == Key.Tab)
      {
        e.Handled = false;
      }
      else if ((Key.D0 <= e.Key && e.Key <= Key.D9) || (Key.NumPad0 <= e.Key && e.Key <= Key.NumPad9))
      {
        e.Handled = false;
      }
      else if (e.Key == Key.Decimal || e.Key == Key.OemPeriod)
      {
        if (target.Text.IndexOf(".") < 0 || target.SelectedText.IndexOf(".") >= 0)
        {
          e.Handled = false;
        }
        else
        {
          e.Handled = true;
        }
      }
      else
      {
        e.Handled = true;
      }
    }

    private void TextBoxNums_KeyDown(object sender, KeyEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (e.Key == Key.System || e.Key == Key.Tab)
      {
        e.Handled = false;
      }
      else if ((Key.D0 <= e.Key && e.Key <= Key.D9) || (Key.NumPad0 <= e.Key && e.Key <= Key.NumPad9))
      {
        e.Handled = false;
      }
      else if (e.Key == Key.OemComma)
      {
        e.Handled = false;
      }
      else
      {
        e.Handled = true;
      }
    }

    private void TextBoxUint_KeyDown(object sender, KeyEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (e.Key == Key.System || e.Key == Key.Tab)
      {
        e.Handled = false;
      }
      else if ((Key.D0 <= e.Key && e.Key <= Key.D9) || (Key.NumPad0 <= e.Key && e.Key <= Key.NumPad9))
      {
        e.Handled = false;
      }
      else
      {
        e.Handled = true;
      }
    }

    private void TextBox_GotFocus(object sender, RoutedEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (target == null) return;
      target.SelectAll();
    }

    private void TextBox_PreMouseLeftDown(object sender, MouseButtonEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (target.IsFocused == false)
      {
        target.Focus();
        e.Handled = true;
      }
    }

    private void TextBox_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (target == null) return;
      target.SelectAll();
    }



    private uint HexTextToUInt(string str)
    {
      byte[] bytes = BitConverter.GetBytes(Int32.Parse(str, NumberStyles.AllowHexSpecifier));
      uint num = BitConverter.ToUInt32(bytes, 0);
      return num;
    }

    private string IntToHexText(int num)
    {
      byte[] bytes = BitConverter.GetBytes(num);
      Array.Reverse(bytes);
      string str = BitConverter.ToString(bytes).Replace("-", "");
      return str;
    }

    private void SetShiftSelectBase(DataGrid datagrid, DataGridRow row, int columnIndex)
    {
      var cell = datagrid.Columns[columnIndex].GetCellContent(row).Parent as DataGridCell;
      var method = typeof(DataGrid).GetMethod("HandleSelectionForCellInput", BindingFlags.Instance | BindingFlags.NonPublic);
      method.Invoke(datagrid, new object[] { cell, false, false, false });
    }

    private List<byte> ReplaceByteList(List<byte> bin, byte[] replace, int index)
    {
      bin.RemoveRange(index, replace.Length);
      bin.InsertRange(index, replace);
      return bin;
    }

    private List<float> Matrix3DToList(Matrix3D matrix)
    {
      List<float> m = new List<float>();
      m.Add((float)matrix.M11);
      m.Add((float)matrix.M12);
      m.Add((float)matrix.M13);
      m.Add((float)matrix.M14);
      m.Add((float)matrix.M21);
      m.Add((float)matrix.M22);
      m.Add((float)matrix.M23);
      m.Add((float)matrix.M24);
      m.Add((float)matrix.M31);
      m.Add((float)matrix.M32);
      m.Add((float)matrix.M33);
      m.Add((float)matrix.M34);
      m.Add((float)matrix.OffsetX);
      m.Add((float)matrix.OffsetY);
      m.Add((float)matrix.OffsetZ);
      m.Add((float)matrix.M44);
      return m;
    }

    private List<byte> BuildHeaderBaseBin(string name)
    {
      var bin = new List<byte>();
      bin.AddRange(Encoding.ASCII.GetBytes(name));
      if (bin.Count != 8) bin.AddRange(new byte[8 - bin.Count]);
      bin.AddRange(new byte[8] { 0, 0, 1, 1, 0x30, 0, 0, 0 });
      bin.AddRange(new byte[0x20]);
      return bin;
    }

    private void FillZeroBin(List<byte> bin, int num)
    {
      if (bin.Count % num != 0) bin.AddRange(new byte[num - bin.Count % num]);
    }

    private void BuildBin(List<byte> bin, List<List<byte>> childBins, List<byte> optionBin, bool addSize, bool nullSkip)
    {
      BuildBin(bin, childBins, optionBin, addSize, nullSkip, 0);
    }
    private void BuildBin(List<byte> bin, List<List<byte>> childBins, List<byte> optionBin, bool addSize, bool nullSkip, int staticSize)
    {
      int basesize = bin.Count;
      int offsetsize = 4 * ((childBins.Count + 3) / 4 * 4);
      int count = 0;

      ReplaceByteList(bin, BitConverter.GetBytes(bin.Count), 0x20);

      // オフセット部分追加
      bin.AddRange(new byte[offsetsize]);

      // サイズ部分追加
      if (addSize)
      {
        ReplaceByteList(bin, BitConverter.GetBytes(bin.Count), 0x24);
        bin.AddRange(new byte[offsetsize]);
      }

      if (optionBin != null)
      {
        ReplaceByteList(bin, BitConverter.GetBytes(bin.Count), 0x28);
        bin.AddRange(optionBin);
      }

      // 固定サイズ
      if (staticSize != 0)
      {
        if (bin.Count < staticSize) bin.AddRange(new byte[staticSize - bin.Count]);
      }

      for (int i = 0; i < childBins.Count; i++)
      {
        if (!nullSkip || childBins[i].Count != 0)
        {
          // オフセット変更と追加
          ReplaceByteList(bin, BitConverter.GetBytes(bin.Count), basesize + (4 * i));
          if (addSize) ReplaceByteList(bin, BitConverter.GetBytes(childBins[i].Count), basesize + offsetsize + (4 * i));
          bin.AddRange(childBins[i]);
          count++;
        }
      }

      // 個数変更
      ReplaceByteList(bin, BitConverter.GetBytes(childBins.Count), 0x14);
      ReplaceByteList(bin, BitConverter.GetBytes(count), 0x18);

      // binサイズ変更
      ReplaceByteList(bin, BitConverter.GetBytes(bin.Count), 0x10);
    }

    private void mainWindow_Activated(object sender, EventArgs e)
    {
      if (!appStarted)
      {
        var story = (System.Windows.Media.Animation.Storyboard)this.FindResource("fadeIn");
        story.Begin();
        appStarted = true;
      }
      else if (updateChecking)
      {
        updateChecking = false;
        CheckUpdated();
        updateChecking = true;
      }
    }

    private void FadeInAnimation_Completed(object sender, EventArgs e)
    {
      var story = (System.Windows.Media.Animation.Storyboard)this.FindResource("fadeIn");
      story.Stop();
    }

    private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
    {
      var story = (System.Windows.Media.Animation.Storyboard)this.FindResource("fadeOut");
      story.Begin();
      e.Cancel = true;
    }

    private void FadeOutAnimation_Completed(object sender, EventArgs e)
    {
      var story = (System.Windows.Media.Animation.Storyboard)this.FindResource("fadeOut");
      story.Stop();

      Application.Current.Shutdown();
    }

    private void ShowTextBlockMessage(string text)
    {
      ShowTextBlockMessage(text, new SolidColorBrush(Color.FromRgb(0x00, 0x88, 0xDD)));
    }
    private void ShowTextBlockMessage(string text, Brush background)
    {
      textMessage.Background = background;
      textMessage.Text = text;
      var story = (System.Windows.Media.Animation.Storyboard)this.FindResource("fadeTextMessage");
      story.SeekAlignedToLastTick(new TimeSpan(0, 0, 0));
      story.Stop();
      story.Begin();
    }
    private void FadeTextMessageAnimation_Completed(object sender, EventArgs e)
    {
      var story = (System.Windows.Media.Animation.Storyboard)this.FindResource("fadeTextMessage");
      story.Stop();
      textMessage.Text = "";
    }

    public static void DoEvents()
    {
      DispatcherFrame frame = new DispatcherFrame();
      Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Background, new DispatcherOperationCallback(ExitFrames), frame);
      Dispatcher.PushFrame(frame);
    }
    public static object ExitFrames(object frames)
    {
      ((DispatcherFrame)frames).Continue = false;
      return null;
    }
  }
}
