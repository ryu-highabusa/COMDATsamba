﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media.Media3D;

namespace TMC_Tool
{
  public class HeaderData
  {
    public HeaderData(int start, byte[] bin)
    {
      Start = start;
      Offsets = new List<int>(0);
      Sizes = new List<int>(0);

      if (BitConverter.ToUInt32(bin, start + 0x08) != 0x01010000) return;

      Name = Encoding.ASCII.GetString(bin, start, 8).TrimEnd('\0');
      Flg1 = BitConverter.ToUInt32(bin, start + 0x08);
      HSize = BitConverter.ToInt32(bin, start + 0x0C);
      Size = BitConverter.ToInt32(bin, start + 0x10);
      Count1 = BitConverter.ToInt32(bin, start + 0x14);
      Count2 = BitConverter.ToInt32(bin, start + 0x18);
      Count3 = BitConverter.ToInt32(bin, start + 0x1C);
      Offset1 = BitConverter.ToInt32(bin, start + 0x20);
      Offset2 = BitConverter.ToInt32(bin, start + 0x24);
      Offset3 = BitConverter.ToInt32(bin, start + 0x28);
      Flg2 = BitConverter.ToUInt32(bin, start + 0x2C);

      for (int i = 0; i < Count1; i++)
      {
        Offsets.Add(BitConverter.ToInt32(bin, start + Offset1 + (i * 0x04)));
      }

      if (Offset2 > 0)
      {
        for (int i = 0; i < Count1; i++)
        {
          Sizes.Add(BitConverter.ToInt32(bin, start + Offset2 + (i * 0x04)));
        }
      }
    }

    public int Start { get; set; }
    public string Name { get; set; }
    public uint Flg1 { get; set; }
    public int HSize { get; set; }
    public int Size { get; set; }
    public int Count1 { get; set; }
    public int Count2 { get; set; }
    public int Count3 { get; set; }
    public int Offset1 { get; set; }
    public int Offset2 { get; set; }
    public int Offset3 { get; set; }
    public uint Flg2 { get; set; }

    public List<int> Offsets { get; private set; }
    public List<int> Sizes { get; private set; }
  }

  public class TmcData
  {
    public TmcData(byte[] bin)
    {
      H = new HeaderData(0, bin);

      ParseGlobalMatrices(bin);
      ParseNodeLayer(bin);
    }

    public void ParseObjBaseData(byte[] bin)
    {
      ParseCpf(bin);
      PreParseVertexData(bin);
      PreParseIndexData(bin);

      ObjGrp = new List<ObjectGroup>();
      ParseObjectData(bin);
    }

    public void ParseObjectData(byte[] bin)
    {
      int start = H.Offsets[0];
      var mdlGeoH = new HeaderData(start, bin);
      byte[] tempBn;

      for (int i = 0; i < mdlGeoH.Count1; i++)
      {
        var h = new HeaderData(mdlGeoH.Start + mdlGeoH.Offsets[i], bin);
        var newGrp = new ObjectGroup(h, mdlGeoH.Offsets[i], bin);

        int idx = Array.FindIndex(Node.ToArray(), node => node.ObjIndex == i && node.Master == -1);
        if (idx == -1)
        {
          idx = Array.FindIndex(Node.ToArray(), node => node.ObjIndex == i);
          if (idx == -1)
          {
            idx = Array.FindIndex(Node.ToArray(), node => node.Name == newGrp.Name);
            if (idx == -1)
            {
              string tempname = newGrp.Name.Replace("*", "");
              idx = Array.FindIndex(Node.ToArray(), node => node.Name.Length > tempname.Length && node.Name.Substring(node.Name.Length - tempname.Length) == tempname);
              if (idx != -1) newGrp.Name = Node[idx].Name;
            }
          }
          else
          {
            newGrp.Name = Node[idx].Name;
          }
        }
        else
        {
          newGrp.Name = Node[idx].Name;
        }
        newGrp.Node = idx;

        if (NodeCp.Count > 0)
          newGrp.NodeCp = Array.FindIndex(NodeCp.ToArray(), nodecp => nodecp.Index == newGrp.Node);
        else
          newGrp.NodeCp = -1;

        newGrp.Matrix = new Matrix3D();
        if (idx != -1) newGrp.Matrix.Append(MtxGrp[Node[idx].Index].Matrix);

        var declH = new HeaderData(h.Start + h.Offset3, bin);

        var Offsets = new int[declH.Count1];
        for (int j = 0; j < declH.Count1; j++)
        {
          var newDecl = new DeclPart();

          newDecl.Offset = declH.Offsets[j];
          newDecl.Start = declH.Start + declH.Offsets[j];
          newDecl.IdxGrpIndex = BitConverter.ToInt32(bin, newDecl.Start + 0x0C);
          newDecl.IdxCount = BitConverter.ToInt32(bin, newDecl.Start + 0x10);
          newDecl.VtxCount = BitConverter.ToUInt16(bin, newDecl.Start + 0x14);
          newDecl.VtxGrpIndex = BitConverter.ToInt32(bin, newDecl.Start + 0x30);
          newDecl.DataSize = BitConverter.ToInt32(bin, newDecl.Start + 0x34);
          VtxGrp[newDecl.VtxGrpIndex].DataSize = newDecl.DataSize;
          int vtxDataLayersCount = BitConverter.ToInt32(bin, newDecl.Start + 0x38);
          ParseVertexDataLayers(bin, VtxGrp[newDecl.VtxGrpIndex], newDecl.Start + 0x40, vtxDataLayersCount);

          IdxGrp[newDecl.IdxGrpIndex].AddIdx(newDecl.IdxCount, bin);
          newGrp.Decl.Add(newDecl);
        }

        newGrp.MaxObjID = 0;
        tempBn = new byte[4];
        for (int j = 0; j < newGrp.ChildCount; j++)
        {
          var newObj = new ObjectPart();
          newObj.Offset = BitConverter.ToInt32(bin, newGrp.Start + h.Offset1 + (j * 4));
          newObj.Start = newGrp.Start + newObj.Offset;
          newObj.ID = BitConverter.ToInt32(bin, newObj.Start);
          newObj.MtrColor = BitConverter.ToInt32(bin, newObj.Start + 0x4);
          newObj.TexCount = BitConverter.ToInt32(bin, newObj.Start + 0xC);
          newObj.DeclIndex = BitConverter.ToInt32(bin, newObj.Start + 0x38);

          newObj.Transparent1 = BitConverter.ToInt32(bin, newObj.Start + 0x40);
          newObj.Transparent2 = BitConverter.ToInt32(bin, newObj.Start + 0x48);
          newObj.DoubleSided = BitConverter.ToInt32(bin, newObj.Start + 0x6C);

          newObj.VtxGrpIndex = newGrp.Decl[newObj.DeclIndex].VtxGrpIndex;
          newObj.IdxGrpIndex = newGrp.Decl[newObj.DeclIndex].IdxGrpIndex;
          newObj.IdxStartIndex = BitConverter.ToInt32(bin, newObj.Start + 0x70);
          newObj.IdxCount = BitConverter.ToInt32(bin, newObj.Start + 0x74);
          newObj.VtxStartIndex = BitConverter.ToInt32(bin, newObj.Start + 0x78);
          newObj.VtxCount = BitConverter.ToUInt16(bin, newObj.Start + 0x7C);

          newObj.TexParams = bin.Skip(newObj.Start + 0xCC).Take(4).ToArray();

          for (int k = 0; k < newObj.TexCount; k++)
          {
            var newTex = new ObjectTextureData(bin, k, newObj.Start);
            newObj.Tex.Add(newTex);
          }

          if (newObj.IdxStartIndex + newObj.IdxCount > newGrp.Decl[newObj.DeclIndex].IdxCount)
          {
            newGrp.Decl[newObj.DeclIndex].IdxCount = newObj.IdxStartIndex + newObj.IdxCount;
            IdxGrp[newObj.IdxGrpIndex].AddIdx(newGrp.Decl[newObj.DeclIndex].IdxCount, bin);
          }

          if (MateCp.Count > 0)
          {
            int index = Itable[i].Indices[j];
            if (index < MateCp.Count)
            {
              if (Array.FindIndex(MateCp[index].Cp.ToArray(), cp => cp.Data1 == 0xEB53FEEF) != -1)
              {
                newObj.MaterialType = "Skin";
              }
              else if (Array.FindIndex(MateCp[index].Cp.ToArray(), cp => cp.Data1 == 0x60121B1E) != -1)
              {
                newObj.MaterialType = "WetTex";
              }
            }
          }

          if (newObj.ID > newGrp.MaxObjID) newGrp.MaxObjID = newObj.ID;
          newGrp.Obj.Add(newObj);
        }
        ObjGrp.Add(newGrp);
      }
    }

    public static void ParseVertexDataLayers(byte[] bin, VertexGroup grp, int offset, int count)
    {
      for (int i = 0; i < count; i++)
      {
        byte[] bs = new byte[8];
        Array.Copy(bin, offset + (i * 8), bs, 0, 8);

        if (bs[6] == 0)
        {
          grp.Position = true;
          grp.PositionOffset = bs[2];
          grp.PositionType = bs[4];
        }
        else if (bs[6] == 3)
        {
          grp.Normal = true;
          grp.NormalOffset = bs[2];
          grp.NormalType = bs[4];
        }
        else if (bs[6] == 1)
        {
          grp.BlendWeight = true;
          grp.BlendWeightOffset = bs[2];
          grp.BlendWeightType = bs[4];
        }
        else if (bs[6] == 2)
        {
          grp.BlendIndices = true;
          grp.BlendIndicesOffset = bs[2];
          grp.BlendIndicesType = bs[4];
        }
        else if (bs[6] == 10)
        {
          grp.Color = true;
          grp.ColorOffset = bs[2];
          grp.ColorType = bs[4];
        }
        else if (bs[6] == 6)
        {
          grp.Tangent = true;
          grp.TangentOffset = bs[2];
          grp.TangentType = bs[4];
        }
        else if (bs[6] == 5 && bs[4] == 0x0B)
        {
          grp.UVCount += 2;
          grp.TexCoord.Add(2);
          grp.TexCoordOffsets.Add(bs[2]);
        }
        else if (bs[6] == 5 && bs[4] == 0x0A)
        {
          grp.UVCount += 1;
          grp.TexCoord.Add(1);
          grp.TexCoordOffsets.Add(bs[2]);
        }
      }
    }

    public void ParseTextureData(byte[] bin)
    {
      int start = H.Offsets[1];
      Tex = new List<Textures>();

      var ttdmH = new HeaderData(start, bin);
      var ttdhH = new HeaderData(start + ttdmH.HSize, bin);
      var ttdlH = new HeaderData(start + ttdmH.Offset3, bin);

      for (int i = 0; i < ttdhH.Count1; i++)
      {
        var newTex = new Textures();

        newTex.ID = i;
        newTex.InL = (BitConverter.ToInt32(bin, ttdhH.Start + ttdhH.Offsets[i]) == 1) ? true : false;
        newTex.RelativeID = BitConverter.ToInt32(bin, ttdhH.Start + ttdhH.Offsets[i] + 4);

        if (newTex.InL)
        {
          newTex.Offset = ttdlH.Offsets[newTex.RelativeID];
          newTex.Size = ttdlH.Sizes[newTex.RelativeID];
        }
        else
        {
          newTex.Offset = ttdmH.Offsets[newTex.RelativeID];
          newTex.Size = ttdmH.Sizes[newTex.RelativeID];
        }

        Tex.Add(newTex);
      }
    }

    public void PreParseVertexData(byte[] bin)
    {
      int start = H.Offsets[2];
      VtxGrp = new List<VertexGroup>();

      var h = new HeaderData(start, bin);
      for (int i = 0; i < h.Count1; i++)
      {
        var newGrp = new VertexGroup(h.Start, h.Offsets[i], h.Sizes[i]);
        VtxGrp.Add(newGrp);
      }
    }

    public void ParseVertexData(byte[] bin)
    {

      for (int i = 0; i < VtxGrp.Count; i++)
      {
        // Declとリンクしていないものはスキップ
        if (VtxGrp[i].DataSize == 0) continue;

        if (i == 0)
        {
          VtxGrp[i].StartIndex = 0;
        }
        else
        {
          VtxGrp[i].StartIndex = VtxGrp[i - 1].Vtx.Count;
        }

        ParseVertexGrp(bin, VtxGrp[i], i);
      }
    }

    public static void ParseVertexGrp(byte[] bin, VertexGroup grp, int index)
    {
      byte[] tempBn = new byte[grp.DataSize];
      for (int i = 0; i < (grp.Size) / grp.DataSize; i++)
      {
        var newVtx = new Vertex();
        newVtx.Group = index;
        newVtx.Address = grp.Start + (i * grp.DataSize);
        Array.Copy(bin, newVtx.Address, tempBn, 0, grp.DataSize);

        var newUV = new UV();

        if (grp.Position)
        {
          newVtx.X = BitConverter.ToSingle(tempBn, grp.PositionOffset);
          newVtx.Y = BitConverter.ToSingle(tempBn, grp.PositionOffset + 0x04);
          newVtx.Z = BitConverter.ToSingle(tempBn, grp.PositionOffset + 0x08);
          if (grp.PositionType == 3) newVtx.W = BitConverter.ToSingle(tempBn, grp.PositionOffset + 0x0C);
        }

        if (grp.Normal)
        {
          newVtx.N1 = BitConverter.ToSingle(tempBn, grp.NormalOffset);
          newVtx.N2 = BitConverter.ToSingle(tempBn, grp.NormalOffset + 0x04);
          newVtx.N3 = BitConverter.ToSingle(tempBn, grp.NormalOffset + 0x08);
          if (grp.NormalType == 3) newVtx.N4 = BitConverter.ToSingle(tempBn, grp.NormalOffset + 0x0C);
        }

        if (grp.BlendWeight)
        {
          if (grp.BlendWeightType == 3)
          {
            newVtx.WeightsF = new float[4];
            for (int j = 0; j < 4; j++)
            {
              newVtx.WeightsF[j] = BitConverter.ToSingle(tempBn, grp.BlendWeightOffset + (4 * j));
            }
          }
          else
          {
            newVtx.Weights = new byte[4];
            Array.Copy(bin, newVtx.Address + grp.BlendWeightOffset, newVtx.Weights, 0, 4);
          }
        }

        if (grp.BlendIndices)
        {
          newVtx.BlendIdx = new byte[4];
          Array.Copy(bin, newVtx.Address + grp.BlendIndicesOffset, newVtx.BlendIdx, 0, 4);
        }

        if (grp.Tangent)
        {
          newVtx.T1 = BitConverter.ToSingle(tempBn, grp.TangentOffset);
          newVtx.T2 = BitConverter.ToSingle(tempBn, grp.TangentOffset + 0x04);
          newVtx.T3 = BitConverter.ToSingle(tempBn, grp.TangentOffset + 0x08);
          newVtx.T4 = BitConverter.ToSingle(tempBn, grp.TangentOffset + 0x0C);
        }

        for (int j = 0; j < grp.TexCoord.Count; j++)
        {
          int offset = grp.TexCoordOffsets[j];

          if (grp.TexCoord[j] == 2)
          {
            newUV = new UV();
            newUV.U = new byte[] { tempBn[offset], tempBn[offset + 0x01] };
            newUV.V = new byte[] { tempBn[offset + 0x02], tempBn[offset + 0x03] };
            newVtx.UV.Add(newUV);
            newUV = new UV();
            newUV.U = new byte[] { tempBn[offset + 0x04], tempBn[offset + 0x05] };
            newUV.V = new byte[] { tempBn[offset + 0x06], tempBn[offset + 0x07] };
            newVtx.UV.Add(newUV);
          }
          else if (grp.TexCoord[j] == 1)
          {
            newUV = new UV();
            newUV.U = new byte[] { tempBn[offset], tempBn[offset + 0x01] };
            newUV.V = new byte[] { tempBn[offset + 0x02], tempBn[offset + 0x03] };
            newVtx.UV.Add(newUV);
          }
        }

        grp.Vtx.Add(newVtx);
      }
    }

    public void PreParseIndexData(byte[] bin)
    {
      int start = H.Offsets[3];
      IdxGrp = new List<IndexGroup>();

      var h = new HeaderData(start, bin);
      for (int i = 0; i < h.Count1; i++)
      {
        var newGrp = new IndexGroup(h.Start, h.Offsets[i], h.Sizes[i], bin);
        IdxGrp.Add(newGrp);
      }
    }

    public void ParseMtrColor(byte[] bin)
    {
      int start = H.Offsets[4];
      HeaderData h = new HeaderData(start, bin);
      ColGrp = new List<MtrColorGroup>();
      foreach (int offset in h.Offsets)
      {
        var newGrp = new MtrColorGroup(h.Start, offset, bin);
        ColGrp.Add(newGrp);
      }
    }

    public void ParseMdlInfo(byte[] bin)
    {
      int start = H.Offsets[5];
      HeaderData h = new HeaderData(start, bin);
      ObjInfo = new List<ObjInfo>();
      foreach (int offset in h.Offsets)
      {
        var newObjInfo = new ObjInfo(h.Start, offset, bin);
        ObjInfo.Add(newObjInfo);
      }
    }

    public void ParseHieLayer(byte[] bin)
    {
      int start = H.Offsets[6];
      HeaderData h = new HeaderData(start, bin);
      maxBoneLevel = 0;

      Hie = new List<Hies>();
      for (int i = 0; i < h.Count1; i++)
      {
        var newHie = new Hies(h.Start, h.Offsets[i], bin);

        if (newHie.BoneLevel > maxBoneLevel) maxBoneLevel = newHie.BoneLevel;

        Hie.Add(newHie);
      }

      foreach (var hie in Hie)
      {
        if (hie.BoneLevel == 0) SetMatrixLayered(hie);
      }
    }

    public void SetMatrixLayered(Hies hie)
    {
      if (hie.Parent == -1)
        hie.MatrixLayered = hie.Matrix;
      else
        hie.MatrixLayered = hie.Matrix * Hie[hie.Parent].MatrixLayered;
      foreach (var child in hie.Children)
      {
        SetMatrixLayered(Hie[child]);
      }
    }

    public void ParseNodeLayer(byte[] bin)
    {
      Node = new List<Nodes>();
      BlendIdxGrp = new Dictionary<int, BlendIndexGroup>();

      if (H.Offsets[8] == 0) return;

      int start = H.Offsets[8];
      HeaderData h = new HeaderData(start, bin);

      for (int i = 0; i < h.Count1; i++)
      {
        HeaderData nodeH = new HeaderData(h.Start + h.Offsets[i], bin);
        var newNode = new Nodes(this, nodeH, bin);
        Node.Add(newNode);
      }
    }

    public void ParseGlobalMatrices(byte[] bin)
    {
      MtxGrp = new List<MatrixGroup>();
      int start = H.Offsets[9];
      HeaderData h = new HeaderData(start, bin);
      if (h.Offsets.Count == 0) return;

      for (int i = 0; i < h.Count1; i++)
      {
        var newGrp = new MatrixGroup(h.Start, h.Offsets[i], bin);
        MtxGrp.Add(newGrp);
      }
    }

    public void ParseBoneOffsetMatrices(byte[] bin)
    {
      int start = H.Offsets[10];
      HeaderData h = new HeaderData(start, bin);

      BnOfsMtxGrp = new List<MatrixGroup>();
      for (int i = 0; i < h.Count1; i++)
      {
        var newGrp = new MatrixGroup(h.Start, h.Offsets[i], bin);
        BnOfsMtxGrp.Add(newGrp);
      }
    }

    public void ParseCpf(byte[] bin)
    {
      NodeCp = new List<Customp>();
      MateCp = new List<Customp>();
      Itable = new List<ItableData>();

      if (H.Offsets[11] == 0) return;

      int start = H.Offsets[11];
      HeaderData h = new HeaderData(start, bin);
      if (h.Offsets.Count == 0) return;

      cpfOffsets = h.Offsets.Select(elem => elem).ToArray();

      if (h.Offsets[0] != 0)
      {
        // nodecp
        HeaderData nodecpH = new HeaderData(start + h.Offsets[0], bin);
        for (int i = 0; i < nodecpH.Count1; i++)
        {
          if (nodecpH.Offsets[i] != 0)
          {
            var newNodeCp = new Customp(nodecpH.Start, nodecpH.Offsets[i], bin);
            newNodeCp.Index = i;
            NodeCp.Add(newNodeCp);
          }
        }
      }

      if (h.Offsets[1] != 0)
      {
        // matecp
        HeaderData matecpH = new HeaderData(start + h.Offsets[1], bin);
        for (int i = 0; i < matecpH.Count1; i++)
        {
          if (matecpH.Offsets[i] != 0)
          {
            var newMateCp = new Customp(matecpH.Start, matecpH.Offsets[i], bin);
            newMateCp.Index = i;
            MateCp.Add(newMateCp);
          }
        }

        //itable
        itableOffset = matecpH.Offset3;
        HeaderData itableH = new HeaderData(matecpH.Start + matecpH.Offset3, bin);
        for (int i = 0; i < itableH.Count1; i++)
        {
          var newItable = new ItableData(itableH.Start, itableH.Offsets[i], bin);
          Itable.Add(newItable);
        }
      }

    }

    public void ParseMCAPack(byte[] bin)
    {
      int start = H.Offsets[12];
      if (start == 0) return;

      var mcaPackH = new HeaderData(start, bin);
      if (mcaPackH.Offsets.Count == 0) return;

      var mcaIndexH = new HeaderData(mcaPackH.Start + mcaPackH.Offset3, bin);
      McaindexOffset = mcaPackH.Offset3;

      McaIdx = new List<MCAIndex>();
      for (int i = 0; i < mcaIndexH.Count1; i++)
      {
        var newIdx = new MCAIndex(mcaIndexH.Start, mcaIndexH.Offsets[i], bin, ObjGrp[i]);
        McaIdx.Add(newIdx);
      }

      Mat = new List<Material>();
      for (int i = 0; i < mcaPackH.Count1; i++)
      {
        var newMat = new Material(mcaPackH.Start, mcaPackH.Offsets[i], bin);
        newMat.ID = i;
        Mat.Add(newMat);
      }
    }

    public void ParseACSCLS(byte[] bin)
    {
      int start = H.Offsets[16];
      if (start == 0) return;

      var h = new HeaderData(start, bin);

      Physics = new List<PhysicsData>();
      if (h.Offsets[0] != 0)
      {
        var physicsH = new HeaderData(h.Start + h.Offsets[0], bin);
        var physicsSubH = new HeaderData(physicsH.Start + physicsH.HSize, bin);

        for (int i = 0; i < physicsH.Count1; i++)
        {
          var newPhysics = new PhysicsData(physicsSubH.Start + physicsSubH.Offset1 + (0x0C * i), physicsH.Start, physicsH.Offsets[i], bin);
          newPhysics.Index = i;
          Physics.Add(newPhysics);
        }

        int inUseCount = BitConverter.ToInt32(bin, physicsSubH.Start + physicsSubH.HSize);
        for (int i = 0; i < inUseCount; i++)
        {
          int index = BitConverter.ToInt32(bin, physicsSubH.Start + physicsSubH.HSize + 4 * (i + 1));
          Physics[index].InUse = true;
        }
      }

      Collisions = new List<Collision>();
      if (h.Offsets[1] != 0)
      {
        var collisionsH = new HeaderData(h.Start + h.Offsets[1], bin);
        var collisionsSubH = new HeaderData(collisionsH.Start + collisionsH.HSize, bin);
        for (int i = 0; i < collisionsH.Count1; i++)
        {
          var newCollision = new Collision(collisionsSubH.Start + collisionsSubH.Offset1 + (0x0C * i), collisionsH.Start + collisionsH.Offsets[i], bin);
          newCollision.Index = i;
          Collisions.Add(newCollision);
        }
      }

      AcsclsIndices = new List<int[]>();
      for (int i = 2; i < h.Count1; i++)
      {
        int count = 0;
        HeaderData childH = null;
        if (h.Offsets[i] != 0)
        {
          childH = new HeaderData(h.Start + h.Offsets[i], bin);
          count = childH.Count1;
        }
        var newIndices = new int[count];

        for (int j = 0; j < count; j++)
        {
          newIndices[j] = BitConverter.ToInt32(bin, childH.Start + childH.Offset1 + (4 * j));
        }

        AcsclsIndices.Add(newIndices);
      }
    }


    public string Path { get; set; }
    public DateTime WriteTime { get; set; }

    public int maxBoneLevel { get; set; }
    public int[] cpfOffsets { get; set; }
    public int itableOffset { get; set; }
    public int McaindexOffset { get; set; }

    public HeaderData H { get; private set; }

    public List<Hies> Hie { get; private set; }
    public List<MatrixGroup> MtxGrp { get; private set; }
    public List<MatrixGroup> BnOfsMtxGrp { get; private set; }
    public List<Nodes> Node { get; private set; }
    public Dictionary<int, BlendIndexGroup> BlendIdxGrp { get; private set; }

    public List<ObjectGroup> ObjGrp { get; set; }
    public List<Textures> Tex { get; private set; }
    public List<VertexGroup> VtxGrp { get; set; }
    public List<IndexGroup> IdxGrp { get; set; }
    public List<MtrColorGroup> ColGrp { get; private set; }
    public List<ObjInfo> ObjInfo { get; private set; }
    public List<Customp> NodeCp { get; private set; }
    public List<Customp> MateCp { get; private set; }
    public List<ItableData> Itable { get; private set; }
    public List<MCAIndex> McaIdx { get; private set; }
    public List<Material> Mat { get; private set; }
    public List<PhysicsData> Physics { get; private set; }
    public List<Collision> Collisions { get; private set; }
    public List<int[]> AcsclsIndices { get; private set; }
  }




  // MdlGeo
  public class ObjectGroup
  {
    public ObjectGroup(HeaderData hData, int offset, byte[] bin)
    {
      Decl = new List<DeclPart>();
      Obj = new List<ObjectPart>();
      Matrix = new Matrix3D();

      if (hData == null) return;

      Offset = offset;
      Start = hData.Start;
      ChildCount = hData.Count1;
      DeclOffset = hData.Offset3;

      unknown0x30 = BitConverter.ToInt16(bin, Start + 0x30);
      unknown0x32 = BitConverter.ToInt16(bin, Start + 0x32);
      ID = BitConverter.ToInt32(bin, Start + 0x34);
      unknown0x38 = BitConverter.ToInt32(bin, Start + 0x38);

      Name = Encoding.ASCII.GetString(bin, Start + 0x50, 16).TrimEnd('\0');
    }

    public int Offset { get; set; }
    public int Start { get; set; }
    public int ChildCount { get; set; }
    public int DeclOffset { get; set; }

    public int ID { get; set; }
    public string Name { get; set; }
    public int Node { get; set; }
    public int NodeCp { get; set; }
    public int MaxObjID { get; set; }

    public short unknown0x30 { get; set; }
    public short unknown0x32 { get; set; }
    public int unknown0x38 { get; set; }

    public List<DeclPart> Decl { get; private set; }
    public List<ObjectPart> Obj { get; private set; }
    public Matrix3D Matrix { get; set; }
  }

  public class DeclPart
  {
    public DeclPart()
    {
    }

    public int Offset { get; set; }
    public int Start { get; set; }
    public int DataSize { get; set; }
    public int IdxGrpIndex { get; set; }
    public int IdxCount { get; set; }
    public int VtxGrpIndex { get; set; }
    public ushort VtxCount { get; set; }
  }

  public class ObjectPart
  {
    public ObjectPart()
    {
      Tex = new List<ObjectTextureData>();
    }

    public int Offset { get; set; }
    public int Start { get; set; }
    public int ID { get; set; }
    public int MtrColor { get; set; }

    public int Transparent1 { get; set; }
    public int Transparent2 { get; set; }
    public int DoubleSided { get; set; }

    public int VtxGrpIndex { get; set; }
    public int VtxStartIndex { get; set; }
    public ushort VtxCount { get; set; }
    public int IdxGrpIndex { get; set; }
    public int IdxStartIndex { get; set; }
    public int IdxCount { get; set; }
    public int TexCount { get; set; }
    public int DeclIndex { get; set; }

    public string MaterialType { get; set; }

    public byte[] TexParams { get; set; }

    public List<ObjectTextureData> Tex { get; private set; }
  }

  public class ObjectTextureData
  {
    public ObjectTextureData()
    {
      Data = new dynamic[27];
    }
    public ObjectTextureData(byte[] bin, int index, int start)
    {
      Data = new dynamic[27];
      Offset = BitConverter.ToInt32(bin, start + 0x10 + (index * 4));
      ID = BitConverter.ToInt32(bin, start + Offset);
      Type = BitConverter.ToInt32(bin, start + Offset + 4);
      Num = BitConverter.ToInt32(bin, start + Offset + 8);
      int count = 0;
      for (int i = 0; i < 27; i++)
      {
        if (i == 3 || i == 5 || i == 6 || i == 20 || i == 21)
        {
          Data[i] = BitConverter.ToSingle(bin, start + Offset + 0x0C + count);
          count += 4;
        }
        else if (i == 7)
        {
          Data[i] = BitConverter.ToInt32(bin, start + Offset + 0x0C + count);
          count += 4;
        }
        else if (i >= 10 && i <= 13)
        {
          Data[i] = BitConverter.ToUInt16(bin, start + Offset + 0x0C + count);
          count += 2;
        }
        else
        {
          Data[i] = BitConverter.ToUInt32(bin, start + Offset + 0x0C + count);
          count += 4;
        }
      }
    }

    public int Offset { get; set; }
    public int ID { get; set; }
    public int Type { get; set; }
    public int Num { get; set; }

    public dynamic[] Data { get; set; }
  }

  // TTDM/TTDH/TTDL
  public class Textures
  {
    public Textures()
    {

    }

    public int Offset { get; set; }
    public int Size { get; set; }
    public int ID { get; set; }
    public bool InL { get; set; }
    public int RelativeID { get; set; }

    public byte[] Data { get; set; }
  }

  // VtxLay
  public class VertexGroup
  {
    public VertexGroup(int start, int offset, int size)
    {
      Vtx = new List<Vertex>();
      TexCoord = new List<int>();
      TexCoordOffsets = new List<int>();

      Offset = offset;
      Start = start + offset;
      Size = size;

      PositionType = -1;
      NormalType = -1;
      BlendWeightType = -1;
      BlendIndicesType = -1;
      ColorType = -1;
      TangentType = -1;
    }

    public int Offset { get; set; }
    public int Start { get; set; }
    public int Size { get; set; }
    public int StartIndex { get; set; }

    public int DataSize { get; set; }
    public int UVCount { get; set; }

    public bool Position { get; set; }
    public bool Normal { get; set; }
    public bool BlendWeight { get; set; }
    public bool BlendIndices { get; set; }
    public bool Color { get; set; }
    public bool Tangent { get; set; }
    public List<int> TexCoord { get; set; }

    public int PositionType { get; set; }
    public int NormalType { get; set; }
    public int BlendWeightType { get; set; }
    public int BlendIndicesType { get; set; }
    public int ColorType { get; set; }
    public int TangentType { get; set; }

    public int PositionOffset { get; set; }
    public int NormalOffset { get; set; }
    public int BlendWeightOffset { get; set; }
    public int BlendIndicesOffset { get; set; }
    public int ColorOffset { get; set; }
    public int TangentOffset { get; set; }
    public List<int> TexCoordOffsets { get; set; }

    public List<Vertex> Vtx { get; private set; }
  }

  public class Vertex
  {
    public Vertex()
    {
      UV = new List<UV>();
      BlendIdx = new byte[0];
      W = null;
      N4 = null;
    }

    public int Address { get; set; }
    public int Group { get; set; }

    public float X { get; set; }
    public float Y { get; set; }
    public float Z { get; set; }
    public float? W { get; set; }

    public float N1 { get; set; }
    public float N2 { get; set; }
    public float N3 { get; set; }
    public float? N4 { get; set; }
    public byte[] Weights { get; set; }
    public float[] WeightsF { get; set; }
    public byte[] BlendIdx { get; set; }
    public float T1 { get; set; }
    public float T2 { get; set; }
    public float T3 { get; set; }
    public float T4 { get; set; }

    public List<UV> UV { get; private set; }
  }

  public class UV
  {
    public UV()
    {
    }

    public byte[] U { get; set; }
    public byte[] V { get; set; }
  }

  // IdxLay
  public class IndexGroup
  {
    public IndexGroup(int start, int offset, int size, byte[] bin)
    {
      Offset = offset;
      Start = start + offset;
      Size = size;
    }

    public void AddIdx(int count, byte[] bin)
    {
      Idx = new ushort[count];
      for (int i = 0; i < count; i++)
      {
        Idx[i] = BitConverter.ToUInt16(bin, Start + (i * 2));
      }
    }

    public int Offset { get; set; }
    public int Start { get; set; }
    public int Size { get; set; }
    public ushort[] Idx { get; set; }
  }

  // MtrCol
  public class MtrColorGroup
  {
    public MtrColorGroup(int start, int offset, byte[] bin)
    {
      Color = new List<float[]>();
      Link = new Dictionary<int, int>();

      if (start == 0 && offset == 0) return;

      Offset = offset;
      Start = start + offset;
      for (int i = 0; i < 13; i++)
      {
        float[] color = {
          BitConverter.ToSingle(bin, Start + (0x10 * i)),
          BitConverter.ToSingle(bin, Start + (0x10 * i) + 0x04),
          BitConverter.ToSingle(bin, Start + (0x10 * i) + 0x08),
          BitConverter.ToSingle(bin, Start + (0x10 * i) + 0x0C)
        };
        Color.Add(color);
      }
      ID = bin[Start + 0xD0];
      for (int i = 0; i < bin[Start + 0xD4]; i++)
      {
        Link[bin[Start + 0xD8 + (8 * i)]] = bin[Start + 0xDC + (8 * i)];
      }
    }

    public int ID { get; set; }
    public int Offset { get; set; }
    public int Start { get; set; }
    public List<float[]> Color { get; set; }
    public Dictionary<int, int> Link { get; set; } // objindex, subobjnum_seq
  }

  // MdlInfo
  public class ObjInfo
  {
    public ObjInfo(int start, int offset, byte[] bin)
    {
      Offset = offset;
      Start = start + offset;
      var h = new HeaderData(start + offset, bin);

      Data1 = BitConverter.ToUInt32(bin, h.Start + h.HSize);
      ID = BitConverter.ToInt32(bin, h.Start + h.HSize + 4);
      Data2 = BitConverter.ToInt32(bin, h.Start + h.HSize + 8);
      Data3 = BitConverter.ToInt32(bin, h.Start + h.HSize + 0x0C);
      Data4 = BitConverter.ToInt32(bin, h.Start + h.HSize + 0x10);
      Z1 = BitConverter.ToInt32(bin, h.Start + h.HSize + 0x14);
      Data5 = BitConverter.ToSingle(bin, h.Start + h.HSize + 0x18);
      Data6 = new int[3];
      for (int i = 0; i < 3; i++)
        Data6[i] = BitConverter.ToInt32(bin, h.Start + h.HSize + 0x1C + (4 * i));
      Z2 = BitConverter.ToInt32(bin, h.Start + h.HSize + 0x28);
      Data7 = BitConverter.ToSingle(bin, h.Start + h.HSize + 0x2C);

      Params = new dynamic[32];
      for (int i = 0; i < 32; i++)
      {
        if (i == 15 || i == 27)
          Params[i] = BitConverter.ToSingle(bin, h.Start + h.HSize + 0x30 + (4 * i));
        else
          Params[i] = BitConverter.ToInt32(bin, h.Start + h.HSize + 0x30 + (4 * i));
      }
      FParams = new float[28];
      for (int i = 0; i < 28; i++)
        FParams[i] = BitConverter.ToSingle(bin, h.Start + h.HSize + 0xB0 + (4 * i));

      Info = new List<Info>();
      for (int i = 0; i < h.Count1; i++)
      {
        var newInfo = new Info(h.Start, h.Offsets[i], bin);
        Info.Add(newInfo);
      }
    }

    public int Offset { get; set; }
    public int Start { get; set; }

    public uint Data1 { get; set; }
    public int ID { get; private set; }
    public int Data2 { get; private set; }
    public int Data3 { get; private set; }
    public int Data4 { get; private set; }
    public int Z1 { get; private set; }
    public float Data5 { get; private set; }
    public int[] Data6 { get; private set; }
    public int Z2 { get; private set; }
    public float Data7 { get; private set; }

    public dynamic[] Params { get; set; }
    public float[] FParams { get; set; }

    public List<Info> Info { get; set; }
  }

  public class Info
  {
    public Info(int start, int offset, byte[] bin)
    {
      Offset = offset;
      Start = start + offset;

      ID = BitConverter.ToInt32(bin, Start);
      Z1 = BitConverter.ToInt32(bin, Start + 4);
      Data1 = BitConverter.ToInt32(bin, Start + 8);
      Data2 = BitConverter.ToSingle(bin, Start + 0x0C);
      Data3 = BitConverter.ToInt32(bin, Start + 0x10);
      Data4 = BitConverter.ToInt32(bin, Start + 0x14);
      Z2 = BitConverter.ToInt32(bin, Start + 0x18);
      Data5 = BitConverter.ToInt32(bin, Start + 0x1C);

      Params = new dynamic[8];
      for (int i = 0; i < 8; i++)
      {
        if (i == 1 || i == 5)
          Params[i] = BitConverter.ToSingle(bin, Start + 0x20 + (4 * i));
        else
          Params[i] = BitConverter.ToInt32(bin, Start + 0x20 + (4 * i));
      }
      FParams = new float[28];
      for (int i = 0; i < 28; i++)
        FParams[i] = BitConverter.ToSingle(bin, Start + 0x40 + (4 * i));
    }

    public int Offset { get; set; }
    public int Start { get; set; }

    public int ID { get; private set; }
    public int Z1 { get; private set; }
    public int Data1 { get; set; }
    public float Data2 { get; private set; }
    public int Data3 { get; set; }
    public int Data4 { get; set; }
    public int Z2 { get; private set; }
    public int Data5 { get; set; }

    public dynamic[] Params { get; set; }
    public float[] FParams { get; set; }
  }

  // HieLay
  public class Hies
  {
    public Hies(int start, int offset, byte[] bin)
    {
      Offset = offset;
      Start = start + offset;

      double[] m = new double[16];
      for (int i = 0; i < 16; i++)
      {
        m[i] = BitConverter.ToSingle(bin, Start + (0x04 * i));
      }
      Matrix = new Matrix3D(m[0], m[1], m[2], m[3], m[4], m[5], m[6], m[7], m[8], m[9], m[10], m[11], m[12], m[13], m[14], m[15]);

      Parent = BitConverter.ToInt32(bin, Start + 0x40);
      ChildCount = BitConverter.ToInt32(bin, Start + 0x44);
      BoneLevel = BitConverter.ToInt32(bin, Start + 0x48);

      Children = new int[ChildCount];
      for (int i = 0; i < ChildCount; i++)
      {
        Children[i] = BitConverter.ToInt32(bin, Start + 0x50 + (0x04 * i));
      }
    }

    public int Offset { get; set; }
    public int Start { get; set; }

    public int Parent { get; set; }
    public int ChildCount { get; set; }
    public int BoneLevel { get; set; }

    public Matrix3D Matrix { get; set; }
    public Matrix3D MatrixLayered { get; set; }
    public int[] Children { get; set; }
  }

  // NodeLay
  public class Nodes
  {
    public Nodes(dynamic tmcdata, HeaderData nodeH, byte[] bin)
    {
      Matrix = new Matrix3D();
      ObjIndex = -1;

      Start = nodeH.Start;
      Master = BitConverter.ToInt32(bin, nodeH.Start + 0x34);
      Index = BitConverter.ToInt32(bin, nodeH.Start + 0x38);

      int length = (nodeH.Offset1 == 0) ? nodeH.Size - 0x40 : nodeH.Offset1 - 0x40;
      Name = Encoding.ASCII.GetString(bin, nodeH.Start + 0x40, length).TrimEnd('\0');
      if (nodeH.Offset1 > 0)
      {
        Offset = BitConverter.ToInt32(bin, nodeH.Start + nodeH.Offset1);
        ObjIndex = BitConverter.ToInt32(bin, nodeH.Start + Offset);
        ChildCount = BitConverter.ToInt32(bin, nodeH.Start + Offset + 0x04);

        double[] m = new double[16];
        for (int i = 0; i < 16; i++)
        {
          m[i] = BitConverter.ToSingle(bin, nodeH.Start + Offset + 0x10 + (0x04 * i));
        }
        Matrix = new Matrix3D(m[0], m[1], m[2], m[3], m[4], m[5], m[6], m[7], m[8], m[9], m[10], m[11], m[12], m[13], m[14], m[15]);

        BlendIndexGroup newGrp = new BlendIndexGroup(tmcdata, this, nodeH.Start + Offset, bin);
      }
    }

    public int Offset { get; set; }
    public int Start { get; set; }

    public string Name { get; set; }
    public int Master { get; set; }
    public int Index { get; set; }
    public int ObjIndex { get; set; }
    public int ChildCount { get; set; }

    public Matrix3D Matrix { get; set; }
  }

  public class BlendIndexGroup
  {
    public BlendIndexGroup(TmcData tmcdata, Nodes node, int start, byte[] bin)
    {
      Idx = new int[node.ChildCount];
      for (int i = 0; i < node.ChildCount; i++)
      {
        Idx[i] = BitConverter.ToInt32(bin, start + 0x50 + (0x04 * i));
      }
      tmcdata.BlendIdxGrp[node.Index] = this;
    }

    public int[] Idx { get; set; }
  }

  // GlblMtx / BnOfsMtx
  public class MatrixGroup
  {
    public MatrixGroup(int start, int offset, byte[] bin)
    {
      if (start == 0)
      {
        Offset = 0;
        Start = 0;
        Matrix = new Matrix3D();
        Matrix.SetIdentity();
        return;
      }

      Offset = offset;
      Start = start + offset;

      double[] m = new double[16];
      for (int j = 0; j < 16; j++)
      {
        m[j] = BitConverter.ToSingle(bin, Start + (0x04 * j));
      }
      Matrix = new Matrix3D(m[0], m[1], m[2], m[3], m[4], m[5], m[6], m[7], m[8], m[9], m[10], m[11], m[12], m[13], m[14], m[15]);
    }

    public int Offset { get; set; }
    public int Start { get; set; }

    public Matrix3D Matrix { get; set; }
  }

  // cpf
  public class Customp
  {
    public Customp(int start, int offset, byte[] bin)
    {
      Cp = new List<CustompParam>();

      if (start == 0 && offset == 0) return;

      var cpH = new HeaderData(start + offset, bin);
      Offset = offset;
      Start = start + offset;
      Size = cpH.Size;
      for (int i = 0; i < cpH.Count1; i++)
      {
        var newCp = new CustompParam();
        newCp.Index = BitConverter.ToInt32(bin, cpH.Start + cpH.Offset3 + (8 * i) + 4);
        newCp.Data1 = BitConverter.ToUInt32(bin, cpH.Start + cpH.Offset3 + (8 * i));
        newCp.Data2 = BitConverter.ToInt32(bin, cpH.Start + cpH.Offsets[i]);

        switch (newCp.Data2)
        {
          case 2:
            newCp.Param = BitConverter.ToSingle(bin, cpH.Start + cpH.Offsets[i] + 4);
            break;
          case 3:
            int datasize = 0;
            if (i == cpH.Count1 - 1)
              datasize = cpH.Size - cpH.Offsets[i] - 4;
            else
              datasize = cpH.Offsets[i + 1] - cpH.Offsets[i] - 4;
            newCp.Param = Encoding.ASCII.GetString(bin.Skip(cpH.Start + cpH.Offsets[i] + 4).Take(datasize).ToArray()).TrimEnd('\0');
            break;
          default:
            newCp.Param = BitConverter.ToInt32(bin, cpH.Start + cpH.Offsets[i] + 4);
            break;
        }

        Cp.Add(newCp);
      }
    }

    public Customp Clone()
    {
      Customp cloned = (Customp)MemberwiseClone();
      return cloned;
    }

    public int Offset { get; set; }
    public int Start { get; set; }
    public int Size { get; set; }
    public int Index { get; set; }

    public List<CustompParam> Cp { get; private set; }
  }

  public class CustompParam
  {
    public CustompParam() { }

    public int Index { get; set; }
    public uint Data1 { get; set; }
    public int Data2 { get; set; }
    public dynamic Param { get; set; } // Data2が02ならfloat、03ならstring、それ以外ならint
  }

  public class ItableData
  {
    public ItableData(int start, int offset, byte[] bin)
    {
      Offset = offset;
      int count = BitConverter.ToInt32(bin, start + offset);
      Indices = new int[count];
      for (int i = 0; i < count; i++)
      {
        Indices[i] = BitConverter.ToInt32(bin, start + offset + (i + 1) * 4);
      }
    }

    public int Offset { get; set; }
    public int[] Indices { get; set; }
  }

  // MCAPACK
  public class MCAIndex
  {
    public MCAIndex(int start, int offset, byte[] bin, ObjectGroup grp)
    {
      if (offset == 0) return;

      Offset = offset;
      MatID = new int[grp.MaxObjID + 1];
      for (int i = 0; i < grp.MaxObjID + 1; i++)
      {
        MatID[i] = BitConverter.ToInt16(bin, start + offset + (i * 4));
      }
    }

    public int Offset { get; set; }
    public int[] MatID { get; set; }
  }

  public class Material
  {
    public Material(int start, int offset, byte[] bin)
    {
      Param = new List<MaterialParameter>();
      Offset = offset;
      Start = start + offset;

      var h = new HeaderData(start + offset, bin);
      for (int i = 0; i < h.Count1; i++)
      {
        var newParam = h.Offsets[i] != 0 ? new MaterialParameter(h.Start, h.Offsets[i], bin) : null;
        if (newParam != null)
        {
          newParam.ID = i;
          Param.Add(newParam);
        }
      }
    }

    public int Offset { get; set; }
    public int Start { get; set; }
    public int ID { get; set; }
    public List<MaterialParameter> Param { get; private set; }
  }

  public class MaterialParameter
  {
    public MaterialParameter(int start, int offset, byte[] bin)
    {
      Offset = offset;
      var h = new HeaderData(start + offset, bin);
      Count = h.Count1;
      Data1 = BitConverter.ToSingle(bin, h.Start + h.HSize);
      Data2 = bin[h.Start + h.HSize + 4];

      if (h.Offset3 != 0)
      {
        Data3 = new dynamic[8];
        for (int i = 0; i < 8; i++)
        {
          if (i == 2)
          {
            Data3[i] = BitConverter.ToInt32(bin, h.Start + h.Offset3 + (4 * i));
          }
          else
          {
            Data3[i] = BitConverter.ToSingle(bin, h.Start + h.Offset3 + (4 * i));
          }
        }
      }

      if (h.Offset1 != 0)
      {
        Params = new List<dynamic[]>();
        for (int i = 0; i < h.Count1; i++)
        {
          dynamic[] nums = new dynamic[8];
          nums[0] = BitConverter.ToInt32(bin, h.Start + h.Offset1 + (0x20 * i));
          for (int j = 1; j < 8; j++)
          {
            nums[j] = BitConverter.ToSingle(bin, h.Start + h.Offset1 + (0x20 * i) + (4 * j));
          }
          Params.Add(nums);
        }
      }

    }

    public int Offset { get; set; }
    public int ID { get; set; }
    public int Count { get; set; }
    public float Data1 { get; set; }
    public byte Data2 { get; set; }
    public dynamic[] Data3 { get; set; }
    public List<dynamic[]> Params { get; set; }
  }

  // ACSCLS
  public class PhysicsData
  {
    public PhysicsData(int startSub, int start, int offset, byte[] bin)
    {
      Offset = offset;
      Start = start + offset;
      Type = BitConverter.ToInt32(bin, startSub);
      Node = BitConverter.ToInt32(bin, startSub + 4);
      Param = BitConverter.ToUInt32(bin, startSub + 8);
      Block1 = new List<PhysicsBlock1Data>();
      Block2 = new List<PhysicsBlock2Data>();
      Type2 = new List<List<PhysicsType2Data>>();
      BlockEndIndices = new List<int>();
      Collisions = new List<List<uint>>();


      var h = new HeaderData(start + offset, bin);

      if (Type != 2)
      {
        Params = new float[24];
        for (int i = 0; i < 24; i++)
        {
          Params[i] = BitConverter.ToSingle(bin, h.Start + h.HSize + (4 * i));
        }

        RootNode = BitConverter.ToInt32(bin, h.Start + h.HSize + 0x60);
        HeaderIdx1 = BitConverter.ToInt16(bin, h.Start + h.HSize + 0x64);
        HeaderIdx2 = BitConverter.ToInt16(bin, h.Start + h.HSize + 0x66);
        BaseNode = BitConverter.ToInt32(bin, h.Start + h.HSize + 0x68);

        // Block1
        Block1H1 = new HeaderData(h.Start + h.Offsets[0], bin);
        Block1Offset = h.Offsets[0];

        for (int i = 0; i < Block1H1.Count1; i++)
        {
          var block1data = new PhysicsBlock1Data(Block1H1.Start + Block1H1.Offset1 + (0xA0 * i), bin);
          Block1.Add(block1data);
        }

        // Block2
        Block2H1 = new HeaderData(h.Start + h.Offsets[1], bin);

        for (int i = 0; i < Block2H1.Count1; i++)
        {
          var block2data = new PhysicsBlock2Data(Block2H1.Start + Block2H1.Offset1 + (0x60 * i), bin);
          Block2.Add(block2data);
        }


        if (h.Count1 == 6) // Type == 0
        {
          ParseCollisions(h, bin, 3);
          ParseBlockEnd(h, bin, 5);
        }
        else // Type == 1 || Type == 3
        {
          ParseCollisions(h, bin, 2);
          ParseBlockEnd(h, bin, 4);
        }
      }
      else
      {
        RootNode = BitConverter.ToInt32(bin, h.Start + h.HSize + 0x70);
        HeaderIdx1 = -1;
        HeaderIdx2 = -1;
        BaseNode = BitConverter.ToInt32(bin, h.Start + h.HSize + 0x74);

        for (int i = 0; i < h.Count1; i++)
        {
          var type2 = new List<PhysicsType2Data>();
          if (h.Offsets[i] != 0)
          {
            var type2H = new HeaderData(h.Start + h.Offsets[i], bin);
            for (int j = 0; j < type2H.Count1; j++)
            {
              var type2data = new PhysicsType2Data(type2H.Start + type2H.HSize + (0x40 * j), bin);
              type2.Add(type2data);
            }
          }
          Type2.Add(type2);
        }
      }
    }

    private void ParseCollisions(HeaderData h, byte[] bin, int index)
    {
      for (int i = index; i < index + 2; i++)
      {
        var collisions = new List<uint>();

        if (h.Offsets[i] != 0)
        {
          var childH = new HeaderData(h.Start + h.Offsets[i], bin);
          for (int j = 0; j < childH.Count1; j++)
          {
            collisions.Add(BitConverter.ToUInt32(bin, childH.Start + childH.Offset1 + (4 * j)));
          }
        }

        Collisions.Add(collisions);
      }
    }

    private void ParseBlockEnd(HeaderData h, byte[] bin, int index)
    {
      // BlockEnd
      if (h.Offsets[index] != 0)
      {
        HeaderData blockEndH = new HeaderData(h.Start + h.Offsets[index], bin);
        HeaderData blockEndHSub = new HeaderData(blockEndH.Start + blockEndH.HSize, bin);

        int blockEndSubCount = BitConverter.ToInt32(bin, blockEndHSub.Start + blockEndHSub.HSize);

        for (int i = 0; i < blockEndSubCount; i++)
        {
          BlockEndIndices.Add(BitConverter.ToInt32(bin, blockEndHSub.Start + blockEndHSub.Offsets[0] + (4 * i)));

          float[] matrix = new float[16];
          for (int j = 0; j < 16; j++)
          {
            matrix[j] = BitConverter.ToSingle(bin, blockEndHSub.Start + blockEndHSub.Offsets[1] + (0x40 * i) + (4 * j));
          }
        }
      }
    }



    public int Index { get; set; }
    public int Offset { get; set; }
    public int Start { get; set; }
    public int Block1Offset { get; set; }
    public int Block2Offset { get; set; }

    public bool InUse { get; set; }
    public int Type { get; set; }
    public int Node { get; set; }
    public uint Param { get; set; }

    public int RootNode { get; set; }
    public short HeaderIdx1 { get; set; }
    public short HeaderIdx2 { get; set; }
    public int BaseNode { get; set; }

    public float[] Params { get; set; }

    public HeaderData Block1H1 { get; set; }
    public List<PhysicsBlock1Data> Block1 { get; set; }

    public HeaderData Block2H1 { get; set; }
    public List<PhysicsBlock2Data> Block2 { get; set; }

    public List<List<uint>> Collisions { get; set; }

    public List<int> BlockEndIndices { get; set; }


    public List<List<PhysicsType2Data>> Type2 { get; set; }
  }

  public class PhysicsBlock1Data
  {
    public PhysicsBlock1Data(int start, byte[] bin)
    {
      double[] m = new double[16];
      for (int i = 0; i < 16; i++)
      {
        m[i] = BitConverter.ToSingle(bin, start + (4 * i));
      }
      Matrix = new Matrix3D(m[0], m[1], m[2], m[3], m[4], m[5], m[6], m[7], m[8], m[9], m[10], m[11], m[12], m[13], m[14], m[15]);

      Spring = new float[4];
      for (int i = 0; i < 4; i++)
      {
        Spring[i] = BitConverter.ToSingle(bin, start + 0x40 + (4 * i));
      }
      Elastic = new float[4];
      for (int i = 0; i < 4; i++)
      {
        Elastic[i] = BitConverter.ToSingle(bin, start + 0x50 + (4 * i));
      }
      Friction = new float[4];
      for (int i = 0; i < 4; i++)
      {
        Friction[i] = BitConverter.ToSingle(bin, start + 0x60 + (4 * i));
      }
      Unknown = new float[4];
      for (int i = 0; i < 4; i++)
      {
        Unknown[i] = BitConverter.ToSingle(bin, start + 0x70 + (4 * i));
      }
      Bending = new float[2];
      for (int i = 0; i < 2; i++)
      {
        Bending[i] = BitConverter.ToSingle(bin, start + 0x80 + (4 * i));
      }
      NodeIndex = BitConverter.ToInt32(bin, start + 0x88);
      IndexInGroup = BitConverter.ToInt16(bin, start + 0x8C);
      Parent = BitConverter.ToInt16(bin, start + 0x8E);
      LocalIndex = BitConverter.ToInt32(bin, start + 0x90);
    }

    public Matrix3D Matrix { get; set; }
    public float[] Spring { get; set; }
    public float[] Elastic { get; set; }
    public float[] Friction { get; set; }
    public float[] Unknown { get; set; }
    public float[] Bending { get; set; }
    public int NodeIndex { get; set; }
    public short IndexInGroup { get; set; }
    public short Parent { get; set; }
    public int LocalIndex { get; set; }
  }

  public class PhysicsBlock2Data
  {
    public PhysicsBlock2Data(int start, byte[] bin)
    {
      Distance = new float[4];
      for (int i = 0; i < Distance.Length; i++)
      {
        Distance[i] = BitConverter.ToSingle(bin, start + (4 * i));
      }
      Fs = new float[16];
      for (int i = 0; i < Fs.Length; i++)
      {
        Fs[i] = BitConverter.ToSingle(bin, start + 0x10 + (4 * i));
      }
      Index1 = BitConverter.ToInt16(bin, start + 0x50);
      Index2 = BitConverter.ToInt16(bin, start + 0x52);
      Index3 = BitConverter.ToInt16(bin, start + 0x54);
      Index4 = BitConverter.ToInt16(bin, start + 0x56);
    }

    
    public float[] Distance { get; set; }
    public float[] Fs { get; set; }
    public short Index1 { get; set; }
    public short Index2 { get; set; }
    public short Index3 { get; set; }
    public short Index4 { get; set; }
  }

  public class PhysicsType2Data
  {
    public PhysicsType2Data(int start, byte[] bin)
    {
      Fs = new float[12];
      for (int i = 0; i < Fs.Length; i++)
      {
        Fs[i] = BitConverter.ToSingle(bin, start + (4 * i));
      }
      NodeIndex = BitConverter.ToInt32(bin, start + 0x30);
      LocalIndex = BitConverter.ToInt32(bin, start + 0x34);
    }

    public int NodeIndex { get; set; }
    public int LocalIndex { get; set; }
    public float[] Fs { get; set; }
  }

  public class Collision
  {
    public Collision()
    {
      Rotation = new float[4];
      Size = new float[4];
      Position = new float[4];
    }
    public Collision(int startSub, int start, byte[] bin)
    {
      Rotation = new float[4];
      Size = new float[4];
      Position = new float[4];

      Type = BitConverter.ToInt32(bin, startSub);
      Node = BitConverter.ToInt32(bin, startSub + 4);
      Code = BitConverter.ToUInt32(bin, startSub + 8);

      for (int i = 0; i < 4; i++)
        Rotation[i] = BitConverter.ToSingle(bin, start + (4 * i));

      for (int i = 0; i < 4; i++)
        Size[i] = BitConverter.ToSingle(bin, start + (4 * (i + 4)));

      for (int i = 0; i < 4; i++)
        Position[i] = BitConverter.ToSingle(bin, start + (4 * (i + 8)));

      Node2 = BitConverter.ToInt32(bin, start + 0x30);
      Code2 = BitConverter.ToUInt32(bin, start + 0x34);
    }

    public int Index { get; set; }
    public int Type { get; set; }
    public int Node { get; set; }
    public uint Code { get; set; }

    public float[] Rotation { get; private set; }
    public float[] Size { get; private set; }
    public float[] Position { get; private set; }
    public int Node2 { get; set; }
    public uint Code2 { get; set; }
  }
}
