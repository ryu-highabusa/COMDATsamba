﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Media.Media3D;

namespace TMC_Tool
{
  public partial class MainWindow : Window
  {
    private List<ExBone> PrepareExBones()
    {
      List<ExBone> exBones = new List<ExBone>();
      foreach (var bone in vm.Bones)
      {
        if (
          (bone.IsDeleted && !bone.InPhysics && vm.IsEnabledBone) ||
          (bone.IsDeleted && bone.InPhysics && vm.IsEnabledPhysics) ||
          (bone.IsAdded && bone.InPhysics && !vm.IsEnabledPhysics)
        )
          continue;

        var data = tmcData;
        if (bone.IsAdded && bone.InPhysics) data = boneData;

        var newExBone = new ExBone();
        newExBone.BoneData = bone;

        if (vm.IsEnabledBone || bone.IsAdded)
          newExBone.Name = bone.Name;
        else
          newExBone.Name = data.Node[bone.OriginalIndex].Name;

        int parent;

        if (vm.Parentage && vm.IsEnabledBone)
        {
          parent = bone.Parent - 1;
          if (parent > -1)
          {
            newExBone.ParentName = vm.ParentBones[bone.Parent];
          }
        }
        else
        {
          parent = data.Hie[bone.OriginalIndex].Parent;
          if (parent > -1)
          {
            newExBone.ParentName = data.Node[parent].Name;
          }
        }

        if (parent == -1) newExBone.ParentName = "";

        exBones.Add(newExBone);
      }

      // 並び替え
      exBones = SortBones(exBones);

      for (int i = 0; i < exBones.Count; i++)
      {
        if (exBones[i].ParentName == "") continue;

        int idx = Array.FindIndex(exBones.ToArray(), elem => elem.Name == exBones[i].ParentName);
        exBones[i].Parent = idx;
        exBones[idx].Children.Add(i);
      }

      foreach (var exBone in exBones)
      {
        if (exBone.ParentName == "")
        {
          SetExBones(exBones, exBone, null, 0, false);
        }
      }

      return exBones;
    }

    private List<ExBone> SortBones(List<ExBone> bones)
    {
      var instanceNodes = new List<ExBone>();
      var baseNames = new Dictionary<string, string>();
      int count = 0;

      bones = bones.OrderBy(node => node.Name.ToLower(), StringComparer.Ordinal).ToList();

      while (bones.Count > count)
      {
        int position = bones[count].Name.IndexOf("Instance");
        if (position == -1)
        {
          count++;
        }
        else
        {
          position += 8;

          while (bones[count].Name.Length > position)
          {
            int num;
            if (int.TryParse(bones[count].Name[position].ToString(), out num))
            {
              position++;
            }
            else
            {
              break;
            }
          }
          baseNames[bones[count].Name] = bones[count].Name.Substring(0, position);

          instanceNodes.Add(bones[count]);
          bones.RemoveAt(count);
        }
      }

      var instanceNodesSet = new Dictionary<string, List<ExBone>>();
      foreach (var node in instanceNodes)
      {
        string baseName = baseNames[node.Name];

        if (!instanceNodesSet.ContainsKey(baseName))
        {
          var nodes = new List<ExBone>();
          instanceNodesSet[baseName] = nodes;
        }

        instanceNodesSet[baseName].Add(node);
      }

      foreach (var pair in instanceNodesSet)
      {
        bones.AddRange(pair.Value);
      }

      return bones;
    }

    private void SetExBones(List<ExBone> exBones, ExBone exBone, ExBone parent, int level, bool changed)
    {
      var bone = exBone.BoneData;

      if (
        (
          !changed && bone.Selected && bone.Selectable && bone.Refer > 0 &&
          (
            tmcData.Hie[bone.OriginalIndex].Matrix != boneData.Hie[bone.Refer - 1].Matrix ||
            tmcData.MtxGrp[bone.OriginalIndex].Matrix != boneData.MtxGrp[bone.Refer - 1].Matrix ||
            tmcData.BnOfsMtxGrp[bone.OriginalIndex].Matrix != boneData.BnOfsMtxGrp[bone.Refer - 1].Matrix
          )
        ) ||
        bone.IsAdded
      )
      {
        changed = true;
      }

      exBone.BoneLevel = level;

      bool parentChanged = false;
      if ((vm.IsEnabledBone || bone.InPhysics) && bone.ChangedParent && vm.Parentage)
      {
        parentChanged = true;
      }

      if (bone.IsAdded && bone.InPhysics)
        SetHieMatrix(exBone, parent, true, boneData, bone.OriginalIndex, parentChanged);
      else if (vm.IsEnabledBone && bone.Selected && bone.Refer > 0 && bone.Selectable && vm.ChangeHieLay)
        SetHieMatrix(exBone, parent, changed, boneData, bone.Refer - 1, parentChanged);
      else
        SetHieMatrix(exBone, parent, changed, tmcData, bone.OriginalIndex, parentChanged);

      if (bone.IsAdded && bone.InPhysics)
        SetGlblMatrix(exBone, parent, true, boneData, bone.OriginalIndex);
      else if (vm.IsEnabledBone && bone.Selected && bone.Refer > 0 && bone.Selectable && vm.ChangeGlblMtx)
        SetGlblMatrix(exBone, parent, changed, boneData, bone.Refer - 1);
      else
        SetGlblMatrix(exBone, parent, changed, tmcData, bone.OriginalIndex);

      if (bone.IsAdded && bone.InPhysics)
        SetBnOfsMatrix(exBone, parent, true, boneData, bone.OriginalIndex);
      else if (vm.IsEnabledBone && bone.Selected && bone.Refer > 0 && bone.Selectable && vm.ChangeBnOfsMtx)
        SetBnOfsMatrix(exBone, parent, changed, boneData, bone.Refer - 1);
      else
        SetBnOfsMatrix(exBone, parent, changed, tmcData, bone.OriginalIndex);

      level++;

      foreach (var child in exBone.Children)
      {
        SetExBones(exBones, exBones[child], exBone, level, changed);
      }
    }

    private void SetHieMatrix(ExBone bone, ExBone parent, bool changed, TmcData data, int index, bool parentChanged)
    {
      Matrix3D matrixLayered;
      Matrix3D matrixHie;

      if (index == -1)
      {
        var matrix = new Matrix3D();
        matrix.SetIdentity();
        matrixHie = matrix;
        matrixLayered = parent.HieMtxLayered;
      }
      else
      {
        matrixHie = data.Hie[index].Matrix;
        matrixLayered = data.Hie[index].MatrixLayered;
      }

      if ((changed || parentChanged) && vm.IsAbsolute && vm.ChangeHieLay)
      {
        var matrix = new Matrix3D();
        if (parent == null)
          matrix.SetIdentity();
        else
          matrix.Append(parent.HieMtxLayered);
        matrix.Invert();
        bone.HieMtx = matrixLayered * matrix;
      }
      else
      {
        bone.HieMtx = matrixHie;
      }
      bone.HieMtxLayered = matrixLayered;
    }

    private void SetGlblMatrix(ExBone bone, ExBone parent, bool changed, TmcData data, int index)
    {
      if (changed && vm.IsRelative && vm.ChangeHieLay && vm.ChangeGlblMtx)
      {
        if (parent == null)
          bone.GlblMtx = bone.HieMtx;
        else
          bone.GlblMtx = bone.HieMtx * parent.GlblMtx;
      }
      else
      {
        if (index == -1)
          bone.GlblMtx = parent.GlblMtx;
        else
          bone.GlblMtx = data.MtxGrp[index].Matrix;
      }
    }

    private void SetBnOfsMatrix(ExBone bone, ExBone parent, bool changed, TmcData data, int index)
    {
      if (changed && vm.IsRelative && vm.ChangeHieLay && vm.ChangeBnOfsMtx)
      {
        var matrix = new Matrix3D();
        matrix.Append(bone.HieMtx);
        matrix.Invert();
        if (parent == null)
          bone.BnOfsMtx = matrix;
        else
          bone.BnOfsMtx = parent.BnOfsMtx * matrix;
      }
      else
      {
        if (index == -1)
          bone.BnOfsMtx = parent.BnOfsMtx;
        else
          bone.BnOfsMtx = data.BnOfsMtxGrp[index].Matrix;
      }
    }

    private List<byte> SetHieLayDataChanges(List<byte> bin, List<ExBone> bones)
    {
      List<byte> partBin = BuildHeaderBaseBin("HieLay");

      List<byte> optionBin = new List<byte>();
      optionBin.AddRange(BitConverter.GetBytes(1));
      optionBin.AddRange(new byte[0x0C]);

      int rootCount = 0;

      List<List<byte>> childBins = new List<List<byte>>();
      for (int i = 0; i < bones.Count; i++)
      {
        List<byte> newBin = new List<byte>();

        List<float> m = Matrix3DToList(bones[i].HieMtx);
        foreach (float f in m)
        {
          newBin.AddRange(BitConverter.GetBytes(f));
        }

        //0x40 Parent
        int parentIdx = Array.FindIndex(bones.ToArray(), elem => elem.Name == bones[i].ParentName);
        newBin.AddRange(BitConverter.GetBytes(parentIdx));
        if (parentIdx == -1) rootCount++;

        //0x44 ChildCount
        newBin.AddRange(BitConverter.GetBytes(bones[i].Children.Count));

        //0x48 BoneLevel
        newBin.AddRange(BitConverter.GetBytes(bones[i].BoneLevel));

        newBin.AddRange(new byte[4]);

        //0x50～ Children
        foreach (var child in bones[i].Children)
        {
          newBin.AddRange(BitConverter.GetBytes(child));
        }

        if (newBin.Count % 16 != 0) newBin.AddRange(new byte[16 - newBin.Count % 16]);

        if (bones[i].BoneLevel == 0)
        {
          optionBin.AddRange(BitConverter.GetBytes(i));
        }

        childBins.Add(newBin);
      }

      ReplaceByteList(optionBin, BitConverter.GetBytes(rootCount), 0);
      if (optionBin.Count % 16 != 0) optionBin.AddRange(new byte[16 - optionBin.Count % 16]);

      BuildBin(partBin, childBins, optionBin, false, false);

      return partBin;
    }

    private List<byte> setNodeLayDataChanges(List<byte> bin, List<ExBone> bones)
    {
      List<byte> nodeLayBin = BuildHeaderBaseBin("NodeLay");
      nodeLayBin.AddRange(new byte[0x10]);
      nodeLayBin[0x30] = 1;
      nodeLayBin[0x32] = 2;

      List<List<byte>> nodeObjBins = new List<List<byte>>();

      int count = 0;
      foreach (var bone in bones)
      {
        TmcData data = tmcData;
        if (bone.BoneData.IsAdded && bone.BoneData.InPhysics) data = boneData;

        Nodes originalNode = null;
        if (bone.BoneData.OriginalIndex != -1) originalNode = data.Node[bone.BoneData.OriginalIndex];

        List<byte> nodeObjBin = BuildHeaderBaseBin("NodeObj");
        nodeObjBin.AddRange(BitConverter.GetBytes(0));

        int master = -1;
        if (originalNode != null) master = originalNode.Master;
        if (master != -1) master = Array.FindIndex(bones.ToArray(), elem => elem.Name == data.Node[master].Name);
        nodeObjBin.AddRange(BitConverter.GetBytes(master));

        nodeObjBin.AddRange(BitConverter.GetBytes(count));
        nodeObjBin.AddRange(BitConverter.GetBytes(0));
        nodeObjBin.AddRange(Encoding.ASCII.GetBytes(bone.Name));
        nodeObjBin.AddRange(new byte[16 - (nodeObjBin.Count % 16)]);

        if (originalNode != null && originalNode.ObjIndex != -1 && !bone.BoneData.IsAdded)
        {
          ReplaceByteList(nodeObjBin, BitConverter.GetBytes(nodeObjBin.Count), 0x20);
          nodeObjBin[0x14] = 1;
          nodeObjBin[0x18] = 1;
          nodeObjBin.AddRange(BitConverter.GetBytes(nodeObjBin.Count + 0x10));
          nodeObjBin.AddRange(new byte[12]);

          nodeObjBin.AddRange(BitConverter.GetBytes(originalNode.ObjIndex));
          nodeObjBin.AddRange(BitConverter.GetBytes(originalNode.ChildCount)); // boneDataなら0

          nodeObjBin.AddRange(BitConverter.GetBytes(count));
          nodeObjBin.AddRange(BitConverter.GetBytes(0));

          List<float> m = Matrix3DToList(originalNode.Matrix);
          foreach (float f in m)
          {
            nodeObjBin.AddRange(BitConverter.GetBytes(f));
          }

          // boneDataならスキップ
          foreach (var blendIdx in data.BlendIdxGrp[originalNode.Index].Idx)
          {
            int idx = Array.FindIndex(bones.ToArray(), elem => elem.Name == data.Node[blendIdx].Name);
            if (idx == -1)
            {
              Console.WriteLine("Missing BlendIdx : " + data.Node[blendIdx].Name);
            }
            nodeObjBin.AddRange(BitConverter.GetBytes(idx));
          }

          if (nodeObjBin.Count % 16 > 0) nodeObjBin.AddRange(new byte[16 - (nodeObjBin.Count % 16)]);
        }

        ReplaceByteList(nodeObjBin, BitConverter.GetBytes(nodeObjBin.Count), 0x10);

        nodeObjBins.Add(nodeObjBin);

        count++;
      }

      BuildBin(nodeLayBin, nodeObjBins, null, false, false);

      return nodeLayBin;
    }

    private List<byte> SetMtxDataChanges(List<byte> bin, List<ExBone> bones, string type)
    {
      List<byte> partBin = BuildHeaderBaseBin(type);

      List<List<byte>> childBins = new List<List<byte>>();
      foreach (var bone in bones)
      {
        List<byte> newBin = new List<byte>();

        Matrix3D matrix = bone.GlblMtx;
        if (type == "BnOfsMtx") matrix = bone.BnOfsMtx;

        List<float> m = Matrix3DToList(matrix);
        foreach (float f in m)
        {
          newBin.AddRange(BitConverter.GetBytes(f));
        }

        childBins.Add(newBin);
      }
      BuildBin(partBin, childBins, null, false, false);

      return partBin;
    }

    private List<byte> SetCpfDataChanges(List<byte> bin, List<ExBone> bones)
    {
      if (bin.Count == 0) return bin;


      List<byte> partBin = BuildHeaderBaseBin("cpf");
      List<List<byte>> childBins = new List<List<byte>>();

      var h = new HeaderData(0, bin.ToArray());

      // nodecp
      List<byte> nodecpBin = BuildHeaderBaseBin("nodecp");
      List<List<byte>> cpBins = new List<List<byte>>();

      foreach (var bone in bones)
      {
        List<byte> cpBin = new List<byte>();

        var data = tmcData;
        var mainBin = bn;
        if (bone.BoneData.IsAdded && bone.BoneData.InPhysics)
        {
          data = boneData;
          mainBin = boneBn;
        }

        if (data.NodeCp == null) goto AddBin;


        List<List<byte>> paramBins = new List<List<byte>>();
        List<byte> paramOptionBin = new List<byte>();


        if (vm.IsEnabledNodecp)
        {
          int index = Array.FindIndex(vm.Nodecps.ToArray(), elem => elem.Node == bone.Name);

          if (index == -1) goto AddBin;


          var nodecp = vm.Nodecps[index];

          if (nodecp.Customps.Count == 0) goto AddBin;


          for (int i = 0; i < nodecp.Customps.Count; i++)
          {
            List<byte> paramBin = new List<byte>();

            paramOptionBin.AddRange(BitConverter.GetBytes(nodecp.Customps[i].Code));
            paramOptionBin.AddRange(BitConverter.GetBytes(i));

            paramBin.AddRange(BitConverter.GetBytes(nodecp.Customps[i].Type));

            if (nodecp.Customps[i].Code == 0x0EEC72A1 || nodecp.Customps[i].Code == 0xC32CEE4A)
            {
              int val;
              if (int.TryParse(nodecp.Customps[i].Value, out val))
              {
                int nodeIndex = Array.FindIndex(bones.ToArray(), elem => elem.Name == vm.Nodecps[val].Node);
                paramBin.AddRange(BitConverter.GetBytes(nodeIndex));
              }
              else
              {
                continue;
              }
            }
            else if (nodecp.Customps[i].Type == 3)
            {
              paramBin.AddRange(Encoding.ASCII.GetBytes(nodecp.Customps[i].Value));
            }
            else if (nodecp.Customps[i].Type == 2)
            {
              float val;
              if (float.TryParse(nodecp.Customps[i].Value, out val))
              {
                paramBin.AddRange(BitConverter.GetBytes(val));
              }
              else
              {
                continue;
              }
            }
            else
            {
              int val;
              if (int.TryParse(nodecp.Customps[i].Value, out val))
              {
                paramBin.AddRange(BitConverter.GetBytes(val));
              }
              else
              {
                continue;
              }
            }

            paramBin.AddRange(new byte[16 - paramBin.Count % 16]);

            paramBins.Add(paramBin);
          }
        }
        else
        {
          int index = Array.FindIndex(data.NodeCp.ToArray(), elem => elem.Index == bone.BoneData.OriginalIndex);

          if (index == -1) goto AddBin;


          var nodecp = data.NodeCp[index];

          for (int i = 0; i < nodecp.Cp.Count; i++)
          {
            List<byte> paramBin = new List<byte>();

            paramOptionBin.AddRange(BitConverter.GetBytes(nodecp.Cp[i].Data1));
            paramOptionBin.AddRange(BitConverter.GetBytes(i));

            paramBin.AddRange(BitConverter.GetBytes(nodecp.Cp[i].Data2));

            if (nodecp.Cp[i].Data1 == 0x0EEC72A1 || nodecp.Cp[i].Data1 == 0xC32CEE4A)
            {
              int nodeIndex = Array.FindIndex(bones.ToArray(), elem => elem.Name == data.Node[nodecp.Cp[i].Param].Name);
              paramBin.AddRange(BitConverter.GetBytes(nodeIndex));
            }
            else if (nodecp.Cp[i].Data2 == 3)
            {
              paramBin.AddRange(Encoding.ASCII.GetBytes(nodecp.Cp[i].Param));
            }
            else
            {
              paramBin.AddRange(BitConverter.GetBytes(nodecp.Cp[i].Param));
            }

            paramBin.AddRange(new byte[16 - paramBin.Count % 16]);

            paramBins.Add(paramBin);
          }
        }


        if (paramOptionBin.Count % 16 > 0) paramOptionBin.AddRange(new byte[16 - paramOptionBin.Count % 16]);

        cpBin.AddRange(BuildHeaderBaseBin("customp"));
        BuildBin(cpBin, paramBins, paramOptionBin, false, false);


        AddBin:
        cpBins.Add(cpBin);
      }

      BuildBin(nodecpBin, cpBins, null, false, true);

      childBins.Add(nodecpBin);


      // matecp
      List<byte> matecpBin = new List<byte>();
      if (h.Offsets[1] != 0)
      {
        matecpBin.AddRange(bin.Skip(h.Offsets[1]).Take(h.Size - h.Offsets[1]));
      }
      childBins.Add(matecpBin);


      BuildBin(partBin, childBins, null, false, true);

      return partBin;
    }

    private List<byte> SetAcsclsDataChanges(List<byte> bin, List<ExBone> bones)
    {
      List<List<byte>> childBins = new List<List<byte>>();
      HeaderData h = null;
      if (bin.Count != 0)
      {
        h = new HeaderData(0, bin.ToArray());
        int lastOffset = h.Size;
        for (int i = h.Count1 - 1; i >= 0; i--)
        {
          List<byte> childBin = new List<byte>();
          if (h.Offsets[i] != 0)
          {
            childBin.AddRange(bin.Skip(h.Offsets[i]).Take(lastOffset - h.Offsets[i]));
            lastOffset = h.Offsets[i];
          }
          childBins.Insert(0, childBin);
        }
      }
      else
      {
        for (int i = 0; i < 4; i++)
        {
          List<byte> childBin = new List<byte>();
          childBins.Add(childBin);
        }
      }

      if (vm.IsEnabledPhysics || vm.IsChangedBone)
      {
        // Indices
        List<List<string>> IndicesNames = new List<List<string>>();
        for (int i = 2; i < 4; i++)
        {
          var resTuple = BuildIndicesBin(bones, i);
          childBins[i] = resTuple.Item1;
          IndicesNames.Add(resTuple.Item2);
        }

        // シミュレーション 初期位置・パラメータ・ノードインデックス変更
        childBins[0] = BuildPhysicsBin(h, childBins[0], bones, IndicesNames);
      }

      // コリジョン変更
      if ((vm.IsEnabledCollision || vm.IsChangedBone) && vm.Collisions.Count != 0)
      {
        childBins[1] = BuildCollisionBin(bones);
      }


      List<byte> partBin = new List<byte>();

      partBin = BuildHeaderBaseBin("ACSCLS");
      partBin.AddRange(new byte[0x10]);
      partBin[0x30] = 0x0C;

      BuildBin(partBin, childBins, null, false, true);

      // Headerの全体サイズを変更
      ReplaceByteList(partBin, BitConverter.GetBytes(partBin.Count), 0x10);

      return partBin;
    }

    private List<byte> BuildPhysicsBin(HeaderData h, List<byte> bin, List<ExBone> bones, List<List<string>> IndicesNames)
    {
      List<List<byte>> physicsBins = new List<List<byte>>();
      HeaderData childBinH = null;
      if (h.Offsets[0] != 0)
      {
        childBinH = new HeaderData(0, bin.ToArray());
      }

      List<MainViewModel.PhysicsData> physicsList = new List<MainViewModel.PhysicsData>();

      foreach (var physics in vm.Physics)
      {
        if (physics.IsIncluded)
          physicsList.Add(physics);
      }


      List<byte> childBin = BuildHeaderBaseBin("");

      List<byte> childHeaderBin = BuildHeaderBaseBin("");
      int inUseCount = 0;
      for (int i = 0; i < physicsList.Count; i++)
      {
        if (physicsList[i].InUse)
        {
          childHeaderBin.AddRange(BitConverter.GetBytes(i));
          inUseCount++;
        }
      }
      childHeaderBin.InsertRange(0x30, BitConverter.GetBytes(inUseCount));

      if (childHeaderBin.Count % 16 > 0) childHeaderBin.AddRange(new byte[16 - (childHeaderBin.Count % 16)]);
      ReplaceByteList(childHeaderBin, BitConverter.GetBytes(childHeaderBin.Count), 0x20);


      physicsList = physicsList.OrderBy(elem => elem.Root.ToLower(), StringComparer.Ordinal).ToList();

      foreach (var physics in physicsList)
      {
        List<byte> physicsBin = new List<byte>();
        HeaderData physicsH;

        var data = tmcData;
        if (physics.InBoneData)
        {
          data = boneData;
          var acsclsH = new HeaderData(data.H.Offsets[16], boneBn.ToArray());
          var acsclsChildBinH = new HeaderData(acsclsH.Start + acsclsH.Offsets[0], boneBn.ToArray());
          physicsH = new HeaderData(acsclsChildBinH.Start + acsclsChildBinH.Offsets[physics.Index], boneBn.ToArray());
          physicsBin.AddRange(boneBn.Skip(physicsH.Start).Take(physicsH.Size));
        }
        else
        {
          physicsH = new HeaderData(childBinH.Offsets[physics.Index], bin.ToArray());
          physicsBin.AddRange(bin.Skip(physicsH.Start).Take(physicsH.Size));
        }


        List<byte> physicsHeaderBin = new List<byte>();
        physicsHeaderBin.AddRange(physicsBin.Skip(physicsH.HSize).Take(physicsH.Offset1 - physicsH.HSize));

        List<List<byte>> blockBins = new List<List<byte>>();
        for (int i = 0; i < physicsH.Count1; i++)
        {
          List<byte> blockBin = new List<byte>();
          if (physicsH.Offsets[i] != 0)
          {
            HeaderData blockH = new HeaderData(physicsH.Offsets[i], physicsBin.ToArray());
            blockBin.AddRange(physicsBin.Skip(blockH.Start).Take(blockH.Size));
          }
          blockBins.Add(blockBin);
        }


        PhysicsData physicsData = data.Physics[physics.Index];

        if (physics.IsEdited == true)
        {
          ChangePhysicsParameter(blockBins, physicsHeaderBin, physicsData, physics);
        }

        if (physics.Recalc == true)
        {
          RecalcPhysicsParameter(blockBins, bones, physicsData);
        }


        int node = Array.FindIndex(bones.ToArray(), elem => elem.Name == physics.Root);
        if (node == -1)
        {
          Console.WriteLine("Missing Root Node : " + physics.Root);
        }

        int nodeInIndices = IndicesNames[0].IndexOf(physics.BaseNode);
        if (nodeInIndices == -1)
        {
          Console.WriteLine("Missing nodeInIndices : " + physics.Root);
        }


        if (physics.Type != "Type2")
        {
          ReplaceByteList(physicsHeaderBin, BitConverter.GetBytes(node), 0x60);
          ReplaceByteList(physicsHeaderBin, BitConverter.GetBytes(nodeInIndices), 0x68);

          for (int i = 0; i < physicsData.Block1.Count; i++)
          {
            int offset = physicsData.Block1H1.Offset1 + (0xA0 * i);

            int nodeIndex = Array.FindIndex(bones.ToArray(), elem => elem.Name == physics.Bones[i].Name);
            int localIndex = IndicesNames[1].IndexOf(physics.Bones[i].Name);

            ReplaceByteList(blockBins[0], BitConverter.GetBytes(nodeIndex), offset + 0x88);
            ReplaceByteList(blockBins[0], BitConverter.GetBytes(localIndex), offset + 0x90);
          }

          int blockEndIndex = 5;
          if (physicsData.Type != 0)
          {
            blockEndIndex = 4;
          }
          for (int i = 0; i < physicsData.BlockEndIndices.Count; i++)
          {
            string nodeName = data.Node[physicsData.BlockEndIndices[i]].Name;
            int nodeIndex = Array.FindIndex(bones.ToArray(), elem => elem.Name == nodeName);

            ReplaceByteList(blockBins[blockEndIndex], BitConverter.GetBytes(nodeIndex), 0x80 + (4 * i));
          }
        }
        else
        {
          ReplaceByteList(physicsHeaderBin, BitConverter.GetBytes(node), 0x70);
          ReplaceByteList(physicsHeaderBin, BitConverter.GetBytes(nodeInIndices), 0x74);

          for (int i = 0; i < physicsH.Count1; i++)
          {
            for (int j = 0; j < physicsData.Type2[i].Count; j++)
            {
              int nodeIndex = Array.FindIndex(bones.ToArray(), elem => elem.Name == physics.Bones[j].Name);
              int localIndex = IndicesNames[1].IndexOf(physics.Bones[j].Name);

              ReplaceByteList(blockBins[i], BitConverter.GetBytes(nodeIndex), 0x30 + 0x40 * j + 0x30);
              ReplaceByteList(blockBins[i], BitConverter.GetBytes(localIndex), 0x30 + 0x40 * j + 0x34);
            }
          }
        }

        List<byte> newBin = BuildHeaderBaseBin("");
        newBin.AddRange(physicsHeaderBin);

        BuildBin(newBin, blockBins, null, false, true);

        physicsBins.Add(newBin);

        // childHeaderBin
        childHeaderBin.AddRange(BitConverter.GetBytes(physicsData.Type));
        childHeaderBin.AddRange(BitConverter.GetBytes(node));
        childHeaderBin.AddRange(BitConverter.GetBytes(physicsData.Param));
      }

      // childHeaderBin
      if (childHeaderBin.Count % 16 > 0) childHeaderBin.AddRange(new byte[16 - (childHeaderBin.Count % 16)]);
      ReplaceByteList(childHeaderBin, BitConverter.GetBytes(childHeaderBin.Count), 0x10);
      ReplaceByteList(childHeaderBin, BitConverter.GetBytes(physicsList.Count), 0x14);
      ReplaceByteList(childHeaderBin, BitConverter.GetBytes(physicsList.Count), 0x18);

      childBin.AddRange(childHeaderBin);


      BuildBin(childBin, physicsBins, null, false, false);

      return childBin;
    }

    private void ChangePhysicsParameter(List<List<byte>> blockBins, List<byte> physicsHeaderBin, PhysicsData physicsData, MainViewModel.PhysicsData physics)
    {
      for (int i = 0; i < physicsData.Block1.Count; i++)
      {
        int offset = physicsData.Block1H1.Offset1 + (0xA0 * i);

        float spring = physics.Bones[i].Spring;
        float elastic = physics.Bones[i].Elastic;
        float friction = physics.Bones[i].Friction;
        float unknown = physics.Bones[i].Unknown;
        float bending = physics.Bones[i].Bending;

        for (int j = 0; j < 3; j++)
          ReplaceByteList(blockBins[0], BitConverter.GetBytes(spring), offset + 0x40 + (4 * j));

        for (int j = 0; j < 3; j++)
          ReplaceByteList(blockBins[0], BitConverter.GetBytes(elastic), offset + 0x50 + (4 * j));

        for (int j = 0; j < 3; j++)
          ReplaceByteList(blockBins[0], BitConverter.GetBytes(friction), offset + 0x60 + (4 * j));

        for (int j = 0; j < 3; j++)
          ReplaceByteList(blockBins[0], BitConverter.GetBytes(unknown), offset + 0x70 + (4 * j));

        for (int j = 0; j < 2; j++)
          ReplaceByteList(blockBins[0], BitConverter.GetBytes(bending), offset + 0x80 + (4 * j));
      }

      for (int i = 1; i < physics.Params.Count; i++)
      {
        int offset = 0x10 * i;

        for (int j = 0; j < 4; j++)
        {
          ReplaceByteList(physicsHeaderBin, BitConverter.GetBytes(physics.Params[i].Value), offset + (4 * j));
        }
      }


      if (physics.Collisions.Count == 0 || physics.CollisionType == -1) return;


      int index = 2;

      if (physics.TypeID % 2 == 0) index = 3;

      // CollisionTypeの0と1の両方のバイナリをクリア
      if (blockBins[index].Count > 0) blockBins[index].Clear();
      if (blockBins[index + 1].Count > 0) blockBins[index + 1].Clear();

      index += physics.CollisionType;
      blockBins[index] = BuildPhysicsCollisionBin(physics);
    }

    private List<byte> BuildPhysicsCollisionBin(MainViewModel.PhysicsData physics)
    {
      List<byte> blockBin = BuildHeaderBaseBin("");
      ReplaceByteList(blockBin, BitConverter.GetBytes(physics.Collisions.Count), 0x14);
      ReplaceByteList(blockBin, BitConverter.GetBytes(physics.Collisions.Count), 0x18);
      ReplaceByteList(blockBin, BitConverter.GetBytes(blockBin.Count), 0x20);

      foreach (var collision in physics.Collisions)
      {
        blockBin.AddRange(BitConverter.GetBytes(collision.Code));
      }

      if (blockBin.Count % 16 > 0) blockBin.AddRange(new byte[16 - (blockBin.Count % 16)]);

      ReplaceByteList(blockBin, BitConverter.GetBytes(blockBin.Count), 0x10);

      return blockBin;
    }

    private void RecalcPhysicsParameter(List<List<byte>> blockBins, List<ExBone> bones, PhysicsData physicsData)
    {
      // Block1
      for (int i = 0; i < bones.Count; i++)
      {
        int idx = Array.FindIndex(physicsData.Block1.ToArray(), elem => elem.NodeIndex == i);
        if (idx == -1) continue;

        int offset = physicsData.Block1H1.Offset1 + (0xA0 * idx);

        int parent = physicsData.Block1[physicsData.Block1[idx].Parent].NodeIndex;
        var matrix = new Matrix3D();
        matrix.Append(bones[parent].HieMtxLayered);
        matrix.Invert();

        List<float> m = Matrix3DToList(bones[i].HieMtxLayered * matrix);
        int count = 0;
        foreach (float f in m)
        {
          ReplaceByteList(blockBins[0], BitConverter.GetBytes(f), offset + (4 * count));
          count++;
        }
      }

      // Block2
      for (int i = 0; i < physicsData.Block2.Count; i++)
      {
        var mat1 = bones[physicsData.Block1[physicsData.Block2[i].Index1].NodeIndex].HieMtxLayered;
        var mat2 = bones[physicsData.Block1[physicsData.Block2[i].Index2].NodeIndex].HieMtxLayered;

        Vector3D vector = new Vector3D(mat1.OffsetX - mat2.OffsetX, mat1.OffsetY - mat2.OffsetY, mat1.OffsetZ - mat2.OffsetZ);

        int offset = physicsData.Block2H1.Offset1 + (0x60 * i);

        for (int j = 0; j < 3; j++)
        {
          ReplaceByteList(blockBins[1], BitConverter.GetBytes((float)vector.Length), offset + (4 * j));
        }
      }
    }


    private List<byte> BuildCollisionBin(List<ExBone> bones)
    {
      List<Collision> collisions = new List<Collision>();
      Dictionary<int, int> newIndices = new Dictionary<int, int>();
      foreach (var collision in vm.Collisions)
      {
        if (collision.Data == txt["Delete"] && vm.IsEnabledCollision)
        {
          continue;
        }

        int idx = Array.FindIndex(bones.ToArray(), node => node.Name == collision.Name);
        if (idx != -1)
        {
          if (!vm.IsEnabledCollision)
          {
            if (collision.TmcIndex != -1)
            {
              var newCollision = CopyCollisionData(tmcData.Collisions[collision.TmcIndex]);
              collisions.Add(newCollision);
              newIndices[tmcData.Collisions[collision.TmcIndex].Node] = idx;
            }
          }
          else if (collision.Data == txt["TmcData"])
          {
            var newCollision = CopyCollisionData(tmcData.Collisions[collision.TmcIndex]);

            newCollision.Code = collision.Code;
            newCollision.Code2 = collision.Code;

            collisions.Add(newCollision);
            newIndices[tmcData.Collisions[collision.TmcIndex].Node] = idx;
          }
          else if (collision.Data == txt["BoneData"])
          {
            var newCollision = CopyCollisionData(boneData.Collisions[collision.BoneIndex]);

            newCollision.Code = collision.Code;
            newCollision.Code2 = collision.Code;

            collisions.Add(newCollision);
            newIndices[boneData.Collisions[collision.BoneIndex].Node] = idx;
          }
          else if (collision.Data == txt["CustomData"])
          {
            Collision curCollision;
            if (collision.BaseData == txt["TmcData"])
              curCollision = tmcData.Collisions[collision.TmcIndex];
            else
              curCollision = boneData.Collisions[collision.BoneIndex];

            var newCollision = CopyCollisionData(curCollision);

            for (int i = 0; i < 3; i++)
              newCollision.Rotation[i] = (float)((float)collision.Rotation[i] / 180 * Math.PI);

            for (int i = 0; i < 3; i++)
              newCollision.Size[i] = (float)collision.Size[i];

            for (int i = 0; i < 3; i++)
              newCollision.Position[i] = (float)collision.Position[i];

            newCollision.Code = collision.Code;
            newCollision.Code2 = collision.Code;

            collisions.Add(newCollision);
            newIndices[curCollision.Node] = idx;
          }
        }
      }

      collisions = collisions.OrderBy(elem => elem.Node).ThenBy(elem => elem.Code).ToList();

      List<byte> collisionBin = new List<byte>();
      if (collisions.Count > 0)
      {
        collisionBin = BuildHeaderBaseBin("");
        ReplaceByteList(collisionBin, BitConverter.GetBytes(collisions.Count), 0x14);
        ReplaceByteList(collisionBin, BitConverter.GetBytes(collisions.Count), 0x18);

        List<byte> headerOptBin = BuildHeaderBaseBin("");
        headerOptBin[0x20] = 0x30;
        ReplaceByteList(headerOptBin, BitConverter.GetBytes(collisions.Count), 0x14);
        ReplaceByteList(headerOptBin, BitConverter.GetBytes(collisions.Count), 0x18);

        List<List<byte>> dataBins = new List<List<byte>>();

        foreach (var collision in collisions)
        {
          headerOptBin.AddRange(BitConverter.GetBytes(collision.Type));
          headerOptBin.AddRange(BitConverter.GetBytes(newIndices[collision.Node]));
          headerOptBin.AddRange(BitConverter.GetBytes(collision.Code));

          List<byte> dataBin = new List<byte>();

          foreach (var f in collision.Rotation)
            dataBin.AddRange(BitConverter.GetBytes(f));

          foreach (var f in collision.Size)
            dataBin.AddRange(BitConverter.GetBytes(f));

          foreach (var f in collision.Position)
            dataBin.AddRange(BitConverter.GetBytes(f));

          dataBin.AddRange(BitConverter.GetBytes(newIndices[collision.Node]));
          dataBin.AddRange(BitConverter.GetBytes(collision.Code2));
          if (dataBin.Count % 16 != 0) dataBin.AddRange(new byte[16 - dataBin.Count % 16]);

          dataBins.Add(dataBin);
        }
        if (headerOptBin.Count % 16 != 0) headerOptBin.AddRange(new byte[16 - headerOptBin.Count % 16]);
        ReplaceByteList(headerOptBin, BitConverter.GetBytes(headerOptBin.Count), 0x10);
        collisionBin.AddRange(headerOptBin);

        BuildBin(collisionBin, dataBins, null, false, false);
      }

      return collisionBin;
    }

    private Collision CopyCollisionData(Collision collision)
    {
      Collision newCollision = new Collision();

      newCollision.Type = collision.Type;
      newCollision.Node = collision.Node;
      newCollision.Code = collision.Code;
      newCollision.Node2 = collision.Node2;
      newCollision.Code2 = collision.Code2;

      for (int i = 0; i < 4; i++)
        newCollision.Rotation[i] = collision.Rotation[i];

      for (int i = 0; i < 4; i++)
        newCollision.Size[i] = collision.Size[i];

      for (int i = 0; i < 4; i++)
        newCollision.Position[i] = collision.Position[i];

      return newCollision;
    }


    private Tuple<List<byte>, List<string>> BuildIndicesBin(List<ExBone> bones, int partIndex)
    {
      List<int> indices = new List<int>();
      List<string> names = new List<string>();

      for (int i = 0; i < bones.Count; i++)
      {
        var data = tmcData;
        if (bones[i].BoneData.IsAdded && bones[i].BoneData.InPhysics) data = boneData;

        if (data.AcsclsIndices[partIndex - 2].Contains(bones[i].BoneData.OriginalIndex))
        {
          indices.Add(i);
          names.Add(bones[i].Name);
        }
      }

      List<byte> childBin = BuildHeaderBaseBin("");

      ReplaceByteList(childBin, BitConverter.GetBytes(indices.Count), 0x14);
      ReplaceByteList(childBin, BitConverter.GetBytes(indices.Count), 0x18);
      ReplaceByteList(childBin, BitConverter.GetBytes(0x30), 0x20);

      foreach (var index in indices)
      {
        childBin.AddRange(BitConverter.GetBytes(index));
      }

      if (childBin.Count % 16 > 0) childBin.AddRange(new byte[16 - (childBin.Count % 16)]);

      ReplaceByteList(childBin, BitConverter.GetBytes(childBin.Count), 0x10);

      return Tuple.Create(childBin, names);
    }
  }
}
