﻿using System;

namespace Common
{
  public class Command
  {
    public string Name;

    Action doAction;
    Action undoAction;
    Action redoAction;
    Action commonDoAction;

    public Command(string name, Action doAction, Action undoAction, Action commonDoAction)
    {
      this.Name = name;
      this.doAction = doAction;
      this.undoAction = undoAction;
      this.redoAction = doAction;
      this.commonDoAction = commonDoAction;
    }

    public Command(string name, Action doAction, Action redoAction, Action undoAction, Action commonDoAction)
    {
      this.Name = name;
      this.doAction = doAction;
      this.undoAction = undoAction;
      this.redoAction = redoAction;
      this.commonDoAction = commonDoAction;
    }

    public void Do()
    {
      doAction();
      commonDoAction();
    }
    public void Undo()
    {
      undoAction();
      commonDoAction();
    }
    public void Redo()
    {
      redoAction();
      commonDoAction();
    }
  }
}
