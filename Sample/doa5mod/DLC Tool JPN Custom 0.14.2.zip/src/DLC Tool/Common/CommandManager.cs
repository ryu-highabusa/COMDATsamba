﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reflection;

namespace Common
{
  public delegate void ChangedEventHandler(object sender);

  public class CommandManager
  {
    public CommandManager()
    {
      this.History = new ObservableCollection<string>();
    }

    public short MaxUndoCount { get; set; }
    private short _undoCount;
    public short UndoCount
    {
      get { return _undoCount; }
      set
      {
        _undoCount = value;
        OnChange(this);
      }
    }

    public bool UpdateUI = true;


    private bool doing = false;

    List<Command> undoList = new List<Command>();

    public ObservableCollection<string> History { get; set; }

    public event ChangedEventHandler Changed;


    public void Clear()
    {
      undoList.Clear();
      History.Clear();
      UndoCount = 0;
      History.Add(DLC_Tool.MainWindow.lang.HistoryStart);
    }

    public void Do(Command command)
    {
      command.Do();
      undoList.Insert(0, command);

      if (UndoCount > 0)
      {
        undoList.RemoveRange(1, UndoCount);
      }
      else if (undoList.Count > MaxUndoCount)
      {
        undoList.RemoveAt(undoList.Count - 1);
      }

      BuildHistory();
      UndoCount = 0;
    }

    public void Undo()
    {
      if (UndoCount >= MaxUndoCount || undoList.Count <= UndoCount)
        return;

      doing = true;
      undoList[UndoCount].Undo();
      UndoCount++;
      doing = false;
    }

    public void Redo()
    {
      if (UndoCount <= 0)
        return;

      doing = true;
      UndoCount--;
      undoList[UndoCount].Redo();
      doing = false;
    }

    public bool CanUndo()
    {
      return undoList.Count > 0 && UndoCount < undoList.Count && !doing;
    }

    public bool CanRedo()
    {
      return UndoCount > 0 && !doing;
    }

    public void BuildHistory()
    {
      if (History.Count > 0) History.Clear();

      Type t = typeof(Lang.Sentence);

      foreach (var command in undoList)
      {
        PropertyInfo pi = t.GetProperty(command.Name);

        if (pi == null)
        {
          History.Add(command.Name);
        }
        else
        {
          string name = (string)pi.GetValue(DLC_Tool.MainWindow.lang, null);
          History.Add(name);
        }
      }
      History.Add(DLC_Tool.MainWindow.lang.HistoryStart);
    }

    public void HistoryChange(int count)
    {
      if (count == -1) return;

      UpdateUI = false;

      if (count > UndoCount)
      {
        // Undo
        for (int i = UndoCount; i < count; i++)
        {
          if (i == count - 1) UpdateUI = true;
          undoList[i].Undo();
        }
      }
      else if (count < UndoCount)
      {
        for (int i = UndoCount - 1; i >= count; i--)
        {
          if (i == count) UpdateUI = true;
          undoList[i].Redo();
        }
      }

      UndoCount = (short)count;
    }






    private void OnChange(object sender)
    {
      if (Changed != null)
      {
        Changed(sender);
      }
    }
  }
}
