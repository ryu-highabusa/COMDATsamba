﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Message
{
  /// <summary>
  /// MessageWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class MessageWindow : Window
  {
    private static Lang.Sentence lang = null;

    private static Result dialogResult;

    public MessageWindow()
    {
      InitializeComponent();

      this.MouseLeftButtonDown += (sender, e) => this.DragMove();
      this.ShowInTaskbar = false;
    }

    public static void SetLang(Lang.Sentence newLang)
    {
      lang = newLang;
    }

    // Window Owner, string Message, string Title, string OkText, string CancelText, string OtherText, string Other2Text 
    public static Result Show(Window Owner, params string[] args)
    {
      MessageWindow dlg = new MessageWindow();
      dlg.WindowBuild(args);
      dlg.Owner = Owner;
      Owner.IsEnabled = false;
      dlg.ShowDialog();
      Owner.IsEnabled = true;
      Owner.Activate();
      Owner.Focus();
      return dialogResult;
    }

    public void WindowBuild(string[] args)
    {
      string Message = "";
      string Title = lang.Message;
      string OkText = lang.OK;
      string CancelText = lang.Cancel;
      string OtherText = "Other";
      string Other2Text = "Other2";

      for (int i = 0; i < args.Length; i++)
      {
        switch (i)
        {
          case 0:
            Message = args[i];
            break;
          case 1:
            Title = args[i];
            break;
          case 2:
            OkText = args[i];
            break;
          case 3:
            CancelText = args[i];
            break;
          case 4:
            OtherText = args[i];
            break;
          case 5:
            Other2Text = args[i];
            break;
        }
      }

      labelTitle.Content = Title;
      tbMessage.Text = Message;
      btnOk.Content = OkText;
      btnCancel.Content = CancelText;
      btnOther.Content = OtherText;
      btnOther2.Content = Other2Text;

      if (args.Length < 4)
      {
        btnOk.IsDefault = true;
        btnCancel.Visibility = Visibility.Collapsed;
        btnOk.Focus();
      }
      else
      {
        btnCancel.Focus();
      }

      if (args.Length < 5)
      {
        btnOther.Visibility = Visibility.Collapsed;
      }

      if (args.Length < 6)
      {
        btnOther2.Visibility = Visibility.Collapsed;
      }

      tbMessage.IsHitTestVisible = false;
      tbMessage.Focusable = false;

      if (Title == lang.Error)
      {
        wrapper.BorderBrush = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF0000"));
        tbMessage.IsHitTestVisible = true;
        tbMessage.Focusable = true;
      }
      else if (Title == lang.Caution || Title == lang.Confirm)
      {
        wrapper.BorderBrush = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FFBB00"));
      }
    }

    private void btnOk_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = Result.OK;
      this.DialogResult = true;
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = Result.Cancel;
      this.DialogResult = false;
    }

    private void btnOther_Click(object sender, RoutedEventArgs e)
    {
      Button btn = sender as Button;
      dialogResult = Result.Other;
      if (btn.Name == "btnOther2") dialogResult = Result.Other2;
      this.DialogResult = true;
    }

    private void btn_SizeChanged(object sender, SizeChangedEventArgs e)
    {
      List<double> widths = new List<double> { btnOk.ActualWidth, btnCancel.ActualWidth, btnOther.ActualWidth, btnOther2.ActualWidth };
      if (btnOk.ActualWidth < widths.Max()) btnOk.Width = widths.Max();
      if (btnCancel.ActualWidth < widths.Max()) btnCancel.Width = widths.Max();
      if (btnOther.ActualWidth < widths.Max()) btnOther.Width = widths.Max();
      if (btnOther2.ActualWidth < widths.Max()) btnOther2.Width = widths.Max();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      this.SizeToContent = SizeToContent.WidthAndHeight;
      if (this.ActualHeight > this.Owner.ActualHeight - 10)
      {
        this.MaxHeight = this.Owner.ActualHeight - 10;
        this.SizeToContent = SizeToContent.Manual;
      }
      this.Top = this.Owner.Top + (this.Owner.ActualHeight / 2) - (this.ActualHeight / 2);
      this.Left = this.Owner.Left + (this.Owner.ActualWidth / 2) - (this.ActualWidth / 2);
      this.MaxHeight = Double.PositiveInfinity;
    }

    public enum Result
    {
      None = 0,
      OK = 1,
      Cancel = 2,
      Other = 3,
      Other2 = 4
    }
  }
}
