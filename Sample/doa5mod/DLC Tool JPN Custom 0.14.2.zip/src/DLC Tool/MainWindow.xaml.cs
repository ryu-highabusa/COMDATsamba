﻿using System;
using System.IO;
using System.Globalization;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Collections;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Data;
using System.Runtime.Serialization.Formatters.Binary;
using Microsoft.Win32;
using Message;
using Common;
using Microsoft.WindowsAPICodePack.Dialogs;
using Hardcodet.Wpf.Util;
using NaturalSort;

namespace DLC_Tool
{
  /// <summary>
  /// MainWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class MainWindow : Window
  {
    public static Common.CommandManager commandManager = new Common.CommandManager();

    public static Config config = new Config();
    public static Dictionary<byte, List<DlcCostumeData>> dlcCostumeData = new Dictionary<byte, List<DlcCostumeData>>();
    public static List<NameEntry> nameDB;

    public static DlcToolData dtData;
    public static DefaultData defaultData;

    public static Dictionary<byte, string> CharaNamesLocale;
    public static Dictionary<byte, List<CostumeSlotItem>> CostumeSlots = new Dictionary<byte, List<CostumeSlotItem>>();
    public static DateTime CostumeSlotsSettedTime;
    public static Dictionary<string, Thumbnail> Thumbs = new Dictionary<string, Thumbnail>();
    public static Dictionary<string, string> SendTos = new Dictionary<string, string>();

    private static string currentFile = "";
    private static string currentListFile = "";
    private static string currentBcmFile = "";
    private static string currentCosFile = "";
    private static string currentDlcFolder = "";

    private static List<DlcData> clipboardDlcData;
    private static List<Costume> clipboardCosData;
    private static List<HairStyle> clipboardHStyleData;
    private static List<string> clipboardCosFilesData;

    private static string biginningText = "";

    private static int currentCostumeSlot = -1;

    private static bool notCommandStack = false;

    public static bool databaseChanged = false;

    private static bool editBcm = false;
    private static bool editDefault = false;

    private static bool isDropDownOpen = false;

    private static bool cosAdding = false;

    private static bool doing = false;

    private static bool appStarted = false;
    public static bool updateChecking = true;
    private static bool modified = false;
    private static bool exitConfirm = true;
    public static Lang.Sentence lang;
    public static Lang.Sentence defaultLang;



    public MainWindow()
    {
      InitializeComponent();

      LoadConfigs();


      defaultLang = Lang.Localized.SetFromResources(this);

      lang = defaultLang.Clone();
      if (config.Language != Const.Default) lang = Lang.Localized.SetLanguage(this, config.Language, defaultLang);

      MessageWindow.SetLang(lang);


      MainWindowTitle();

      Application.Current.ShutdownMode = ShutdownMode.OnMainWindowClose;
    }

    private void mainWindow_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      if (e.LeftButton == MouseButtonState.Pressed && !IsDragStart && !IsDragging) this.DragMove();
    }

    private void mainWindow_Loaded(object sender, RoutedEventArgs e)
    {
      SetCharaNamesLocale();

      SetConfigs();

      commandManager.MaxUndoCount = config.MaxUndoCount;

      GetSendTo();

      CharaMenuInit();
      GetDlcCostumeData();

      var skippedList = LoadDefault();
      if (skippedList != null && skippedList.Count > 0)
      {
        string text = lang.FoundErrorsInDefault + "\r\n";
        foreach (var skipped in skippedList)
        {
          text += "\r\n" + skipped;
        }
        MessageWindow.Show(this, text, lang.Error);
      }

      nameDB = LoadDB(false);

      foreach (var pair in defaultData.Charas)
      {
        byte count = GetCharaSlotCount(pair.Key);
        if (count > 0 && count < 255)
        {
          pair.Value.SlotCount = count;
        }
      }

      BuildCostumeSlots();

      dgDlc.Items.IsLiveSorting = true;
      dgCos.Items.IsLiveSorting = true;

      databaseChanged = false;

      List<string> cmds = System.Environment.GetCommandLineArgs().ToList();
      if (cmds.Count > 1)
      {
        cmds.RemoveAt(0);
        OpenFilesAssort(cmds, "");
      }
      else
      {
        if (config.OpenLastDd && !String.IsNullOrEmpty(config.LastDdPath) && File.Exists(config.LastDdPath))
        {
          OpenFile(config.LastDdPath, "");
        }
        else
        {
          config.LastDdPath = "";
        }
      }

      CheckClipboardData();
    }

    private void mainWindow_DragOver(object sender, DragEventArgs e)
    {
      e.Handled = true;
      if (e.Data.GetDataPresent(DataFormats.FileDrop))
      {
        if ((e.KeyStates & DragDropKeyStates.ControlKey) != 0)
          e.Effects = DragDropEffects.Copy;
        else if ((e.KeyStates & DragDropKeyStates.AltKey) != 0)
          e.Effects = DragDropEffects.Link;
        else
          e.Effects = DragDropEffects.Move;
      }
      else
      {
        e.Effects = DragDropEffects.None;
      }
    }

    private void mainWindow_DragDrop(object sender, DragEventArgs e)
    {
      List<string> filePaths = ((string[])e.Data.GetData(DataFormats.FileDrop, false)).ToList();
      if ((e.KeyStates & DragDropKeyStates.ControlKey) != 0)
        OpenFilesAssort(filePaths, Const.Add);
        else if ((e.KeyStates & DragDropKeyStates.AltKey) != 0)
        OpenFilesAssort(filePaths, Const.Temporary);
      else
        OpenFilesAssort(filePaths, "");
    }

    private void mainWindow_SizeChanged(object sender, SizeChangedEventArgs e)
    {
      var windowBounds = this.RestoreBounds;
      config.Window.Width = (int)Math.Floor(windowBounds.Right - windowBounds.Left);
      config.Window.Height = (int)Math.Floor(windowBounds.Bottom - windowBounds.Top);
    }

    private void mainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
    {
      SaveConfigs();

      var story = (System.Windows.Media.Animation.Storyboard)this.FindResource("fadeOut");
      story.Begin();
      e.Cancel = true;
    }

    private void undoCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      e.CanExecute = commandManager.CanUndo();
    }
    private void undoCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      commandManager.Undo();
    }

    private void redoCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      e.CanExecute = commandManager.CanRedo();
    }
    private void redoCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      commandManager.Redo();
    }

    private void newCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      string result = CreateNewData(true);
      if (result != null) DlcAdd(result);
    }

    private void emptyNewCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      CreateNewData(false);
    }

    private void addDlcCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (dtData != null)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void addDlcCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      string result = InputDlcNameWindow.Show(this);
      if (result != null) DlcAdd(result);
    }

    private void switchLstModeCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      e.CanExecute = editBcm;
    }
    private void switchLstModeCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      SwitchLstMode();
    }

    private void OpenFromClipboard()
    {
      var pathText = Clipboard.GetText();
      if (Clipboard.ContainsFileDropList())
      {
        //データを取得する（取得できなかった時はnull）
        System.Collections.Specialized.StringCollection files = Clipboard.GetFileDropList();
        if (files != null) pathText = files[0];
      }
      if (!string.IsNullOrEmpty(pathText) && File.Exists(pathText) && supportedExtLst.Contains(Path.GetExtension(pathText).ToLower()))
      {
        var result = MessageWindow.Show(this, pathText + "\r\n\r\n" + lang.ConfirmOpenFile, lang.Info, lang.BtnOpen, lang.Cancel);
        if (result == MessageWindow.Result.OK)
        {
          OpenFile(pathText, "");
        }
        Keyboard.Focus(mainWindow);
      }
    }

    private void openCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      this.IsEnabled = false;

      OpenFileDialog dlg = new OpenFileDialog();
      dlg.Filter = String.Format("{0}|*.dd;*.bcm;*.lst;*.rst|{1}|*.dd|{2}|*.lst;*.rst|{3}|*.bcm", lang.AllSupportedFormats, lang.DlcToolDataFile, lang.LstFile, lang.BcmFile);
      if (currentFile != "")
      {
        dlg.InitialDirectory = Path.GetDirectoryName(currentFile);
      }

      if (dlg.ShowDialog() == true)
      {
        OpenFilesAssort(dlg.FileNames.ToList(), "");
      }

      this.IsEnabled = true;
      this.Focus();
    }

    private void revertCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (dtData != null && !String.IsNullOrEmpty(config.LastDdPath) && modified)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void revertCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      OpenFile(null, "");
    }

    private void reloadDlcCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      string dlcDirPath = config.GameDirPath + @"DLC\";

      if (Directory.Exists(dlcDirPath))
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void reloadDlcCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      ReloadDlcCostumeData();
    }

    private void openDlcDirCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      string dlcDirPath = config.GameDirPath + @"DLC\";

      if (Directory.Exists(dlcDirPath))
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void openDlcDirCommand_CanExecute(object sender, ExecutedRoutedEventArgs e)
    {
      string dlcDirPath = config.GameDirPath + @"DLC\";

      if (Directory.Exists(dlcDirPath)) System.Diagnostics.Process.Start("EXPLORER.EXE", dlcDirPath);
    }

    private void openBuildDirCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (dtData !=null && Directory.Exists(dtData.OutputPath))
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void openBuildDirCommand_CanExecute(object sender, ExecutedRoutedEventArgs e)
    {
      if (dtData != null && Directory.Exists(dtData.OutputPath)) System.Diagnostics.Process.Start("EXPLORER.EXE", dtData.OutputPath);
    }

    private void saveCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (CheckCanSave() && modified)
          e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void saveCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      if (config.LastDdPath == "")
      {
        SaveAs();
      }
      else
      {
        var result = MessageWindow.Show(this, lang.Overwrite, lang.Confirm, lang.OverwriteYes, lang.Cancel);
        if (result == MessageWindow.Result.OK)
        {
          SaveDbFile(config.LastDdPath);
        }
      }
    }

    private void saveAsCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (CheckCanSave())
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void saveAsCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      SaveAs();
    }

    private bool CheckCanSave()
    {
      if (dtData == null || dtData.Dlcs.Count == 0) return false;

      foreach (var dlc in dtData.Dlcs)
      {
        if (!dlc.IsTemporary) return true;
      }

      return false;
    }

    private void SaveAs()
    {
      SaveFileDialog dlg = new SaveFileDialog();
      dlg.Title = lang.SaveDlcToolData;
      dlg.Filter = lang.DlcToolDataFile + "|*.dd";

      if (config.LastDdPath != "")
      {
        dlg.FileName = Path.GetFileNameWithoutExtension(config.LastDdPath); ;
        dlg.InitialDirectory = Path.GetDirectoryName(config.LastDdPath);
      }

      if (dlg.ShowDialog() == true)
      {
        SaveDbFile(dlg.FileName);
        textStatus.Path = dlg.FileName;
        currentFile = dlg.FileName;
        config.LastDdPath = dlg.FileName;
      }
    }

    private void lstExportCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      var dlc = dgDlc.SelectedItem as DlcData;

      if (dtData != null && dgDlc.SelectedItems.Count == 1 && dlc.Costumes.Count > 0)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void lstExportCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      if (dgDlc.SelectedItems.Count != 1) return;

      var dlc = dgDlc.SelectedItem as DlcData;

      SaveFileDialog dlg = new SaveFileDialog();
      dlg.Title = lang.ExportLst;
      dlg.Filter = lang.LstFile + "|*.lst";

      if (currentFile != "")
      {
        dlg.FileName = Path.GetFileNameWithoutExtension(currentFile); ;
        dlg.InitialDirectory = Path.GetDirectoryName(currentFile);
      }
      else
      {
        dlg.FileName = dlc.Name;
      }

      if (dlg.ShowDialog() == true)
      {
        SaveLstFile(dlg.FileName, dlc);
        currentFile = dlg.FileName;
        currentListFile = dlg.FileName;
      }
    }

    private void bcmSaveCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      e.CanExecute = editBcm && modified;
    }
    private void bcmSaveCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      SaveBcmFile(currentBcmFile);
    }

    private void bcmSaveAsCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      e.CanExecute = editBcm;
    }
    private void bcmSaveAsCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      SaveFileDialog dlg = new SaveFileDialog();
      dlg.Title = lang.SaveBcm;
      dlg.Filter = lang.BcmFile + "|*.bcm";
      dlg.FileName = Path.GetFileNameWithoutExtension(currentBcmFile);
      dlg.InitialDirectory = Path.GetDirectoryName(currentBcmFile);

      if (dlg.ShowDialog() == true)
      {
        SaveBcmFile(dlg.FileName);
        currentBcmFile = dlg.FileName;
        currentFile = dlg.FileName;
      }
    }

    private void buildCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      var dlc = dgDlc.SelectedItem as DlcData;

      if (!editBcm && !editDefault && !IsDragging && dtData != null && dgDlc.SelectedItems.Count == 1 && dlc.Costumes.Count > 0)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void buildCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      this.IsEnabled = false;
      DoEvents();

      bool result = BuildDlc();

      this.IsEnabled = true;

      if (result) ShowTextBlockMessage(lang.DlcBuilded);
    }

    private void buildAllCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (!editBcm && !editDefault && dtData != null && dtData.Dlcs.Count > 0)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void buildAllCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      this.IsEnabled = false;
      DoEvents();

      string result = BuildDlcs();

      this.IsEnabled = true;

      if (result == null)
      {
        return;
      }
      else if (result != "")
      {
        MessageWindow.Show(this, result, lang.Error);
      }
      else
      {
        ShowTextBlockMessage(lang.DlcBuilded);
      }
    }

    // Undoable OK
    private void btnPath_Click(object sender, RoutedEventArgs e)
    {
      string saveDirPath = SetSavePath();

      if (saveDirPath == "") return;

      string prevSaveDirPath = dtData.OutputPath;

      commandManager.Do(new Command(
        nameof(lang.ChangeOutputPath),
        () => {
          dtData.OutputPath = saveDirPath;
          currentDlcFolder = saveDirPath;
        },
        () => {
          dtData.OutputPath = prevSaveDirPath;
          currentDlcFolder = prevSaveDirPath;
        },
        () => {
        }));

      Modified();
    }

    private void tbPath_GotFocus(object sender, RoutedEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (target == null) return;

      biginningText = dtData.OutputPath;

      target.SelectAll();
    }

    // Undoable OK
    private void tbPath_LostFocus(object sender, RoutedEventArgs e)
    {
      Task.Delay(100);

      string prevSaveDirPath = biginningText;
      string redoSaveDirPath = dtData.OutputPath;

      commandManager.Do(new Command(
        nameof(lang.ChangeOutputPath),
        () => {
        },
        () => {
          dtData.OutputPath = redoSaveDirPath;
        },
        () => {
          dtData.OutputPath = prevSaveDirPath;
        },
        () => {
        }));
    }

    private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
    {
      if (this.IsEnabled)
      {
        Modified();
      }
    }

    private void btnConfig_Click(object sender, RoutedEventArgs e)
    {
      string curLanguage = config.Language;

      config = ConfigWindow.Show(this);

      commandManager.MaxUndoCount = config.MaxUndoCount;

      if (config.Language == null) config.Language = Const.Default;

      if (curLanguage != config.Language) ChangeLanguage(config.Language);

      DatabaseChanged();

      if (dtData != null)
      {
        foreach (var dlc in dtData.Dlcs)
        {
          foreach (var cos in dlc.Costumes)
          {
            cos.CheckFiles(dlc.Type == Const.Default);
          }
        }
      }
    }

    private void cmbHistory_DropDownClosed(object sender, EventArgs e)
    {
      commandManager.HistoryChange(cmbHistory.SelectedIndex);
    }

    private void cmbHistory_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
    {
      e.Handled = true;
    }

    private void cbDlcIsIncluded_Click(object sender, RoutedEventArgs e)
    {
      CheckBox cb = sender as CheckBox;

      foreach (var sel in dgDlc.SelectedItems)
      {
        var dlc = dtData.Dlcs[dgDlc.Items.IndexOf(sel)];

        dlc.IsIncluded = (bool)cb.IsChecked;
      }

      ResetDragDrop();
      Modified();
    }

    private void cbCosIsIncluded_Click(object sender, RoutedEventArgs e)
    {
      CheckBox cb = sender as CheckBox;

      ChangeIsIncluded(cb);

      Modified();
    }

    private void ChangeIsIncluded(CheckBox cb)
    {
      if (dgDlc.SelectedItems.Count != 1) return;

      var dlc = dgDlc.SelectedItem as DlcData;

      foreach (var sel in dgCos.SelectedItems)
      {
        var cos = dlc.Costumes[dgCos.Items.IndexOf(sel)];

        cos.IsIncluded = (bool)cb.IsChecked;
        cos.CheckFiles(editDefault);
      }

      dlc.CheckCostumeSlot();

      ResetDragDrop();
    }



    private void DataGrid_Sorting(object sender, DataGridSortingEventArgs e)
    {
      if (e.Column.SortDirection == System.ComponentModel.ListSortDirection.Descending)
      {
        e.Column.SortDirection = null;
        e.Handled = true;
        var view = CollectionViewSource.GetDefaultView(((DataGrid)sender).ItemsSource);
        int index = Array.FindIndex(view.SortDescriptions.ToArray(), elem => elem.PropertyName == e.Column.SortMemberPath);
        view.SortDescriptions.RemoveAt(index);
      }
    }



    public void GetSendTo()
    {
      string sendToPath = BaseDirectory + @"SendTo";

      if (!Directory.Exists(sendToPath)) return;


      var filePaths = Directory.GetFiles(sendToPath, "*.lnk", SearchOption.TopDirectoryOnly);

      filePaths = filePaths.OrderBy(f => f, new NaturalStringComparer()).ToArray();

      Type t = Type.GetTypeFromCLSID(new Guid("72C24DD5-D70A-438B-8A42-98424B88AFB8"));
      dynamic shell = Activator.CreateInstance(t);
      Dictionary<string, string> shortcutPaths = new Dictionary<string, string>();
      foreach (string path in filePaths)
      {
        string name = Path.GetFileNameWithoutExtension(path);

        var shortcut = shell.CreateShortcut(path);

        if (!File.Exists(shortcut.TargetPath)) continue;

        shortcutPaths.Add(name, shortcut.TargetPath);
        System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shortcut);
      }
      System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shell);

      int count = 0;
      Style style = this.FindResource("NonShortcutMenuItemStyle") as Style;
      foreach (var pair in shortcutPaths)
      {
        var newMenuItem = new MenuItem();
        newMenuItem.Header = pair.Key.Replace(" - " + lang.Shortcut, "");
        newMenuItem.Click += SendTo_Click;
        newMenuItem.Style = style;
        menuFileSendTo.Items.Add(newMenuItem);
        SendTos.Add(pair.Key, pair.Value);

        count++;
      }

      if (menuFileSendTo.Items.Count > 0) menuFileSendTo.IsEnabled = true;
    }

    private void SendTo_Click(object sender, RoutedEventArgs e)
    {
      MenuItem target = sender as MenuItem;

      string appPath = SendTos[target.Header.ToString()];

      if (!File.Exists(appPath)) return;


      var file = dgFiles.SelectedItem as CostumeFile;
      var filePath = file.Path;

      if (String.IsNullOrEmpty(file.Path))
      {
        var cos = dtData.Costume;

        if (file.InDlc)
        {

        }
        else if (config.UseDefaultCFile && file.ID == 0)
        {
          string path = file.GetDefaultFilePath(defaultData.Charas[cos.ID].Files, config.DefaultCFilePath);
          if (path != null)
            filePath = path;
        }
        else if (config.UseDefaultPFile && file.ID == 1)
        {
          string path = file.GetDefaultFilePath(defaultData.Charas[cos.ID].Files, config.DefaultPFilePath);
          if (path != null)
            filePath = path;
        }
      }

      if (String.IsNullOrEmpty(filePath) || !File.Exists(filePath)) return;

      //ProcessStartInfoオブジェクトを作成する
      System.Diagnostics.ProcessStartInfo psi = new System.Diagnostics.ProcessStartInfo();
      //起動するファイルのパスを指定する
      psi.FileName = appPath;
      //コマンドライン引数を指定する
      psi.Arguments = @"""" + filePath + @"""";

      //アプリケーションを起動する
      System.Diagnostics.Process.Start(psi);

    }

    public static byte GetCharaSlotCount(byte ID)
    {
      if (!File.Exists(BaseDirectory + config.DatabasePath))
      {
        return 255;
      }
      else if (nameDB == null)
      {
        var nameDB = LoadDB(false);
        if (nameDB == null)
        {
          return 255;
        }
        databaseChanged = false;
      }
      for (byte i = 0; i < 255; i++)
      {
        string tmcName = CharaNames[ID] + "_DLCU_" + (i + 1).ToString("D3") + ".TMC";
        if (Array.FindIndex(nameDB.ToArray(), elem => elem.Name == tmcName && elem.Current) == -1)
        {
          return i;
        }
      }
      return 255;
    }

    public void GetDlcCostumeData()
    {
      string dlcDirPath = config.GameDirPath + @"DLC\";

      if (!Directory.Exists(dlcDirPath)) return;

      dlcCostumeData = new Dictionary<byte, List<DlcCostumeData>>();

      string[] tempPaths = Directory.GetDirectories(dlcDirPath, "*", SearchOption.TopDirectoryOnly);
      foreach (string path in tempPaths)
      {
        string name = Path.GetFileName(path);
        if (System.Text.RegularExpressions.Regex.IsMatch(name, @"^[0-9]{1,6}$"))
        {
          string bcmName = path + @"\" + name + ".bcm";
          if (!File.Exists(bcmName)) continue;

          var data = ParseBcm(bcmName, false);
          if (data == null) continue;

          foreach (var cos in data.Costumes)
          {
            DlcCostumeData dlcCos = new DlcCostumeData((byte)cos.CostumeSlot, name);

            if (!dlcCostumeData.ContainsKey(cos.ID))
            {
              dlcCostumeData[cos.ID] = new List<DlcCostumeData>();
            }

            dlcCostumeData[cos.ID].Add(dlcCos);
          }
        }
      }
    }

    public void BuildCostumeSlots()
    {
      if (CostumeSlots.Count > 0) CostumeSlots.Clear();

      foreach (var id in CharaNames.Keys)
      {
        List<DlcCostumeData> dlcCosData = null;
        if (dlcCostumeData.ContainsKey(id)) dlcCosData = dlcCostumeData[id];

        CostumeSlots[id] = new List<CostumeSlotItem>();

        string dlcNum = "";

        for (byte i = 0; i < defaultData.Charas[id].SlotCount; i++)
        {
          if (SlotsInGame.ContainsKey(id) && SlotsInGame[id].Contains(i)) continue;

          dlcNum = "";
          if (dlcCosData != null)
          {
            int index = Array.FindIndex(dlcCosData.ToArray(), elem => elem.Slot == i);
            if (index != -1)
            {
              dlcNum = dlcCosData[index].DlcNum;
            }
          }

          var item = new CostumeSlotItem();
          item.Slot = i;
          item.Dlc = dlcNum;

          CostumeSlots[id].Add(item);
        }

        dlcNum = "";
        if (ParadiseSexyIDs.Contains(id))
        {
          var item = new CostumeSlotItem();
          item.Slot = 109;

          if (dlcCosData != null)
          {
            int index = Array.FindIndex(dlcCosData.ToArray(), elem => elem.Slot == item.Slot);
            if (index != -1)
            {
              dlcNum = dlcCosData[index].DlcNum;
            }
          }
          item.Dlc = dlcNum;

          CostumeSlots[id].Add(item);
        }
        else if (ParadiseSexyIDs2.Contains(id))
        {
          var item = new CostumeSlotItem();
          item.Slot = 105;

          if (dlcCosData != null)
          {
            int index = Array.FindIndex(dlcCosData.ToArray(), elem => elem.Slot == item.Slot);
            if (index != -1)
            {
              dlcNum = dlcCosData[index].DlcNum;
            }
          }
          item.Dlc = dlcNum;

          CostumeSlots[id].Add(item);
        }
      }

      CostumeSlotsSettedTime = DateTime.Now;
    }

    public void SetCharaNamesLocale()
    {
      CharaNamesLocale = new Dictionary<byte, string>();

      Type t = typeof(Lang.Sentence);

      foreach (var pair in CharaNames)
      {
        string name = pair.Value[0] + pair.Value.ToLower().Substring(1);

        PropertyInfo pi = t.GetProperty(name);
        if (pi != null)
        {
          name = (string)pi.GetValue(lang, null);
        }

        CharaNamesLocale[pair.Key] = name;
      }
    }

    public void DatabaseChanged()
    {
      if (!databaseChanged) return;

      foreach (var pair in defaultData.Charas)
      {
        byte count = GetCharaSlotCount(pair.Key);
        if (count > 0 && count < 255)
        {
          pair.Value.SlotCount = count;
        }
      }

      BuildCostumeSlots();

      if (dtData != null)
      {
        foreach (var dlc in dtData.Dlcs)
        {
          foreach (var cos in dlc.Costumes)
          {
            cos.SetCostumeSlots();
          }
        }

        var curDlcData = dgDlc.SelectedItem as DlcData;
        if (curDlcData != null) curDlcData.CheckCostumeSlot();
      }

      databaseChanged = false;
    }

    public void ReloadDlcCostumeData()
    {
      GetDlcCostumeData();

      BuildCostumeSlots();

      if (dtData == null) return;

      foreach (var dlc in dtData.Dlcs)
      {
        foreach (var cos in dlc.Costumes)
        {
          cos.SetCostumeSlots();
        }
      }

      var curDlcData = dgDlc.SelectedItem as DlcData;
      if (curDlcData != null) curDlcData.CheckCostumeSlot();
    }


    public static string GetAbsolutePath(string basePath, string relativePath)
    {
      string sysCurrentDir = Environment.CurrentDirectory;
      Environment.CurrentDirectory = Path.GetDirectoryName(basePath);

      string absolutePath = Path.GetFullPath(relativePath);

      Environment.CurrentDirectory = sysCurrentDir;

      return absolutePath;
    }

    public static string GetRelativePath(string basePath, string absolutePath)
    {
      Uri baseUri = new Uri(basePath);

      Uri absoUri = new Uri(absolutePath);

      Uri relativeUri = baseUri.MakeRelativeUri(absoUri);

      string relativePath = relativeUri.ToString();

      relativePath = relativePath.Replace('/', '\\');

      return relativePath;
    }

    public static List<string> GetAbsolutePaths(string basePath, List<string> relativePaths)
    {
      List<string> absolutePaths = new List<string>();

      string sysCurrentDir = Environment.CurrentDirectory;
      Environment.CurrentDirectory = Path.GetDirectoryName(basePath);

      foreach (var path in relativePaths)
      {
        absolutePaths.Add(Path.GetFullPath(path));
      }

      Environment.CurrentDirectory = sysCurrentDir;

      return absolutePaths;
    }

    public static List<string> GetRelativePaths(string basePath, List<string> absolutePaths)
    {
      List<string> relativePaths = new List<string>();

      Uri baseUri = new Uri(basePath);

      foreach (var path in absolutePaths)
      {
        Uri absoUri = new Uri(path);

        Uri relativeUri = baseUri.MakeRelativeUri(absoUri);

        string relativePath = relativeUri.ToString();

        relativePath = relativePath.Replace('/', '\\');

        relativePaths.Add(relativePath);
      }

      return relativePaths;
    }



    private void ClearDlcUI()
    {
      gridPath.IsEnabled = false;

      modified = false;

      commandManager.Clear();

      ClearCostumeUI();
    }

    private void ClearCostumeUI()
    {
      ClearDataUI();

      if (dtData != null)
      {
        dtData.Dlc = null;
      }

      dgcCosComment.IsReadOnly = false;
      dgcSlotNum.IsReadOnly = false;

      var charaMenuItems = new MenuItem[] { menuAddFemale, menuAddMale, menuInsFemale, menuInsMale };
      foreach (var charaMenuItem in charaMenuItems)
      {
        foreach (var item in charaMenuItem.Items)
        {
          var menuItem = item as MenuItem;
          menuItem.IsEnabled = true;
        }
      }
    }

    private void ClearDataUI()
    {
      if (dtData != null)
      {
        dtData.Costume = null;
      }
    }

    private string CreateNewData(bool addDlc)
    {
      if (modified)
      {
        if (MessageWindow.Show(this, lang.DisposeDataWhenCreateNew, lang.Confirm, lang.Continue, lang.Cancel) == MessageWindow.Result.Cancel)
        {
          return null;
        }
      }

      string saveDirPath = "";

      if (config.UseFolderSelectDialog)
      {
        saveDirPath = SetSavePath();

        if (saveDirPath == "") return null;
      }
      else
      {
        saveDirPath = config.UsersFolderPath ?? "";
      }


      string result = null;

      if (addDlc)
      {
        result = InputDlcNameWindow.Show(this);
        if (result == null) return null;
      }


      ClearDlcUI();

      dtData = new DlcToolData();

      dtData.OutputPath = saveDirPath;
      currentDlcFolder = saveDirPath;

      this.DataContext = dtData;

      gridPath.IsEnabled = true;
      textStatus.Path = lang.CreatingAndNotSaved;

      dgDlc.Focus();


      return result;
    }

    private void SwitchLstMode()
    {
      if (dgDlc.SelectedItems.Count != 1) return;

      var dlc = dgDlc.SelectedItem as DlcData;

      dlc.Comment = "";
      dlc.IsTemporary = false;
      dlc.Type = "";
      dlc.BcmVer = 9;
      editBcm = false;
      editDefault = false;

      commandManager.Clear();

      ClearCostumeUI();

      foreach (var cos in dlc.Costumes)
      {
        cos.InitFiles();
        cos.CheckFiles(editDefault);
        cos.SetCostumeSlots();
      }

      dlc.CheckCostumeSlot();

      gridPath.IsEnabled = true;

      currentFile = "";
      currentListFile = "";
      currentBcmFile = "";

      SelectDlc(dlc);
    }

    private void OpenFilesAssort(List<string> filePaths, string behavior)
    {
      if (filePaths.Count < 1) return;

      string filepath = "";
      var dirPaths = new List<string>();
      var lstFilePaths = new List<string>();
      var cosFilePaths = new List<string>();
      var lnkPaths = new List<string>();
      foreach (string path in filePaths)
      {
        if (Directory.Exists(path))
        {
          dirPaths.Add(path);
        }

        if (dirPaths.Count > 0) continue;

        if (filepath == "" && Path.GetExtension(path).ToLower() == ".dd")
        {
          filepath = path;
          break;
        }
        else if (supportedExtLst.Contains(Path.GetExtension(path).ToLower()))
        {
          lstFilePaths.Add(path);
        }
        else if (supportedExtCos.Contains(Path.GetExtension(path).ToUpper()))
        {
          cosFilePaths.Add(path);
        }
        else if (Path.GetExtension(path).ToLower() == ".lnk")
        {
          lnkPaths.Add(path);
        }
      }

      if (lnkPaths.Count > 0 && dirPaths.Count == 0 && filepath == "")
      {
        Type t = Type.GetTypeFromCLSID(new Guid("72C24DD5-D70A-438B-8A42-98424B88AFB8"));
        dynamic shell = Activator.CreateInstance(t);
        List<string> shortcutPaths = new List<string>();
        foreach (string path in lnkPaths)
        {
          var shortcut = shell.CreateShortcut(path);
          shortcutPaths.Add(shortcut.TargetPath);
          System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shortcut);
        }
        System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shell);

        foreach (string path in shortcutPaths)
        {
          if (Path.GetExtension(path).ToLower() == ".dd")
          {
            filepath = path;
            break;
          }
          else if (supportedExtLst.Contains(Path.GetExtension(path).ToLower()))
          {
            lstFilePaths.Add(path);
          }
          else if (supportedExtCos.Contains(Path.GetExtension(path).ToUpper()))
          {
            cosFilePaths.Add(path);
          }
        }
      }

      if (dirPaths.Count > 0)
      {
        OpenDir(dirPaths);
      }
      else if (filepath != "")
      {
        OpenFile(filepath, behavior);
      }
      else if (lstFilePaths.Count > 0)
      {
        lstFilePaths = lstFilePaths.OrderBy(name => name.ToLower(), StringComparer.Ordinal).ToList();

        foreach (var path in lstFilePaths)
        {
          bool result = OpenFile(path, behavior);
          if (!result) break;
        }
      }
      else if (!editBcm && dtData != null && dgCos.SelectedItems.Count == 1)
      {
        var cos = dgCos.SelectedItem as Costume;
        OpenCosFile(cos, cosFilePaths, null);
      }
    }

    //Undoable OK
    private void OpenDir(List<string> dirPaths)
    {
      if (dgDlc.SelectedItems.Count != 1) return;

      var dlc = dgDlc.SelectedItem as DlcData;

      bool replace = true;
      int addCount = 0;

      // デフォルト設定編集モードやbcmモードでドロップした場合
      if (editDefault)
      {
        MessageWindow.Show(this, lang.NotAddFromFolderInDefaultMode, lang.Caution);
      }
      else if (editBcm)
      {
        var result = MessageWindow.Show(this, lang.NotAddFromFolderInBcmMode, lang.Confirm, lang.Continue, lang.Cancel);
        if (result == MessageWindow.Result.Cancel)
        {
          return;
        }
        else if (result == MessageWindow.Result.OK)
        {
          SwitchLstMode();
        }
      }

      // 動作選択ダイアログ
      string selectText = lang.RegistFromFolders;
      if (dlc.Costumes.Count > 0)
      {
        selectText += "\r\n\r\n";
        selectText += lang.CostumesAlreadyExists;
        var result = MessageWindow.Show(this, selectText, lang.Confirm, lang.AddCostumes, lang.Cancel, lang.ReplaceFiles);
        if (result == MessageWindow.Result.Cancel)
        {
          return;
        }
        else if (result == MessageWindow.Result.OK)
        {
          replace = false;
        }
      }
      else
      {
        var result = MessageWindow.Show(this, selectText, lang.Confirm, lang.StartRegistration, lang.Cancel);
        if (result == MessageWindow.Result.Cancel)
        {
          return;
        }
      }

      List<string> filePaths = new List<string>();
      Dictionary<string, Costume> addedCostumes = new Dictionary<string, Costume>();

      // ファイル取得
      foreach (string path in dirPaths)
      {
        filePaths.AddRange(Directory.GetFiles(path, "*.*", SearchOption.TopDirectoryOnly));
      }

      var prevDlc = dlc.Clone();

      foreach (string filePath in filePaths)
      {
        string fileName = Path.GetFileNameWithoutExtension(filePath);
        string[] nameParams = fileName.Split('_');

        if (nameParams.Length < 3 || nameParams[1].ToUpper() != "DLCU" || nameParams[2].Length < 3) continue;

        byte id = 255;
        if (CharaNames.ContainsValue(nameParams[0].ToUpper()))
        {
          id = CharaNames.First(x => x.Value == nameParams[0].ToUpper()).Key;
        }
        else
        {
          continue;
        }

        byte num;
        if (!Byte.TryParse(nameParams[2].Substring(0, 3), out num))
        {
          continue;
        }
        num--;

        // ここから分岐
        bool add = true;
        if (replace)
        {
          foreach (var cos in dlc.Costumes)
          {
            if (cos.ID == id && cos.CostumeSlot == num)
            {
              for (byte i = 0; i < FileTypes.Length; i++)
              {
                if (filePath.EndsWith(FileTypes[i], true, null))
                {
                  cos.SetFile(i, filePath);
                  addCount++;
                  break;
                }
              }
              add = false;
              break;
            }
          }
        }

        if (add)
        {
          for (byte i = 0; i < FileTypes.Length; i++)
          {
            if (filePath.EndsWith(FileTypes[i], true, null))
            {
              if (addedCostumes.ContainsKey(id + "_" + num))
              {
                addedCostumes[id + "_" + num].SetFile(i, filePath);
              }
              else
              {
                var cosEntry = new Costume(id, false);
                cosEntry.SetFile(i, filePath);
                cosEntry.CostumeSlot = num;
                dlc.Costumes.Add(cosEntry);
                addedCostumes[id + "_" + num] = cosEntry;
              }
              addCount++;
              break;
            }
          }
        }
      }

      var redoDlc = dlc.Clone();

      commandManager.Do(new Command(
        nameof(lang.AddFromFolder),
        () => {
        },
        () => {
          if (dlc.Costumes.Count > 0) dlc.Costumes.Clear();

          foreach (var cos in redoDlc.Costumes)
          {
            dlc.Costumes.Add(cos);
          }
        },
        () => {
          if (dlc.Costumes.Count > 0) dlc.Costumes.Clear();

          foreach (var cos in prevDlc.Costumes)
          {
            dlc.Costumes.Add(cos);
          }
        },
        () => {
          foreach (var cos in dlc.Costumes)
          {
            cos.SetCostumeSlots();
            cos.SetThumbnail();
            cos.SetCFlags();
            cos.AddTexsCount = (byte)CheckInners(cos).Count;
            cos.CheckFiles(editDefault);
          }

          dlc.CheckCostumeCount();
          dlc.CheckCostumeSlot();

          DoEvents();

          var selCos = dgCos.SelectedItem as Costume;
          if (selCos != null) dtData.Costume = selCos;
        }));

      Modified();

      if (addCount > 0)
        ShowTextBlockMessage(String.Format(lang.CompletedAddAndReplaceFiles, addCount));
      else
        ShowTextBlockMessage(lang.NotAddAndReplaceFiles);
    }

    //Undoable OK
    private bool OpenFile(string filePath, string behavior)
    {
      try
      {
        this.IsEnabled = false;
        DoEvents();

        if (String.IsNullOrEmpty(filePath)) filePath = config.LastDdPath;

        if (Path.GetExtension(filePath).ToLower() == ".dd")
        {
          OpenDdFile(filePath, behavior);
        }
        else
        {
          DlcData dlc = null;

          if (behavior == Const.Add && dgDlc.SelectedIndex != -1) dlc = dgDlc.SelectedItem as DlcData;

          if (dlc == null)
          {
            if (behavior == Const.Add) behavior = "";
          }
          else if (editBcm)
          {
            var result = MessageWindow.Show(this, lang.NotAddFromFileInBcmMode, lang.Confirm, lang.Yes, lang.Cancel);
            if (result == MessageWindow.Result.Cancel)
            {
              return false;
            }
          }
          else if (editDefault)
          {
            var result = MessageWindow.Show(this, lang.NotAddFromFileInDefaultMode, lang.Confirm, lang.Yes, lang.Cancel);
            if (result == MessageWindow.Result.OK)
            {
              behavior = "";
              dlc = null;
            }
            else
            {
              return false;
            }
          }
          else if (dlc.IsTemporary)
          {
            var result = MessageWindow.Show(this, lang.NotAddFromFileToTemporaryData, lang.Confirm, lang.Yes, lang.Cancel);
            if (result == MessageWindow.Result.Cancel)
            {
              return false;
            }
          }

          if (dtData == null)
          {
            modified = false;
            CreateNewData(false);
            if (dtData == null) return false;
          }

          if (Path.GetExtension(filePath).ToLower() == ".lst" || Path.GetExtension(filePath).ToLower() == ".rst")
          {
            #region lst

            var data = OpenLstFile(filePath);

            if (behavior == Const.Add)
            {
              // 追加の場合
              if (dlc.IsTemporary)
              {
                commandManager.Clear();

                dlc.Comment = "";
                dlc.IsTemporary = false;
                dlc.Type = "";
                editBcm = false;

                foreach (var cos in dlc.Costumes)
                {
                  cos.InitFiles();
                }
              }

              var costumes = data.Costumes;

              commandManager.Do(new Command(
                nameof(lang.CostumeAddFromFile),
                () => {
                  foreach (var cos in costumes)
                  {
                    dlc.Costumes.Add(cos);
                  }
                },
                () => {
                  foreach (var cos in costumes)
                  {
                    dlc.Costumes.Remove(cos);
                  }
                },
                () => {
                  dgDlc.SelectedItem = null;
                  dgDlc.SelectedItem = dlc;
                }));
            }
            else
            {
              commandManager.Do(new Command(
                nameof(lang.DlcAddLst),
                () => {
                  if (String.IsNullOrEmpty(dtData.OutputPath)) dtData.OutputPath = data.OutputPath;
                  currentListFile = filePath;
                  currentBcmFile = "";

                  if (behavior == Const.Temporary)
                  {
                    data.Comment = lang.IsTemporary;
                    data.IsTemporary = true;
                  }

                  dtData.Dlcs.Add(data);
                },
                () => {
                  dtData.Dlcs.Remove(data);
                },
                () => {
                  dgDlc.SelectedItem = data;
                }));
            }

            #endregion
          }
          else if (Path.GetExtension(filePath).ToLower() == ".bcm")
          {
            #region bcm

            var data = OpenBcmFile(filePath);

            if (behavior == Const.Add)
            {
              // 追加の場合
              if (dlc.IsTemporary)
              {
                commandManager.Clear();

                dlc.Comment = "";
                dlc.IsTemporary = false;
                dlc.Type = "";
                editBcm = false;

                foreach (var cos in dlc.Costumes)
                {
                  cos.InitFiles();
                }
              }

              foreach (var cos in data.Costumes)
              {
                cos.InitFiles();
                dlc.Costumes.Add(cos);
              }

              dgDlc.SelectedItem = null;
              dgDlc.SelectedItem = dlc;
              dlc.CheckCostumeCount();
              dlc.CheckCostumeSlot();
            }
            else
            {
              commandManager.Do(new Command(
                nameof(lang.DlcAddBcm),
                () => {
                  data.FilePath = filePath;
                  data.Name = Path.GetFileName(filePath);
                  data.Comment = lang.IsTemporary;
                  data.IsTemporary = true;

                  editBcm = true;
                  editDefault = false;
                  cbDisplayThumb.IsChecked = false;

                  data.OutputPath = Path.GetDirectoryName(Path.GetDirectoryName(filePath));
                  data.Type = Const.Bcm;

                  data.Comment = lang.IsTemporary;
                  data.IsTemporary = true;

                  dtData.Dlcs.Add(data);

                  currentListFile = "";
                  currentBcmFile = filePath;
                },
                () => {
                  dtData.Dlcs.Remove(data);
                },
                () => {
                  dgDlc.SelectedItem = null;
                  dgDlc.SelectedItem = data;
                  data.CheckCostumeCount();
                  data.CheckCostumeSlot();
                }));
            }

            currentFile = filePath;

            #endregion
          }

          var curData = dgDlc.SelectedItem as DlcData;

          if (!curData.IsTemporary) Modified();
        }

        if (dgDlc.SelectedItem != null)
        {
          SetSelectChanged(dgDlc, dgDlc.SelectedItem, 1);
        }

        return true;
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, lang.Error);
        return false;
      }
      finally
      {
        this.IsEnabled = true;
        this.Activate();
        this.Focus();
        dgDlc.Focus();
      }
    }

    private void OpenDdFile(string filePath, string behavior)
    {
      DlcToolData tempData = null;
      object data = null;

      System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(DlcToolData));
      using (var sr = new StreamReader(filePath, new UTF8Encoding(false)))
      {
        data = (DlcToolData)serializer.Deserialize(sr);
      }

      if (data is DlcToolData)
        tempData = data as DlcToolData;

      if (tempData == null) return;


      ClearDlcUI();

      if (behavior == Const.Add)
      {
        foreach (var dlc in tempData.Dlcs)
        {
          dtData.Dlcs.Add(dlc);
        }
        dgDlc.SelectedIndex = dtData.Dlcs.Count - 1;
      }
      else
      {
        dtData = tempData;
        dgDlc.SelectedIndex = 0;
      }

      textStatus.Path = filePath;
      currentFile = filePath;
      config.LastDdPath = filePath;

      foreach (var dlc in dtData.Dlcs)
      {
        dlc.ErrorTexts = new Dictionary<string, string>();
        foreach (var cos in dlc.Costumes)
        {
          if (cos.ErrorTexts == null)
            cos.ErrorTexts = new Dictionary<string, string>();

          foreach (var file in cos.Files)
          {
            if (!file.InDlc)
            {
              file.DisplayPath = file.Path;
            }
          }
        }

        foreach (var cos in dlc.Costumes)
        {
          cos.SetCostumeSlots();
          cos.CheckFiles(editDefault);
        }

        dlc.CheckCostumeCount();
        dlc.CheckCostumeSlot();
      }

      this.DataContext = dtData;

      gridPath.IsEnabled = true;

      if (dtData.Dlcs.Count > 0) dgDlc.SelectedIndex = 0;
    }

    private DlcData OpenLstFile(string filePath)
    {
      DlcData data = ParseLst(filePath, true);

      if (data == null) return data;

      ClearCostumeUI();

      editBcm = false;

      string fileName = Path.GetFileNameWithoutExtension(filePath);
      if (fileName == Const.Default.ToLower())
        editDefault = true;
      else
        editDefault = false;

      if (editDefault)
      {
        data.Type = Const.Default;
        data.Comment = lang.IsTemporary;
        data.IsTemporary = true;
      }

      return data;
    }

    private DlcData OpenBcmFile(string filePath)
    {
      DlcData data = ParseBcm(filePath, true);

      if (data == null) return data;

      ClearCostumeUI();

      return data;
    }

    private void SaveDbFile(string filePath)
    {
      foreach (var dlc in dtData.Dlcs)
      {
        dlc.ResetIsAdded();
      }

      DlcToolData saveData = dtData.GetDataForSave();

      System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(DlcToolData));
      using (var sw = new StreamWriter(filePath, false, new UTF8Encoding(false)))
      {
        serializer.Serialize(sw, saveData);
      }


      saveData = null;

      modified = false;
      textStatus.Path = filePath;
      currentFile = filePath;
      config.LastDdPath = filePath;

      ShowTextBlockMessage(lang.DlcToolDataFileSaved);
    }

    private void SaveLstFile(string filePath, DlcData dlc)
    {
      try
      {
        this.IsEnabled = false;
        DoEvents();

        string lst = BuildLst(dlc);

        // 保存
        using (StreamWriter sw = new StreamWriter(filePath, false))
        {
          sw.Write(lst);
        }

        if (editDefault) LoadDefault();

        ShowTextBlockMessage(lang.LstExported);
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, lang.Error);
      }
      finally
      {
        this.IsEnabled = true;
      }
    }

    private void SaveBcmFile(string filePath)
    {
      if (dgDlc.SelectedItems.Count != 1) return;

      var dlc = dgDlc.SelectedItem as DlcData;

      try
      {
        this.IsEnabled = false;
        DoEvents();

        SaveBcm(dlc, filePath);

        ShowTextBlockMessage(lang.BcmSaved);

        modified = false;
        textStatus.Path = filePath;
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, lang.Error);
      }
      finally
      {
        this.IsEnabled = true;
      }
    }


    private bool CheckDlcNumConflict()
    {
      SortedSet<string> conflictNumList = new SortedSet<string>();

      List<string> numList = new List<string>();

      numList.AddRange(dtData.Dlcs.Where(elem => elem.IsIncluded).Select(elem => elem.DlcNum));

      foreach (var dlc in dtData.Dlcs)
      {
        if (numList.Where(elem => elem == dlc.DlcNum).Count() > 1)
        {
          conflictNumList.Add(dlc.DlcNum);
        }
      }

      if (conflictNumList.Count > 0)
      {
        string text = "";

        foreach (var num in conflictNumList)
        {
          text += "\r\n" + num;
        }

        MessageWindow.Show(this, lang.BuildCancelledDlcNumDuplicated + "\r\n" + text, lang.Error);

        return false;
      }

      return true;
    }

    private string CheckErrorPreBuild(DlcData dlc)
    {
      string errorText = "";

      if (nameDB == null)
      {
        var nameDB = LoadDB(false);
        if (nameDB == null)
        {
          errorText += "\r\n- " + lang.DatabaseNotFound;
        }
        DatabaseChanged();
      }
      else
      {
        // 名前がデータベースにあるか
        foreach (var cos in dlc.Costumes)
        {
          if (!cos.IsIncluded) continue;

          string decTmcName = CharaNames[cos.ID] + "_DLCU_" + (cos.CostumeSlot + 1).ToString("D3") + ".TMC";
          if (cos.CostumeSlot > 100)
          {
            decTmcName = CharaNames[cos.ID] + "_DLC_" + (cos.CostumeSlot - 99).ToString("D3") + ".TMC";
          }
          if (Array.FindIndex(nameDB.ToArray(), elem => elem.Name == decTmcName && elem.Current) == -1)
          {
            errorText += String.Format("\r\n- " + lang.CosNameNotFoundInDatabase, CharaNames[cos.ID], cos.CostumeSlot);
          }
        }
      }

      // DLC内でスロット重複していないか
      foreach (var cos in dlc.Costumes)
      {
        if (dlc.Costumes.Where(elem => elem.ID == cos.ID && elem.CostumeSlot == cos.CostumeSlot && elem.IsIncluded).Count() > 1)
        {
          errorText += String.Format("\r\n- " + lang.CosSlotIsDuplicatedInLst, CharaNames[cos.ID], cos.CostumeSlot);
        }
      }

      // TMC/TMCL/---C/--Pの設定漏れ確認
      foreach (var cos in dlc.Costumes)
      {
        if (
          cos.IsIncluded &&
          (
            Array.FindIndex(cos.Files.ToArray(), elem => elem.ID == 0) == -1 ||
            Array.FindIndex(cos.Files.ToArray(), elem => elem.ID == 1) == -1 ||
            Array.FindIndex(cos.Files.ToArray(), elem => elem.ID == 2) == -1 ||
            Array.FindIndex(cos.Files.ToArray(), elem => elem.ID == 3) == -1
          )
        )
        {
          errorText += String.Format("\r\n- " + lang.CosRequiredFilesNotFound, CharaNames[cos.ID], cos.CostumeSlot);
        }
      }

      // ファイルの存在確認
      foreach (var cos in dlc.Costumes)
      {
        foreach (var file in cos.Files)
        {
          if (cos.IsIncluded && !String.IsNullOrEmpty(file.Path) && !File.Exists(file.Path))
          {
            errorText += String.Format("\r\n- " + lang.NotFound, file.Path);
          }
        }
      }

      // DLC番号チェック
      ulong dlcNum;
      if (!ulong.TryParse(dlc.DlcNum, out dlcNum) || dlcNum > 999999)
      {
        errorText += String.Format("\r\n- " + lang.DlcNumMustNumber6Digits, dlc.DlcNum);
      }


      return errorText;
    }

    private string CheckCautionPreBuild(DlcData dlc)
    {
      string cautionText = "";

      foreach (var cos in dlc.Costumes)
      {
        // 他DLCと重複しているなら注意
        if (cos.IsIncluded && dlcCostumeData.ContainsKey(cos.ID))
        {
          var usedList = dlcCostumeData[cos.ID].Where(elem => elem.Slot == cos.CostumeSlot && elem.DlcNum != dlc.DlcNum).ToList();
          if (usedList.Count > 0)
          {
            string usedDlc = "";
            foreach (var used in usedList)
            {
              if (usedDlc.Length > 0) usedDlc += ", ";
              usedDlc += used.DlcNum;
            }

            cautionText += String.Format("\r\n- " + lang.CosSlotIsDuplicatedWithOtherDlc, CharaNamesLocale[cos.ID], cos.CostumeSlot, usedDlc);
          }
        }
      }

      return cautionText;
    }

    private bool CheckBuildOutputPath()
    {
      if (tbPath.Text == string.Empty)
      {
        string path = SetSavePath();
        if (path != "")
        {
          dtData.OutputPath = path;
        }
        else
        {
          MessageWindow.Show(this, lang.SetSavePath, lang.Error);
          return false;
        }
      }
      else
      {
        var confirmResult = MessageWindow.Show(this, lang.ConfirmBuildDlc, lang.Confirm, lang.Build, lang.Cancel);
        if (confirmResult == MessageWindow.Result.Cancel)
        {
          return false;
        }
      }

      return true;
    }

    private bool BuildDlc()
    {
      var dlc = dgDlc.SelectedItem as DlcData;

      dlc.ResetIsAdded();

      string errorText = CheckErrorPreBuild(dlc);
      if (errorText != "")
      {
        MessageWindow.Show(this, lang.FailedToBuildDlc + "\r\n" + errorText, lang.Error);
        return false;
      }

      if (!CheckBuildOutputPath())
      {
        return false;
      }

      string cautionText = CheckCautionPreBuild(dlc);
      if (cautionText != "")
      {
        var result = MessageWindow.Show(this, lang.ConfirmBuildDlcWithProblem + "\r\n" + cautionText, lang.Confirm, lang.Build, lang.Cancel);
        if (result != MessageWindow.Result.OK)
        {
          return false;
        }
      }


      string dlcNum = BuildDlcFiles(dlc);

      if (dlcNum != null)
      {
        var dlcNumList = new List<string>();
        dlcNumList.Add(dlcNum);
        bool result = CopyDlcFiles(dlcNumList);

        string outputPath = dtData.OutputPath;
        if (outputPath[outputPath.Length - 1] != '\\') outputPath += @"\";

        if (result || outputPath == config.GameDirPath + @"DLC\") ReloadDlcCostumeData();

        return true;
      }

      return false;
    }

    private string BuildDlcs()
    {
      int failedCount = 0;
      var dlcNumList = new List<string>();

      // DLC番号重複確認
      if (!CheckDlcNumConflict())
      {
        return null;
      }

      // DLCビルド先確認
      if (!CheckBuildOutputPath())
      {
        return null;
      }

      string failedText = "";
      foreach (var dlc in dtData.Dlcs)
      {
        dlc.ResetIsAdded();

        if (dlc.IsIncluded && dlc.Costumes.Count > 0)
        {
          string dlcNum = BuildDlcFiles(dlc);

          if (CheckErrorPreBuild(dlc) == "" && dlcNum != null)
          {
            dlcNumList.Add(dlcNum);
          }
          else
          {
            failedText += String.Format("\r\n  [ {0} ]", dlc.Name);
            failedCount++;
          }
        }
      }

      if (failedText != "")
      {
        failedText = String.Format(lang.FailedToBuildDlcs, failedText, dlcNumList.Count, failedCount);
      }

      if (dlcNumList.Count > 0)
      {
        bool result = CopyDlcFiles(dlcNumList);

        string outputPath = dtData.OutputPath;
        if (outputPath[outputPath.Length - 1] != '\\') outputPath += @"\";

        if (result || outputPath == config.GameDirPath + @"DLC\") ReloadDlcCostumeData();
      }

      return failedText;
    }

    private string BuildDlcFiles(DlcData dlc)
    {
      string dlcNum = null;
      string tempDir = "";

      try
      {
        string outputPath = dtData.OutputPath;
        if (outputPath[outputPath.Length - 1] != '\\') outputPath += @"\";

        // tempディレクトリを作成
        tempDir = outputPath + @"~temp\";
        int count = 0;
        while (Directory.Exists(tempDir))
        {
          tempDir = outputPath + @"~temp" + count + @"\";
          count++;
        }
        string tempDataDir = tempDir + @"\data\";
        Directory.CreateDirectory(tempDataDir);

        string tempBcmPath = tempDir + dlc.DlcNum + ".bcm";
        string tempBinPath = tempDataDir + dlc.DlcNum + ".bin";
        string tempLnkPath = tempDataDir + dlc.DlcNum + ".lnk";
        string tempBlpPath = tempDataDir + dlc.DlcNum + ".blp";

        SaveBcm(dlc, tempBcmPath);
        var nameIndexes = SaveBin(dlc, tempBinPath);
        var fileSizes = SaveLnk(dlc, tempLnkPath, nameIndexes.Count);
        SaveBlp(tempBlpPath, nameIndexes, fileSizes);


        // 問題無ければ移動
        string dlcDir = outputPath + dlc.DlcNum + @"\";
        string dlcDataDir = dlcDir + @"\data\";

        string bcmPath = dlcDir + dlc.DlcNum + ".bcm";
        string binPath = dlcDataDir + dlc.DlcNum + ".bin";
        string lnkPath = dlcDataDir + dlc.DlcNum + ".lnk";
        string blpPath = dlcDataDir + dlc.DlcNum + ".blp";

        if (!Directory.Exists(dlcDataDir)) Directory.CreateDirectory(dlcDataDir);
        if (File.Exists(bcmPath)) File.Delete(bcmPath);
        if (File.Exists(binPath)) File.Delete(binPath);
        if (File.Exists(lnkPath)) File.Delete(lnkPath);
        if (File.Exists(blpPath)) File.Delete(blpPath);

        File.Move(tempBcmPath, bcmPath);
        File.Move(tempBinPath, binPath);
        File.Move(tempLnkPath, lnkPath);
        File.Move(tempBlpPath, blpPath);

        dlcNum = dlc.DlcNum;
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, lang.Error);
      }
      finally
      {
        if (Directory.Exists(tempDir)) Directory.Delete(tempDir, true);
      }

      return dlcNum;
    }

    private bool CopyDlcFiles(List<string> dlcNumList)
    {
      string gameDlcDir = config.GameDirPath + @"DLC\";

      string outputPath = dtData.OutputPath;
      if (outputPath[outputPath.Length - 1] != '\\') outputPath += @"\";

      if (!config.EnableCopyToDlcFolder || !Directory.Exists(gameDlcDir) || outputPath == gameDlcDir) return false;

      var confirmResult = MessageWindow.Show(this, lang.ConfirmCopyDlcFiles, lang.Confirm, lang.Yes, lang.No);
      if (confirmResult == MessageWindow.Result.Cancel)
      {
        return false;
      }

      try
      {
        foreach (var dlcNum in dlcNumList)
        {
          string dlcDir = gameDlcDir + @"\" + dlcNum + @"\";
          string dlcDataDir = dlcDir + @"\data\";

          string bcmPath = dlcDir + dlcNum + ".bcm";
          string binPath = dlcDataDir + dlcNum + ".bin";
          string lnkPath = dlcDataDir + dlcNum + ".lnk";
          string blpPath = dlcDataDir + dlcNum + ".blp";

          string outputDir = outputPath + dlcNum + @"\";
          string outputDataNum = outputDir + @"\data\" + dlcNum;


          if (!Directory.Exists(dlcDataDir)) Directory.CreateDirectory(dlcDataDir);
          if (File.Exists(bcmPath)) File.Delete(bcmPath);
          if (File.Exists(binPath)) File.Delete(binPath);
          if (File.Exists(lnkPath)) File.Delete(lnkPath);
          if (File.Exists(blpPath)) File.Delete(blpPath);

          File.Copy(outputDir + dlcNum + ".bcm", bcmPath);
          File.Copy(outputDataNum + ".bin", binPath);
          File.Copy(outputDataNum + ".lnk", lnkPath);
          File.Copy(outputDataNum + ".blp", blpPath);
        }

        return true;
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, lang.Error);
        return false;
      }
    }


    private string SetSavePath()
    {
      var dlg = new CommonOpenFileDialog();
      dlg.IsFolderPicker = true;
      dlg.EnsureReadOnly = false;
      dlg.AllowNonFileSystemItems = false;
      dlg.Title = lang.SelectFolderToSaveDlcFolder;

      dlg.InitialDirectory = currentDlcFolder;

      if (dlg.ShowDialog() == CommonFileDialogResult.Ok)
      {
        return dlg.FileName;
      }
      else
      {
        return "";
      }
    }

    private void Modified()
    {
      if (!modified)
      {
        modified = true;
        textStatus.Path += "*";
      }
    }

    public void ChangeLanguage(string language)
    {
      // 言語切り替え
      lang = Lang.Localized.SetLanguage(this, language, defaultLang);
      MessageWindow.SetLang(lang);

      commandManager.BuildHistory();

      SetCharaNamesLocale();

      CharaMenuInit();

      if (dtData == null) return;

      foreach (var dlc in dtData.Dlcs)
      {
        dlc.CheckCostumeSlot();
        dlc.CheckDuplicatedCharacter();

        foreach (var cos in dlc.Costumes)
          cos.CheckFiles(editDefault);
      }

      if (dtData.Dlc != null)
      {
        var dlc = dtData.Dlc;
        dgDlc.SelectedItem = null;
        dgDlc.SelectedItem = dlc;
      }
    }



    #region Copy and Paste

    private void dlcDataCopyCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (dgDlc.SelectedItems.Count > 0)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void dlcDataCopyCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var dataDict = new Dictionary<int, DlcData>();

      foreach (var item in dgDlc.SelectedItems)
      {
        var data = item as DlcData;

        int index = dtData.Dlcs.IndexOf(data);

        if (data != null)
        {
          dataDict.Add(index, data);
        }
      }

      var dataList = new List<DlcData>();

      foreach (var pair in dataDict.OrderBy(p => p.Key))
      {
        dataList.Add(pair.Value);
      }

      if (dataList.Count > 0)
      {
        BinaryFormatter bf = new BinaryFormatter();
        MemoryStream ms = new MemoryStream();
        bf.Serialize(ms, dataList);
        Clipboard.SetDataObject(ms);
      }

      panelClipboard.Visibility = Visibility.Visible;
      tbClipboard.Text = lang.DlcData;
    }

    private void dlcDataPasteCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      clipboardDlcData = null;
      var data = GetDataFromClipboard();
      if (data is List<DlcData>)
        clipboardDlcData = data as List<DlcData>;

      if (clipboardDlcData == null)
      {
        e.CanExecute = false;
      }
      else
      {

        e.CanExecute = true;
      }
    }
    private void dlcDataPasteCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      DlcDataPaste(clipboardDlcData);
    }

    private void cosDataCopyCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (dgCos.SelectedItems.Count > 0)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void cosDataCopyCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var dlc = dgDlc.SelectedItem as DlcData;
      if (dlc == null) return;

      var dataDict = new Dictionary<int, Costume>();

      foreach (var item in dgCos.SelectedItems)
      {
        var data = item as Costume;

        int index = dlc.Costumes.IndexOf(data);

        if (data != null)
        {
          dataDict.Add(index, data);
        }
      }

      var dataList = new List<Costume>();

      foreach (var pair in dataDict.OrderBy(p => p.Key))
      {
        dataList.Add(pair.Value);
      }

      if (dataList.Count > 0)
      {
        BinaryFormatter bf = new BinaryFormatter();
        MemoryStream ms = new MemoryStream();
        bf.Serialize(ms, dataList);
        Clipboard.SetDataObject(ms);
      }

      panelClipboard.Visibility = Visibility.Visible;
      tbClipboard.Text = lang.CostumeData;
    }

    private void cosDataPasteCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      clipboardCosData = null;
      var data = GetDataFromClipboard();
      if (data is List<Costume>)
        clipboardCosData = data as List<Costume>;

      if (dgDlc.SelectedItem as DlcData == null || clipboardCosData == null)
        e.CanExecute = false;
      else
        e.CanExecute = true;
    }
    private void cosDataPasteCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      CosDataPaste(clipboardCosData);
    }

    private void hairStyleCopyCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (dgHStyles.SelectedItems.Count > 0)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void hairStyleCopyCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var cos = dgCos.SelectedItem as Costume;
      if (cos == null) return;

      var dataDict = new Dictionary<int, HairStyle>();

      foreach (var item in dgHStyles.SelectedItems)
      {
        var data = item as HairStyle;

        int index = cos.HStyles.IndexOf(data);

        if (data != null)
        {
          dataDict.Add(index, data);
        }
      }

      var dataList = new List<HairStyle>();

      foreach (var pair in dataDict.OrderBy(p => p.Key))
      {
        dataList.Add(pair.Value);
      }

      if (dataList.Count > 0)
      {
        BinaryFormatter bf = new BinaryFormatter();
        MemoryStream ms = new MemoryStream();
        bf.Serialize(ms, dataList);
        Clipboard.SetDataObject(ms);
      }

      panelClipboard.Visibility = Visibility.Visible;
      tbClipboard.Text = lang.HairStyleData;
    }

    private void hairStylePasteCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      clipboardHStyleData = null;
      var data = GetDataFromClipboard();
      if (data is List<HairStyle>)
        clipboardHStyleData = data as List<HairStyle>;

      if (dgCos.SelectedItem as Costume == null || clipboardHStyleData == null)
        e.CanExecute = false;
      else
        e.CanExecute = true;
    }
    private void hairStylePasteCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      HairStylePaste(clipboardHStyleData);
    }

    private void cosFilesCopyCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (dgFiles.SelectedItems.Count > 0)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void cosFilesCopyCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      string text = "";

      foreach (var item in dgFiles.SelectedItems)
      {
        var cosFile = item as CostumeFile;

        if (text != "") text += "\r\n";
        if (!String.IsNullOrEmpty(cosFile.Path)) text += cosFile.Path;
      }

      if (String.IsNullOrEmpty(text)) return;

      Clipboard.SetDataObject(text, true);

      panelClipboard.Visibility = Visibility.Visible;
      tbClipboard.Text = lang.FileData;
    }

    private void cosFilesPasteCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      clipboardCosFilesData = null;
      var data = GetDataFromClipboard();
      if (data is List<string>)
        clipboardCosFilesData = data as List<string>;

      if (dgCos.SelectedItem as Costume == null || clipboardCosFilesData == null)
        e.CanExecute = false;
      else
        e.CanExecute = true;
    }
    private void cosFilesPasteCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      CosFilesPaste(clipboardCosFilesData);
    }


    //Undoable OK
    private void DlcDataPaste(List<DlcData> data)
    {
      if (dtData == null || data.Count == 0) return;

      doing = true;

      List<DlcData> prevSelectedDlcs = new List<DlcData>();
      foreach (var item in dgDlc.SelectedItems)
      {
        prevSelectedDlcs.Add(item as DlcData);
      }

      int startIndex = dgDlc.SelectedIndex + 1;
      if (dgDlc.SelectedIndex == -1)
        startIndex = dgDlc.Items.Count;

      commandManager.Do(new Command(
        nameof(lang.DlcPaste),
        () => {
          dgDlc.SelectedIndex = -1;
          int index = startIndex;
          foreach (var dlc in data)
          {
            dtData.Dlcs.Insert(index, dlc);
            dgDlc.SelectedItems.Add(dlc);
            index++;

            if (dlc.Type == Const.Default) editDefault = true;
            dlc.CheckCostumeCount();
            dlc.CheckCostumeSlot();
            dlc.CheckDuplicatedCharacter();
          }
        },
        () => {
          foreach (var dlc in data)
          {
            dtData.Dlcs.Remove(dlc);
            foreach (var prevSelectedDlc in prevSelectedDlcs)
            {
              dgDlc.SelectedItems.Add(prevSelectedDlc);
            }
          }
        },
        () => {
        }));


      Modified();

      doing = false;
    }

    //Undoable OK
    private void CosDataPaste(List<Costume> data)
    {
      var dlc = dgDlc.SelectedItem as DlcData;
      if (dlc == null || data.Count == 0) return;

      doing = true;

      List<Costume> prevSelectedCostumes = new List<Costume>();
      foreach (var item in dgCos.SelectedItems)
      {
        prevSelectedCostumes.Add(item as Costume);
      }

      int startIndex = dgCos.SelectedIndex + 1;
      if (dgCos.SelectedIndex == -1)
        startIndex = dgCos.Items.Count;


      commandManager.Do(new Command(
        nameof(lang.CostumePaste),
        () => {
          dgCos.SelectedIndex = -1;
          int index = startIndex;
          foreach (var cos in data)
          {
            cos.SetCostumeSlots();
            cos.CostumeSlot = GetUnusedCostumeSlot(cos, false);

            dlc.Costumes.Insert(index, cos);
            dgCos.SelectedItems.Add(cos);
            index++;
          }
        },
        () => {
          foreach (var cos in data)
          {
            dlc.Costumes.Remove(cos);
            foreach (var prevSelectedCostume in prevSelectedCostumes)
            {
              dgCos.SelectedItems.Add(prevSelectedCostume);
            }
          }
        },
        () => {
          dlc.CheckCostumeCount();
          dlc.CheckCostumeSlot();
          dlc.CheckDuplicatedCharacter();
        }));


      Modified();

      doing = false;
    }

    //Undoable OK
    private void HairStylePaste(List<HairStyle> data)
    {
      var cos = dgCos.SelectedItem as Costume;
      if (cos == null || data.Count == 0) return;

      doing = true;

      List<HairStyle> prevHStyles = new List<HairStyle>();
      List<HairStyle> prevSelectedHStyles = new List<HairStyle>();
      List<HairStyle> redoHStyles = new List<HairStyle>();
      List<HairStyle> redoSelectedHStyles = new List<HairStyle>();

      foreach (var style in cos.HStyles)
      {
        var newStyle = style.Clone();
        prevHStyles.Add(newStyle);
        if (dgHStyles.SelectedItems.Contains(style))
          prevSelectedHStyles.Add(newStyle);
      }

      var dataDict = new Dictionary<int, HairStyle>();

      foreach (var item in dgHStyles.SelectedItems)
      {
        var hairStyleData = item as HairStyle;

        int hairStyleIndex = cos.HStyles.IndexOf(hairStyleData);

        if (data != null)
        {
          dataDict.Add(hairStyleIndex, hairStyleData);
        }
      }

      int selIndex = 0;
      int index = 0;
      foreach (var pair in dataDict.OrderBy(p => p.Key))
      {
        pair.Value.Hair = data[index].Hair;
        pair.Value.Face = data[index].Face;
        index++;
        selIndex = pair.Key;
        if (selIndex++ >= cos.HStyles.Count || index >= data.Count)
        {
          break;
        }
      }

      if (dgHStyles.SelectedItems.Count == 0) selIndex = cos.HStyles.Count;

      for (int i = 0; cos.HStyles.Count < 8 && index + i < data.Count; i++)
      {
        HairStyle newStyle = new HairStyle(data[index + i].Hair, data[index + i].Face);
        cos.HStyles.Insert(selIndex + i, newStyle);
        dgHStyles.SelectedItems.Add(newStyle);
      }

      foreach (var style in cos.HStyles)
      {
        var newStyle = style.Clone();
        redoHStyles.Add(newStyle);
        if (dgHStyles.SelectedItems.Contains(style))
          redoSelectedHStyles.Add(newStyle);
      }


      commandManager.Do(new Command(
        nameof(lang.HairStylePaste),
        () => {
        },
        () => {
          dgCos.SelectedItem = cos;
          if (cos.HStyles.Count > 0) cos.HStyles.Clear();
          foreach (var style in redoHStyles)
          {
            var newStyle = style;
            cos.HStyles.Add(newStyle);
            if (redoSelectedHStyles.Contains(style)) dgHStyles.SelectedItems.Add(newStyle);
          }
        },
        () => {
          dgCos.SelectedItem = cos;
          if (cos.HStyles.Count > 0) cos.HStyles.Clear();
          foreach (var style in prevHStyles)
          {
            var newStyle = style;
            cos.HStyles.Add(newStyle);
            if (prevSelectedHStyles.Contains(style)) dgHStyles.SelectedItems.Add(newStyle);
          }
        },
        () => {
          cos.ResetHairType();
        }));

      Modified();

      doing = false;
    }

    //Undoable OK
    private void CosFilesPaste(List<string> data)
    {
      var cos = dgCos.SelectedItem as Costume;
      if (cos == null) return;

      doing = true;

      var files = new List<string>();

      Uri u;
      foreach (var text in data as List<string>)
      {
        if (!Uri.TryCreate(text, UriKind.Absolute, out u) || !u.IsFile) continue;

        files.Add(text);
      }

      if (files.Count > 0) OpenCosFile(cos, files, nameof(lang.FilePaste));

      Modified();

      doing = false;
    }

    private void globalPasteCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (doing)
        e.CanExecute = false;
      else
        e.CanExecute = true;
    }
    private void globalPasteCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var data = GetDataFromClipboard();

      if (data is List<DlcData>)
      {
        DlcDataPaste(data as List<DlcData>);
      }
      else if (data is List<Costume>)
      {
        CosDataPaste(data as List<Costume>);
      }
      else if (data is List<HairStyle>)
      {
        HairStylePaste(data as List<HairStyle>);
      }
      else if (data is List<string>)
      {
        CosFilesPaste(data as List<string>);
      }
    }

    private object GetDataFromClipboard()
    {
      try
      {
        IDataObject clipboardData = Clipboard.GetDataObject();
        if (clipboardData != null)
        {
          if (clipboardData.GetDataPresent(typeof(MemoryStream)))
          {
            using (MemoryStream stream = clipboardData.GetData(typeof(MemoryStream)) as MemoryStream)
            {
              BinaryFormatter bf = new BinaryFormatter();
              return bf.Deserialize(stream);
            }
          }
        }
        string text = Clipboard.GetText();
        if (Clipboard.ContainsFileDropList())
        {
          System.Collections.Specialized.StringCollection files = Clipboard.GetFileDropList();
          if (files != null) return files.Cast<string>().ToList();
        }
        if (!String.IsNullOrEmpty(text)) return text.Split(new string[] { "\r\n" }, StringSplitOptions.None).ToList();

        return null;
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, lang.Error);
        return null;
      }
    }

    private void CheckClipboardData()
    {
      panelClipboard.Visibility = Visibility.Visible;

      var data = GetDataFromClipboard();

      if (data is List<DlcData>)
      {
        tbClipboard.Text = lang.DlcData;
      }
      else if (data is List<Costume>)
      {
        tbClipboard.Text = lang.CostumeData;
      }
      else if (data is List<HairStyle>)
      {
        tbClipboard.Text = lang.HairStyleData;
      }
      else if (data is List<string>)
      {
        tbClipboard.Text = lang.TextData;
      }
      else
      {
        tbClipboard.Text = "";
        panelClipboard.Visibility = Visibility.Collapsed;
      }
    }

    #endregion



    #region DLC

    private void dgDlc_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      DlcData dlc;
      try
      {
        if (dgDlc.SelectedItems.Count != 1 || IsDragging)
        {
          ClearCostumeUI();
          return;
        }

        dlc = dgDlc.SelectedItem as DlcData;

        SelectDlc(dlc);
      }
      catch (Exception ex)
      {
        MessageWindow.Show(this, ex.Message + "\r\n\r\n" + ex.StackTrace, lang.Error);
      }
    }

    private async void SelectDlc(DlcData dlc)
    {
      if (dlc == null) return;

      dtData.Dlc = dlc;
      editBcm = false;
      editDefault = false;

      if (dgCos.SelectedIndex == -1)
      {
        if (dlc.Costumes.Count > 0)
        {
          cosAdding = true;
          dgCos.SelectedIndex = 0;
        }
        else
        {
          ClearDataUI();
        }
      }

      if (dlc.Type == Const.Bcm)
      {
        editBcm = true;

        dgcCosComment.IsReadOnly = true;
        dgcSlotNum.IsReadOnly = true;
        cbDisplayThumb.IsChecked = false;

        dgCos.SelectionMode = DataGridSelectionMode.Single;
      }
      else
      {
        await Task.Run(() => {
          foreach (var cos in dlc.Costumes)
          {
            cos.SetCostumeSlots();
          }

          if (dlc.Type == Const.Default)
          {
            editDefault = true;

            dlc.CheckDuplicatedCharacter();
          }
          else
          {
            dlc.CheckCostumeCount();
            dlc.CheckCostumeSlot();
          }

          foreach (var cos in dlc.Costumes)
          {
            cos.SetThumbnail();
            cos.SetCFlags();
            cos.CheckFiles(editDefault);
            if (cos.Error)
              dlc.Error = true;
            else if (cos.Caution)
              dlc.Caution = true;
          }
        });

        dgCos.SelectionMode = DataGridSelectionMode.Extended;
      }
    }

    private void dgDlc_BeginningEdit(object sender, DataGridBeginningEditEventArgs e)
    {
      IsEditing = true;
      if (IsDragging) ResetDragDrop();

      var dataGrid = sender as DataGrid;
      FrameworkElement contentElement = dataGrid.CurrentCell.Column.GetCellContent(dataGrid.CurrentCell.Item);
      var tb = contentElement as TextBlock;

      biginningText = tb.Text;
    }

    private void dgDlc_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
    {
      // for Drag and Drop
      IsEditing = false;

      var tb = e.EditingElement as TextBox;
      if (tb == null || biginningText == tb.Text) return;

      var dataGrid = sender as DataGrid;
      string prevText = biginningText;
      string curText = tb.Text;

      var dlc = dataGrid.SelectedItem as DlcData;
      if (dlc == null) return;

      Modified();

      if (e.Column.SortMemberPath == "Name")
      {
        commandManager.Do(new Command(
          nameof(lang.DlcChangeName),
          () => {
          },
          () => {
            dgDlc.SelectedItem = dlc;
            dlc.Name = curText;
          },
          () => {
            dgDlc.SelectedItem = dlc;
            dlc.Name = prevText;
          },
          () => {
          }));
      }
      else if (e.Column.SortMemberPath == "DlcNum")
      {
        commandManager.Do(new Command(
          nameof(lang.DlcChangeNumber),
          () => {
          },
          () => {
            dgDlc.SelectedItem = dlc;
            dlc.DlcNum = curText;
          },
          () => {
            dgDlc.SelectedItem = dlc;
            dlc.DlcNum = prevText;
          },
          () => {
          }));
      }
      else if (e.Column.SortMemberPath == "Comment")
      {
        commandManager.Do(new Command(
          nameof(lang.DlcChangeComment),
          () => {
          },
          () => {
            dgDlc.SelectedItem = dlc;
            dlc.Comment = curText;
          },
          () => {
            dgDlc.SelectedItem = dlc;
            dlc.Comment = prevText;
          },
          () => {
          }));
      }
    }

    private void dgDlc_ContextMenuOpening(object sender, ContextMenuEventArgs e)
    {
      DataGrid dataGrid = sender as DataGrid;

      DataGrid_ContextMenuOpened = true;
    }

    private void dgDlc_ContextMenuClosing(object sender, ContextMenuEventArgs e)
    {
      DataGrid_ContextMenuOpened = false;
    }

    private void dlcDuplicateCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (dgDlc.SelectedItems.Count == 1)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void dlcDuplicateCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      DlcDuplicate();
    }

    private void dlcDeleteCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (dgDlc.SelectedItems.Count > 0)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void dlcDeleteCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      DlcDelete();
    }

    private void dlcsDecideSortCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      var view = CollectionViewSource.GetDefaultView(dgDlc.ItemsSource);
      if (view != null && view.SortDescriptions.Count > 0)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void dlcsDecideSortCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      DlcsDecideSort(true);
    }

    private void extractFilesCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      var dlc = dgDlc.SelectedItem as DlcData;

      if (nameDB != null && dgDlc.SelectedItems.Count == 1 && CheckDlcExtractable(dlc))
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void extractFilesCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      this.IsEnabled = false;

      var result = SelectFolderForExtractFiles(lang.SelectFolderToExtractFiles);
      if (!String.IsNullOrEmpty(result))
      {
        ExtractDlcFiles(result, false);
      }

      this.IsEnabled = true;
    }

    private void extractFilesWithCreateDirCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      e.CanExecute = false;

      if (nameDB == null) return;

      foreach (var item in dgDlc.SelectedItems)
      {
        var dlc = item as DlcData;

        if (CheckDlcExtractable(dlc))
        {
          e.CanExecute = true;
          return;
        }
      }
    }
    private void extractFilesWithCreateDirCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      this.IsEnabled = false;

      var result = SelectFolderForExtractFiles(lang.SelectFolderToExtractFilesWithCreateDir);
      if (!String.IsNullOrEmpty(result))
      {
        ExtractDlcFiles(result, true);
      }

      this.IsEnabled = true;
    }


    //Undoable OK
    private void DlcAdd(string dlcNum)
    {
      Modified();

      editBcm = false;
      ClearCostumeUI();

      var dlc = new DlcData();
      dlc.Name = dlcNum;
      dlc.DlcNum = dlcNum;

      commandManager.Do(new Command(
        nameof(lang.DlcAdd),
        () => {
          dtData.Dlcs.Add(dlc);
          dgDlc.SelectedItem = dlc;
        },
        () => {
          dtData.Dlcs.Remove(dlc);
        },
        () => {
        }));
    }

    //Undoable OK
    private void DlcDuplicate()
    {
      var dlc = dgDlc.SelectedItem as DlcData;
      DlcData dlcEntry = dlc.Clone();

      commandManager.Do(new Command(
        nameof(lang.DlcDuplicate),
        () => {
          int index = dtData.Dlcs.IndexOf(dlc) + 1;
          dtData.Dlcs.Insert(index, dlcEntry);
          dgDlc.SelectedIndex = index;
        },
        () => {
          dtData.Dlcs.Remove(dlcEntry);
        },
        () => {
          if (dlcEntry.Type == Const.Default) editDefault = true;
          dlcEntry.CheckDuplicatedCharacter();
        }));

      Modified();
    }

    //Undoable OK
    private void DlcDelete()
    {
      SortedDictionary<int, DlcData> selDlcs = new SortedDictionary<int, DlcData>();

      foreach (var item in dgDlc.SelectedItems)
      {
        var dlc = item as DlcData;

        var idx = dtData.Dlcs.IndexOf(dlc);

        selDlcs.Add(idx, dlc);
      }

      commandManager.Do(new Command(
        nameof(lang.DlcDelete),
        () => {
          foreach (var cos in selDlcs.Values.Reverse())
          {
            dtData.Dlcs.Remove(cos);
          }

          int index = selDlcs.Keys.Last();

          if (dgDlc.Items.Count == 0)
          {
            dgDlc.SelectedIndex = -1;
          }
          else if (index == dgDlc.Items.Count)
          {
            dgDlc.SelectedIndex = index - 1;
          }
          else
          {
            dgDlc.SelectedIndex = index;
          }
        },
        () => {
          if (dgDlc.SelectedItems.Count > 0) dgDlc.SelectedItems.Clear();

          foreach (var pair in selDlcs)
          {
            dtData.Dlcs.Insert(pair.Key, pair.Value);
            dgDlc.SelectedItems.Add(pair.Value);
          }
        },
        () => {
          if (dgDlc.SelectedItem != null)
          {
            SetSelectChanged(dgDlc, dgDlc.SelectedItem, 1);

            var dlc = dgDlc.SelectedItem as DlcData;

            if (dlc != null)
            {
              dlc.CheckCostumeCount();
              dlc.CheckCostumeSlot();
            }
          }

          dgDlc.Focus();
        }));

      Modified();
    }

    //Undoable OK
    private void DlcsDecideSort(bool addHistory)
    {
      var view = CollectionViewSource.GetDefaultView(dgDlc.ItemsSource);

      if (view.SortDescriptions.Count == 0) return;

      var views = view.OfType<DlcData>();


      // 実行前の情報を取得
      var sortDirections = new List<System.ComponentModel.ListSortDirection?>(); 
      foreach (var col in dgDlc.Columns) sortDirections.Add(col.SortDirection);
      var sortDescriptions = new List<System.ComponentModel.SortDescription>();
      foreach (var item in view.SortDescriptions) sortDescriptions.Add(item);
      var prevSorted = new List<DlcData>(dtData.Dlcs);


      var selected = dgDlc.SelectedItems.Cast<object>().ToList();
      var sorted = new List<DlcData>(views.ToList());

      foreach (var col in dgDlc.Columns) col.SortDirection = null;
      view.SortDescriptions.Clear();
      for (int i = 0; i < dtData.Dlcs.Count; i++)
      {
        dtData.Dlcs[i] = sorted[i];
      }

      if (addHistory)
      {
        commandManager.Do(new Command(
          nameof(lang.DlcDecideSort),
          () => {
          },
          () => {
            for (int i = 0; i < dtData.Dlcs.Count; i++)
            {
              dtData.Dlcs[i] = prevSorted[i];
            }
            foreach (var item in sortDescriptions) view.SortDescriptions.Add(item);
            foreach (var pair in Enumerable.Zip(dgDlc.Columns, sortDirections, (a, b) => new { a, b }))
            {
              pair.a.SortDirection = pair.b;
            }
          },
          () => {
            if (dgDlc.SelectionMode == DataGridSelectionMode.Extended)
              foreach (var item in selected) dgDlc.SelectedItems.Add(item);
          }));
      }
    }

    private bool CheckDlcExtractable(DlcData dlc)
    {
      if (String.IsNullOrEmpty(dlc.FilePath)) return false;

      var dirPath = Path.GetDirectoryName(dlc.FilePath);

      if (
        Directory.Exists(dirPath + @"\data") &&
        File.Exists(dirPath + @"\data\" + dlc.DlcNum + ".bin") &&
        File.Exists(dirPath + @"\data\" + dlc.DlcNum + ".blp") &&
        File.Exists(dirPath + @"\data\" + dlc.DlcNum + ".lnk")
      ) return true;

      return false;
    }

    private string SelectFolderForExtractFiles(string title)
    {
      var dlg = new CommonOpenFileDialog();
      dlg.IsFolderPicker = true;
      dlg.EnsureReadOnly = false;
      dlg.AllowNonFileSystemItems = false;
      dlg.Title = title;

      if (String.IsNullOrEmpty(currentBcmFile))
      {
        var dlc = dgDlc.SelectedItem as DlcData;
        dlg.InitialDirectory = dlc.FilePath;
      }
      else
      {
        dlg.InitialDirectory = currentBcmFile;
      }

      if (dlg.ShowDialog() == CommonFileDialogResult.Ok)
        return dlg.FileName;
      else
        return null;
    }

    private void ExtractDlcFiles(string path, bool createDir)
    {
      Dictionary<string, DlcData> extractPaths = new Dictionary<string, DlcData>();
      List<string> existedPaths = new List<string>();

      foreach (var item in dgDlc.SelectedItems)
      {
        var dlc = item as DlcData;

        string extractPath = path;

        if (createDir)
        {
          extractPath += @"\" + dlc.DlcNum;
        }

        string basePath = extractPath;
        int count = 1;
        while (extractPaths.ContainsKey(extractPath))
        {
          count++;
          extractPath = basePath + "_" + count;
        }

        if (createDir)
        {
          if (Directory.Exists(extractPath)) existedPaths.Add(extractPath);
        }

        extractPaths.Add(extractPath, dlc);
      }

      if (existedPaths.Count > 0)
      {
        string existed = "";

        foreach (var existedPath in existedPaths)
        {
          existed += existedPath + "\r\n";
        }

        var result = MessageWindow.Show(this, String.Format(lang.ConfirmFolderExistExtractFiles, existed), lang.Confirm, lang.Extract, lang.Cancel);
        if (result != MessageWindow.Result.OK)
        {
          return;
        }
      }

      var errorFileList = new List<string>();

      foreach (var pair in extractPaths)
      {
        var dlcDirPath = Path.GetDirectoryName(pair.Value.FilePath);

        errorFileList.AddRange(ExtractFiles(dlcDirPath + @"\data\" + pair.Value.DlcNum, pair.Key));
      }

      if (errorFileList.Count > 0)
      {
        string fileNames = "";
        foreach (string name in errorFileList) fileNames += "\r\n" + name;

        MessageWindow.Show(this, lang.FilesExtracted + "\r\n\r\n" + lang.FailedExtractedFiles + "\r\n" + fileNames, lang.Error);
      }
      else
      {
        ShowTextBlockMessage(lang.FilesExtracted);
      }
    }

    #endregion



    #region Costume

    public void CharaMenuInit()
    {
      if (menuAddFemale.Items.Count > 0) menuAddFemale.Items.Clear();
      if (menuAddMale.Items.Count > 0) menuAddMale.Items.Clear();
      if (menuInsFemale.Items.Count > 0) menuInsFemale.Items.Clear();
      if (menuInsMale.Items.Count > 0) menuInsMale.Items.Clear();
      if (menuChangeFemale.Items.Count > 0) menuChangeFemale.Items.Clear();
      if (menuChangeMale.Items.Count > 0) menuChangeMale.Items.Clear();

      var sorted = DefaultSort;
      if (lang.CultureName == "ja-JP")
        sorted = DefaultSortLocale;

      Style style = this.FindResource("NonShortcutMenuItemStyle") as Style;
      foreach (byte ID in sorted)
      {
        string charaName = lang.AddedCharacter + ID.ToString();
        if (CharaNamesLocale.ContainsKey(ID))
        {
          charaName = CharaNamesLocale[ID];
        }

        MenuItem newMenuItem = new MenuItem();
        newMenuItem.Header = charaName;
        newMenuItem.Name = "Add_" + ID;
        newMenuItem.Width = 120;
        newMenuItem.Click += AddCostume_Click;
        if (FemaleIDs.Contains(ID))
          menuAddFemale.Items.Add(newMenuItem);
        else
          menuAddMale.Items.Add(newMenuItem);

        newMenuItem = new MenuItem();
        newMenuItem.Header = charaName;
        newMenuItem.Name = "Ins_" + ID;
        newMenuItem.Width = 120;
        newMenuItem.Click += AddCostume_Click;
        if (FemaleIDs.Contains(ID))
          menuInsFemale.Items.Add(newMenuItem);
        else
          menuInsMale.Items.Add(newMenuItem);

        newMenuItem = new MenuItem();
        newMenuItem.Header = charaName;
        newMenuItem.Name = "Change_" + ID;
        newMenuItem.Width = 120;
        newMenuItem.Click += ChangeChara_Click;
        newMenuItem.Style = style;
        if (FemaleIDs.Contains(ID))
          menuChangeFemale.Items.Add(newMenuItem);
        else
          menuChangeMale.Items.Add(newMenuItem);
      }
    }

    private void dgCos_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (dgCos.SelectedIndex == -1 || dgCos.SelectedItems.Count > 1)
      {
        ClearDataUI();
        return;
      }

      if (cosAdding && dgCos.SelectedItem != null)
      {
        SetSelectChanged(dgCos, dgCos.SelectedItem, 1);
        cosAdding = false;
      }

      var cos = dgCos.SelectedItem as Costume;
      if (cos == null) return;
      dtData.Costume = cos;

      cos.ResetHairType();
    }

    private void dgCos_PreviewMouseDown(object sender, MouseButtonEventArgs e)
    {
      bool alreadySelected = false;

      if (
        isDropDownOpen ||
        (Keyboard.Modifiers & ModifierKeys.Shift) > 0 ||
        (Keyboard.Modifiers & ModifierKeys.Control) > 0
      ) return;

      Point position = e.GetPosition(dgCos);
      var row = UIHelpers.TryFindFromPoint<DataGridRow>(dgCos, position);
      var cb = UIHelpers.TryFindFromPoint<CheckBox>(dgCos, position);
      var tb = UIHelpers.TryFindFromPoint<TextBox>(dgCos, position);
      var cmb = UIHelpers.TryFindFromPoint<ComboBox>(dgCos, position);

      if (row == null)
      {
        return;
      }

      var dlc = dgDlc.SelectedItem as DlcData;

      if (cb != null)
      {

        if (dgCos.SelectedItems.Contains(row.Item))
        {
          cb.IsChecked = !cb.IsChecked;
          ChangeIsIncluded(cb);
          dlc.CheckCostumeCount();
          dlc.CheckCostumeSlot();
          e.Handled = true;
          return;
        }
        else
        {
          var cos = row.Item as Costume;
          cos.CheckFiles(editDefault);
          dlc.CheckCostumeCount();
          dlc.CheckCostumeSlot();
        }
      }

      if (cbDisplayThumb.IsChecked != true)
      {
        return;
      }

      if (dgCos.SelectedItems.Contains(row.Item))
      {
        alreadySelected = true;
      }

      if (dgCos.SelectedItems.Count != 1 && alreadySelected)
      {
        e.Handled = true;
      }

      if (dgCos.SelectedItems.Count > 1)
      {
        if (!dgCos.SelectedItems.Contains(row.Item))
        {
          dgCos.SelectedItems.Clear();
          dgCos.SelectedItem = row.Item;
          dgCos.Focus();
          row.Focus();
          SetShiftSelectBase(dgCos, row, 1);
        }
        else
        {
          alreadySelected = false;
        }
      }

      if (tb != null && !alreadySelected)
      {
        if (!tb.IsFocused) tb.Focus();
      }

      if (cmb != null && !alreadySelected)
      {
        if (!cmb.IsFocused)
        {
          cmb.Focus();
          cmb.IsDropDownOpen = true;
        }
      }
    }

    private void dgCos_BeginningEdit(object sender, DataGridBeginningEditEventArgs e)
    {
      IsEditing = true;
      if (IsDragging) ResetDragDrop();

      var dataGrid = sender as DataGrid;

      var curCellInfo = dataGrid.CurrentCell;

      dataGrid.ScrollIntoView(curCellInfo.Item);
      FrameworkElement contentElement = curCellInfo.Column.GetCellContent(curCellInfo.Item);
      if (contentElement == null)
      {
        return;
      }

      var tblock = contentElement as TextBlock;
      if (tblock != null)
      {
        biginningText = tblock.Text;
        return;
      }

      var dataGridCell = contentElement.Parent as DataGridCell;
      if (dataGridCell == null)
      {
        return;
      }


      var tb = dataGridCell.Descendants<TextBox>().FirstOrDefault();

      if (tb == null || tb.Name != "PART_EditableTextBox") return;

      tb.Focus();
      tb.SelectionStart = 0;
      tb.SelectAll();

      e.Cancel = true;
    }

    //Undoable OK
    private void dgCos_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
    {
      // for Drag and Drop
      IsEditing = false;

      var tb = e.EditingElement as TextBox;
      if (tb == null || biginningText == tb.Text) return;

      var dataGrid = sender as DataGrid;
      string prevText = biginningText;
      string redoText = tb.Text;

      var dlc = dtData.Dlc;
      var cos = dtData.Costume;
      if (dlc == null || cos == null) return;

      Modified();

      if (e.Column.SortMemberPath == "Comment")
      {
        commandManager.Do(new Command(
        nameof(lang.CostumeChangeComment),
          () => {
          },
          () => {
            dgDlc.SelectedItem = dlc;
            cos.Comment = redoText;
            dgCos.SelectedItem = cos;
          },
          () => {
            dgDlc.SelectedItem = dlc;
            cos.Comment = prevText;
            dgCos.SelectedItem = cos;
          },
          () => {
            dlc.CheckCostumeSlot();

            SetSelectChanged(dgDlc, dgDlc.SelectedItem, 1);
            dgDlc.ScrollIntoView(dlc);
            SetSelectChanged(dgCos, dgCos.SelectedItem, 1);
            dgCos.ScrollIntoView(dgCos.SelectedItem);
          }));
      }
    }

    //Undoable OK
    private async void CellComboBox_LostFocus(object sender, RoutedEventArgs e)
    {
      ComboBox target = sender as ComboBox;

      if (target.IsKeyboardFocused || target.IsKeyboardFocusWithin || currentCostumeSlot == -1 || target.SelectedValue == null) return;

      if (notCommandStack)
      {
        notCommandStack = false;
        return;
      }

      int selValue = (int)target.SelectedValue;

      var dlc = dtData.Dlc;

      if (dlc == null) return;

      DataGrid dataGrid = Styles.FindVisualParent<DataGrid>(target);
      DataGridRow dataGridRow = Styles.FindVisualParent<DataGridRow>(target);
      DataGridCell dataGridCell = Styles.FindVisualParent<DataGridCell>(target);
      Costume curCos = dataGridRow.Item as Costume;

      int curCosSlot = currentCostumeSlot;

      IsEditing = false;

      if (selValue == curCosSlot) return;

      var tb = e.OriginalSource as TextBox;
      if (dgCos.SelectedItems.Count == 1 && tb != null)
      {
        var cos = dgCos.SelectedItem as Costume;
        byte slot;
        if (byte.TryParse(tb.Text, out slot))
        {
          if (SlotsInGame.ContainsKey(cos.ID) && SlotsInGame[cos.ID].Contains(slot))
          {
            cos.CostumeSlot = curCosSlot;
            return;
          }
        }
        else
        {
          cos.CostumeSlot = curCosSlot;
          return;
        }
      }


      await Task.Delay(120);


      if (!modified)
      {
        Modified();
        System.Windows.Input.CommandManager.InvalidateRequerySuggested();
      }

      if (dgCos.SelectedItems.Count > 1)
      {
        List<Costume> selCostumes = new List<Costume>();
        List<int> prevCosSlots = new List<int>();
        foreach (var item in dgCos.SelectedItems)
        {
          var cos = item as Costume;

          selCostumes.Add(cos);
          prevCosSlots.Add(cos.CostumeSlot);
        }

        commandManager.Do(new Command(
        nameof(lang.CostumeChangeSlot),
          () => {
            if (dgCos.SelectedItems.Count > 0) dgCos.SelectedItems.Clear();
            foreach (var cos in selCostumes)
            {
              notCommandStack = true;
              if (Array.FindIndex(cos.CostumeSlots.ToArray(), elem => elem.Slot == selValue) != -1)
              {
                cos.CostumeSlot = selValue;
              }
              dgCos.SelectedItems.Add(cos);
            }
          },
          () => {
            if (dgCos.SelectedItems.Count > 0) dgCos.SelectedItems.Clear();
            int count = 0;
            foreach (var cos in selCostumes)
            {
              notCommandStack = true;
              if (cos == curCos)
                cos.CostumeSlot = curCosSlot;
              else
                cos.CostumeSlot = prevCosSlots[count];
              dgCos.SelectedItems.Add(cos);
              count++;
            }
          },
          () => {
            notCommandStack = false;

            dlc.CheckCostumeSlot();

            if (dataGridCell != null)
              dataGridCell.Focus();
            else
              dataGrid.Focus();

            if (dgDlc.SelectedItem != dlc)
            {
              dgDlc.SelectedItem = dlc;
              SetSelectChanged(dgDlc, dgDlc.SelectedItem, 1);
              dgDlc.ScrollIntoView(dlc);
              dgCos.ScrollIntoView(dgCos.SelectedItem);
              dgCos.Focus();
            }
          }));
      }
      else
      {
        commandManager.Do(new Command(
        nameof(lang.CostumeChangeSlot),
          () => {
          },
          () => {
            notCommandStack = true;
            curCos.CostumeSlot = selValue;

            if (dataGridCell != null)
              dataGridCell.Focus();
            else
              dataGrid.Focus();
          },
          () => {
            notCommandStack = true;
            curCos.CostumeSlot = curCosSlot;

            if (dataGridCell != null)
              dataGridCell.Focus();
            else
              dataGrid.Focus();
          },
          () => {
            notCommandStack = false;

            dlc.CheckCostumeSlot();

            dgCos.SelectedItem = curCos;

            IsEditing = false;

            if (dgDlc.SelectedItem != dlc)
            {
              dgDlc.SelectedItem = dlc;
              SetSelectChanged(dgDlc, dgDlc.SelectedItem, 1);
              dgDlc.ScrollIntoView(dlc);
              dgCos.ScrollIntoView(dgCos.SelectedItem);
              dgCos.Focus();
            }
          }));
      }

      currentCostumeSlot = -1;
    }

    //Undoable OK
    private void ComboBox_DropDownClosed(object sender, EventArgs e)
    {
      ComboBox target = sender as ComboBox;

      if (!target.IsMouseCaptured && !target.IsMouseOver && !target.IsKeyboardFocused && !target.IsKeyboardFocusWithin) return;

      DataGrid dataGrid = Styles.FindVisualParent<DataGrid>(target);
      DataGridCell dataGridCell = Styles.FindVisualParent<DataGridCell>(target);
      DataGridRow dataGridRow = Styles.FindVisualParent<DataGridRow>(target);
      Costume curCos = dataGridRow.Item as Costume;
      currentCostumeSlot = curCos.CostumeSlot;

      if (dataGridCell != null)
        dataGridCell.Focus();
      else
        dataGrid.Focus();

      isDropDownOpen = false;
    }

    private void CellComboBox_KeyUp(object sender, KeyEventArgs e)
    {
      ComboBox target = sender as ComboBox;

      if ((Key.D0 <= e.Key && e.Key <= Key.D9) || (Key.NumPad0 <= e.Key && e.Key <= Key.NumPad9))
      {
        if (!IsEditing)
        {
          DataGrid dataGrid = Styles.FindVisualParent<DataGrid>(target);
          DataGridRow dataGridRow = Styles.FindVisualParent<DataGridRow>(target);
          Costume curCos = dataGridRow.Item as Costume;
          currentCostumeSlot = curCos.CostumeSlot;
          IsEditing = true;
        }
        Modified();
      }
    }

    private void CellComboBox_PreviewMouseDown(object sender, MouseButtonEventArgs e)
    {
      IsDragStart = false;
      IsDragging = false;
      popupCosDrag.IsOpen = false;
    }

    private void RowDetailsComboBox_DropDownOpened(object sender, EventArgs e)
    {
      isDropDownOpen = true;
    }

    private void dgCos_ContextMenuOpening(object sender, ContextMenuEventArgs e)
    {
      if (dgCos.SelectedItems.Count > 0)
        menuChange.IsEnabled = true;
      else
        menuChange.IsEnabled = false;

      DataGrid_ContextMenuOpened = true;
    }

    private void dgCos_ContextMenuClosing(object sender, ContextMenuEventArgs e)
    {
      DataGrid_ContextMenuOpened = false;
    }

    private void TextBox_KeyUp(object sender, KeyEventArgs e)
    {
      var dlc = dgDlc.SelectedItem as DlcData;

      if (dlc != null)
      {
        dlc.CheckCostumeSlot();
      }

      Modified();
    }

    private void btnCosAdd_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      if (dgCos.Items.Count == 0)
        menuInsert.IsEnabled = false;
      else
        menuInsert.IsEnabled = true;
    }

    private void MenuAdd_SubmenuOpened(object sender, RoutedEventArgs e)
    {
      if (!editDefault || dgDlc.SelectedItems.Count != 1) return;

      var dlc = dgDlc.SelectedItem as DlcData;

      var senderMenuItem = sender as MenuItem;

      foreach (var item in senderMenuItem.Items)
      {
        var menuItem = item as MenuItem;
        var id = menuItem.Name.Split('_')[1];
        if (Array.FindIndex(dlc.Costumes.ToArray(), elem => elem.ID.ToString() == id) == -1)
          menuItem.IsEnabled = true;
        else
          menuItem.IsEnabled = false;
      }
    }

    //Undoable OK
    private void menuAddFromFile_Click(object sender, RoutedEventArgs e)
    {
      OpenFileDialog dlg = new OpenFileDialog();
      dlg.Filter = lang.LstFile + "|*.lst";
      if (currentListFile != "")
      {
        dlg.InitialDirectory = Path.GetDirectoryName(currentListFile);
      }

      try
      {
        this.IsEnabled = false;
        DoEvents();

        var dlc = dtData.Dlc;

        if (dlc == null) return;

        if (dlg.ShowDialog() != true) return;

        var data = OpenLstFile(dlg.FileName);

        var costumes = data.Costumes;

        commandManager.Do(new Command(
        nameof(lang.CostumeAddFromFile),
          () => {
            foreach (var cos in costumes)
            {
              dlc.Costumes.Add(cos);
            }
          },
          () => {
            foreach (var cos in costumes)
            {
              dlc.Costumes.Remove(cos);
            }
          },
          () => {
            dgDlc.SelectedItem = null;
            dgDlc.SelectedItem = dlc;
            dlc.CheckCostumeCount();
            dlc.CheckCostumeSlot();

            SetSelectChanged(dgDlc, dgDlc.SelectedItem, 1);
            dgDlc.ScrollIntoView(dlc);
            dgCos.Focus();
          }));
      }
      catch (Exception ex)
      {
        MessageWindow.Show(this, ex.Message + "\r\n\r\n" + ex.StackTrace, lang.Error);
      }
      finally
      {
        this.IsEnabled = true;
        this.Activate();
        this.Focus();
      }
    }

    private void cosDuplicateCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (!editBcm && !editDefault && dgCos.SelectedItems.Count > 0)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void cosDuplicateCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      CostumeDuplicate();
    }

    private void cosDeleteCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (!editBcm && dgCos.SelectedItems.Count > 0)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void cosDeleteCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      CostumeDelete();
    }

    private void cosResetInnerCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (!editBcm && !editDefault)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void cosResetInnerCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      CostumeResetInner();
    }

    private void costumesDecideSortCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      var view = CollectionViewSource.GetDefaultView(dgCos.ItemsSource);
      if (view != null && !editBcm && !editDefault && view.SortDescriptions.Count > 0)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void costumesDecideSortCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      CostumesDecideSort(true);
    }

    private void cosSlotSequentialCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (!editBcm && !editDefault && dgCos.SelectedItems.Count > 1)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void cosSlotSequentialCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      CostumeSlotSequential();
    }

    private void updateThumbnailsCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      DlcData dlc = dgDlc.SelectedItem as DlcData;

      foreach (var cos in dlc.Costumes)
      {
        cos.SetThumbnail();
        cos.CheckFiles(editDefault);
      }
    }


    //Undoable OK
    private void AddCostume_Click(object sender, RoutedEventArgs e)
    {
      MenuItem target = sender as MenuItem;

      var dlc = dtData.Dlc;

      if (dlc == null) return;

      int index = dgCos.SelectedIndex;

      Costume cos = null;
      Costume selCos = null;
      string[] strs = target.Name.Split('_');
      if (strs[0] == Const.Add)
      {
        commandManager.Do(new Command(
        nameof(lang.CostumeAdd),
          () => {
            selCos = dgCos.SelectedItem as Costume;
            cos = new Costume(Byte.Parse(strs[1]), true);
            cos.CostumeSlot = GetUnusedCostumeSlot(cos, true);
            cos.CheckFiles(editDefault);
            cos.SetThumbnail();
            cos.SetCFlags();
            dlc.Costumes.Add(cos);
            dgCos.SelectedIndex = dlc.Costumes.IndexOf(cos);
            if (cos != null) dgCos.ScrollIntoView(cos);
          },
          () => {
            dlc.Costumes.Remove(cos);
            dgCos.SelectedItem = selCos;
          },
          () => {
            dlc.CheckCostumeCount();
            dlc.CheckCostumeSlot();
            dlc.CheckDuplicatedCharacter();

            if (dgDlc.SelectedItem != dlc)
            {
              dgDlc.SelectedItem = dlc;
              SetSelectChanged(dgDlc, dgDlc.SelectedItem, 1);
              dgDlc.ScrollIntoView(dlc);
              dgCos.ScrollIntoView(dgCos.SelectedItem);
              dgCos.Focus();
            }
          }));
      }
      else
      {
        commandManager.Do(new Command(
        nameof(lang.CostumeInsert),
          () => {
            selCos = dgCos.SelectedItem as Costume;
            cos = new Costume(Byte.Parse(strs[1]), true);
            cos.CostumeSlot = GetUnusedCostumeSlot(cos, true);
            cos.CheckFiles(editDefault);
            cos.SetThumbnail();
            cos.SetCFlags();
            dlc.Costumes.Insert(index, cos);
            dgCos.SelectedIndex = index;
          },
          () => {
            dlc.Costumes.Remove(cos);
            dgCos.SelectedItem = selCos;
          },
          () => {
            dlc.CheckCostumeCount();
            dlc.CheckCostumeSlot();
            dlc.CheckDuplicatedCharacter();

            if (dgDlc.SelectedItem != dlc)
            {
              dgDlc.SelectedItem = dlc;
              SetSelectChanged(dgDlc, dgDlc.SelectedItem, 1);
              dgDlc.ScrollIntoView(dlc);
              dgCos.ScrollIntoView(dgCos.SelectedItem);
              dgCos.Focus();
            }
          }));
      }

      Modified();
    }

    //Undoable OK
    private void ChangeChara_Click(object sender, RoutedEventArgs e)
    {
      var dlc = dtData.Dlc;

      if (dlc == null) return;

      MenuItem target = sender as MenuItem;

      string[] strs = target.Name.Split('_');
      byte newId = Byte.Parse(strs[1]);

      List<byte> Ids = new List<byte>();
      List<Costume> costumes = new List<Costume>();
      foreach (var item in dgCos.SelectedItems)
      {
        var cos = item as Costume;
        costumes.Add(cos);
        Ids.Add(cos.ID);
      }

      commandManager.Do(new Command(
        nameof(lang.ChangeCharacter),
        () => {
          foreach (var cos in costumes)
          {
            cos.ID = newId;
            cos.CostumeSlotsSettedTime = DateTime.Now;
            cos.SetCostumeSlots();
          }
        },
        () => {
          foreach (var pair in Enumerable.Zip(costumes, Ids, (cos, id) => new { cos, id }))
          {
            pair.cos.ID = pair.id;
          }
        },
        () => {
          dlc.CheckCostumeCount();
          dlc.CheckCostumeSlot();
          dlc.CheckDuplicatedCharacter();

          if (dgDlc.SelectedItem != dlc)
          {
            dgDlc.SelectedItem = dlc;
            SetSelectChanged(dgDlc, dgDlc.SelectedItem, 1);
            dgDlc.ScrollIntoView(dlc);
            dgCos.ScrollIntoView(dgCos.SelectedItem);
            dgCos.Focus();
          }
        }));

      Modified();
    }

    private void cbDisplayThumb_CheckeChanged(object sender, RoutedEventArgs e)
    {
      if (cbDisplayThumb.IsChecked == true)
      {
        dgCos.RowDetailsVisibilityMode = DataGridRowDetailsVisibilityMode.Visible;
      }
      else
      {
        dgCos.RowDetailsVisibilityMode = DataGridRowDetailsVisibilityMode.Collapsed;
      }

      config.DisplayThumbnails = (bool)cbDisplayThumb.IsChecked;
    }

    //Undoable OK
    private void CostumeDuplicate()
    {
      var dlc = dtData.Dlc;

      if (dlc == null) return;

      var selectedItems = new List<Costume>();
      var duplicatedItems = new List<Costume>();

      commandManager.Do(new Command(
        nameof(lang.CostumeDuplicate),
        () => {
          foreach (var item in dgCos.SelectedItems)
          {
            var cos = item as Costume;
            if (cos == null) continue;

            int index = dlc.Costumes.IndexOf(cos) + 1;

            Costume cosEntry = cos.Clone();
            cosEntry.CostumeSlotsSettedTime = DateTime.Now;
            cosEntry.SetCostumeSlots();
            cosEntry.CostumeSlot = GetUnusedCostumeSlot(cosEntry, false);

            dlc.Costumes.Insert(index, cosEntry);
            duplicatedItems.Add(cosEntry);
            selectedItems.Add(cos);
          }

          dgCos.SelectedIndex = -1;
          foreach (var item in duplicatedItems)
          {
            dgCos.SelectedItems.Add(item);
            if (dgCos.SelectedItems.Count == 1)
              SetSelectChanged(dgCos, dgCos.SelectedItem, 1);
          }
        },
        () => {
          foreach (var item in duplicatedItems)
          {
            dlc.Costumes.Remove(item);
          }

          if (dgCos.SelectedItems.Count > 0) dgCos.SelectedItems.Clear();
          foreach (var cos in selectedItems)
          {
            dgCos.SelectedItems.Add(cos);
            if (dgCos.SelectedItems.Count == 1)
              SetSelectChanged(dgCos, dgCos.SelectedItem, 1);
          }
        },
        () => {
          dlc.CheckCostumeCount();
          dlc.CheckCostumeSlot();
          dlc.CheckDuplicatedCharacter();

          if (dgDlc.SelectedItem != dlc)
          {
            dgDlc.SelectedItem = dlc;
            SetSelectChanged(dgDlc, dgDlc.SelectedItem, 1);
            dgDlc.ScrollIntoView(dlc);
            dgCos.ScrollIntoView(dgCos.SelectedItem);
            dgCos.Focus();
          }
        }));

      Modified();
    }

    //Undoable OK
    private void CostumeDelete()
    {
      var dlc = dtData.Dlc;

      if (dlc == null) return;

      SortedDictionary<int, Costume> selCostumes = new SortedDictionary<int, Costume>();

      foreach (var item in dgCos.SelectedItems)
      {
        var cos = item as Costume;

        var idx = dlc.Costumes.IndexOf(cos);

        selCostumes.Add(idx, cos);
      }

      commandManager.Do(new Command(
        nameof(lang.CostumeDelete),
        () => {
          foreach (var key in selCostumes.Keys.Reverse())
          {
            dlc.Costumes.RemoveAt(key);
          }

          int index = selCostumes.Keys.Last() - selCostumes.Count + 1;

          if (dgCos.Items.Count <= 0)
          {
            dgCos.SelectedIndex = -1;
          }
          else if (index >= dgCos.Items.Count)
          {
            dgCos.SelectedIndex = index - 1;
          }
          else
          {
            dgCos.SelectedIndex = index;
          }
          if (dgCos.SelectedItem != null)
            SetSelectChanged(dgCos, dgCos.SelectedItem, 1);
        },
        () => {
          if (dgCos.SelectedItems.Count > 0) dgCos.SelectedItems.Clear();

          foreach (var pair in selCostumes)
          {
            dlc.Costumes.Insert(pair.Key, pair.Value);
            dgCos.SelectedItems.Add(pair.Value);
            if (dgCos.SelectedItems.Count == 1)
              SetSelectChanged(dgCos, dgCos.SelectedItem, 1);
          }
        },
        () => {
          dlc.CheckCostumeCount();
          dlc.CheckCostumeSlot();
          dlc.CheckDuplicatedCharacter();

          if (dgDlc.SelectedItem != dlc)
          {
            dgDlc.SelectedItem = dlc;
            SetSelectChanged(dgDlc, dgDlc.SelectedItem, 1);
            dgDlc.ScrollIntoView(dlc);
            dgCos.ScrollIntoView(dgCos.SelectedItem);
            dgCos.Focus();
          }
        }));

      dgCos.Focus();

      Modified();
    }

    //Undoable OK
    private void CostumeResetInner()
    {
      var dlc = dtData.Dlc;

      if (dlc == null) return;

      List<byte> texsCountList = new List<byte>();

      commandManager.Do(new Command(
        nameof(lang.ResetInner),
        () => {
          foreach (var cos in dlc.Costumes)
          {
            texsCountList.Add(cos.AddTexsCount);
            cos.AddTexsCount = (byte)CheckInners(cos).Count;
          }
        },
        () => {
          foreach (var pair in Enumerable.Zip(dlc.Costumes, texsCountList, (cos, count) => new { cos, count }))
          {
            pair.cos.AddTexsCount = pair.count;
          }
        },
        () => {
          dlc.CheckCostumeCount();
          dlc.CheckCostumeSlot();
          dlc.CheckDuplicatedCharacter();

          if (dgDlc.SelectedItem != dlc)
          {
            dgDlc.SelectedItem = dlc;
            SetSelectChanged(dgDlc, dgDlc.SelectedItem, 1);
            dgDlc.ScrollIntoView(dlc);
            dgCos.ScrollIntoView(dgCos.SelectedItem);
            dgCos.Focus();
          }
        }));
    }

    //Undoable OK
    private void CostumesDecideSort(bool addHistory)
    {
      var dlc = dtData.Dlc;

      if (dlc == null) return;

      var view = CollectionViewSource.GetDefaultView(dgCos.ItemsSource);

      if (view.SortDescriptions.Count == 0) return;

      var views = view.OfType<Costume>();

      // 実行前の情報を取得
      var sortDirections = new List<System.ComponentModel.ListSortDirection?>();
      foreach (var col in dgCos.Columns) sortDirections.Add(col.SortDirection);
      var sortDescriptions = new List<System.ComponentModel.SortDescription>();
      foreach (var item in view.SortDescriptions) sortDescriptions.Add(item);
      var prevSorted = new List<Costume>(dlc.Costumes);

      var selected = dgCos.SelectedItems.Cast<object>().ToList();
      var sorted = new List<Costume>(views.ToList());

      foreach (var col in dgCos.Columns) col.SortDirection = null;
      view.SortDescriptions.Clear();
      for (int i = 0; i < dlc.Costumes.Count; i++)
      {
        dlc.Costumes[i] = sorted[i];
      }

      if (addHistory)
      {
        commandManager.Do(new Command(
          nameof(lang.CostumeDecideSort),
          () => {
          },
          () => {
            dlc.Costumes.Clear();
            foreach (var cos in prevSorted)
            {
              dlc.Costumes.Add(cos);
            }
          foreach (var item in sortDescriptions) view.SortDescriptions.Add(item);
            foreach (var pair in Enumerable.Zip(dgCos.Columns, sortDirections, (a, b) => new { a, b }))
            {
              pair.a.SortDirection = pair.b;
            }
          },
          () => {
            if (dgCos.SelectionMode == DataGridSelectionMode.Extended)
              foreach (var item in selected) dgCos.SelectedItems.Add(item);

            if (dgDlc.SelectedItem != dlc)
            {
              dgDlc.SelectedItem = dlc;
              SetSelectChanged(dgDlc, dgDlc.SelectedItem, 1);
              dgDlc.ScrollIntoView(dlc);
              dgCos.Focus();
            }
          }));
      }

    }

    //Undoable OK
    private void CostumeSlotSequential()
    {
      var dlc = dtData.Dlc;

      if (dlc == null) return;

      List<Costume> selected = new List<Costume>();
      List<int> newSlotList = new List<int>();
      List<int> prevSlotList = new List<int>();
      foreach (var item in dgCos.Items)
      {
        var cos = item as Costume;
        if (cos == null) continue;

        if (!dgCos.SelectedItems.Contains(cos)) continue;

        selected.Add(cos);

        List<byte> skipSlot = new List<byte>();
        if (SlotsInGame.ContainsKey(cos.ID)) skipSlot.AddRange(SlotsInGame[cos.ID]);

        prevSlotList.Add(cos.CostumeSlot);

        if (newSlotList.Count == 0)
        {
          newSlotList.Add(cos.CostumeSlot);
        }
        else
        {
          byte newSlot = (byte)newSlotList[newSlotList.Count - 1];

          do
          {
            newSlot += 1;
          }
          while (skipSlot.Contains(newSlot));

          newSlotList.Add(newSlot);
        }
      }

      commandManager.Do(new Command(
        nameof(lang.SlotSequential),
        () => {
          foreach (var pair in Enumerable.Zip(selected, newSlotList, (cos, slot) => new { cos, slot }))
          {
            pair.cos.CostumeSlot = pair.slot;
          }
        },
        () => {
          foreach (var pair in Enumerable.Zip(selected, prevSlotList, (cos, slot) => new { cos, slot }))
          {
            pair.cos.CostumeSlot = pair.slot;
          }
        },
        () => {
          if (dgCos.SelectedItems.Count > 0) dgCos.SelectedItems.Clear();
          foreach (var cos in selected)
          {
            dgCos.SelectedItems.Add(cos);
          }

          dlc.CheckCostumeSlot();

          if (dgDlc.SelectedItem != dlc)
          {
            dgDlc.SelectedItem = dlc;
            SetSelectChanged(dgDlc, dgDlc.SelectedItem, 1);
            dgDlc.ScrollIntoView(dlc);
            dgCos.ScrollIntoView(dgCos.SelectedItem);
            dgCos.Focus();
          }
        }));

    }

    private byte GetUnusedCostumeSlot(Costume cos, bool add)
    {
      if (dgDlc.SelectedItems.Count != 1) return 0;

      var dlc = dgDlc.SelectedItem as DlcData;

      List<byte> usedList = new List<byte>();

      if (dlcCostumeData.Count > 0 && dlcCostumeData.ContainsKey(cos.ID))
      {
        usedList.AddRange(dlcCostumeData[cos.ID].Where(elem => elem.DlcNum != dlc.DlcNum).Select(elem => elem.Slot));
      }

      usedList.AddRange(dlc.Costumes.Where(elem => elem.ID == cos.ID).Select(elem => (byte)elem.CostumeSlot));
      if (SlotsInGame.ContainsKey(cos.ID)) usedList.AddRange(SlotsInGame[cos.ID]);

      byte slot = 0xFF;
      if (add)
      {
        byte tempSlot = 0;

        while (tempSlot < defaultData.Charas[cos.ID].SlotCount)
        {
          if (!usedList.Contains(tempSlot))
          {
            slot = tempSlot;
            break;
          }
          tempSlot++;
        }

        if (slot == 0xFF) slot = 0;
      }
      else
      {
        byte tempSlot = (byte)cos.CostumeSlot;

        while (tempSlot < defaultData.Charas[cos.ID].SlotCount)
        {
          if (!usedList.Contains(tempSlot))
          {
            slot = tempSlot;
            break;
          }
          tempSlot++;
        }

        if (slot == 0xFF)
        {
          tempSlot = (byte)cos.CostumeSlot;
          while (tempSlot > 0)
          {
            tempSlot--;
            if (!usedList.Contains(tempSlot))
            {
              slot = tempSlot;
              break;
            }
          }
        }

        if (slot == 0xFF) slot = (byte)cos.CostumeSlot;
      }

      return slot;
    }

    #endregion



    #region HairStyle

    //Undoable OK
    private void dgHStylesAdd()
    {
      if (dgCos.SelectedItem == null) return;

      var cos = dgCos.SelectedItem as Costume;

      HairStyle newHStyle = new HairStyle(1, 1);

      commandManager.Do(new Command(
        nameof(lang.HairStyleAdd),
        () => {
          cos.HStyles.Add(newHStyle);
        },
        () => {
          cos.HStyles.Remove(newHStyle);
        },
        () => {
          dgCos.SelectedItem = cos;

          dgHStyles.SelectedIndex = dgHStyles.Items.Count - 1;
          cos.ResetHairType();
        }));


      Modified();
    }

    //Undoable OK
    private void dgHStylesInsert()
    {
      if (dgCos.SelectedItem == null) return;

      var cos = dgCos.SelectedItem as Costume;

      int selIndex = dgHStyles.SelectedIndex;
      HairStyle newHStyle = new HairStyle(1, 1);

      commandManager.Do(new Command(
        nameof(lang.HairStyleInsert),
        () => {
          cos.HStyles.Insert(selIndex, newHStyle);
        },
        () => {
          cos.HStyles.Remove(newHStyle);
        },
        () => {
          dgCos.SelectedItem = cos;

          dgHStyles.SelectedIndex = selIndex;
          cos.ResetHairType();

          dgHStyles.Items.Refresh();
        }));


      Modified();
    }

    //Undoable OK
    private void dgHStylesDelete()
    {
      if (dgCos.SelectedItem == null) return;

      var cos = dgCos.SelectedItem as Costume;


      SortedDictionary<int, HairStyle> selStyles = new SortedDictionary<int, HairStyle>();

      foreach (var item in dgHStyles.SelectedItems)
      {
        var style = item as HairStyle;

        var idx = cos.HStyles.IndexOf(style);

        selStyles.Add(idx, style);
      }

      HairStyle newHStyle = null;


      commandManager.Do(new Command(
        nameof(lang.HairStyleDelete),
        () => {
          dgCos.SelectedItem = cos;

          foreach (var key in selStyles.Keys.Reverse())
          {
            cos.HStyles.RemoveAt(key);
          }

          if (dgHStyles.Items.Count == 0)
          {
            newHStyle = new HairStyle(1, 1);
            cos.HStyles.Add(newHStyle);
          }

          int index = selStyles.Keys.Last() - selStyles.Count + 1;

          if (selStyles.Count == 1 && index == dgHStyles.Items.Count)
          {
            dgHStyles.SelectedIndex = index - 1;
          }
          else if (selStyles.Count == 1)
          {
            dgHStyles.SelectedIndex = index;
          }
        },
        () => {
          dgCos.SelectedItem = cos;

          if (dgHStyles.SelectedItems.Count > 0) dgHStyles.SelectedItems.Clear();

          foreach (var pair in selStyles)
          {
            cos.HStyles.Insert(pair.Key, pair.Value);
            dgHStyles.SelectedItems.Add(pair.Value);
          }
        },
        () => {
          if (dgHStyles.SelectedItem != null)
            SetSelectChanged(dgHStyles, dgHStyles.SelectedItem, 1);
          dgHStyles.Focus();
          cos.ResetHairType();
        }));


      Modified();
    }

    //Undoable OK
    private void dgHStylesReset()
    {
      if (dgCos.SelectedItem == null) return;

      var cos = dgCos.SelectedItem as Costume;

      var prevHairStyles = new ObservableCollection<HairStyle>(cos.HStyles);
      var resetHairStyles = new ObservableCollection<HairStyle>(cos.OriginHStyles);

      commandManager.Do(new Command(
        nameof(lang.HairStyleReset),
        () => {
          if (cos.HStyles.Count > 0) cos.HStyles.Clear();
          foreach (var style in resetHairStyles)
          {
            cos.HStyles.Add(style);
          }
        },
        () => {
          if (cos.HStyles.Count > 0) cos.HStyles.Clear();
          foreach (var style in prevHairStyles)
          {
            cos.HStyles.Add(style);
          }
        },
        () => {
          cos.ResetHairType();
          dgCos.SelectedItem = cos;
        }));
    }

    private void HStyleAddCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (dgHStyles.Items.Count < 8)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void HStyleAddCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      dgHStylesAdd();
    }

    private void HStyleInsertCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (dgHStyles.Items.Count < 8 && dgHStyles.SelectedItems.Count > 0)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void HStyleInsertCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      dgHStylesInsert();
    }

    private void HStyleDeleteCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (dgHStyles.Items.Count > 1 && dgHStyles.SelectedItems.Count > 0)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void HStyleDeleteCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      dgHStylesDelete();
    }

    private void HStyleResetCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (dgHStyles.Items.Count != 0)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void HStyleResetCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      dgHStylesReset();
    }


    private void dgHStyles_BeginningEdit(object sender, DataGridBeginningEditEventArgs e)
    {
      var dataGrid = sender as DataGrid;
      FrameworkElement contentElement = dataGrid.CurrentCell.Column.GetCellContent(dataGrid.CurrentCell.Item);
      var tb = contentElement as TextBlock;

      biginningText = tb.Text;
    }

    //Undoable OK
    private void dgHStyles_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
    {
      Modified();

      var tb = e.EditingElement as TextBox;
      if (tb == null || biginningText == tb.Text) return;

      var dataGrid = sender as DataGrid;
      string prevText = biginningText;
      string curText = tb.Text;

      if (String.IsNullOrEmpty(tb.Text))
      {
        tb.Text = biginningText;
        return;
      }

      byte prevByte;
      if (!Byte.TryParse(prevText, out prevByte)) return;

      byte curByte;
      if (!Byte.TryParse(curText, out curByte))
      {
        tb.Text = biginningText;
        return;
      }

      var cos = dtData.Costume;

      var style = dataGrid.SelectedItem as HairStyle;
      if (style == null) return;

      if (e.Column.SortMemberPath == "Hair")
      {
        commandManager.Do(new Command(
          nameof(lang.HairChange),
          () => {
          },
          () => {
            dgHStyles.CancelEdit();
            dgCos.SelectedItem = cos;
            style.Hair = curByte;
          },
          () => {
            dgHStyles.CancelEdit();
            dgCos.SelectedItem = cos;
            style.Hair = prevByte;
          },
          () => {
            dgHStyles.SelectedItem = style;
            SetSelectChanged(dgHStyles, dgHStyles.SelectedItem, 1);
          }));
      }
      else if (e.Column.SortMemberPath == "Face")
      {
        commandManager.Do(new Command(
          nameof(lang.FaceChange),
          () => {
          },
          () => {
            dgHStyles.CancelEdit();
            dgCos.SelectedItem = cos;
            style.Face = curByte;
          },
          () => {
            dgHStyles.CancelEdit();
            dgCos.SelectedItem = cos;
            style.Face = prevByte;
          },
          () => {
            dgHStyles.SelectedItem = style;
            SetSelectChanged(dgHStyles, dgHStyles.SelectedItem, 1);
          }));
      }
    }

    #endregion



    #region File

    private void btnFileAdd_Click(object sender, RoutedEventArgs e)
    {
      if (dgDlc.SelectedIndex == -1 || dgCos.SelectedIndex == -1) return;

      var cos = dgCos.SelectedItem as Costume;

      this.IsEnabled = false;

      OpenFileDialog dlg = new OpenFileDialog();
      dlg.Filter = lang.AllSupportedFormats + "|*.TMC;*.TMCL;*.--H;*.--HL;*.---C;*.--P";
      if (currentCosFile != "")
      {
        dlg.InitialDirectory = Path.GetDirectoryName(currentCosFile);
      }
      dlg.Multiselect = true;

      if (dlg.ShowDialog() == true)
      {
        currentCosFile = dlg.FileNames[0];
        OpenCosFile(cos, dlg.FileNames.ToList(), null);
      }

      this.IsEnabled = true;
      this.Focus();
    }

    private void cosFilesDeleteCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      foreach (var item in dgFiles.SelectedItems)
      {
        var file = item as CostumeFile;
        if (!String.IsNullOrEmpty(file.Path))
        {
          e.CanExecute = true;
          return;
        }
      }

      e.CanExecute = false;
    }
    private void cosFilesDeleteCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      dgFilesDelete();
    }

    private void openWithExplorerCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      e.CanExecute = false;

      if (dgFiles.SelectedItems.Count != 1) return;

      var file = dgFiles.SelectedItem as CostumeFile;

      if (String.IsNullOrEmpty(file.DisplayPath)) return;

      string filePath = file.DisplayPath.Replace(lang.AutoSet, "");
      var dirPath = System.IO.Path.GetDirectoryName(filePath);

      if (!Directory.Exists(dirPath)) return;

      e.CanExecute = true;
    }
    private void openWithExplorerCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var file = dgFiles.SelectedItem as CostumeFile;
      string filePath = file.DisplayPath.Replace(lang.AutoSet, "");

      if (File.Exists(filePath))
      {
        System.Diagnostics.Process.Start("EXPLORER.EXE", @"/select,""" + filePath + @"""");
      }
      else
      {
        var dirPath = System.IO.Path.GetDirectoryName(filePath);
        System.Diagnostics.Process.Start("EXPLORER.EXE", dirPath);
      }
    }

    private void dgFiles_ContextMenuOpening(object sender, ContextMenuEventArgs e)
    {
      var file = dgFiles.SelectedItem as CostumeFile;

      if (menuFileSendTo.Items.Count == 0 || dgFiles.SelectedItems.Count > 1 || String.IsNullOrEmpty(file.DisplayPath))
        menuFileSendTo.IsEnabled = false;
      else
        menuFileSendTo.IsEnabled = true;
    }

    //Undoable OK
    private void OpenCosFile(Costume cos, List<string> filePaths, string historyName)
    {
      Dictionary<byte, string> prevFiles = new Dictionary<byte, string>();
      Dictionary<byte, string> addedFiles = new Dictionary<byte, string>();

      foreach (var file in cos.Files)
      {
        if (!String.IsNullOrEmpty(file.Path)) prevFiles[file.ID] = file.Path;
      }


      foreach (var filePath in filePaths)
      {
        for (byte i = 0; i < FileTypes.Length; i++)
        {
          if (filePath.EndsWith(FileTypes[i], true, null))
          {
            cos.SetFile(i, filePath);
            addedFiles[i] = filePath;
            break;
          }
        }
      }

      if (addedFiles.Count == 0) return;

      var dlc = dtData.Dlc;

      if (historyName == null) historyName = nameof(lang.FileAdd);

      commandManager.Do(new Command(
        historyName,
        () => {
        },
        () => {
          foreach (var pair in addedFiles)
          {
            cos.SetFile(pair.Key, pair.Value);
          }
        },
        () => {
          foreach (var file in cos.Files) file.Path = "";
          foreach (var pair in prevFiles)
          {
            cos.SetFile(pair.Key, pair.Value);
          }
        },
        () => {
          cos.SetThumbnail();
          cos.SetCFlags();
          cos.AddTexsCount = (byte)CheckInners(cos).Count;
          cos.CheckFiles(editDefault);

          dlc.CheckCostumeError();

          dgCos.SelectedItem = cos;
          SetSelectChanged(dgCos, dgCos.SelectedItem, 1);
        }));


      Modified();
    }

    //Undoable OK
    private void dgFilesDelete()
    {
      if (dgCos.SelectedItem == null || dgFiles.SelectedIndex == -1) return;

      var cos = dgCos.SelectedItem as Costume;

      var dlc = dtData.Dlc;

      Dictionary<byte, string> prevFiles = new Dictionary<byte, string>();
      List<byte> deletedFiles = new List<byte>();

      foreach (var file in cos.Files)
      {
        if (!String.IsNullOrEmpty(file.Path)) prevFiles[file.ID] = file.Path;
      }


      commandManager.Do(new Command(
        nameof(lang.FileDelete),
        () => {
          foreach (var item in dgFiles.SelectedItems)
          {
            var file = item as CostumeFile;
            file.Path = "";
            deletedFiles.Add(file.ID);
          }
        },
        () => {
          foreach (var file in cos.Files)
          {
            if (deletedFiles.Contains(file.ID)) file.Path = "";
          }
        },
        () => {
          foreach (var file in cos.Files) file.Path = "";
          foreach (var pair in prevFiles)
          {
            cos.SetFile(pair.Key, pair.Value);
          }
        },
        () => {
          cos.AddTexsCount = (byte)CheckInners(cos).Count;
          cos.SetThumbnail();
          cos.SetCFlags();
          cos.CheckFiles(editDefault);

          dlc.CheckCostumeError();

          dgCos.SelectedItem = cos;
          SetSelectChanged(dgCos, dgCos.SelectedItem, 1);
        }));


      Modified();
    }

    private List<byte> CheckInners(Costume cos)
    {
      List<byte> inners = new List<byte>();
      for (byte i = 0; i < 4; i++)
      {
        if (
          Array.FindIndex(cos.Files.ToArray(), elem => elem.ID == 4 + 2 * i && !String.IsNullOrEmpty(elem.Path)) != -1 &&
          Array.FindIndex(cos.Files.ToArray(), elem => elem.ID == 4 + 2 * i + 1 && !String.IsNullOrEmpty(elem.Path)) != -1
        )
          inners.Add(i);
      }

      if (inners.Count == 0)
      {
        inners.Add(0xff);
      }

      return inners;
    }

    #endregion



    //Umdoable
    #region Drag and Drop

    public bool IsEditing { get; set; }

    public bool IsDragStart { get; set; }
    public bool IsDragging { get; set; }

    Point startPosition;

    DataGrid activeDataGrid;

    private static bool DataGrid_ContextMenuOpened = false;

    public dynamic DraggedItem { get; set; }

    public List<dynamic> DraggedItems;

    private void OnBeginEdit(object sender, DataGridBeginningEditEventArgs e)
    {
      IsEditing = true;
      if (IsDragging) ResetDragDrop();
    }

    private void OnEndEdit(object sender, DataGridCellEditEndingEventArgs e)
    {
      IsEditing = false;
    }

    private void OnMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      if (IsEditing || editBcm) return;

      activeDataGrid = sender as DataGrid;

      DraggedItems = new List<dynamic>();
      foreach (var item in activeDataGrid.Items)
      {
        if (activeDataGrid.SelectedItems.Contains(item))
        {
          var cos = item as dynamic;
          DraggedItems.Add(cos);
        }
      }

      startPosition = e.GetPosition(this);
      var row = UIHelpers.TryFindFromPoint<DataGridRow>(this, startPosition);
      if (row == null || row.IsEditing) return;
      IsDragStart = true;

      DraggedItem = (dynamic)row.Item;

      if (!DraggedItems.Contains(DraggedItem))
      {
        if (DraggedItems.Count > 0) DraggedItems.Clear();
        DraggedItems.Add(DraggedItem);
      }

      if (Keyboard.Modifiers == ModifierKeys.Shift || Keyboard.Modifiers == ModifierKeys.Control)
      {
        IsDragStart = false;
      }
    }

    private void OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
      if (activeDataGrid == null) return;

      if (!IsDragging || IsEditing)
      {
        if (Keyboard.Modifiers != ModifierKeys.Shift && Keyboard.Modifiers != ModifierKeys.Control && activeDataGrid.SelectedItems.Count > 1)
        {
          activeDataGrid.SelectedItem = DraggedItem;
          SetSelectChanged(activeDataGrid, activeDataGrid.SelectedItem, 1);
        }

        ResetDragDrop();
        return;
      }


      dynamic targetItem = (dynamic)activeDataGrid.SelectedItem;
      dynamic collection = null;
      dynamic prevCollection = null;
      dynamic redoCollection = null;
      dynamic selectedCollection = null;

      var dlc = dtData.Dlc;

      if (activeDataGrid.Name == "dgDlc")
      {
        DlcsDecideSort(false);

        collection = dtData.Dlcs;
        prevCollection = new List<DlcData>(dtData.Dlcs);
        selectedCollection = new List<object>(DraggedItems);
      }
      else if (activeDataGrid.Name == "dgCos")
      {
        CostumesDecideSort(false);

        collection = dlc.Costumes;
        prevCollection = new List<Costume>(dlc.Costumes);
        selectedCollection = new List<object>(DraggedItems);
      }

      if (collection == null) return;


      if (targetItem != null)
      {
        var targetIndex = collection.IndexOf(targetItem);
        if (targetIndex != -1)
        {
          while (targetIndex < collection.Count)
          {
            targetItem = collection[targetIndex];

            if (!DraggedItems.Contains(targetItem)) break;

            targetIndex++;
          }

          if (targetIndex == collection.Count)
          {
            targetItem = null;
          }
          else
          {
            foreach (var item in DraggedItems) collection.Remove(item);

            targetIndex = collection.IndexOf(targetItem);

            foreach (var item in DraggedItems)
            {
              collection.Insert(targetIndex, item);
              targetIndex++;
            }
          }
        }
      }
      else
      {
        foreach (var item in DraggedItems) collection.Remove(item);
        foreach (var item in DraggedItems) collection.Add(item);
      }

      if (activeDataGrid.Name == "dgDlc")
      {
        redoCollection = new List<DlcData>(dtData.Dlcs);
      }
      else if (activeDataGrid.Name == "dgCos")
      {
        redoCollection = new List<Costume>(dlc.Costumes);
      }

      ResetDragDrop();

      activeDataGrid.SelectionMode = DataGridSelectionMode.Extended;

      if (activeDataGrid.SelectedItems.Count > 0) activeDataGrid.SelectedItems.Clear();
      foreach (var item in DraggedItems)
      {
        activeDataGrid.SelectedItems.Add(item);
        if (activeDataGrid.SelectedItems.Count == 1) SetSelectChanged(activeDataGrid, item, 1);
      }


      if (activeDataGrid.Name == "dgDlc")
      {
        commandManager.Do(new Command(
          nameof(lang.DlcSort),
          () => {
          },
          () => {
            if (dtData.Dlcs.Count > 0) dtData.Dlcs.Clear();
            foreach (var item in redoCollection)
            {
              dtData.Dlcs.Add(item);
              if (selectedCollection.Contains(item))
              {
                dgDlc.SelectedItems.Add(item);
                if (dgDlc.SelectedItems.Count == 1) SetSelectChanged(dgDlc, item, 1);
              }
            }
          },
          () => {
            if (dtData.Dlcs.Count > 0) dtData.Dlcs.Clear();
            foreach (var item in prevCollection)
            {
              dtData.Dlcs.Add(item);
              if (selectedCollection.Contains(item))
              {
                dgDlc.SelectedItems.Add(item);
                if (dgDlc.SelectedItems.Count == 1) SetSelectChanged(dgDlc, item, 1);
              }
            }
          },
          () => {
          }));
      }
      else if (activeDataGrid.Name == "dgCos")
      {
        commandManager.Do(new Command(
          nameof(lang.CostumeSort),
          () => {
          },
          () => {
            if (dlc.Costumes.Count > 0) dlc.Costumes.Clear();
            foreach (var item in redoCollection)
            {
              dlc.Costumes.Add(item);
              if (selectedCollection.Contains(item))
              {
                dgCos.SelectedItems.Add(item);
                if (dgCos.SelectedItems.Count == 1) SetSelectChanged(dgCos, item, 1);
              }
            }
          },
          () => {
            if (dlc.Costumes.Count > 0) dlc.Costumes.Clear();
            foreach (var item in prevCollection)
            {
              dlc.Costumes.Add(item);
              if (selectedCollection.Contains(item))
              {
                dgCos.SelectedItems.Add(item);
                if (dgCos.SelectedItems.Count == 1) SetSelectChanged(dgCos, item, 1);
              }
            }
          },
          () => {
            SetSelectChanged(dgDlc, dlc, 1);
          }));
      }

    }

    private void ResetDragDrop()
    {
      IsDragStart = false;
      IsDragging = false;
      popupCosDrag.IsOpen = false;

      if (activeDataGrid == null) return;

      activeDataGrid.IsReadOnly = false;
      activeDataGrid.SelectionMode = DataGridSelectionMode.Extended;

      if (activeDataGrid.Name == "dgDlc")
      {
        foreach (var dlc in dtData.Dlcs)
        {
          dlc.IsDragging = false;
          dlc.IsDragOver = false;
        }
      }
      else if (activeDataGrid.Name == "dgCos")
      {
        var dlc = dgDlc.SelectedItem as DlcData;

        if (dlc == null) return;

        foreach (var cos in dlc.Costumes)
        {
          cos.IsDragging = false;
          cos.IsDragOver = false;
        }
      }
    }

    private void OnMouseMove(object sender, MouseEventArgs e)
    {
      Point position = e.GetPosition(this);

      if ((startPosition - position).Length < 5)
      {
        return;
      }


      if (!IsDragStart || e.LeftButton != MouseButtonState.Pressed || DataGrid_ContextMenuOpened) return;

      if (!popupCosDrag.IsOpen)
      {
        activeDataGrid.IsReadOnly = true;
        activeDataGrid.SelectionMode = DataGridSelectionMode.Single;

        popupCosDrag.IsOpen = true;
        IsDragging = true;

        foreach (var item in DraggedItems)
        {
          item.IsDragging = true;
        }
      }

      Size popupSize = new Size(popupCosDrag.ActualWidth, popupCosDrag.ActualHeight);
      popupCosDrag.PlacementRectangle = new Rect(e.GetPosition(this), popupSize);

      var row = UIHelpers.TryFindFromPoint<DataGridRow>(this, position);
      DataGrid dataGrid = Common.Styles.FindVisualParent<DataGrid>(row);
      if (row != null && dataGrid == activeDataGrid)
      {
        activeDataGrid.SelectedItem = row.Item;
        var item = activeDataGrid.SelectedItem as dynamic;
        item.IsDragOver = true;
      }
      else
      {
        activeDataGrid.SelectedItem = null;
      }
    }

    private void OnMouseRightButtonUp(object sender, MouseButtonEventArgs e)
    {
      if (!IsDragging) return;

      ResetDragDrop();
    }

    private void cancelDragDropCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      if (!IsDragging) return;

      ResetDragDrop();
    }

    #endregion



    public void CheckUpdated()
    {
      CheckUpdated(this);
      DatabaseChanged();
      CheckClipboardData();
    }
    public static void CheckUpdated(Window window)
    {
      if (File.Exists(BaseDirectory + config.DefaultLstPath))
      {
        var lastWriteTime = File.GetLastWriteTime(BaseDirectory + config.DefaultLstPath);
        if (config.DefaultLstWriteTime.CompareTo(lastWriteTime) != 0)
        {
          if (MessageWindow.Show(window, lang.ConfirmFileUpdated + "\r\n\r\n" + BaseDirectory + config.DefaultLstPath, lang.Confirm, lang.Yes, lang.No) == MessageWindow.Result.OK)
          {
            var skippedList = LoadDefault();
            if (skippedList.Count > 0)
            {
              string text = lang.FoundErrorsInDefault + "\r\n";
              foreach (var skipped in skippedList)
              {
                text += "\r\n" + skipped;
              }
              MessageWindow.Show(window, text, lang.Error);
            }
          }
          else
          {
            config.DefaultLstWriteTime = lastWriteTime;
          }
        }
      }

      if (File.Exists(BaseDirectory + config.DatabasePath))
      {
        var lastWriteTime = File.GetLastWriteTime(BaseDirectory + config.DatabasePath);
        if (config.DatabaseWriteTime.CompareTo(lastWriteTime) != 0)
        {
          if (MessageWindow.Show(window, lang.ConfirmFileUpdated + "\r\n\r\n" + BaseDirectory + config.DatabasePath, lang.Confirm, lang.Yes, lang.No) == MessageWindow.Result.OK)
          {
            nameDB = LoadDB(false);
          }
          else
          {
            config.DatabaseWriteTime = lastWriteTime;
          }
        }
      }
    }

  }

  public class BoolToOppositeBoolConverter : IValueConverter
  {
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
      if (value == null) return null;

      if (targetType != typeof(bool))
        throw new InvalidOperationException("The target must be a boolean");

      return !(bool)value;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
      throw new NotSupportedException();
    }
  }

  public class IsNullConverter : IValueConverter
  {
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
      return (value == null || value.ToString() == "");
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
      throw new InvalidOperationException("IsNullConverter can only be used OneWay.");
    }
  }

  public class NumToCharNameConverter : IValueConverter
  {
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
      if (value == null || targetType != typeof(string)) return null;

      string charaName = MainWindow.lang.AddedCharacter + value.ToString();
      if (MainWindow.CharaNamesLocale.ContainsKey((byte)value))
      {
        charaName = MainWindow.CharaNamesLocale[(byte)value];
      }
      else if (MainWindow.CharaNames.ContainsKey((byte)value))
      {
        charaName = MainWindow.CharaNames[(byte)value];
      }

      return charaName;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
      return null;
    }
  }

  public class NumToHairTypeConverter : IValueConverter
  {
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
      if (value == null || targetType != typeof(string)) return null;

      return MainWindow.lang.Type + (char)(65 + (byte)value);
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
      return null;
    }
  }

  public class IDToCostumeSlotsConverter : IValueConverter
  {
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
      if (value == null || targetType != typeof(IEnumerable)) return null;

      byte id = (byte)value;

      if (!MainWindow.CostumeSlots.ContainsKey(id)) return null;

      var items = new List<CostumeSlotItem>(MainWindow.CostumeSlots[id]);

      return items;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
      return null;
    }
  }

  public class PathToBitmapSourceConverter : IValueConverter
  {
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
      if (value == null || targetType != typeof(ImageSource)) return null;

      string path = value.ToString();

      if (!MainWindow.Thumbs.ContainsKey(path)) return null;

      return MainWindow.Thumbs[path].Source;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
      return null;
    }
  }

  public class ModeToVisibilityConverter : IValueConverter
  {
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
      if (value != null && value.ToString() == "") return Visibility.Visible;

      return Visibility.Collapsed;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
      return null;
    }
  }


}
