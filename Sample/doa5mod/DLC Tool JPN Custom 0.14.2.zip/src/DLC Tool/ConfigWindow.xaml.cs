﻿using System;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.ComponentModel;
using Microsoft.WindowsAPICodePack.Dialogs;
using Microsoft.Win32;
using Message;

namespace DLC_Tool
{
  /// <summary>
  /// ConfigWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class ConfigWindow : Window
  {
    private static ConfigWindow dlg;

    private static Config config;
    private static Config originalConfig;
    private static Lang.Sentence lang;

    private static string currentDir = "";

    private static bool databaseChanged = false;

    private static bool activated = false;
    private static bool modified = false;

    private static int ownerWidth;
    private static int ownerHeight;

    private static bool dialogResult;

    public ConfigWindow()
    {
      InitializeComponent();

      this.MouseLeftButtonDown += (sender, e) => this.DragMove();
      this.ShowInTaskbar = false;
    }

    private void configWindow_Loaded(object sender, RoutedEventArgs e)
    {
      dlg.MinHeight = dlg.ActualHeight;
      dlg.MaxHeight = dlg.ActualHeight;
    }

    public static Config Show(Window owner)
    {
      dlg = new ConfigWindow();
      dlg.Owner = owner;
      dlg.Owner.IsEnabled = false;
      activated = false;
      modified = false;

      ownerWidth = (int)dlg.Owner.Width;
      ownerHeight = (int)dlg.Owner.Height;

      lang = MainWindow.lang;
      Lang.Localized.SetToResources(dlg, lang);

      config = MainWindow.config;
      originalConfig = config.Clone();

      dlg.SetupLanguageComboBox();

      dlg.DataContext = config;

      dlg.ShowDialog();

      dlg.Owner.IsEnabled = true;
      dlg.Owner.Focus();

      MainWindow.databaseChanged = databaseChanged;

      if (dialogResult)
        return config;
      else
        return originalConfig;
    }

    public void SetupLanguageComboBox()
    {
      string curLanguage = config.Language;

      if (config.Languages.Count > 0) config.Languages.Clear();

      var defaultItem = new LanguageList();
      defaultItem.Text = "日本語（デフォルト）";
      defaultItem.Value = "Default";
      config.Languages.Add(defaultItem);

      string dataDirPath = AppDomain.CurrentDomain.BaseDirectory + @"Data\";

      if (!Directory.Exists(dataDirPath)) return;

      var files = System.IO.Directory.GetFiles(dataDirPath, "lang.*.xml", System.IO.SearchOption.TopDirectoryOnly);

      foreach (var file in files)
      {
        var loadLang = LoadLanguageData(file);

        if (loadLang == null) continue;

        var item = new LanguageList();
        item.Text = loadLang.LanguageName ?? Path.GetFileName(file);
        item.Value = Path.GetFileNameWithoutExtension(file).Replace("lang.", "");
        config.Languages.Add(item);
      }

      config.Language = curLanguage;
    }

    public static Lang.Sentence LoadLanguageData(string path)
    {
      System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(Lang.Sentence));
      using (var sr = new StreamReader(path, new UTF8Encoding(false)))
      {
        return (Lang.Sentence)serializer.Deserialize(sr);
      }
    }



    private void okCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (modified)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void okCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      MainWindow.SaveConfigs();
      dialogResult = true;
      Window_Hide();
    }

    private void cancelCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      dlg.Owner.Width = ownerWidth;
      dlg.Owner.Height = ownerHeight;
      config = originalConfig;
      dialogResult = false;
      Window_Hide();
    }

    private void applyCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (modified)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void applyCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      MainWindow.SaveConfigs();
      originalConfig = config.Clone();
    }

    private void databaseReloadCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (config == null) return;

      if (File.Exists(MainWindow.BaseDirectory + config.DatabasePath))
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void databaseReloadCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      MainWindow.nameDB = MainWindow.LoadDB(false);
      databaseChanged = MainWindow.databaseChanged;
    }

    private void databaseUpdateCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (config == null) return;

      if (File.Exists(MainWindow.BaseDirectory + config.DatabasePath))
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void databaseUpdateCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      try
      {
        string gameExePath = null;

        if (!String.IsNullOrEmpty(config.GameDirPath))
        {
          gameExePath = config.GameDirPath + "game.exe";

          if (!File.Exists(gameExePath))
          {
            gameExePath = null;
          }
        }

        if (String.IsNullOrEmpty(gameExePath))
        {
          OpenFileDialog dlg = new OpenFileDialog();
          dlg.Filter = "game.exe|game.exe";

          if (dlg.ShowDialog() == true)
          {
            gameExePath = dlg.FileName;
          }
        }

        if (String.IsNullOrEmpty(gameExePath)) return;

        this.IsEnabled = false;
        MainWindow.DoEvents();

        string message = MainWindow.UpdateDB(gameExePath);

        if (String.IsNullOrEmpty(message))
        {
          originalConfig.DatabaseWriteTime = config.DefaultLstWriteTime;
          MessageWindow.Show(this, lang.DatabaseUpdated, lang.Info);
        }
        else if (message == "New information not found")
        {
          MessageWindow.Show(this, lang.NewInformationNotFound, lang.Info);
        }
        else
        {
          MessageWindow.Show(this, message, lang.Error);
        }
      }
      catch (Exception ex)
      {
        MessageWindow.Show(this, ex.Message, lang.Error);
      }
      finally
      {
        this.IsEnabled = true;
        this.Focus();
        databaseChanged = MainWindow.databaseChanged;
      }
    }

    private void referFolderCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var dlg = new CommonOpenFileDialog();
      dlg.IsFolderPicker = true;
      dlg.EnsureReadOnly = false;
      dlg.AllowNonFileSystemItems = false;

      if (!String.IsNullOrEmpty(config.UsersFolderPath))
      {
        dlg.InitialDirectory = Path.GetDirectoryName(config.UsersFolderPath);
      }
      else if (!String.IsNullOrEmpty(currentDir))
      {
        dlg.InitialDirectory = currentDir;
      }

      if (dlg.ShowDialog() == CommonFileDialogResult.Ok)
      {
        config.UsersFolderPath = dlg.FileName;
      }

      modified = true;
    }

    private void referFileCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var element = (FrameworkElement)e.Source;

      OpenFileDialog dlg = new OpenFileDialog();

      var dataDir = MainWindow.BaseDirectory + @"Data\";
      if (!String.IsNullOrEmpty(currentDir))
      {
        dlg.InitialDirectory = currentDir;
      }
      else if (Directory.Exists(dataDir))
      {
        dlg.InitialDirectory = dataDir;
      }

      if (element.Name == "btnCFilePath")
      {
        dlg.Filter = lang.CFile + "|*.---C";

        if (!String.IsNullOrEmpty(config.DefaultCFilePath))
        {
          dlg.InitialDirectory = Path.GetDirectoryName(config.DefaultCFilePath);
        }

        if (dlg.ShowDialog() != true) return;

        config.DefaultCFilePath = dlg.FileName;
      }
      else if (element.Name == "btnPFilePath")
      {
        dlg.Filter = lang.PFile + "|*.--P";

        if (!String.IsNullOrEmpty(config.DefaultPFilePath))
        {
          dlg.InitialDirectory = Path.GetDirectoryName(config.DefaultPFilePath);
        }

        if (dlg.ShowDialog() != true) return;

        config.DefaultPFilePath = dlg.FileName;
      }
      else
      {
        return;
      }

      currentDir = Path.GetDirectoryName(dlg.FileName);

      modified = true;
    }

    private void resetWindowSizeCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (config != null && (bool)cbRestoreWindowSize.IsChecked && (config.Window.Width != 800 || config.Window.Height != 700))
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void resetWindowSizeCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      config.Window.Width = 800;
      config.Window.Height = 700;
      dlg.Owner.Width = 800;
      dlg.Owner.Height = 700;
      modified = true;
    }

    private void cmbLanguage_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (!activated) return;

      lang = Lang.Localized.SetLanguage(this, config.Language, MainWindow.defaultLang);

      modified = true;
    }

    private void RadioButton_Checked(object sender, RoutedEventArgs e)
    {
      if (rbUseUsersFolder.IsChecked == true)
      {
        gridFolderWhenNew.IsEnabled = true;
      }
      else
      {
        gridFolderWhenNew.IsEnabled = false;
      }

      if (!activated) return;


      modified = true;
    }

    private void cbCFilePath_CheckChanged(object sender, RoutedEventArgs e)
    {
      if (!activated) return;

      modified = true;
    }

    private void cbPFilePath_CheckChanged(object sender, RoutedEventArgs e)
    {
      if (!activated) return;

      modified = true;
    }

    private void SetDefaultRadioButton_Checked(object sender, RoutedEventArgs e)
    {
      if (!activated) return;

      modified = true;
    }

    private void CheckBox_CheckChanged(object sender, RoutedEventArgs e)
    {
      if (!activated) return;

      modified = true;
    }



    private void Window_Activated(object sender, EventArgs e)
    {
      if (!activated)
      {
        var story = (System.Windows.Media.Animation.Storyboard)this.FindResource("fadeIn");
        story.Begin();
        activated = true;
      }
      else if (MainWindow.updateChecking)
      {
        MainWindow.updateChecking = false;
        MainWindow.CheckUpdated(this);
        MainWindow.updateChecking = true;
      }
    }

    private void FadeInAnimation_Completed(object sender, EventArgs e)
    {
      var story = (System.Windows.Media.Animation.Storyboard)this.FindResource("fadeIn");
      story.Stop();
    }

    private void Window_Closing(object sender, CancelEventArgs e)
    {
      e.Cancel = true;

      dlg.MinHeight = 0;
      dlg.MaxHeight = double.PositiveInfinity;

      var story = (System.Windows.Media.Animation.Storyboard)this.FindResource("fadeOut");
      story.Begin();
    }

    private void Window_Hide()
    {
      var story = (System.Windows.Media.Animation.Storyboard)this.FindResource("fadeOut");
      story.Begin();
    }

    private void FadeOutAnimation_Completed(object sender, EventArgs e)
    {
      var story = (System.Windows.Media.Animation.Storyboard)this.FindResource("fadeOut");
      story.Stop();

      this.Hide();
      this.Owner.Activate();
    }
  }
}
