﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace DLC_Tool
{
  public partial class MainWindow : Window
  {
    private static readonly string configPath = AppDomain.CurrentDomain.BaseDirectory + "DLC Tool Custom.xml";
    private static readonly string[] supportedExtLst = new string[] { ".lst", ".rst", ".bcm" };
    private static readonly string[] supportedExtCos = new string[] { ".---C", ".--P", ".TMC", ".TMCL", ".--H", ".--HL" };

    public static readonly Dictionary<byte, string> CharaNames = new Dictionary<byte, string>()
    {
      { 0, "ZACK" }, { 1, "TINA" }, { 2, "JANNLEE" }, { 3, "EIN" }, { 4, "HAYABUSA" },
      { 5, "KASUMI" }, { 6, "GENFU" }, { 7, "HELENA" }, { 8, "LEON" }, { 9, "BASS" },
      { 10, "KOKORO" }, { 11, "HAYATE" }, { 12, "LEIFANG" }, { 13, "AYANE" }, { 14, "ELIOT" },
      { 15, "LISA" }, { 16, "ALPHA152" }, { 19, "BRAD" }, { 20, "CHRISTIE" },
      { 21, "HITOMI" }, { 24, "BAYMAN" }, { 29, "RIG" }, { 30, "MILA" },
      { 31, "AKIRA" }, { 32, "SARAH" }, { 33, "PAI" }, { 39, "MOMIJI" }, { 40, "RACHEL" }, { 41, "JACKY" },
      { 42, "MARIE" }, { 43, "PHASE4" }, { 44, "NYOTENGU" },
      { 45, "HONOKA" }, { 46, "RAIDOU" }, { 47, "NAOTORA" }, { 48, "MAI" }
    };

    public static readonly List<byte> FemaleIDs = new List<byte>
    {
      1, 5, 7, 10, 12, 13, 15, 16, 20, 21, 30, 32, 33, 39, 40, 42, 43, 44, 45, 47, 48
    };

    public static readonly List<byte> ParadiseSexyIDs = new List<byte>
    {
      1, 5, 7, 10, 12, 13, 15, 16, 20, 21, 30
    };

    public static readonly List<byte> ParadiseSexyIDs2 = new List<byte>
    {
      32, 33
    };

    public static readonly List<byte> DefaultSort = new List<byte>
    {
      16, // Alpha-152
      13, // AYANE
      20, // CHRISTIE
      7,  // HELENA
      21, // HITOMI
      45, // HONOKA
      5,  // KASUMI
      10, // KOKORO
      12, // LEIFANG
      15, // LISA
      48, // MAI
      42, // MARIE
      30, // MILA
      39, // MOMIJI
      47, // NAOTORA
      44, // NYOTENGU
      33, // PAI
      43, // PHASE4
      40, // RACHEL
      32, // SARAH
      1,  // TINA
      31,
      9,
      24,
      19,
      3,
      14,
      6,
      4,
      11,
      41,
      2,
      8,
      46,
      29,
      0
    };

    public static readonly List<byte> DefaultSortLocale = new List<byte>
    {
      13, // AYANE
      47, // NAOTORA
      7,  // HELENA
      5,  // KASUMI
      20, // CHRISTIE
      10, // KOKORO
      32, // SARAH
      48, // MAI
      1,  // TINA
      44, // NYOTENGU
      33, // PAI
      21, // HITOMI
      43, // PHASE4
      45, // HONOKA
      42, // MARIE
      30, // MILA
      39, // MOMIJI
      15, // LISA
      40, // RACHEL
      12, // LEIFANG
      16, // Alpha-152
      3,
      31,
      14,
      6,
      0,
      41,
      2,
      9,
      24,
      11,
      19,
      46,
      29,
      4,
      8
    };

    public static readonly Dictionary<byte, byte[]> SlotsInGame = new Dictionary<byte, byte[]>()
    {
      { 13, new byte[] { 3, 4, 5, 6 } }, // AYANE
      { 5, new byte[] { 3, 4, 5, 6 } }, // KASUMI

      { 20, new byte[] { 3, 5, 6 } }, // CHRISTIE
      { 7, new byte[] { 3, 5, 8 } }, // HELENA
      { 21, new byte[] { 3, 5, 6 } }, // HITOMI
      { 10, new byte[] { 3, 5, 6 } }, // KOKORO
      { 12, new byte[] { 3, 5, 8 } }, // LEIFANG
      { 15, new byte[] { 3, 5, 6 } }, // LISA
      { 30, new byte[] { 3, 5, 6 } }, // MILA
      { 39, new byte[] { 3, 4, 5, 6, 7, 8, 10 } }, // MOMIJI
      { 33, new byte[] { 1, 2 } }, // PAI
      { 40, new byte[] { 3, 5, 6, 7 } }, // RACHEL
      { 32, new byte[] { 1, 2 } }, // SARAH
      { 1, new byte[] { 3, 5, 8 } }, // TINA

      { 4, new byte[] { 1, 2, 3 } }, // HAYABUSA
      { 11, new byte[] { 1, 2 } }, // HAYATE

      { 31, new byte[] { 1, 2 } }, // AKIRA
      { 9, new byte[] { 0, 1, 2 } }, // BASS
      { 24, new byte[] { 0, 1, 2 } }, // BAYMAN
      { 19, new byte[] { 1, 2 } }, // BRAD
      { 3, new byte[] { 1, 2, 3 } }, // EIN
      { 14, new byte[] { 0, 1, 2 } }, // ELIOT
      { 6, new byte[] { 1, 2 } }, // GENFU
      { 41, new byte[] { 1, 2, 3 } }, // JACKY
      { 2, new byte[] { 1, 2 } }, // JANNLEE
      { 8, new byte[] { 0, 1, 2, 3 } }, // LEON
      { 29, new byte[] { 0, 1, 2 } }, // RIG
      { 0, new byte[] { 0, 1, 2 } } // ZACK
    };

    public static readonly Dictionary<byte, Dictionary<int, byte>> InnerLimits = new Dictionary<byte, Dictionary<int, byte>>()
    {
      { // AYANE
        13,
        new Dictionary<int, byte>() {
          { 0, 2 },
          { 9, 0 },
          { 14, 0 },
          { 17, 0 },
          { 18, 0 },
          { 21, 0 },
          { 22, 0 },
          { 25, 0 },
          { 29, 0 },
          { 30, 0 },
          { 31, 0 },
          { 37, 0 },
          { 40, 0 },
          { 41, 0 },
          { 42, 0 },
          { 50, 0 },
          { 51, 0 },
          { 52, 0 },
          { 54, 0 },
          { 55, 0 }
        }
      },
      { // KASUMI
        5,
        new Dictionary<int, byte>() {
          { 0, 2 },
          { 7, 0 },
          { 9, 0 },
          { 18, 0 },
          { 21, 0 },
          { 22, 0 },
          { 31, 0 },
          { 37, 0 },
          { 40, 0 },
          { 41, 0 },
          { 42, 0 },
          { 43, 0 },
          { 51, 0 },
          { 52, 0 },
          { 53, 0 }
        }
      },
      { // CHRISTIE
        20,
        new Dictionary<int, byte>() {
          { 0, 0 },
          { 2, 0 },
          { 9, 0 },
          { 12, 0 },
          { 18, 0 },
          { 21, 2 },
          { 22, 0 },
          { 23, 0 },
          { 24, 0 },
          { 25, 0 },
          { 30, 0 },
          { 31, 0 },
          { 36, 0 },
          { 37, 0 },
          { 40, 0 },
          { 41, 0 },
          { 43, 0 },
          { 48, 0 },
          { 49, 0 },
          { 50, 0 },
          { 51, 0 },
          { 52, 0 },
          { 54, 0 },
          { 55, 0 }
        }
      },
      { // HELENA
        7,
        new Dictionary<int, byte>() {
          { 0, 0 },
          { 9, 0 },
          { 12, 0 },
          { 18, 0 },
          { 20, 0 },
          { 22, 0 },
          { 23, 0 },
          { 24, 0 },
          { 31, 0 },
          { 37, 0 },
          { 40, 0 },
          { 41, 0 },
          { 43, 0 },
          { 45, 0 },
          { 49, 0 },
          { 50, 0 },
          { 51, 0 },
          { 52, 0 },
          { 54, 0 },
          { 55, 0 }
        }
      },
      { // HITOMI
        21,
        new Dictionary<int, byte>() {
          { 0, 0 },
          { 9, 0 },
          { 14, 0 },
          { 15, 0 },
          { 17, 0 },
          { 22, 0 },
          { 23, 0 },
          { 29, 0 },
          { 31, 0 },
          { 36, 0 },
          { 40, 0 },
          { 41, 0 },
          { 42, 0 },
          { 43, 0 },
          { 48, 0 },
          { 49, 0 },
          { 51, 0 },
          { 52, 0 }
        }
      },
      { // KOKORO
        10,
        new Dictionary<int, byte>() {
          { 0, 2 },
          { 9, 0 },
          { 14, 0 },
          { 15, 0 },
          { 22, 0 },
          { 23, 0 },
          { 25, 0 },
          { 36, 0 },
          { 37, 0 },
          { 40, 0 },
          { 41, 0 },
          { 42, 0 },
          { 49, 0 },
          { 51, 0 },
          { 52, 0 }
        }
      },
      { // LEIFANG
        12,
        new Dictionary<int, byte>() {
          { 0, 0 },
          { 9, 0 },
          { 12, 0 },
          { 14, 0 },
          { 15, 0 },
          { 17, 0 },
          { 18, 0 },
          { 19, 0 },
          { 22, 0 },
          { 23, 0 },
          { 30, 0 },
          { 31, 0 },
          { 36, 0 },
          { 37, 0 },
          { 38, 0 },
          { 40, 0 },
          { 41, 0 },
          { 51, 0 },
          { 52, 0 },
          { 54, 0 }
        }
      },
      { // LISA
        15,
        new Dictionary<int, byte>() {
          { 0, 0 },
          { 9, 0 },
          { 12, 0 },
          { 18, 0 },
          { 21, 0 },
          { 22, 0 },
          { 23, 0 },
          { 30, 0 },
          { 36, 0 },
          { 40, 0 },
          { 41, 0 },
          { 43, 0 },
          { 48, 0 },
          { 50, 0 },
          { 51, 0 },
          { 52, 0 },
          { 54, 0 },
          { 55, 0 }
        }
      },
      { // MILA
        30,
        new Dictionary<int, byte>() {
          { 0, 0 },
          { 9, 0 },
          { 12, 0 },
          { 14, 0 },
          { 17, 0 },
          { 18, 0 },
          { 19, 0 },
          { 21, 0 },
          { 22, 0 },
          { 23, 0 },
          { 24, 0 },
          { 25, 0 },
          { 29, 0 },
          { 30, 0 },
          { 31, 0 },
          { 36, 0 },
          { 37, 0 },
          { 40, 0 },
          { 41, 0 },
          { 48, 0 },
          { 50, 0 },
          { 51, 0 },
          { 52, 0 },
          { 54, 0 }
        }
      },
      { // MOMIJI
        39,
        new Dictionary<int, byte>() {
          { 0, 0 },
          { 9, 0 },
          { 12, 0 },
          { 14, 0 },
          { 17, 0 },
          { 20, 0 },
          { 22, 0 },
          { 23, 0 },
          { 25, 0 },
          { 30, 0 },
          { 31, 0 },
          { 36, 0 },
          { 40, 0 },
          { 41, 0 },
          { 43, 0 },
          { 45, 0 },
          { 48, 0 },
          { 49, 0 },
          { 50, 0 },
          { 51, 0 },
          { 52, 0 },
          { 55, 0 }
        }
      },
      { // RACHEL
        40,
        new Dictionary<int, byte>() {
          { 0, 0 },
          { 9, 0 },
          { 12, 0 },
          { 18, 0 },
          { 21, 0 },
          { 22, 0 },
          { 23, 0 },
          { 24, 0 },
          { 29, 0 },
          { 31, 0 },
          { 36, 0 },
          { 40, 0 },
          { 41, 0 },
          { 43, 0 },
          { 48, 0 },
          { 49, 0 },
          { 50, 0 },
          { 51, 0 },
          { 52, 0 },
          { 55, 0 }
        }
      },
      { // TINA
        1,
        new Dictionary<int, byte>() {
          { 0, 0 },
          { 9, 0 },
          { 12, 0 },
          { 14, 0 },
          { 17, 0 },
          { 18, 0 },
          { 19, 0 },
          { 21, 0 },
          { 22, 0 },
          { 23, 0 },
          { 29, 0 },
          { 30, 0 },
          { 31, 0 },
          { 36, 0 },
          { 40, 0 },
          { 41, 0 },
          { 43, 0 },
          { 48, 0 },
          { 50, 0 },
          { 51, 0 },
          { 52, 0 },
          { 54, 0 },
          { 55, 0 }
        }
      },
      { // SARAH
        32,
        new Dictionary<int, byte>() {
          { 0, 0 },
          { 3, 0 },
          { 4, 0 },
          { 6, 0 },
          { 9, 0 },
          { 10, 0 },
          { 11, 0 },
          { 12, 0 }
        }
      },
      { // PAI
        33,
        new Dictionary<int, byte>() {
          { 0, 0 },
          { 3, 0 },
          { 4, 0 },
          { 5, 0 },
          { 6, 0 },
          { 10, 0 },
          { 12, 0 }
        }
      },
      { // MARIE
        42,
        new Dictionary<int, byte>() {
          { 5, 0 },
          { 6, 0 },
          { 8, 0 },
          { 14, 2 },
          { 15, 0 },
          { 16, 0 },
          { 27, 0 },
          { 31, 0 },
          { 34, 0 },
          { 35, 0 },
          { 38, 0 },
          { 39, 0 },
          { 48, 0 },
          { 49, 0 },
          { 50, 0 },
          { 51, 0 },
          { 52, 0 },
          { 54, 0 }
        }
      },
      { // PHASE4
        43,
        new Dictionary<int, byte>() {
          { 0, 0 },
          { 3, 0 },
          { 5, 0 },
          { 10, 0 },
          { 11, 0 },
          { 14, 0 },
          { 15, 0 },
          { 16, 0 },
          { 23, 0 },
          { 27, 0 },
          { 31, 0 },
          { 33, 0 },
          { 34, 0 },
          { 35, 0 },
          { 36, 0 },
          { 38, 0 },
          { 39, 0 },
          { 41, 0 },
          { 47, 0 },
          { 49, 0 },
          { 50, 0 },
          { 51, 0 },
          { 52, 0 }
        }
      },
      { // NYOTENGU
        44,
        new Dictionary<int, byte>() {
          { 0, 0 },
          { 6, 0 },
          { 13, 0 },
          { 14, 0 },
          { 15, 0 },
          { 16, 0 },
          { 17, 0 },
          { 18, 0 },
          { 24, 0 },
          { 27, 0 },
          { 33, 0 },
          { 38, 0 },
          { 39, 0 },
          { 43, 0 },
          { 47, 0 },
          { 49, 0 },
          { 51, 0 },
          { 54, 0 }
        }
      },
      { // HONOKA
        45,
        new Dictionary<int, byte>() {
          { 0, 0 },
          { 1, 0 },
          { 4, 0 },
          { 7, 0 },
          { 16, 0 },
          { 20, 0 },
          { 24, 0 },
          { 27, 0 },
          { 28, 0 },
          { 30, 0 },
          { 32, 0 },
          { 39, 0 },
          { 40, 0 },
          { 41, 0 },
          { 42, 0 }
        }
      },
      { // NAOTORA
        47,
        new Dictionary<int, byte>() {
          { 4, 0 },
          { 7, 0 },
          { 8, 2 },
          { 9, 0 },
          { 14, 0 },
          { 15, 0 },
          { 16, 0 },
          { 17, 0 },
          { 18, 0 },
          { 19, 0 }
        }
      },
      { // MAI
        48,
        new Dictionary<int, byte>() {
          { 4, 0 }
        }
      }
    };

    public static readonly string[] FileTypes = { ".---C", ".--P", ".TMC", ".TMCL", "1.--H", "1.--HL", "2.--H", "2.--HL", "3.--H", "3.--HL", "4.--H", "4.--HL" };

    public static readonly string BaseDirectory = AppDomain.CurrentDomain.BaseDirectory;

    public static readonly string DefaultDatabasePath = "file5lr.dat";

    public static readonly string DefaultDefaultLstPath = @"Data\default.lst";

    public static readonly short DefaultMaxUndoCount = 20;

    private static readonly byte[] FirstName = new byte[8] { 0x32, 0x52, 0x42, 0x36, 0x33, 0x40, 0x31, 0x53 };
    private static readonly byte[] FirstAsset = new byte[12] { 0x19, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0x1A, 0x00, 0x00, 0x00 };
    private static readonly byte[] FirstData = new byte[8] { 0x14, 0x3D, 0x08, 0x00, 0x01, 0x00, 0x00, 0xE0 };

    private const string RegKeyName = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Steam App 311730";
    private const string RegGetValueName = "InstallLocation";

  }

  public class Const
  {
    public const string Bcm = "bcm";
    public const string Default = "Default";

    public const string Add = "Add";
    public const string Temporary = "Temporary";

    public const string DuplicatedCharacter = "DuplicatedCharacter";
    public const string OverMaxSlot = "OverMaxSlot";
    public const string SlotNotSetted = "SlotNotSetted";
    public const string SlotIsDuplicatedInThisLst = "SlotIsDuplicatedInThisLst";
    public const string SlotIsDuplicatedWithOtherDlc = "SlotIsDuplicatedWithOtherDlc";
    public const string FilesNotExists = "FilesNotExists";
    public const string InnerOnlyOneSideIsSet = "InnerOnlyOneSideIsSet";
    public const string RequiredFilesIsNotSet = "RequiredFilesIsNotSet";
    public const string InnerOverLimit = "InnerOverLimit";
  }
}