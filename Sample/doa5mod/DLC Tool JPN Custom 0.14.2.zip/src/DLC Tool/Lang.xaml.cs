﻿using System;
using System.Collections;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows;
using System.Reflection;
using System.Runtime.Serialization;
using System.Xml.Serialization;


namespace Lang
{
  partial class Localized : ResourceDictionary
  {
    public static Sentence SetFromResources(FrameworkElement element)
    {
      ResourceDictionary resources = GetResources(element);

      Type t = typeof(Lang.Sentence);

      var lang = new Lang.Sentence();
      lang.LanguageName = "Default";
      lang.CultureName = "ja-JP";

      foreach (DictionaryEntry res in resources)
      {
        if (res.Value.GetType() != typeof(string)) continue;

        string resourceKey = res.Key.ToString();
        string resource = (string)res.Value;

        resource = resource.Replace(@"\r\n", "\r\n");

        PropertyInfo pi = t.GetProperty(resourceKey);
        pi.SetValue(lang, resource, null);
      }

      return lang;
    }

    private static ResourceDictionary GetResources(FrameworkElement element)
    {
      ResourceDictionary resources = null;
      foreach (var dict in element.Resources.MergedDictionaries)
      {
        if (dict.Source.ToString() == "Lang.xaml")
        {
          resources = dict;
          break;
        }
      }
      return resources;
    }

    public static void SetToResources(FrameworkElement element, Sentence lang)
    {
      PropertyInfo[] infoArray = lang.GetType().GetProperties();

      ResourceDictionary resources = GetResources(element);

      foreach (PropertyInfo info in infoArray)
      {
        if (!resources.Contains(info.Name)) continue;

        var value = info.GetValue(lang, null);
        element.Resources[info.Name] = value;
      }
    }

    public static Sentence SetLanguage(FrameworkElement element, string cultureName, Sentence defaultLang)
    {
      var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
      var culture = CultureInfo.CurrentCulture;
      var langFilePath = baseDirectory + @"\Data\lang." + cultureName + ".xml";

      Sentence lang = defaultLang.Clone();

      if (File.Exists(langFilePath))
      {
        lang = LoadLanguageData(langFilePath, lang);
      }
      else if (culture.Name != "ja-JP" && File.Exists(langFilePath = baseDirectory + @"\Data\lang.en-US.xml"))
      {
        lang = LoadLanguageData(langFilePath, lang);
      }

      if (lang != null) SetToResources(element, lang);

      return lang;
    }

    public static void WriteXml(Sentence lang, string savePath)
    {
      XmlSerializer serializer = new XmlSerializer(typeof(Lang.Sentence));
      using (var sw = new StreamWriter(savePath, false, new UTF8Encoding(false)))
      {
        serializer.Serialize(sw, lang);
      }
    }

    public static Sentence LoadLanguageData(string path, Sentence lang)
    {
      Sentence loadLang = null;

      XmlSerializer serializer = new XmlSerializer(typeof(Sentence));
      using (var sr = new StreamReader(path, new UTF8Encoding(false)))
      {
        loadLang =  (Sentence)serializer.Deserialize(sr);
      }

      if (loadLang == null) return lang;


      PropertyInfo[] infoArray = loadLang.GetType().GetProperties();
      Type t = typeof(Lang.Sentence);

      foreach (PropertyInfo info in infoArray)
      {
        var value = info.GetValue(loadLang, null);

        if (value == null) continue;

        string resource = (string)value;

        resource = resource.Replace(@"\r\n", "\r\n");

        PropertyInfo pi = t.GetProperty(info.Name);
        if (pi != null) pi.SetValue(lang, resource, null);
      }

      return lang;
    }
  }

  public class Sentence
  {
    public Sentence Clone()
    {
      return (Sentence)MemberwiseClone();
    }

    [DataMember(Order = 0)]
    public string LanguageName { get; set; }
    public string CultureName { get; set; }

    public string Zack { get; set; }
    public string Tina { get; set; }
    public string Jannlee { get; set; }
    public string Ein { get; set; }
    public string Hayabusa { get; set; }
    public string Kasumi { get; set; }
    public string Genfu { get; set; }
    public string Helena { get; set; }
    public string Leon { get; set; }
    public string Bass { get; set; }
    public string Kokoro { get; set; }
    public string Hayate { get; set; }
    public string Leifang { get; set; }
    public string Ayane { get; set; }
    public string Eliot { get; set; }
    public string Lisa { get; set; }
    public string Alpha152 { get; set; }
    public string Brad { get; set; }
    public string Christie { get; set; }
    public string Hitomi { get; set; }
    public string Bayman { get; set; }
    public string Rig { get; set; }
    public string Mila { get; set; }
    public string Akira { get; set; }
    public string Sarah { get; set; }
    public string Pai { get; set; }
    public string Momiji { get; set; }
    public string Rachel { get; set; }
    public string Jacky { get; set; }
    public string Marie { get; set; }
    public string Phase4 { get; set; }
    public string Nyotengu { get; set; }
    public string Honoka { get; set; }
    public string Raidou { get; set; }
    public string Naotora { get; set; }
    public string Mai { get; set; }

    public string OK { get; set; }
    public string Cancel { get; set; }
    public string Yes { get; set; }
    public string No { get; set; }
    public string Auto { get; set; }
    public string Info { get; set; }
    public string Error { get; set; }
    public string Caution { get; set; }
    public string Confirm { get; set; }
    public string Message { get; set; }
    public string TextStatus { get; set; }
    public string ExitWithoutSave { get; set; }
    public string Exit { get; set; }
    public string Overwrite { get; set; }
    public string OverwriteYes { get; set; }
    public string Saved { get; set; }
    public string FailedToCreateBackup { get; set; }
    public string UnsupportedFile { get; set; }
    public string FailedToReopen { get; set; }
    public string ConfirmOpenFile { get; set; }
    public string ConfirmFileUpdated { get; set; }

    public string Continue { get; set; }
    public string Add { get; set; }
    public string Insert { get; set; }
    public string Delete { get; set; }
    public string Copy { get; set; }
    public string Paste { get; set; }
    public string Duplicate { get; set; }
    public string Other { get; set; }
    public string Reset { get; set; }
    public string DecideSort { get; set; }
    public string CharaFemale { get; set; }
    public string CharaMale { get; set; }

    public string Name { get; set; }
    public string Comment { get; set; }
    public string Type { get; set; }
    public string File { get; set; }

    public string BtnNew { get; set; }
    public string BtnEmptyNew { get; set; }
    public string MenuNewDlc { get; set; }

    public string BtnOpen { get; set; }
    public string MenuRevert { get; set; }
    public string MenuReloadDlc { get; set; }
    public string MenuOpenDlcDir { get; set; }
    public string MenuOpenBuildDir { get; set; }

    public string BtnSave { get; set; }
    public string MenuSaveAs { get; set; }
    public string MenuSaveBcm { get; set; }
    public string MenuSaveAsBcm { get; set; }
    public string MenuExportLst { get; set; }

    public string BtnBuild { get; set; }
    public string MenuBuildAll { get; set; }

    public string BtnConfig { get; set; }

    public string LabelDlcDir { get; set; }

    public string MenuDuplicateDlc { get; set; }
    public string MenuDeleteDlc { get; set; }
    public string MenuLstMode { get; set; }

    public string DlcNum { get; set; }
    public string CostumeCount { get; set; }
    public string ExtractFiles { get; set; }
    public string ExtractFilesWithCreateDir { get; set; }

    public string CharaName { get; set; }
    public string DgcSlot { get; set; }
    public string DgcInner { get; set; }
    public string DetailsCharaName { get; set; }
    public string DetailsSlot { get; set; }
    public string DetailsInner { get; set; }

    public string AddFromFile { get; set; }
    public string ResetInner { get; set; }
    public string UpdateThumbs { get; set; }
    public string DisplayThumb { get; set; }
    public string SlotSequential { get; set; }
    public string ChangeCharacter { get; set; }

    public string HairType { get; set; }
    public string Hair { get; set; }
    public string Face { get; set; }

    public string OpenWithExplorer { get; set; }
    public string AddOrReplace { get; set; }
    public string Flags { get; set; }



    public string Config { get; set; }
    public string AddedCharacter { get; set; }
    public string SkipLoadCostume { get; set; }
    public string InputDlcNameTitle { get; set; }
    public string InputDlcNameNote { get; set; }
    public string IsTemporary { get; set; }
    public string FoundErrorsInLst { get; set; }
    public string FoundErrorsInDefault { get; set; }

    public string AllSupportedFormats { get; set; }
    public string DlcToolDataFile { get; set; }
    public string LstFile { get; set; }
    public string BcmFile { get; set; }
    public string CFile { get; set; }
    public string PFile { get; set; }

    public string SaveDlcToolData { get; set; }
    public string DlcToolDataFileSaved { get; set; }
    public string ExportLst { get; set; }
    public string LstExported { get; set; }
    public string SaveBcm { get; set; }
    public string BcmSaved { get; set; }
    public string DlcBuilded { get; set; }
    public string DlcsBuilded { get; set; }
    public string BuildCancelledDlcNumDuplicated { get; set; }
    public string CreatingAndNotSaved { get; set; }

    public string RegistFromFolders { get; set; }
    public string CostumesAlreadyExists { get; set; }
    public string AddCostumes { get; set; }
    public string ReplaceFiles { get; set; }
    public string StartRegistration { get; set; }

    public string CompletedAddAndReplaceFiles { get; set; }
    public string NotAddAndReplaceFiles { get; set; }

    public string SkippedReadingUnsupportedData { get; set; }

    public string CosNameNotFoundInDatabase { get; set; }
    public string CosSlotIsDuplicatedInLst { get; set; }
    public string CosRequiredFilesNotFound { get; set; }
    public string NotFound { get; set; }
    public string DlcNumMustNumber6Digits { get; set; }
    public string FailedToBuildDlc { get; set; }
    public string FailedToBuildDlcs { get; set; }
    public string CosSlotIsDuplicatedWithOtherDlc { get; set; }
    public string SetSavePath { get; set; }
    public string ConfirmBuildDlc { get; set; }
    public string ConfirmBuildDlcWithProblem { get; set; }
    public string Build { get; set; }
    public string ConfirmCopyDlcFiles { get; set; }

    public string DisposeDataWhenCreateNew { get; set; }
    public string NotAddFromFolderInDefaultMode { get; set; }
    public string NotAddFromFolderInBcmMode { get; set; }
    public string NotAddFromFileInDefaultMode { get; set; }
    public string NotAddFromFileInBcmMode { get; set; }
    public string NotAddFromFileToTemporaryData { get; set; }

    public string SelectFolderToSaveDlcFolder { get; set; }
    public string BcmMode { get; set; }
    public string DefaultSettingsMode { get; set; }
    public string OverMaxSlot { get; set; }
    public string SlotNotSetted { get; set; }
    public string SlotIsDuplicatedWithOtherDlc { get; set; }
    public string SlotIsDuplicatedInThisLst { get; set; }

    public string SelectFolderToExtractFiles { get; set; }
    public string SelectFolderToExtractFilesWithCreateDir { get; set; }
    public string ConfirmFolderExistExtractFiles { get; set; }
    public string Extract { get; set; }
    public string FilesExtracted { get; set; }
    public string FailedExtractedFiles { get; set; }

    public string NotFoundInDatabaseAndAbort { get; set; }
    public string DatabaseNotFound { get; set; }

    public string RequiredFilesIsNotSet { get; set; }
    public string InnerOnlyOneSideIsSet { get; set; }
    public string FilesNotExists { get; set; }
    public string DuplicatedCharacter { get; set; }
    public string InnerOverLimit { get; set; }

    public string Apply { get; set; }
    public string DatabaseUpdateFailed { get; set; }
    public string DatabaseUpdated { get; set; }
    public string NewInformationNotFound { get; set; }
    public string SelectLanguage { get; set; }
    public string Database { get; set; }
    public string Reload { get; set; }
    public string Update { get; set; }
    public string OutputPathWhenCreateNew { get; set; }
    public string UseFolderSelectDialog { get; set; }
    public string UseUsersFolder { get; set; }
    public string EnableCopyToDlcFolder { get; set; }
    public string AutoSetWhenNotSetted { get; set; }
    public string UseDefaultCFile { get; set; }
    public string UseDefaultPFile { get; set; }
    public string DefaultCFilePath { get; set; }
    public string DefaultPFilePath { get; set; }
    public string DefaultHighPriorityUse { get; set; }
    public string DefaultOnlyUse { get; set; }
    public string DefaultNotUse { get; set; }
    public string RestoreWindowSize { get; set; }
    public string OpenLastDd { get; set; }


    public string ChangeOutputPath { get; set; }
    public string AddFromFolder { get; set; }

    public string DlcPaste { get; set; }
    public string CostumePaste { get; set; }
    public string HairStylePaste { get; set; }
    public string FilePaste { get; set; }

    public string DlcAddLst { get; set; }
    public string DlcAddBcm { get; set; }
    public string DlcAdd { get; set; }
    public string DlcDuplicate { get; set; }
    public string DlcDelete { get; set; }
    public string DlcDecideSort { get; set; }
    public string DlcChangeName { get; set; }
    public string DlcChangeNumber { get; set; }
    public string DlcChangeComment { get; set; }
    public string DlcSort { get; set; }

    public string CostumeChangeComment { get; set; }
    public string CostumeChangeSlot { get; set; }
    public string CostumeAddFromFile { get; set; }
    public string CostumeAdd { get; set; }
    public string CostumeInsert { get; set; }
    public string CostumeDuplicate { get; set; }
    public string CostumeDelete { get; set; }
    public string CostumeDecideSort { get; set; }
    public string CostumeSort { get; set; }

    public string HairStyleAdd { get; set; }
    public string HairStyleInsert { get; set; }
    public string HairStyleDelete { get; set; }
    public string HairStyleReset { get; set; }
    public string HairChange { get; set; }
    public string FaceChange { get; set; }

    public string FileAdd { get; set; }
    public string FileDelete { get; set; }


    public string Shortcut { get; set; }
    public string Clipboard { get; set; }
    public string UnsupportedData { get; set; }
    public string DlcData { get; set; }
    public string CostumeData { get; set; }
    public string HairStyleData { get; set; }
    public string FileData { get; set; }
    public string TextData { get; set; }
    public string AutoSet { get; set; }
    public string HistoryStart { get; set; }



    public string Test { get; set; }

  }

}