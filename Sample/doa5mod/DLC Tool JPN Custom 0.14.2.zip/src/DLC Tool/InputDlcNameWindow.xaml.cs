﻿using System;
using System.Globalization;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Data;
using System.ComponentModel;
using System.Collections.ObjectModel;
using Message;

namespace DLC_Tool
{
  /// <summary>
  /// EditMaterialWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class InputDlcNameWindow : Window
  {
    private static Lang.Sentence lang = new Lang.Sentence();

    private static bool dialogResult;

    private bool IsActivated = false;

    public InputDlcNameWindow()
    {
      InitializeComponent();

      this.MouseLeftButtonDown += (sender, e) => this.DragMove();
      this.ShowInTaskbar = false;
    }

    private void btnOk_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = true;
      this.Close();
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = false;
    }

    private void tbName_KeyDown(object sender, KeyEventArgs e)
    {
      TextBox tb = sender as TextBox;
      ModifierKeys modifierKeys = Keyboard.Modifiers;

      if (e.Key == Key.System || e.Key == Key.Tab)
      {
        e.Handled = false;
      }
      else if ((Key.D0 <= e.Key && e.Key <= Key.D9) || (Key.NumPad0 <= e.Key && e.Key <= Key.NumPad9))
      {
        e.Handled = false;
      }
      else if (e.Key == Key.Enter && btnOk.IsEnabled)
      {
        e.Handled = true;
        dialogResult = true;
        this.Close();
      }
      else
      {
        e.Handled = true;
      }
    }

    private void tbName_KeyUp(object sender, KeyEventArgs e)
    {
      if (tbName.Text.Length > 0) btnOk.IsEnabled = true;
    }

    private void tb_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (target == null) return;
      target.SelectAll();
    }



    public static string Show(Window owner)
    {
      InputDlcNameWindow dlg = new InputDlcNameWindow();
      dlg.Owner = owner;
      dlg.Owner.IsEnabled = false;

      lang = MainWindow.lang;
      Lang.Localized.SetToResources(dlg, lang);

      dlg.tbName.Focus();

      dlg.IsActivated = false;
      dlg.ShowDialog();

      dlg.Owner.IsEnabled = true;
      dlg.Owner.Focus();

      if (dialogResult)
      {
        return dlg.tbName.Text;
      }
      else
      {
        return null;
      }
    }

    private void Window_Activated(object sender, EventArgs e)
    {
      if (!IsActivated) IsActivated = true;
    }

    private void Window_Closing(object sender, CancelEventArgs e)
    {
      e.Cancel = true;
      IsActivated = false;
      this.Hide();
      if (this.Owner != null) this.Owner.Activate();
    }
  }
}
