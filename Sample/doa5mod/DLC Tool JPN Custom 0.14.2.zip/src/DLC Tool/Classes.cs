﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;
using System.Xml.Serialization;

namespace DLC_Tool
{
  [Serializable]
  public class DlcToolData : NotifyPropertyChangedBase
  {
    public DlcToolData()
    {
      this.Dlcs = new ObservableCollection<DlcData>();
      this.Version = 1;
      this.History = MainWindow.commandManager.History;

      Common.ChangedEventHandler eventHandler = new Common.ChangedEventHandler(this.UpdateUndoCount);
      MainWindow.commandManager.Changed += eventHandler;
    }

    public void UpdateUndoCount(object sender)
    {
      this.UndoCount = MainWindow.commandManager.UndoCount;
    }

    public DlcToolData GetDataForSave()
    {
      DlcToolData data = (DlcToolData)MemberwiseClone();

      data.Dlcs = new ObservableCollection<DlcData>();
      foreach (var dlc in this.Dlcs)
      {
        if (!dlc.IsTemporary) data.Dlcs.Add(dlc);
      }

      return data;
    }


    public short Version { get; set; }
    private string _outputPath;
    public string OutputPath
    {
      get { return _outputPath; }
      set
      {
        _outputPath = value;
        OnPropertyChanged(nameof(OutputPath));
      }
    }

    public ObservableCollection<DlcData> Dlcs { get; private set; }


    private DlcData _dlc;
    [XmlIgnore]
    public DlcData Dlc
    {
      get { return _dlc; }
      set
      {
        _dlc = value;
        OnPropertyChanged(nameof(Dlc));
      }
    }

    private Costume _costume;
    [XmlIgnore]
    public Costume Costume
    {
      get { return _costume; }
      set
      {
        _costume = value;
        OnPropertyChanged(nameof(Costume));
      }
    }

    [XmlIgnore]
    public ObservableCollection<string> History { get; set; }

    private short _undoCount;
    [XmlIgnore]
    public short UndoCount
    {
      get { return _undoCount; }
      set
      {
        _undoCount = value;
        OnPropertyChanged(nameof(UndoCount));
      }
    }
  }

  [Serializable]
  public class DlcData : NotifyPropertyChangedBase
  {
    public DlcData()
    {
      Costumes = new ObservableCollection<Costume>();
      ErrorTexts = new Dictionary<string, string>();
      SkippedList = new List<string>();

      Name = "";
      DlcNum = "";
      BcmVer = 9;
      CostumeCount = "";
      Type = "";
      FilePath = "";
      IsIncluded = true;
    }

    public async void CheckCostumeCount()
    {
      await Task.Delay(200);

      int includedCount = Costumes.Where(elem => elem.IsIncluded).Count();
      this.CostumeCount = includedCount + " / " + Costumes.Count;
    }

    public void CheckCostumeError()
    {
      if (Type == Const.Bcm || Type == Const.Default) return;

      Error = false;
      Caution = false;

      foreach (var cos in Costumes)
      {
        if (cos.Error) Error = true;
        if (cos.Caution) Caution = true;
      }
    }

    public async void CheckCostumeSlot()
    {
      if (Type == Const.Bcm || Type == Const.Default) return;

      Error = false;
      Caution = false;

      await Task.Delay(20);

      foreach (var cos in Costumes)
      {
        cos.ErrorTexts[Const.OverMaxSlot] = "";
        cos.ErrorTexts[Const.SlotNotSetted] = "";
        cos.ErrorTexts[Const.SlotIsDuplicatedWithOtherDlc] = "";
        cos.ErrorTexts[Const.SlotIsDuplicatedInThisLst] = "";

        if (cos.IsIncluded == false) continue;

        // スロット数より大きければエラー
        if (
          cos.CostumeSlot >= MainWindow.defaultData.Charas[cos.ID].SlotCount &&
          !(MainWindow.ParadiseSexyIDs.Contains(cos.ID) && cos.CostumeSlot == 109) &&
          !(MainWindow.ParadiseSexyIDs2.Contains(cos.ID) && cos.CostumeSlot == 105)
        )
        {
          cos.ErrorTexts[Const.OverMaxSlot] = MainWindow.lang.OverMaxSlot;
        }

        // スロット番号に問題があるならエラー
        if (Array.FindIndex(cos.CostumeSlots.ToArray(), elem => elem.Slot == cos.CostumeSlot) == -1)
        {
          cos.ErrorTexts[Const.SlotNotSetted] = MainWindow.lang.SlotNotSetted;
        }

        // 他DLCと重複しているなら注意
        if (MainWindow.dlcCostumeData.ContainsKey(cos.ID))
        {
          var usedList = MainWindow.dlcCostumeData[cos.ID].Where(elem => elem.Slot == cos.CostumeSlot && elem.DlcNum != DlcNum).ToList();
          if (usedList.Count > 0)
          {
            string usedDlc = "";
            foreach (var used in usedList)
            {
              if (usedDlc.Length > 0) usedDlc += ", ";
              usedDlc += used.DlcNum;
            }
            cos.ErrorTexts[Const.SlotIsDuplicatedWithOtherDlc] = String.Format(MainWindow.lang.SlotIsDuplicatedWithOtherDlc, usedDlc);
          }
        }

        // ファイルのエラーをチェック
        cos.CheckFileErrors();

        // DLCデータ内で重複しているならエラー
        if (Costumes.Where(elem => elem.ID == cos.ID && elem.CostumeSlot == cos.CostumeSlot && elem.IsIncluded).Count() > 1)
        {
          cos.ErrorTexts[Const.SlotIsDuplicatedInThisLst] = MainWindow.lang.SlotIsDuplicatedInThisLst;
        }

        cos.BuildErrorText();

        if (cos.Error) Error = true;
        if (cos.Caution) Caution = true;
      }
    }

    public void CheckDuplicatedCharacter()
    {
      if (Type != Const.Default) return;

      foreach (var cos in Costumes)
      {
        cos.ErrorTexts[Const.DuplicatedCharacter] = "";

        if (Costumes.Where(elem => elem.ID == cos.ID).Count() > 1)
        {
          cos.ErrorTexts[Const.DuplicatedCharacter] = MainWindow.lang.DuplicatedCharacter;
        }

        cos.BuildErrorText();
      }
    }

    public void ResetIsAdded()
    {
      foreach (var cos in Costumes)
      {
        cos.IsAdded = false;
      }
    }

    public DlcData Clone()
    {
      DlcData cloned = (DlcData)MemberwiseClone();

      cloned.Costumes = new ObservableCollection<Costume>();
      foreach (var cos in Costumes)
      {
        Costume cosEntry = cos.Clone();
        cosEntry.CostumeSlotsSettedTime = DateTime.Now;
        cosEntry.SetCostumeSlots();
        cloned.Costumes.Add(cosEntry);
      }

      return cloned;
    }

    public string OutputPath { get; set; }

    private string _name;
    public string Name
    {
      get { return _name; }
      set
      {
        _name = value;
        OnPropertyChanged(nameof(Name));
      }
    }
    private string _dlcNum;
    public string DlcNum
    {
      get { return _dlcNum; }
      set
      {
        _dlcNum = value;
        OnPropertyChanged(nameof(DlcNum));
      }
    }
    private byte _bcmVer;
    public byte BcmVer
    {
      get { return _bcmVer; }
      set
      {
        _bcmVer = value;
        OnPropertyChanged(nameof(BcmVer));
      }
    }
    private string _costumeCount;
    public string CostumeCount
    {
      get { return _costumeCount; }
      set
      {
        _costumeCount = value;
        OnPropertyChanged(nameof(CostumeCount));
      }
    }
    private string _comment;
    public string Comment
    {
      get { return _comment; }
      set
      {
        _comment = value;
        OnPropertyChanged(nameof(Comment));
      }
    }

    public string FilePath { get; set; }

    private bool _isIncluded;
    public bool IsIncluded
    {
      get { return _isIncluded; }
      set
      {
        _isIncluded = value;
        OnPropertyChanged(nameof(IsIncluded));
      }
    }

    private string _type;
    [XmlIgnore]
    public string Type
    {
      get { return _type; }
      set
      {
        _type = value;
        OnPropertyChanged(nameof(Type));
      }
    }

    [XmlIgnore]
    public List<string> SkippedList { get; set; }


    private bool _isModified;
    [XmlIgnore]
    public bool IsModified
    {
      get { return _isModified; }
      set
      {
        _isModified = value;
        OnPropertyChanged(nameof(IsModified));
      }
    }

    private bool _isTemporary;
    [XmlIgnore]
    public bool IsTemporary
    {
      get { return _isTemporary; }
      set
      {
        _isTemporary = value;
        OnPropertyChanged(nameof(IsTemporary));
      }
    }

    private bool _caution;
    [XmlIgnore]
    public bool Caution
    {
      get { return _caution; }
      set
      {
        _caution = value;
        OnPropertyChanged(nameof(Caution));
      }
    }

    private bool _error;
    [XmlIgnore]
    public bool Error
    {
      get { return _error; }
      set
      {
        _error = value;
        OnPropertyChanged(nameof(Error));
      }
    }

    private string _errorText;
    [XmlIgnore]
    public string ErrorText
    {
      get { return _errorText; }
      set
      {
        _errorText = value;
        OnPropertyChanged(nameof(ErrorText));
      }
    }

    private Dictionary<string, string> _errorTexts;
    [XmlIgnore]
    public Dictionary<string, string> ErrorTexts
    {
      get { return _errorTexts; }
      set { _errorTexts = value; }
    }

    [NonSerialized]
    private bool _isDragging;
    [XmlIgnore]
    public bool IsDragging
    {
      get { return _isDragging; }
      set
      {
        _isDragging = value;
        OnPropertyChanged(nameof(IsDragging));
      }
    }
    [NonSerialized]
    private bool _isDragOver;
    [XmlIgnore]
    public bool IsDragOver
    {
      get { return _isDragOver; }
      set
      {
        _isDragOver = value;
        OnPropertyChanged(nameof(IsDragOver));
      }
    }

    public ObservableCollection<Costume> Costumes { get; private set; }
  }

  [Serializable]
  public class Costume : NotifyPropertyChangedBase
  {
    public Costume()
    {
      this.HStyles = new ObservableCollection<HairStyle>();
      this.OriginHStyles = new List<HairStyle>();
      this.ErrorTexts = new Dictionary<string, string>();

      this.CostumeSlot = 0;
      this.AddTexsCount = 1;
      this.IsIncluded = true;
      this.CFlags = "";
      this.ThumbnailPath = "";
    }

    public Costume(byte ID, bool isAdded)
    {
      this.HStyles = new ObservableCollection<HairStyle>();
      this.OriginHStyles = new List<HairStyle>();
      this.ErrorTexts = new Dictionary<string, string>();

      this.CostumeSlot = 0;
      this.AddTexsCount = 1;
      this.IsIncluded = true;
      this.CFlags = "";
      this.ThumbnailPath = "";

      this.InitFiles();
      this.ID = ID;
      this.SortID = (byte)MainWindow.DefaultSortLocale.IndexOf(ID);
      this.SetDefaultHStyle(MainWindow.defaultData, ID);
      this.SetCostumeSlots();

      if (isAdded)
      {
        this.IsAdded = true;
        this.ErrorTexts["RequiredFilesIsNotSet"] = MainWindow.lang.RequiredFilesIsNotSet;
        this.BuildErrorText();
      }
    }

    public void InitFiles()
    {
      this.Files = new ObservableCollection<CostumeFile>();
      for (byte i = 0; i < MainWindow.FileTypes.Length; i++)
      {
        this.Files.Add(new CostumeFile(i, MainWindow.FileTypes[i].Split('.')[1]));
      }
    }

    public void SetCostumeSlots()
    {
      if (!MainWindow.CostumeSlots.ContainsKey(this.ID)) return;

      if (CostumeSlotsSettedTime == MainWindow.CostumeSlotsSettedTime) return;

      int slot = this.CostumeSlot;

      if (this.CostumeSlots == null)
        this.CostumeSlots = new ObservableCollection<CostumeSlotItem>();
      else if (this.CostumeSlots.Count > 0)
        this.CostumeSlots.Clear();

      if (this.CostumeSlots2 == null)
        this.CostumeSlots2 = new ObservableCollection<CostumeSlotItem>();
      else if (this.CostumeSlots2.Count > 0)
        this.CostumeSlots2.Clear();

      foreach (var item in MainWindow.CostumeSlots[this.ID])
      {
        int innerLimit = 4;
        if (MainWindow.InnerLimits.ContainsKey(this.ID) && MainWindow.InnerLimits[this.ID].ContainsKey(item.Slot))
        {
          innerLimit = MainWindow.InnerLimits[this.ID][item.Slot];
        }

        bool female = false;
        if (MainWindow.FemaleIDs.Contains(this.ID)) female = true;

        var newItem = new CostumeSlotItem();
        newItem.Slot = item.Slot;
        newItem.Dlc = item.Dlc;
        newItem.InnerLimit = innerLimit;
        newItem.Female = female;
        this.CostumeSlots.Add(newItem);

        newItem = new CostumeSlotItem();
        newItem.Slot = item.Slot;
        newItem.Dlc = item.Dlc;
        newItem.InnerLimit = innerLimit;
        newItem.Female = female;
        this.CostumeSlots2.Add(newItem);
      }

      if (this.CostumeSlots.Count == 0)
      {
        this.CostumeSlots = null;
      }
      else
      {
        CostumeSlotsSettedTime = MainWindow.CostumeSlotsSettedTime;
        IsCostumeSlotsSetted = true;
      }
      if (this.CostumeSlots2.Count == 0) this.CostumeSlots2 = null;

      this.CostumeSlot = slot;
    }

    public void SetDefaultHStyle(DefaultData defaultData, byte ID)
    {
      this.HStyles = new ObservableCollection<HairStyle>();
      foreach (var style in defaultData.Charas[ID].HStyles)
      {
        this.HStyles.Add(style.Clone());
      }

      if (this.HStyles.Count == 0)
      {
        HairStyle newHStyle = new HairStyle(1, 1);
        this.HStyles.Add(newHStyle);
      }
    }

    public void ResetHairType()
    {
      for(byte i = 0; i < this.HStyles.Count; i++)
      {
        this.HStyles[i].Type = i;
      }
    }

    public void SetFile(byte typeID, string filePath)
    {
      this.Files[typeID].Path = filePath;
    }

    public void SetThumbnail()
    {
      string thumbPath = "";
      ThumbnailPath = "";

      if (Files == null) return;

      foreach (var file in Files)
      {
        if (file.ID == 1)
        {
          thumbPath = file.Path;
          break;
        }
      }

      if (MainWindow.AddThumbnail(thumbPath))
      {
        ThumbnailPath = thumbPath;
      }
      else if (thumbPath == "" && MainWindow.config.UseDefaultPFile && MainWindow.AddThumbnail(MainWindow.config.DefaultPFilePath))
      {
        ThumbnailPath = MainWindow.config.DefaultPFilePath;
      }
    }

    public void SetCFlags()
    {
      if (Files == null) return;

      string filePath = Files[0].Path;

      if (!String.IsNullOrEmpty(filePath))
        CFlags = MainWindow.ParseCData(filePath);
      else
      {
        if (MainWindow.config.UseDefaultCFile)
          CFlags = MainWindow.ParseCData(MainWindow.config.DefaultCFilePath);
        else
          CFlags = "";
      }
    }

    public void CheckFiles(bool editDefault)
    {
      if (this.Files == null) return;

      this.CheckFileErrors();
      if (editDefault)
      {
        foreach (var file in this.Files)
        {
          file.SetDisplayPath(this);
        }
      }
      else
      {
        this.CheckFilesNotSetted();
      }
      this.BuildErrorText();
    }

    private void CheckFilesNotSetted()
    {
      this.ErrorTexts[Const.RequiredFilesIsNotSet] = "";
      this.ErrorTexts[Const.InnerOnlyOneSideIsSet] = "";

      foreach (var file in this.Files)
      {
        file.SetDisplayPath(this);
      }

      if (this.IsIncluded == false) return;


      int count = 0;
      List<bool> innerCheck = new List<bool> { false, false, false, false };

      foreach (var file in this.Files)
      {
        if (String.IsNullOrEmpty(file.Path) && String.IsNullOrEmpty(file.DisplayPath))
        {
          continue;
        }

        if (file.ID < 4)
        {
          count++;
        }
        else
        {
          int index = (file.ID - 4) / 2;
          innerCheck[index] = !innerCheck[index];
        }
      }

      if (count < 4)
      {
        this.ErrorTexts[Const.RequiredFilesIsNotSet] = MainWindow.lang.RequiredFilesIsNotSet;
      }

      if (innerCheck.Contains(true))
      {
        this.ErrorTexts[Const.InnerOnlyOneSideIsSet] = MainWindow.lang.InnerOnlyOneSideIsSet;
      }
    }

    private bool CkeckDefaultSetted(CostumeFile file, Dictionary<byte, string> files, byte id, string defaultFilePath)
    {
      if (MainWindow.config.DefaultOnlyUse)
      {
        if (files.ContainsKey(id) && File.Exists(files[id]))
        {
          return true;
        }
      }
      else if (MainWindow.config.DefaultHighPriorityUse && files.ContainsKey(id) && File.Exists(files[id]))
      {
        return true;
      }
      else if (File.Exists(defaultFilePath))
      {
        return true;
      }

      return false;
    }

    public void CheckFileErrors()
    {
      this.ErrorTexts[Const.FilesNotExists] = "";
      this.ErrorTexts[Const.InnerOverLimit] = "";

      if (this.Files == null) return;


      int innerLimit = 4;

      if (MainWindow.InnerLimits.ContainsKey(this.ID) && MainWindow.InnerLimits[this.ID].ContainsKey(this.CostumeSlot))
      {
        innerLimit = MainWindow.InnerLimits[this.ID][this.CostumeSlot];
      }


      bool notExistsError = false;
      bool overLimitError = false;


      for (int i = 0; i < this.Files.Count; i++)
      {
        var file = this.Files[i];

        file.Error = false;
        file.Disabled = false;

        if (!String.IsNullOrEmpty(file.Path) && !File.Exists(file.Path))
        {
          file.Error = true;
          notExistsError = true;
        }

        if (i < 4 + (innerLimit * 2)) continue;

        file.Disabled = true;

        if (!String.IsNullOrEmpty(file.Path))
        {
          file.Error = true;
          overLimitError = true;
        }
      }


      if (notExistsError && this.IsIncluded)
      {
        this.ErrorTexts[Const.FilesNotExists] = MainWindow.lang.FilesNotExists;
      }

      if (overLimitError && this.IsIncluded)
      {
        this.ErrorTexts[Const.InnerOverLimit] = MainWindow.lang.InnerOverLimit;
      }
    }

    public void BuildErrorText()
    {
      string errorText = null;
      this.Caution = false;
      this.Error = false;

      string[] errors = new string[] { Const.DuplicatedCharacter, Const.OverMaxSlot, Const.SlotNotSetted, Const.SlotIsDuplicatedInThisLst, Const.SlotIsDuplicatedWithOtherDlc, Const.FilesNotExists, Const.InnerOnlyOneSideIsSet, Const.RequiredFilesIsNotSet, Const.InnerOverLimit };

      foreach (var error in errors)
      {
        if (!this.ErrorTexts.ContainsKey(error) || this.ErrorTexts[error] == "") continue;

        if (errorText != null) errorText += "\r\n";
        errorText += this.ErrorTexts[error];

        if (error == Const.SlotIsDuplicatedWithOtherDlc || (IsAdded && error == Const.RequiredFilesIsNotSet) || error == Const.InnerOverLimit)
          this.Caution = true;
        else
          this.Error = true;
      }

      this.ErrorText = errorText;
    }

    public Costume Clone()
    {
      Costume cloned = (Costume)MemberwiseClone();

      cloned.HStyles = new ObservableCollection<HairStyle>();
      foreach (var style in this.HStyles)
      {
        cloned.HStyles.Add(style.Clone());
      }
      cloned.OriginHStyles = new List<HairStyle>();
      foreach (var style in this.OriginHStyles)
      {
        cloned.OriginHStyles.Add(style.Clone());
      }
      cloned.Files = new ObservableCollection<CostumeFile>();
      foreach (var file in this.Files)
      {
        cloned.Files.Add(file.Clone());
      }
      cloned.CostumeSlots = new ObservableCollection<CostumeSlotItem>();
      cloned.CostumeSlots2 = new ObservableCollection<CostumeSlotItem>();

      cloned.ErrorTexts = new Dictionary<string, string>();

      return cloned;
    }

    private byte _ID;
    public byte ID
    {
      get { return _ID; }
      set
      {
        _ID = value;
        OnPropertyChanged(nameof(ID));
      }
    }
    private int _CostumeSlot;
    public int CostumeSlot
    {
      get { return _CostumeSlot; }
      set
      {
        _CostumeSlot = value;
        OnPropertyChanged(nameof(CostumeSlot));
        if (_CostumeSlot < 100 && HStyles != null)
          EnableHairStyles = true;
        else
          EnableHairStyles = false;
        this.CheckFileErrors();
        this.BuildErrorText();
      }
    }
    private byte _AddTexsCount;
    public byte AddTexsCount
    {
      get { return _AddTexsCount; }
      set
      {
        _AddTexsCount = value;
        OnPropertyChanged(nameof(AddTexsCount));
      }
    }
    private string _Comment;
    public string Comment
    {
      get { return _Comment; }
      set
      {
        _Comment = value;
        OnPropertyChanged(nameof(Comment));
      }
    }
    private bool _IsIncluded;
    public bool IsIncluded
    {
      get { return _IsIncluded; }
      set
      {
        _IsIncluded = value;
        OnPropertyChanged(nameof(IsIncluded));
      }
    }

    public ObservableCollection<HairStyle> HStyles { get; set; }
    [XmlIgnore]
    public List<HairStyle> OriginHStyles { get; private set; }
    public ObservableCollection<CostumeFile> Files { get; set; }

    private string _CFlags;
    public string CFlags
    {
      get { return _CFlags; }
      set
      {
        _CFlags = value;
        OnPropertyChanged(nameof(CFlags));
      }
    }

    public byte SortID { get; set; }

    [NonSerialized]
    private string _ThumbnailPath;
    [XmlIgnore]
    public string ThumbnailPath
    {
      get { return _ThumbnailPath; }
      set
      {
        _ThumbnailPath = value;
        OnPropertyChanged(nameof(ThumbnailPath));
      }
    }


    private bool _IsAdded;
    [XmlIgnore]
    public bool IsAdded
    {
      get { return _IsAdded; }
      set
      {
        _IsAdded = value;
        OnPropertyChanged(nameof(IsAdded));
      }
    }

    private bool _Caution;
    [XmlIgnore]
    public bool Caution
    {
      get { return _Caution; }
      set
      {
        _Caution = value;
        OnPropertyChanged(nameof(Caution));
      }
    }

    private bool _Error;
    [XmlIgnore]
    public bool Error
    {
      get { return _Error; }
      set
      {
        _Error = value;
        OnPropertyChanged(nameof(Error));
      }
    }

    private string _ErrorText;
    [XmlIgnore]
    public string ErrorText
    {
      get { return _ErrorText; }
      set
      {
        _ErrorText = value;
        OnPropertyChanged(nameof(ErrorText));
      }
    }

    private Dictionary<string, string> _ErrorTexts;
    [XmlIgnore]
    public Dictionary<string, string> ErrorTexts
    {
      get { return _ErrorTexts; }
      set { _ErrorTexts = value; }
    }


    private bool _IsCostumeSlotsSetted;
    [XmlIgnore]
    public bool IsCostumeSlotsSetted
    {
      get { return _IsCostumeSlotsSetted; }
      set
      {
        _IsCostumeSlotsSetted = value;
        OnPropertyChanged(nameof(IsCostumeSlotsSetted));
      }
    }

    [NonSerialized]
    private DateTime _CostumeSlotsSettedTime;
    [XmlIgnore]
    public DateTime CostumeSlotsSettedTime
    {
      get { return _CostumeSlotsSettedTime; }
      set
      {
        _CostumeSlotsSettedTime = value;
        OnPropertyChanged(nameof(CostumeSlotsSettedTime));
      }
    }

    [NonSerialized]
    private ObservableCollection<CostumeSlotItem> _CostumeSlots;
    [XmlIgnore]
    public ObservableCollection<CostumeSlotItem> CostumeSlots
    {
      get { return _CostumeSlots; }
      set
      {
        _CostumeSlots = value;
        OnPropertyChanged(nameof(CostumeSlots));
      }
    }
    [NonSerialized]
    private ObservableCollection<CostumeSlotItem> _CostumeSlots2;
    [XmlIgnore]
    public ObservableCollection<CostumeSlotItem> CostumeSlots2
    {
      get { return _CostumeSlots2; }
      set
      {
        _CostumeSlots2 = value;
        OnPropertyChanged(nameof(CostumeSlots2));
      }
    }

    private bool _EnableHairStyles;
    [XmlIgnore]
    public bool EnableHairStyles
    {
      get { return _EnableHairStyles; }
      set
      {
        _EnableHairStyles = value;
        OnPropertyChanged(nameof(EnableHairStyles));
      }
    }


    [NonSerialized]
    private bool _IsDragging;
    [XmlIgnore]
    public bool IsDragging
    {
      get { return _IsDragging; }
      set
      {
        _IsDragging = value;
        OnPropertyChanged(nameof(IsDragging));
      }
    }
    [NonSerialized]
    private bool _IsDragOver;
    [XmlIgnore]
    public bool IsDragOver
    {
      get { return _IsDragOver; }
      set
      {
        _IsDragOver = value;
        OnPropertyChanged(nameof(IsDragOver));
      }
    }
  }

  [Serializable]
  public class HairStyle : NotifyPropertyChangedBase
  {
    public HairStyle()
    {
    }

    public HairStyle(byte hair, byte face)
    {
      this.Hair = hair;
      this.Face = face;
    }

    public HairStyle Clone()
    {
      HairStyle cloned = (HairStyle)MemberwiseClone();
      return cloned;
    }

    private byte _type;
    public byte Type
    {
      get { return _type; }
      set
      {
        _type = value;
        OnPropertyChanged(nameof(Type));
      }
    }
    private byte _hair;
    public byte Hair
    {
      get { return _hair; }
      set
      {
        _hair = value;
        OnPropertyChanged(nameof(Hair));
      }
    }
    private byte _face;
    public byte Face
    {
      get { return _face; }
      set
      {
        _face = value;
        OnPropertyChanged(nameof(Face));
      }
    }
  }

  [Serializable]
  public class CostumeFile : NotifyPropertyChangedBase
  {
    public CostumeFile()
    {
    }

    public CostumeFile(byte typeID, string fileType)
    {
      this.ID = typeID;
      this.Type = fileType;
      this.Path = "";
      this.DisplayPath = "";
    }

    public void SetDisplayPath(Costume cos)
    {
      if (!String.IsNullOrEmpty(this.Path))
      {
        this.DisplayPath = this.Path;
      }
      else if (this.InDlc)
      {

      }
      else if (MainWindow.config.UseDefaultCFile && this.ID == 0)
      {
        string path = this.GetDefaultFilePath(MainWindow.defaultData.Charas[cos.ID].Files, MainWindow.config.DefaultCFilePath);
        if (path == null)
          this.DisplayPath = null;
        else
          this.DisplayPath = MainWindow.lang.AutoSet + path;
      }
      else if (MainWindow.config.UseDefaultPFile && this.ID == 1)
      {
        string path = this.GetDefaultFilePath(MainWindow.defaultData.Charas[cos.ID].Files, MainWindow.config.DefaultPFilePath);
        if (path == null)
          this.DisplayPath = null;
        else
          this.DisplayPath = MainWindow.lang.AutoSet + path;
      }
      else
      {
        this.DisplayPath = null;
      }
    }

    public string GetDefaultFilePath(Dictionary<byte, string> files, string defaultFilePath)
    {
      byte id = this.ID;

      if (MainWindow.config.DefaultOnlyUse)
      {
        if (files.ContainsKey(id) && File.Exists(files[id]))
        {
          return files[id];
        }
      }
      else if (MainWindow.config.DefaultHighPriorityUse && files.ContainsKey(id) && File.Exists(files[id]))
      {
        return files[id];
      }
      else if (File.Exists(defaultFilePath))
      {
        return defaultFilePath;
      }

      return null;
    }

    public CostumeFile Clone()
    {
      CostumeFile cloned = (CostumeFile)MemberwiseClone();
      return cloned;
    }

    public byte ID { get; set; }
    private string _Type;
    public string Type
    {
      get { return _Type; }
      set
      {
        _Type = value;
        OnPropertyChanged(nameof(Type));
      }
    }
    private bool _InDlc;
    public bool InDlc
    {
      get { return _InDlc; }
      set
      {
        _InDlc = value;
        OnPropertyChanged(nameof(InDlc));
      }
    }
    private string _Path;
    public string Path
    {
      get { return _Path; }
      set
      {
        _Path = value;
        OnPropertyChanged(nameof(Path));
      }
    }

    private string _DisplayPath;
    [XmlIgnore]
    public string DisplayPath
    {
      get { return _DisplayPath; }
      set
      {
        _DisplayPath = value;
        OnPropertyChanged(nameof(DisplayPath));
      }
    }

    private bool _Disabled;
    [XmlIgnore]
    public bool Disabled
    {
      get { return _Disabled; }
      set
      {
        _Disabled = value;
        OnPropertyChanged(nameof(Disabled));
      }
    }

    private bool _Error;
    [XmlIgnore]
    public bool Error
    {
      get { return _Error; }
      set
      {
        _Error = value;
        OnPropertyChanged(nameof(Error));
      }
    }
  }

  public class CostumeSlotItem
  {
    public int Slot { get; set; }
    public int InnerLimit { get; set; }
    public string Dlc { get; set; }
    public bool Female { get; set; }
  }

  public class DefaultData
  {
    public DefaultData()
    {
      this.Charas = new Dictionary<byte, DefaultCharaData>();

      foreach (var id in MainWindow.CharaNames.Keys)
      {
        Charas[id] = new DefaultCharaData();
        Charas[id].HStyles = new List<HairStyle>();
        Charas[id].Files = new Dictionary<byte, string>();
      }
    }

    public void SetDefaultData(DlcData data)
    {
      foreach (var cos in data.Costumes)
      {
        if (!this.Charas.ContainsKey(cos.ID))
        {
          Charas[cos.ID] = new DefaultCharaData();
          Charas[cos.ID].HStyles = new List<HairStyle>();
        }
        foreach (var style in cos.HStyles)
        {
          Charas[cos.ID].HStyles.Add(style.Clone());
        }
      }
    }

    public Dictionary<byte, DefaultCharaData> Charas { get; set; }

    public class DefaultCharaData
    {
      public DefaultCharaData()
      {
        this.SlotCount = 255;
      }

      public byte SlotCount { get; set; }
      public List<HairStyle> HStyles { get; set; }
      public Dictionary<byte, string> Files { get; set; }
    }
  }

  public class NameEntry
  {
    public NameEntry(string encryptedName, string name, string flag, int index, bool current)
    {
      this.EncryptedName = encryptedName;
      this.Name = name;
      this.Flag = flag;
      this.Index = index;
      this.Current = current;
    }

    public string EncryptedName { get; set; }
    public string Name { get; set; }
    public string Flag { get; set; }
    public int Index { get; set; }
    public bool Current { get; set; }
  }

  public class DlcCostumeData
  {
    public DlcCostumeData(byte slot, string numStr)
    {
      this.Slot = slot;
      this.DlcNum = numStr;
    }

    public byte Slot { get; set; }
    public string DlcNum { get; set; }
    public string DlcName { get; set; }
  }

  public class Thumbnail
  {
    public Thumbnail()
    {
    }

    public DateTime WriteTime { get; set; }
    public BitmapSource Source { get; set; }
  }

  public class Config : NotifyPropertyChangedBase
  {
    public Config()
    {
      this.Window = new WindowConfig();
      this.Languages = new ObservableCollection<LanguageList>();
      this.UseFolderSelectDialog = true;
      this.DefaultNotUse = true;
    }

    public Config Clone()
    {
      Config cloned = (Config)MemberwiseClone();

      cloned.Window = this.Window.Clone();

      return cloned;
    }

    public class WindowConfig
    {
      public WindowConfig()
      {
        this.Width = 800;
        this.Height = 700;
      }

      public WindowConfig Clone()
      {
        return (WindowConfig)MemberwiseClone();
      }

      public int Width;
      public int Height;
    }

    public string Language { get; set; }

    public string DatabasePath { get; set; }
    [XmlIgnore]
    public DateTime DatabaseWriteTime { get; set; }

    public string DefaultLstPath { get; set; }
    [XmlIgnore]
    public DateTime DefaultLstWriteTime { get; set; }

    public string GameDirPath { get; set; }

    public bool UseFolderSelectDialog { get; set; }
    public bool UseUsersFolder { get; set; }
    private string _usersFolderPath;
    public string UsersFolderPath
    {
      get { return _usersFolderPath; }
      set
      {
        _usersFolderPath = value;
        OnPropertyChanged(nameof(UsersFolderPath));
      }
    }
    public bool EnableCopyToDlcFolder { get; set; }

    public bool UseDefaultCFile { get; set; }
    private string _defaultCFilePath;
    public string DefaultCFilePath
    {
      get { return _defaultCFilePath; }
      set
      {
        _defaultCFilePath = value;
        OnPropertyChanged(nameof(DefaultCFilePath));
      }
    }

    public bool UseDefaultPFile { get; set; }
    private string _defaultPFilePath;
    public string DefaultPFilePath
    {
      get { return _defaultPFilePath; }
      set
      {
        _defaultPFilePath = value;
        OnPropertyChanged(nameof(DefaultPFilePath));
      }
    }

    public bool DefaultHighPriorityUse { get; set; }
    public bool DefaultOnlyUse { get; set; }
    public bool DefaultNotUse { get; set; }

    public bool DisplayThumbnails { get; set; }

    public bool RestoreWindowSize { get; set; }
    public WindowConfig Window { get; set; }

    public bool OpenLastDd { get; set; }
    public string LastDdPath { get; set; }

    private short _maxUndoCount;
    public short MaxUndoCount
    {
      get { return _maxUndoCount; }
      set
      {
        _maxUndoCount = value;
        OnPropertyChanged(nameof(MaxUndoCount));
      }
    }

    [XmlIgnore]
    public ObservableCollection<LanguageList> Languages { get; set; }
  }

  public class LanguageList
  {
    public LanguageList()
    {
    }

    public string Value { get; set; }
    public string Text { get; set; }
  }



  public class ArchiveFile
  {
    public string Name { get; set; }
    public uint Size { get; set; }
    public string Flag { get; set; }
    public uint LnkOffset { get; set; }
  }



  [Serializable]
  public class NotifyPropertyChangedBase : INotifyPropertyChanged
  {
    [field: NonSerialized]
    public event PropertyChangedEventHandler PropertyChanged;
    public void OnPropertyChanged(string name)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(name));
      }
    }
  }

}
