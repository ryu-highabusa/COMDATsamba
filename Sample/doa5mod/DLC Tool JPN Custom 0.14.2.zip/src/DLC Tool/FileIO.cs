﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using Message;
using ImageUtilities;

namespace DLC_Tool
{
  public partial class MainWindow : Window
  {

    private DlcData ParseLst(string filePath, bool errorOutput)
    {
      var dlcData = ParseLst(filePath);

      if (errorOutput && dlcData.SkippedList.Count > 0)
      {
        string text = lang.FoundErrorsInLst + "\r\n";
        foreach (var skipped in dlcData.SkippedList)
        {
          text += "\r\n" + skipped;
        }
        MessageWindow.Show(this, text, lang.Error);
      }

      return dlcData;
    }
    private static DlcData ParseLst(string filePath)
    {
      DlcData data = new DlcData();
      data.FilePath = filePath;
      data.Name = Path.GetFileNameWithoutExtension(filePath);

      Costume cosEntry = null;
      string group = "";
      string sTemp = "";
      int groupLine = 0;
      int charInd = -1;
      bool skipChar = false;
      string sysCurrentDir = Environment.CurrentDirectory;
      Environment.CurrentDirectory = Path.GetDirectoryName(filePath);

      using (StreamReader sr = new StreamReader(filePath))
      {
        while (sr.Peek() >= 0)
        {
          string s = sr.ReadLine();

          if (s == "")
          {
            continue;
          }
          else if (s == "path")
          {
            group = "path";
          }
          else if (s == "bcmver")
          {
            group = "bcmver";
          }
          else if (s == "character")
          {
            if (charInd != -1 && !skipChar)
            {
              data.Costumes.Add(cosEntry);
            }
            group = "character";
            groupLine = 0;
            charInd = charInd + 1;
            skipChar = false;
          }
          else if (s == "hairstyles" && !skipChar)
          {
            group = "hairstyles";
            groupLine = 0;
          }
          else if (s == "files" && !skipChar)
          {
            if (cosEntry.HStyles.Count == 0)
            {
              cosEntry.HStyles.Add(new HairStyle(1, 1));
            }
            else if (groupLine == 1 && group == "hairstyles")
            {
              cosEntry.HStyles.Add(new HairStyle(byte.Parse(sTemp), 1));
            }
            group = "files";
          }
          else if (group == "path")
          {
            data.OutputPath = Path.GetDirectoryName(s);
            data.DlcNum = Path.GetFileName(s);
          }
          else if (group == "bcmver")
          {
            data.BcmVer = Byte.Parse(s);
          }
          else if (group == "character" && !skipChar)
          {
            if (groupLine == 0)
            {
              foreach (byte key in CharaNames.Keys)
              {
                if (CharaNames[key] == s)
                {
                  cosEntry = new Costume();
                  cosEntry.InitFiles();
                  cosEntry.ID = key;
                  cosEntry.SortID = (byte)DefaultSortLocale.IndexOf(cosEntry.ID);
                  cosEntry.CostumeSlot = 0;
                  cosEntry.AddTexsCount = 1;
                  skipChar = false;
                  break;
                }
                skipChar = true;
              }
              if (skipChar)
              {
                data.SkippedList.Add(s + "/" + lang.SkipLoadCostume);
              }
            }
            else if (groupLine == 1)
            {
              cosEntry.CostumeSlot = byte.Parse(s);
            }
            else if (groupLine == 2)
            {
              cosEntry.AddTexsCount = byte.Parse(s);
            }
            else if (groupLine == 3)
            {
              byte flag = byte.Parse(s);
              if (flag == 0)
                cosEntry.IsIncluded = false;
              else
                cosEntry.IsIncluded = true;
            }
            else if (groupLine == 4)
            {
              cosEntry.Comment = s;
            }
            groupLine++;
          }
          else if (group == "hairstyles" && !skipChar)
          {
            if (groupLine == 0)
            {
              sTemp = s;
              groupLine = 1;
            }
            else if (groupLine == 1)
            {
              cosEntry.HStyles.Add(new HairStyle(byte.Parse(sTemp), byte.Parse(s)));
              cosEntry.OriginHStyles.Add(new HairStyle(byte.Parse(sTemp), byte.Parse(s)));
              groupLine = 0;
            }
          }
          else if (group == "files" && !skipChar)
          {
            for (byte i = 0; i < FileTypes.Length; i++)
            {
              if (s.EndsWith(FileTypes[i], true, null))
              {
                cosEntry.SetFile(i, Path.GetFullPath(s));
                break;
              }
            }
          }
        }
      }
      Environment.CurrentDirectory = sysCurrentDir;
      if (cosEntry != null) data.Costumes.Add(cosEntry);

      return data;
    }

    private string BuildLst(DlcData dlcData)
    {
      string text = "";

      text += "path\r\n";
      if (String.IsNullOrEmpty(dtData.OutputPath) && String.IsNullOrEmpty(dlcData.DlcNum))
        text += "\r\n";
      else
        text += dtData.OutputPath + @"\" + dlcData.DlcNum + "\r\n";

      byte[] sortRule = { 2, 11, 0, 1, 3, 4, 5, 6, 7, 8, 9, 10 };

      foreach (var cos in dlcData.Costumes)
      {
        text += "character\r\n";
        text += CharaNames[cos.ID] + "\r\n";
        text += cos.CostumeSlot.ToString() + "\r\n";
        text += cos.AddTexsCount.ToString() + "\r\n";
        if (cos.IsIncluded)
          text += "1\r\n";
        else
          text += "0\r\n";
        text += cos.Comment + "\r\n";

        text += "hairstyles\r\n";
        for (int j = 0; j < cos.HStyles.Count; j++)
        {
          text += cos.HStyles[j].Hair.ToString() + "\r\n";
          text += cos.HStyles[j].Face.ToString() + "\r\n";
        }

        text += "files\r\n";
        if (cos.Files != null)
        {
          Dictionary<byte, string> filePaths = new Dictionary<byte, string>();
          foreach (var file in cos.Files)
          {
            if (file.Path != "")
            {
              filePaths[sortRule[file.ID]] = file.Path;
            }
          }
          for (byte i = 0; i < 12; i++)
          {
            if (filePaths.ContainsKey(i))
            {
              text += filePaths[i] + "\r\n";
            }
          }
        }
      }

      return text;
    }

    private DlcData ParseBcm(string filePath, bool dlcNumCheck)
    {
      DlcData data = new DlcData();

      using (var ms = new MemoryStream())
      {
        var br = new BinaryReader(ms);
        using (var fs = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
        {
          fs.CopyTo(br.BaseStream);
        }

        br.BaseStream.Position = 0;
        data.BcmVer = br.ReadByte();

        if (data.BcmVer < 9) return null;

        br.BaseStream.Position += 1;
        byte entriesCount = br.ReadByte();
        br.BaseStream.Position += 1;
        uint checkSum = br.ReadUInt32();
        int num = 0;
        for (int i = 0; i < entriesCount; i++)
        {
          var cosEntry = new Costume();
          cosEntry.ID = br.ReadByte();
          cosEntry.SortID = (byte)DefaultSortLocale.IndexOf(cosEntry.ID);
          cosEntry.CostumeSlot = br.ReadByte();

          num += (ushort)(cosEntry.ID * cosEntry.CostumeSlot);

          if (cosEntry.CostumeSlot < 100)
          {
            cosEntry.AddTexsCount = br.ReadByte();
            byte hStylesCount = br.ReadByte();
            for (int j = 0; j < hStylesCount; j++)
            {
              byte hair = br.ReadByte();
              byte face = br.ReadByte();
              cosEntry.HStyles.Add(new HairStyle(hair, face));
              cosEntry.OriginHStyles.Add(new HairStyle(hair, face));
            }
          }

          data.Costumes.Add(cosEntry);
        }

        data.DlcNum = Path.GetFileNameWithoutExtension(filePath);

        if (dlcNumCheck)
        {
          uint dlcNum;
          if (!UInt32.TryParse(data.DlcNum, out dlcNum) || dlcNum > 999999)
          {
            for (int i = 0; i < 1000000; i++)
            {
              if (checkSum == ((i + 1) * (num & 4095)) % ((data.BcmVer * i) + 17))
              {
                data.DlcNum = i.ToString();
                break;
              }
            }
          }
        }

      }
      return data;
    }



    public void SaveBcm(DlcData dlcData, string filePath)
    {
      checked
      {
        ulong dlcNum;
        ulong.TryParse(dlcData.DlcNum, out dlcNum);

        byte costumeCount = 0;
        ulong checkSum = 0;
        foreach (var cos in dlcData.Costumes)
        {
          if (!cos.IsIncluded) continue;

          checkSum += (ushort)(cos.ID * cos.CostumeSlot);
          costumeCount++;
        }

        checkSum = ((dlcNum + 1) * (checkSum & 4095)) % ((dlcData.BcmVer * dlcNum) + 17);

        using (var ms = new MemoryStream())
        {
          var bw = new BinaryWriter(ms);
          bw.Write(dlcData.BcmVer);
          bw.BaseStream.Position += 1;
          bw.Write(costumeCount);
          bw.BaseStream.Position += 1;
          bw.Write(checked((uint)checkSum));
          foreach (var cos in dlcData.Costumes)
          {
            if (!cos.IsIncluded) continue;

            bw.Write(cos.ID);
            bw.Write((byte)cos.CostumeSlot);

            if (cos.CostumeSlot < 100)
            {
              bw.Write(cos.AddTexsCount);
              bw.Write((byte)cos.HStyles.Count);
              for (int i = 0; i < cos.HStyles.Count; i++)
              {
                bw.Write(cos.HStyles[i].Hair);
                bw.Write(cos.HStyles[i].Face);
              }
            }
          }

          bw.BaseStream.Position = 0;
          using (var fs = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.Read))
          {
            bw.BaseStream.CopyTo(fs);
          }
        }
      }
    }

    public List<int> SaveBin(DlcData dlcData, string savePath)
    {
      checked
      {
        var nameIndexes = new List<int>();
        var fileNames = new List<string>();
        foreach (var cos in dlcData.Costumes)
        {
          if (!cos.IsIncluded) continue;

          string baseName = CharaNames[cos.ID] + "_DLCU_" + (cos.CostumeSlot + 1).ToString("D3");
          if (cos.CostumeSlot >= 100)
          {
            baseName = CharaNames[cos.ID] + "_DLC_" + (cos.CostumeSlot - 99).ToString("D3");
          }

          for (int i = 0; i < 4; i++)
          {
            string name = baseName + FileTypes[i];
            int index = Array.FindIndex(nameDB.ToArray(), elem => elem.Name == name && elem.Current);
            if (index != -1)
            {
              nameIndexes.Add(nameDB[index].Index);
              fileNames.Add(nameDB[index].EncryptedName);
            }
            else
            {
              throw new Exception(String.Format(lang.NotFoundInDatabaseAndAbort, name));
            }
          }

          if (cos.AddTexsCount > 1 && cos.CostumeSlot < 100)
          {
            var inners = CheckInners(cos);
            for (int i = 0; i < inners.Count; i++)
            {
              for (int j = 0; j < 2; j++)
              {
                string name = baseName + "_00" + FileTypes[4 + j + (i * 2)];
                int index = Array.FindIndex(nameDB.ToArray(), elem => elem.Name == name && elem.Current);
                if (index != -1)
                {
                  nameIndexes.Add(nameDB[index].Index);
                  fileNames.Add(nameDB[index].EncryptedName);
                }
                else
                {
                  throw new Exception(String.Format(lang.NotFoundInDatabaseAndAbort, name));
                }
              }
            }
          }
        }

        int headerSize = 40 + (fileNames.Count * 12);
        using (var ms = new MemoryStream())
        {
          var bw = new BinaryWriter(ms, new ASCIIEncoding());
          bw.BaseStream.Position = headerSize;
          bw.Write(("_output/costume_pack_" + dlcData.DlcNum + char.MinValue + "order" + char.MinValue).ToCharArray());
          var namesOffs = new List<int>();
          foreach (string fileName in fileNames)
          {
            namesOffs.Add((int)bw.BaseStream.Position);
            bw.Write((@"/" + fileName + char.MinValue).ToCharArray());
          }

          bw.BaseStream.Position = 0;
          bw.Write(0x4F4D464C);
          bw.Write(1);
          bw.Write(fileNames.Count);
          bw.Write(0x20);
          bw.Write(0x28);
          bw.Write(headerSize);
          bw.Write(namesOffs[0]);
          bw.Write(0);
          bw.Write(0);
          bw.Write(headerSize);
          for (int i = 0; i < namesOffs.Count; i++)
          {
            bw.Write(0);
            bw.Write(i);
            bw.Write(namesOffs[i]);
          }

          bw.BaseStream.Position = 0;
          using (var fs = new FileStream(savePath, FileMode.Create, FileAccess.Write, FileShare.Read))
          {
            bw.BaseStream.CopyTo(fs);
          }
        }

        return nameIndexes;
      }
    }

    public List<uint> SaveLnk(DlcData dlcData, string savePath, int fileCount)
    {
      checked
      {
        int headerSize = 32 + (fileCount * 32);
        if (headerSize % 2048 > 0)
        {
          headerSize = headerSize - (headerSize % 2048) + 2048;
        }

        var fileSizes = new List<uint>();
        var fileOffs = new List<uint>();
        using (var fs = new FileStream(savePath, FileMode.Create, FileAccess.Write, FileShare.Read))
        {
          fs.Position = headerSize;
          foreach (var cos in dlcData.Costumes)
          {
            if (!cos.IsIncluded) continue;

            int orderLimit = 4;
            if (cos.AddTexsCount > 1)
            {
              orderLimit += cos.AddTexsCount * 2;
            }

            for (int i = 0; i < 12; i++)
            {
              if ((i >= orderLimit) && (i < 11))
              {
                continue;
              }

              string filePath = cos.Files[i].Path;
              if (String.IsNullOrEmpty(cos.Files[i].Path))
              {
                if (config.UseDefaultCFile && cos.Files[i].ID == 0)
                {
                  filePath = cos.Files[i].GetDefaultFilePath(defaultData.Charas[cos.ID].Files, config.DefaultCFilePath);
                }
                else if (config.UseDefaultPFile && cos.Files[i].ID == 1)
                {
                  filePath = cos.Files[i].GetDefaultFilePath(defaultData.Charas[cos.ID].Files, config.DefaultPFilePath);
                }
                else
                {
                  orderLimit += 2;
                  i++;
                  continue;
                }
              }

              fileOffs.Add((uint)fs.Position);
              using (var fs2 = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
              {
                fileSizes.Add((uint)fs2.Length);
                fs2.CopyTo(fs);
              }

              if (fs.Position % 2048 > 0)
              {
                fs.Position = fs.Position - (fs.Position % 2048) + 2048;
              }
            }
          }

          var bw = new BinaryWriter(fs);
          if (fs.Length % 2048 > 0)
          {
            bw.BaseStream.Position -= 1;
            bw.Write((byte)0);
          }

          bw.BaseStream.Position = 0;
          bw.Write(0x4D444350);
          bw.Write(0);
          bw.Write(fileCount);
          bw.Write(0);
          bw.Write((uint)bw.BaseStream.Length);
          bw.Write(0);
          bw.Write(2048);
          bw.Write(0);
          for (int i = 0; i < fileCount; i++)
          {
            bw.Write(fileOffs[i]);
            bw.Write(0);
            bw.Write(fileSizes[i]);
            bw.Write(0);
            bw.Write(fileSizes[i]);
            bw.Write(0);
            bw.Write(0);
            bw.Write(0);
          }
        }

        return fileSizes;
      }
    }

    public void SaveBlp(string savePath, List<int> nameIndexes, List<uint> fileSizes)
    {
      checked
      {
        using (var ms = new MemoryStream())
        {
          ms.Position = 16;
          var bw = new BinaryWriter(ms);
          for (int i = 0; i < nameIndexes.Count; i++)
          {
            bw.Write(nameIndexes[i]);
            bw.Write(fileSizes[i]);
            bw.Write(0);
            bw.Write(0);
            bw.Write(0);
          }

          bw.BaseStream.Position = 0;
          bw.Write(0x46495031);
          bw.Write(nameIndexes.Count);
          bw.Write(16);
          bw.Write((int)bw.BaseStream.Length);
          bw.BaseStream.Position = 0;
          using (var fs = new FileStream(savePath, FileMode.Create, FileAccess.Write, FileShare.Read))
          {
            bw.BaseStream.CopyTo(fs);
          }
        }
      }
    }



    private static string[] ParseBIN(string fileName)
    {
      using (var ms = new MemoryStream())
      {
        using (var fs = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read))
        {
          fs.CopyTo(ms);
        }

        ms.Position = 0;
        var br = new BinaryReader(ms);
        if (br.ReadInt32() != 0x4F4D464C)
        {
          return null;
        }

        br.BaseStream.Position = 8;
        int nameCount = br.ReadInt32();
        var nameOffsets = new int[nameCount];
        br.BaseStream.Position = 0x30;
        nameOffsets[0] = br.ReadInt32() + 1;
        for (int i = 1; i < nameCount; i++)
        {
          br.BaseStream.Position += 8;
          nameOffsets[i] = br.ReadInt32() + 1;
        }

        var nameEntries = new string[nameCount];
        for (int i = 0; i < nameCount; i++)
        {
          br.BaseStream.Position = nameOffsets[i];
          var charsList = new List<char>();
          int charByte = br.ReadByte();
          while (charByte != 0)
          {
            charsList.Add((char)charByte);
            charByte = ms.ReadByte();
          }

          nameEntries[i] = new string(charsList.ToArray());
        }

        return nameEntries;
      }
    }

    private static uint[,] ParseLNK(string fileName)
    {
      byte[] headerBuffer;
      using (var fs = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read))
      {
        fs.Position = 8;
        var byteBuffer = new byte[4];
        fs.Read(byteBuffer, 0, 4);
        int headerSize = (BitConverter.ToInt32(byteBuffer, 0) + 1) * 32;
        headerBuffer = new byte[headerSize];
        fs.Position = 0;
        fs.Read(headerBuffer, 0, headerSize);
      }

      using (var ms = new MemoryStream(headerBuffer))
      {
        var br = new BinaryReader(ms);
        br.BaseStream.Position = 8;
        int fileCount = br.ReadInt32();
        br.BaseStream.Position = 0x20;
        var lnkEntries = new uint[fileCount, 2];
        for (int i = 0; i < fileCount; i++)
        {
          lnkEntries[i, 0] = br.ReadUInt32();
          br.BaseStream.Position += 4;
          lnkEntries[i, 1] = br.ReadUInt32();
          br.BaseStream.Position += 20;
        }

        return lnkEntries;
      }
    }

    private static uint[,] ParseBLP(string fileName)
    {
      using (var ms = new MemoryStream())
      {
        using (var fs = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read))
        {
          fs.CopyTo(ms);
        }

        ms.Position = 0;
        var br = new BinaryReader(ms);
        if (br.ReadInt32() == 0x46495031)
        {
          int entryCount = br.ReadInt32();
          var blpEntries = new uint[entryCount, 4];
          br.BaseStream.Position = 0x10;
          for (int i = 0; i < entryCount; i++)
          {
            for (int j = 0; j < 4; j++)
            {
              blpEntries[i, j] = br.ReadUInt32();
            }

            br.BaseStream.Position += 4;
          }

          return blpEntries;
        }
        else
        {
          return null;
        }
      }
    }

    private List<string> ExtractFiles(string basePath, string outputPath)
    {
      string lnkPath = basePath + ".lnk";
      string blpPath = basePath + ".blp";

      string[] nameEntries = ParseBIN(basePath + ".bin");
      uint[,] lnkEntries = ParseLNK(lnkPath);
      int[] blpIndexes = null;
      uint[,] blpEntries = null;
      if (File.Exists(blpPath))
      {
        try
        {
          blpEntries = ParseBLP(blpPath);
          if (blpEntries != null)
          {
            blpIndexes = MatchIndexes(nameEntries, lnkEntries, blpEntries);
          }
        }
        catch (Exception e)
        {
          Console.WriteLine(e.Message);
        }
      }

      if (nameEntries == null) return null;


      List<string> errorFileList = new List<string>();

      Directory.CreateDirectory(outputPath);

      for (int i = 0; i < nameEntries.Length; i++)
      {
        var archFile = new ArchiveFile();
        int index = Array.FindIndex(nameDB.ToArray(), elem => elem.EncryptedName == nameEntries[i]);
        if (index != -1)
        {
          archFile.Flag = nameDB[index].Flag;
          if (nameDB[index].Name != string.Empty)
          {
            archFile.Name = nameDB[index].Name;
          }
          else
          {
            archFile.Name = nameEntries[i];
          }
        }
        else
        {
          archFile.Name = nameEntries[i];
        }

        if ((blpIndexes != null) && (blpIndexes[i] != -1))
        {
          archFile.Flag = blpEntries[blpIndexes[i], 2].ToString("X8");
        }
        else
        {
          if (archFile.Flag == null)
          {
            archFile.Flag = "00000000";
          }
        }

        archFile.LnkOffset = lnkEntries[i, 0];
        archFile.Size = lnkEntries[i, 1];

        var result = ExtractFile(archFile, lnkPath, outputPath + @"\" + archFile.Name);
        if (!result)
        {
          errorFileList.Add(archFile.Name);
        }
      }


      return errorFileList;
    }

    public static bool ExtractFile(ArchiveFile archFile, string lnkPath, string outputFilePath)
    {
      try
      {
        using (var fs = new FileStream(lnkPath, FileMode.Open, FileAccess.Read, FileShare.Read))
        {
          fs.Position = archFile.LnkOffset;
          using (var fs2 = new FileStream(outputFilePath, FileMode.Create, FileAccess.Write, FileShare.Read))
          {
            if ((archFile.Flag[0] != '0'))
            {
              var sizeBytes = new byte[4];
              fs.Read(sizeBytes, 0, 4);
              uint decompSize = BitConverter.ToUInt32(sizeBytes, 0);
              fs.Position = archFile.LnkOffset;
              if (archFile.Flag[0] == 'E' || archFile.Flag[0] == 'C')
              {
                var inputBuffer = new byte[archFile.Size];
                fs.Read(inputBuffer, 0, (int)archFile.Size);
                DecryptFile(inputBuffer, decompSize);
                using (var ms = new MemoryStream(inputBuffer))
                {
                  WriteDecompressedFile(ms, fs2, archFile.Size, decompSize);
                  if (fs2.Length != decompSize)
                  {
                    return false;
                  }
                }
              }
              else
              {
                WriteDecompressedFile(fs, fs2, archFile.Size, decompSize);
                if (fs2.Length != decompSize)
                {
                  return false;
                }
              }
            }
            else
            {
              WriteFile(fs, fs2, archFile.Size);
            }
          }
        }

        return true;
      }
      catch (Exception e)
      {
        Console.WriteLine(e.Message);
        return false;
      }
    }

    private static int[] MatchIndexes(string[] nameEntries, uint[,] lnkEntries, uint[,] blpEntries)
    {
      var blpIndexes = new int[nameEntries.Length];
      for (int i = 0; i < blpIndexes.Length; i++)
      {
        blpIndexes[i] = -1;
      }

      var dupIndexes = new List<int>();
      for (int i = 0; i < blpEntries.GetLength(0); i++)
      {
        int index = Array.FindIndex(nameDB.ToArray(), elem => elem.Index == blpEntries[i, 0]);
        if (index != -1)
        {
          var foundIndexes = new List<int>();
          int idx = Array.IndexOf<string>(nameEntries, nameDB[index].EncryptedName);
          while (idx != -1)
          {
            foundIndexes.Add(idx);
            idx = Array.IndexOf<string>(nameEntries, nameDB[index].EncryptedName, ++idx);
          }

          foreach (var foundIndex in foundIndexes)
          {
            if (blpEntries[i, 1] == lnkEntries[foundIndex, 1])
            {
              if (blpIndexes[foundIndex] == -1)
              {
                blpIndexes[foundIndex] = i;
              }
              else
              {
                dupIndexes.Add(foundIndex);
              }
            }
          }
        }
      }

      if (dupIndexes.Count > 0)
      {
        foreach (var dupIndex in dupIndexes)
        {
          blpIndexes[dupIndex] = -1;
        }
      }

      return blpIndexes;
    }

    private static void DecryptFile(byte[] inputBuffer, uint decompSize)
    {
      byte[] tempKey = BitConverter.GetBytes((((decompSize + 0x3E7) * 7) / 0xB) + (decompSize % 0x11) + 0x1AC);
      var byteList = new List<byte>();
      for (int i = tempKey.Length - 1; i >= 0; i--)
      {
        if (tempKey[i] != 00)
        {
          byteList.Add(tempKey[i]);
        }
      }

      byte[] cryptKey = byteList.ToArray();
      int cryptKeyPos = 0;
      byte[] doaKey = DLC_Tool.Properties.Resources.doaKey;
      int doaKeyPos = 0;
      byte xorByte;
      for (int i = 4; i < inputBuffer.Length; i++)
      {
        if (cryptKeyPos == cryptKey.Length)
        {
          cryptKeyPos = 0;
        }

        if (doaKeyPos == doaKey.Length)
        {
          doaKeyPos = 0;
        }

        xorByte = (byte)(cryptKey[cryptKeyPos] ^ doaKey[doaKeyPos]);
        if ((inputBuffer[i] != 0) && (inputBuffer[i] != xorByte))
        {
          inputBuffer[i] = (byte)(inputBuffer[i] ^ xorByte);
        }

        cryptKeyPos++;
        doaKeyPos++;
      }
    }

    private static void WriteFile(Stream s, FileStream fs, uint fileSize)
    {
      fs.SetLength(fileSize);
      var inputBuffer = new byte[0x1000];
      uint chunksCount = fileSize / 0x1000;
      int lastChunkSize = (int)(fileSize % 0x1000);
      int readCount;
      for (int i = 0; i < chunksCount; i++)
      {
        readCount = s.Read(inputBuffer, 0, 0x1000);
        fs.Write(inputBuffer, 0, readCount);
      }

      if (lastChunkSize > 0)
      {
        readCount = s.Read(inputBuffer, 0, lastChunkSize);
        fs.Write(inputBuffer, 0, readCount);
      }
    }

    private static void WriteDecompressedFile(Stream s, FileStream fs, uint fileSize, uint decompSize)
    {
      fs.SetLength(decompSize);
      long fileEndPos = s.Position + fileSize;
      var sizeBytes = new byte[4];
      int chunkSize;
      s.Position += 4;
      while (s.Position < fileEndPos)
      {
        s.Read(sizeBytes, 0, 4);
        chunkSize = BitConverter.ToInt32(sizeBytes, 0) - 0x8000;
        if (chunkSize > 0)
        {
          var inputBuffer = new byte[chunkSize];
          s.Read(inputBuffer, 0, chunkSize);
          using (var iis = new ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputStream(new MemoryStream(inputBuffer)))
          {
            iis.CopyTo(fs);
          }
        }
        else
        {
          chunkSize += 0x8000;
          var inputBuffer = new byte[chunkSize];
          s.Read(inputBuffer, 0, chunkSize);
          fs.Write(inputBuffer, 0, chunkSize);
        }

        if ((s.Position - 4) % 16 != 0)
        {
          s.Position = s.Position - ((s.Position - 4) % 16) + 16;
        }
      }
    }



    public static List<string> LoadDefault()
    {
      defaultData = new DefaultData();

      string path = BaseDirectory + config.DefaultLstPath;
      if (!File.Exists(path)) return null;

      DlcData data = ParseLst(path);

      defaultData.SetDefaultData(data);
      config.DefaultLstWriteTime = File.GetLastWriteTime(path);

      return data.SkippedList;
    }

    public static List<NameEntry> LoadDB(bool updateDatabase)
    {
      // datの存在確認
      if (!File.Exists(BaseDirectory + config.DatabasePath))
      {
        return null;
      }

      List<NameEntry> database = new List<NameEntry>();

      using (var sr = new StreamReader(BaseDirectory + config.DatabasePath, Encoding.ASCII))
      {
        int count = 0;
        bool current = true;
        while (!sr.EndOfStream)
        {
          string[] dbEntry = sr.ReadLine().Split('\t');

          if (dbEntry[0] == "end_flag")
          {
            current = false;
            continue;
          }

          if (dbEntry.Length > 3 && (dbEntry[1] != string.Empty || updateDatabase))
          {
            if (current)
              database.Add(new NameEntry(dbEntry[0], dbEntry[1], dbEntry[2], count, current));
            else
              database.Add(new NameEntry(dbEntry[0], dbEntry[1], dbEntry[2], -1, current));
          }

          count++;
        }
      }

      if (!updateDatabase)
      {
        config.DatabaseWriteTime = File.GetLastWriteTime(BaseDirectory + config.DatabasePath);
        databaseChanged = true;
      }

      return database;
    }

    public static string UpdateDB(string gameExePath)
    {
      try
      {
        string[,] gameDB = DumpGameDB(gameExePath);
        if (gameDB.Length == 1 && gameDB[0, 1] == "")
        {
          return gameDB[0, 0];
        }

        var tempNameDB = LoadDB(true);
        if (tempNameDB == null)
        {
          return lang.DatabaseUpdateFailed;
        }

        bool dbUpdated = false;
        var newDB = new List<string>(tempNameDB.Count + 1);
        var newNameDB = new List<NameEntry>(nameDB.Count);
        for (int i = 0; i < gameDB.GetLength(0); i++)
        {
          // EncryptedNameで検索
          int index = Array.FindIndex(tempNameDB.ToArray(), elem => elem.EncryptedName == gameDB[i, 0]);
          if (index != -1)
          {
            newDB.Add(gameDB[i, 0] + "\t" + tempNameDB[index].Name + "\t" + gameDB[i, 1] + "\t" + i.ToString("X"));
          
            newNameDB.Add(new NameEntry(gameDB[i, 0], tempNameDB[index].Name, gameDB[i, 1], i, true));
          
            if (gameDB[i, 1] != tempNameDB[index].Flag || i != tempNameDB[index].Index)
            {
              dbUpdated = true;
            }
          
            tempNameDB.RemoveAt(index);
          
            continue;
          }

          // Flagで検索
          string name = "";
          if (gameDB[i, 1] != "00000000")
          {
            index = Array.FindIndex(tempNameDB.ToArray(), elem => elem.Flag == gameDB[i, 1]);
            if (index != -1)
            {
              name = tempNameDB[index].Name;
            }
          }
          else if (i > 1)
          {
            int prevPrevIndex = Array.FindIndex(tempNameDB.ToArray(), elem => elem.Flag == gameDB[i - 2, 1]);
            int prevIndex = Array.FindIndex(tempNameDB.ToArray(), elem => elem.Flag == gameDB[i - 1, 1]);
            if (prevPrevIndex != -1 && prevIndex != -1)
            {
              var prevPrevName = tempNameDB[prevPrevIndex].Name.Split('.');
              var prevName = tempNameDB[prevIndex].Name.Split('.');

              if (
                prevPrevName.Length > 1 &&
                prevName.Length > 1 &&
                prevPrevName[0] == prevName[0] &&
                prevPrevName[1].ToUpper() == "TMC" &&
                prevName[1].ToUpper() == "TMCL"
              )
              {
                name = prevName[0] + ".---C";
              }
            }
          }

          if (String.IsNullOrEmpty(name))
          {
            newDB.Add(gameDB[i, 0] + "\t\t" + gameDB[i, 1] + "\t" + i.ToString("X"));
          }
          else
          {
            newDB.Add(gameDB[i, 0] + "\t" + name + "\t" + gameDB[i, 1] + "\t" + i.ToString("X"));

            newNameDB.Add(new NameEntry(gameDB[i, 0], name, gameDB[i, 1], i, true));
          }

          dbUpdated = true;
        }


        if (!dbUpdated)
        {
          return "New information not found";
        }


        if (tempNameDB.Count > 0)
        {
          newDB.Add("end_flag" + "\t\t" + "FFFFFFFF");

          foreach (var entry in tempNameDB)
          {
            newDB.Add(entry.EncryptedName + "\t" + entry.Name + "\t" + entry.Flag + "\t");

            newNameDB.Add(new NameEntry(entry.EncryptedName, entry.Name, entry.Flag, -1, false));
          }
        }


        File.WriteAllLines(BaseDirectory + config.DatabasePath, newDB, Encoding.ASCII);

        nameDB = newNameDB;

        config.DatabaseWriteTime = File.GetLastWriteTime(BaseDirectory + config.DatabasePath);

        databaseChanged = true;

        return "";
      }
      catch (Exception e)
      {
        throw new Exception(e.Message + "\r\n\r\n" + e.StackTrace);
      }
    }

    private static string[,] DumpGameDB(string fileName)
    {
      using (var ms = new MemoryStream())
      {
        using (var fs = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read))
        {
          fs.CopyTo(ms);
        }

        var byteBuffer = ms.ToArray();
        int nameTableOffset = ByteSearch(byteBuffer, FirstName, 0, false);
        if (nameTableOffset < 0)
        {
          return new string[,] { { "Name table not found in the game.exe.", "" } };
        }

        int assetTableOffset = ByteSearch(byteBuffer, FirstAsset, nameTableOffset, true) - 4;
        if (assetTableOffset < 0)
        {
          return new string[,] { { "Asset table not found in the game.exe.", "" } };
        }

        int dataTableOffset = ByteSearch(byteBuffer, FirstData, assetTableOffset, false);
        if (dataTableOffset < 0)
        {
          return new string[,] { { "Data table not found in the game.exe.", "" } };
        }

        var nameOffsets = new List<int>();
        var br = new BinaryReader(ms);
        br.BaseStream.Position = assetTableOffset;
        int nameStartOffset = br.ReadInt32();
        int offsetCorrection = nameStartOffset - nameTableOffset;
        while (nameStartOffset != 0)
        {
          nameOffsets.Add(nameStartOffset - offsetCorrection);
          br.BaseStream.Position += 12;
          nameStartOffset = br.ReadInt32();
        }

        var gameDB = new string[nameOffsets.Count, 2];
        for (int i = 0; i < nameOffsets.Count; i++)
        {
          br.BaseStream.Position = nameOffsets[i];
          var charsList = new List<char>();
          int charByte = br.ReadByte();
          while (charByte != 0)
          {
            charsList.Add((char)charByte);
            charByte = ms.ReadByte();
          }

          gameDB[i, 0] = new string(charsList.ToArray());
        }

        br.BaseStream.Position = dataTableOffset;
        for (int i = 0; i < nameOffsets.Count; i++)
        {
          br.BaseStream.Position += 4;
          gameDB[i, 1] = br.ReadUInt32().ToString("X8");
        }

        return gameDB;
      }
    }

    private static int ByteSearch(byte[] byteBuffer, byte[] searchPattern, int startOffset, bool customSearch)
    {
      bool patternFound = false;
      if (!customSearch)
      {
        for (int i = startOffset; i < byteBuffer.Length - searchPattern.Length; i++)
        {
          if (byteBuffer[i] == searchPattern[0])
          {
            patternFound = true;
            for (int j = 1; j < searchPattern.Length; j++)
            {
              if (byteBuffer[i + j] != searchPattern[j])
              {
                patternFound = false;
                break;
              }
            }

            if (patternFound)
            {
              return i;
            }
          }
        }
      }
      else
      {
        for (int i = startOffset; i < byteBuffer.Length - searchPattern.Length; i++)
        {
          if (byteBuffer[i] == searchPattern[0])
          {
            patternFound = true;
            for (int j = 1; j < 4; j++)
            {
              if (byteBuffer[i + j] != searchPattern[j])
              {
                patternFound = false;
                break;
              }
            }

            for (int j = 4; j < 8; j++)
            {
              if (byteBuffer[i + j + 4] != searchPattern[j])
              {
                patternFound = false;
                break;
              }
            }

            for (int j = 8; j < 12; j++)
            {
              if (byteBuffer[i + j + 8] != searchPattern[j])
              {
                patternFound = false;
                break;
              }
            }

            if (patternFound)
            {
              return i;
            }
          }
        }
      }

      return -1;
    }



    public class HeaderData
    {
      public HeaderData(int Start, byte[] bin)
      {
        this.Start = Start;
        this.Offsets = new List<int>(0);
        this.Sizes = new List<int>(0);

        if (BitConverter.ToUInt32(bin, Start + 0x08) != 0x01010000) return;

        char[] charsToTrim = { '\0' };
        this.Name = Encoding.ASCII.GetString(bin, Start, 8).TrimEnd(charsToTrim);
        this.Flg1 = BitConverter.ToUInt32(bin, Start + 0x08);
        this.HSize = BitConverter.ToInt32(bin, Start + 0x0C);
        this.Size = BitConverter.ToInt32(bin, Start + 0x10);
        this.Count1 = BitConverter.ToInt32(bin, Start + 0x14);
        this.Count2 = BitConverter.ToInt32(bin, Start + 0x18);
        this.Count3 = BitConverter.ToInt32(bin, Start + 0x1C);
        this.Offset1 = BitConverter.ToInt32(bin, Start + 0x20);
        this.Offset2 = BitConverter.ToInt32(bin, Start + 0x24);
        this.Offset3 = BitConverter.ToInt32(bin, Start + 0x28);
        this.Flg2 = BitConverter.ToUInt32(bin, Start + 0x2C);

        for (int i = 0; i < this.Count1; i++)
        {
          this.Offsets.Add(BitConverter.ToInt32(bin, Start + this.Offset1 + (i * 0x04)));
        }

        if (this.Offset2 > 0)
        {
          for (int i = 0; i < this.Count1; i++)
          {
            this.Sizes.Add(BitConverter.ToInt32(bin, Start + this.Offset2 + (i * 0x04)));
          }
        }
      }

      public int Start { get; set; }
      public string Name { get; set; }
      public uint Flg1 { get; set; }
      public int HSize { get; set; }
      public int Size { get; set; }
      public int Count1 { get; set; }
      public int Count2 { get; set; }
      public int Count3 { get; set; }
      public int Offset1 { get; set; }
      public int Offset2 { get; set; }
      public int Offset3 { get; set; }
      public uint Flg2 { get; set; }

      public List<int> Offsets { get; private set; }
      public List<int> Sizes { get; private set; }
    }

    // --Pの読み込み
    public static byte[] ParsePData(string filePath)
    {
      if (!File.Exists(filePath)) return null;

      var bin = System.IO.File.ReadAllBytes(filePath);
      char[] charsToTrim = { '\0' };
      string Name = Encoding.ASCII.GetString(bin, 0, 8).TrimEnd(charsToTrim);
      if (Name != "dlicon" || bin.Length < 0x200 || BitConverter.ToUInt32(bin, 0x08) != 0x01010000)
      {
        return null;
      }

      HeaderData h = new HeaderData(0, bin);

      var ttdmH = new HeaderData(h.Offsets[1], bin);
      var ttdhH = new HeaderData(h.Offsets[1] + ttdmH.HSize, bin);
      var ttdlH = new HeaderData(h.Offsets[1] + ttdmH.Offset3, bin);

      var offset = ttdlH.Offsets[0];
      var start = h.Offsets[0] + offset;
      var size = ttdlH.Sizes[0];

      return bin.Skip(start).Take(size).ToArray();
    }

    // ---Cの読み込み
    public static string ParseCData(string filePath)
    {
      if (!File.Exists(filePath)) return null;

      string flags = "";

      var bin = System.IO.File.ReadAllBytes(filePath);
      char[] charsToTrim = { '\0' };
      string Name = Encoding.ASCII.GetString(bin, 0, 8).TrimEnd(charsToTrim);
      if (Name != "texch" || BitConverter.ToUInt32(bin, 0x08) != 0x01010000)
      {
        return null;
      }

      HeaderData h = new HeaderData(0, bin);

      var offsets = new List<int>();
      var sizes = new List<int>();

      for (int i = 0; i < h.Count1; i++)
      {
        if (h.Offsets[i] != 0)
        {
          int nextOffset = 0;
          int count = i + 1;
          while (count < h.Count1 && h.Offsets[count] == 0)
          {
            count++;
          }
          if (count < h.Count1)
          {
            nextOffset = h.Offsets[count];
          }
          else
          {
            nextOffset = h.Size;
          }

          offsets.Add(h.Offsets[i]);
          sizes.Add(nextOffset - h.Offsets[i]);
        }
        else
        {
          offsets.Add(0);
          sizes.Add(0);
        }
      }

      var hType = new bool[8];

      if (bin[h.Offsets[0]] == 1)
      {
        int count = 0;
        while (count < 8 && h.Offsets[0] + (8 * count) < bin.Length && bin[h.Offsets[0] + (8 * count)] == 1)
        {
          flags += (char)(65 + bin[h.Offsets[0] + (count * 8) + 4]) + " ";
          count++;
        }
      }
      else if (bin[h.Offsets[0]] == 4)
      {
        int count = 0;
        while (count < 8 && bin[h.Offsets[0] + 4 + (count * 8)] == 1)
        {
          flags += (char)(65 + bin[h.Offsets[0] + (count * 8) + 8]) + " ";
          count++;
        }
      }

      return flags;
    }



    private void LoadConfigs()
    {
      if (File.Exists(configPath))
      {
        System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(Config));
        using (var sr = new StreamReader(configPath, new UTF8Encoding(false)))
        {
          config = (Config)serializer.Deserialize(sr);
        }
      }

      if (String.IsNullOrEmpty(config.Language)) config.Language = "Default";

      if (config.RestoreWindowSize)
      {
        if (config.Window.Width != 0) this.Width = config.Window.Width;
        if (config.Window.Height != 0) this.Height = config.Window.Height;
      }
    }

    private void SetConfigs()
    {
      if (String.IsNullOrEmpty(config.DatabasePath) || !File.Exists(GetAbsolutePath(BaseDirectory, config.DatabasePath)))
      {
        config.DatabasePath = DefaultDatabasePath;
      }

      if (String.IsNullOrEmpty(config.DefaultLstPath) || !File.Exists(GetAbsolutePath(BaseDirectory, config.DefaultLstPath)))
      {
        config.DefaultLstPath = DefaultDefaultLstPath;
      }

      if (String.IsNullOrEmpty(config.GameDirPath) || !Directory.Exists(config.GameDirPath))
      {
        using (var reg32 = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
        using (RegistryKey rKey = reg32.OpenSubKey(RegKeyName))
        {
          if (rKey != null)
          {
            try
            {
              string keyValue = (string)rKey.GetValue(RegGetValueName);
              if (!String.IsNullOrEmpty(keyValue)) config.GameDirPath = keyValue;
              if (keyValue[keyValue.Length -1] != '\\') config.GameDirPath += @"\";
            }
            catch (NullReferenceException)
            {

            }
          }
        }
      }
      else
      {
        if (config.GameDirPath[config.GameDirPath.Length - 1] != '\\') config.GameDirPath += @"\";
      }

      if (config.UseDefaultPFile && File.Exists(config.DefaultPFilePath))
      {
        AddThumbnail(config.DefaultPFilePath);
      }

      if (config.MaxUndoCount == 0)
      {
        config.MaxUndoCount = DefaultMaxUndoCount;
      }

      cbDisplayThumb.IsChecked = config.DisplayThumbnails;
    }

    public static void SaveConfigs()
    {
      System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(Config));
      using (var sw = new StreamWriter(configPath, false, new UTF8Encoding(false)))
      {
        serializer.Serialize(sw, config);
      }
    }



    public static bool AddThumbnail(string thumbPath)
    {

      if (Thumbs.ContainsKey(thumbPath))
      {
        if (!File.Exists(thumbPath))
        {
          Thumbs.Remove(thumbPath);
          return false;
        }

        var lastWriteTime = File.GetLastWriteTime(thumbPath);
        if (Thumbs[thumbPath].WriteTime.CompareTo(lastWriteTime) == 0)
        {
          return true;
        }
      }
      else if (thumbPath == "" || !File.Exists(thumbPath))
      {
        return false;
      }

      BitmapSource bitmapSourse = LoadThumbnail(thumbPath);

      if (bitmapSourse == null) return false;

      var thumbnail = new Thumbnail();
      thumbnail.Source = bitmapSourse;
      thumbnail.WriteTime = File.GetLastWriteTime(thumbPath);

      Thumbs[thumbPath] = thumbnail;

      return true;
    }

    public static BitmapSource LoadThumbnail(string thumbPath)
    {
      var bin = MainWindow.ParsePData(thumbPath);
      System.Drawing.Bitmap bitmap = null;
      if (bin != null)
      {
        try
        {
          bitmap = DDS.GetBitmapArray(bin)[0];
        }
        catch (Exception e)
        {
          Console.WriteLine(e);
          return null;
        }
      }

      if (bitmap == null) return null;

      BitmapSource bitmapSourse = null;

      using (Stream st = new MemoryStream())
      {
        bitmap.Save(st, System.Drawing.Imaging.ImageFormat.Png);
        st.Seek(0, SeekOrigin.Begin);
        bitmapSourse = BitmapFrame.Create(st, BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
      }

      return bitmapSourse;
    }
  }
}
