﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;

namespace TMC_Tool
{
  [ValueConversion(typeof(object), typeof(Visibility))]
  public class EqualsToVisibleConveter : IValueConverter
  {

    public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      if (value == null)
      {
        return parameter == null ? Visibility.Visible : Visibility.Collapsed;
      }
      return value.Equals(parameter) ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      throw new NotImplementedException();
    }
  }

  partial class Styles : ResourceDictionary
  {
    //
    // SINGLE CLICK EDITING
    //
    private void DataGridCell_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      DataGridCell cell = sender as DataGridCell;
      if (cell != null && !cell.IsEditing && !cell.IsReadOnly)
      {
        if (!cell.IsFocused)
        {
          cell.Focus();
        }
        DataGrid dataGrid = FindVisualParent<DataGrid>(cell);
        if (dataGrid != null)
        {
          if (dataGrid.SelectionUnit != DataGridSelectionUnit.FullRow)
          {
            if (!cell.IsSelected)
              cell.IsSelected = true;
          }
          else
          {
            DataGridRow row = FindVisualParent<DataGridRow>(cell);
            if (row != null && !row.IsSelected)
            {
              row.IsSelected = true;
            }
          }
        }
      }
    }

    private void DataGridCell_PreviewKeyDown(object sender, KeyEventArgs e)
    {
      if (e.Key == Key.Enter || e.Key == Key.Down || e.Key == Key.Up || e.Key == Key.Right || e.Key == Key.Left)
      {
        e.Handled = true;
        DataGridCell cell = sender as DataGridCell;
        DataGrid dataGrid = FindVisualParent<DataGrid>(cell);

        var dataGridCellInfo = new DataGridCellInfo(dataGrid.Items[dataGrid.SelectedIndex], dataGrid.Columns[cell.Column.DisplayIndex]);
        FrameworkElement contentElement = dataGridCellInfo.Column.GetCellContent(dataGridCellInfo.Item);
        Type type = contentElement.GetType();
        TextBox tb = null;
        if (type.Name == "TextBox")
        {
          tb = contentElement as TextBox;
        }

        int columnOffset = 0;
        if (e.Key == Key.Up)
        {
          if (dataGrid.SelectedIndex == 0) return;
          dataGrid.SelectedIndex -= 1;
        }
        else if (e.Key == Key.Right)
        {
          if (
            cell.Column.DisplayIndex == dataGrid.Columns.Count - 1 ||
            (tb != null && tb.Text != "" && (tb.SelectionStart != 1 || tb.SelectionLength != 0))
            )
          {
            e.Handled = false;
            return;
          }
          columnOffset = 1;
        }
        else if (e.Key == Key.Left)
        {
          if (
            cell.Column.DisplayIndex == 0 ||
            (tb != null && (tb.SelectionStart != 0 || tb.SelectionLength != 0))
            )
          {
            e.Handled = false;
            return;
          }
          columnOffset = -1;
        }
        else
        {
          if (dataGrid.SelectedIndex == dataGrid.Items.Count - 1) return;
          dataGrid.SelectedIndex += 1;
        }

        dataGridCellInfo = new DataGridCellInfo(dataGrid.Items[dataGrid.SelectedIndex], dataGrid.Columns[cell.Column.DisplayIndex + columnOffset]);
        dataGrid.CurrentCell = dataGridCellInfo;
        dataGrid.ScrollIntoView(dataGridCellInfo.Item);
        contentElement = dataGridCellInfo.Column.GetCellContent(dataGridCellInfo.Item);
        if (contentElement == null)
        {
          return;
        }
        var dataGridCell = contentElement.Parent as DataGridCell;
        if (dataGridCell == null)
        {
          return;
        }
        dataGridCell.Focus();
        dataGrid.UpdateLayout();
        dataGrid.BeginEdit();
      }
    }

    public static T FindVisualParent<T>(UIElement element) where T : UIElement
    {
      UIElement parent = element;
      while (parent != null)
      {
        T correctlyTyped = parent as T;
        if (correctlyTyped != null)
        {
          return correctlyTyped;
        }

        parent = VisualTreeHelper.GetParent(parent) as UIElement;
      }
      return null;
    }
  }
}