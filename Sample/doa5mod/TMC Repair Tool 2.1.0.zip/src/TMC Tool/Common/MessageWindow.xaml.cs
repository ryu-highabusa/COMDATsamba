﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Message
{
  /// <summary>
  /// MessageWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class MessageWindow : Window
  {
    private static Dictionary<string, string> txt = new Dictionary<string, string>();

    private static string dialogResult = "";

    public MessageWindow()
    {
      InitializeComponent();

      this.MouseLeftButtonDown += (sender, e) => this.DragMove();
      this.ShowInTaskbar = false;
    }

    public static void lang(Dictionary<string, string> langText)
    {
      txt = langText;
    }

    // Window Owner, string Message, string Title, string OkText, string CancelText, string OtherText, string Other2Text 
    public static string Show(Window Owner, params string[] args)
    {
      MessageWindow dlg = new MessageWindow();
      dlg.WindowBuild(args);
      dlg.Owner = Owner;
      Owner.IsEnabled = false;
      dlg.ShowDialog();
      Owner.IsEnabled = true;
      Owner.Activate();
      Owner.Focus();
      return dialogResult;
    }

    public void WindowBuild(string[] args)
    {
      string Message = "";
      string Title = txt["Message"];
      string OkText = txt["OK"];
      string CancelText = txt["Cancel"];
      string OtherText = "Other";
      string Other2Text = "Other2";

      for (int i = 0; i < args.Length; i++)
      {
        switch (i)
        {
          case 0:
            Message = args[i];
            break;
          case 1:
            Title = args[i];
            break;
          case 2:
            OkText = args[i];
            break;
          case 3:
            CancelText = args[i];
            break;
          case 4:
            OtherText = args[i];
            break;
          case 5:
            Other2Text = args[i];
            break;
        }
      }

      labelTitle.Content = Title;
      textblockMessage.Text = Message;
      btnOk.Content = OkText;
      btnCancel.Content = CancelText;
      btnOther.Content = OtherText;
      btnOther2.Content = Other2Text;
      if (args.Length < 4)
      {
        btnOk.IsDefault = true;
        btnCancel.Visibility = Visibility.Collapsed;
        btnOk.Focus();
      }
      else
      {
        btnCancel.Focus();
      }
      if (args.Length < 5)
      {
        btnOther.Visibility = Visibility.Collapsed;
      }
      if (args.Length < 6)
      {
        btnOther2.Visibility = Visibility.Collapsed;
      }
      if (Title == txt["Error"])
      {
        wrapper.BorderBrush = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF0000"));
      }
      else if (Title == txt["Caution"] || Title == txt["Confirm"])
      {
        wrapper.BorderBrush = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FFBB00"));
      }
    }

    private void btnOk_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = "OK";
      this.DialogResult = true;
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = "Cancel";
      this.DialogResult = false;
    }

    private void btnOther_Click(object sender, RoutedEventArgs e)
    {
      Button btn = sender as Button;
      dialogResult = "Other";
      if (btn.Name == "btnOther2") dialogResult = "Other2";
      this.DialogResult = true;
    }

    private void btn_SizeChanged(object sender, SizeChangedEventArgs e)
    {
      List<double> widths = new List<double> { btnOk.ActualWidth, btnCancel.ActualWidth, btnOther.ActualWidth, btnOther2.ActualWidth };
      if (btnOk.ActualWidth < widths.Max()) btnOk.Width = widths.Max();
      if (btnCancel.ActualWidth < widths.Max()) btnCancel.Width = widths.Max();
      if (btnOther.ActualWidth < widths.Max()) btnOther.Width = widths.Max();
      if (btnOther2.ActualWidth < widths.Max()) btnOther2.Width = widths.Max();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      this.SizeToContent = SizeToContent.WidthAndHeight;
      if (this.ActualHeight > this.Owner.ActualHeight - 10)
      {
        this.MaxHeight = this.Owner.ActualHeight - 10;
        this.SizeToContent = SizeToContent.Manual;
      }
      this.Top = this.Owner.Top + (this.Owner.ActualHeight / 2) - (this.ActualHeight / 2);
      this.Left = this.Owner.Left + (this.Owner.ActualWidth / 2) - (this.ActualWidth / 2);
      this.MaxHeight = Double.PositiveInfinity;
    }
  }
}
