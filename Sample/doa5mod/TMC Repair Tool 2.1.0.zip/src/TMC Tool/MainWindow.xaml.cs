﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using Microsoft.WindowsAPICodePack.Dialogs;
using Message;

namespace TMC_Tool
{
  /// <summary>
  /// MainWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class MainWindow : Window
  {
    private static ObservableCollection<CheckData> dataList;

    private static string currentFolder = "";
    private static List<string> originalFileList = new List<string>();

    private static bool openCanceled = false;

    private static int[] checkSizeArray = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 15 };

    private static bool dropOpened = false;

    private static bool appStarted = false;
    private static bool updateChecking = true;
    private static bool modified = false;
    private static bool exitConfirm = false;
    private static bool addDragDrop = true;
    private static Dictionary<string, string> txt = new Dictionary<string, string>();
    private static string langType = "Jpn";



    public MainWindow()
    {
      InitializeComponent();

      MainWindowTitle();
      changeLanguage();
      MessageWindow.lang(txt);
      textStatus.Text = txt["OpenDir"];

      Application.Current.ShutdownMode = ShutdownMode.OnMainWindowClose;
    }

    private void mainWindow_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      if (e.LeftButton == MouseButtonState.Pressed) this.DragMove();
    }

    private void mainWindow_Loaded(object sender, RoutedEventArgs e)
    {
      List<string> cmds = System.Environment.GetCommandLineArgs().ToList();
      cmds.RemoveAt(0);
      openDorpFile(cmds);
    }

    private void mainWindow_DragDrop(object sender, DragEventArgs e)
    {
      if (!dropOpened)
      {
        List<string> filePaths = ((string[])e.Data.GetData(DataFormats.FileDrop, false)).ToList();

        List<string> dirPaths = new List<string>();
        foreach (string path in filePaths)
        {
          if (Directory.Exists(path))
          {
            dirPaths.Add(path);
          }
        }
        if (dirPaths.Count > 0)
        {
          OpenDir(dirPaths);
        }
        else
        {
          if (addDragDrop && (e.KeyStates & DragDropKeyStates.ControlKey) != 0 && btnOriginalFiles.IsEnabled == true)
            openDorpFile(filePaths, "original");
          else
            openDorpFile(filePaths, "tmc");
        }
      }
      dropOpened = false;
    }

    private void openDorpFile(List<string> filePaths)
    {
      openDorpFile(filePaths, "tmc");
    }
    private void openDorpFile(List<string> filePaths, string type)
    {
      if (filePaths.Count < 1) return;

      List<string> tmcPaths = new List<string>();
      List<string> lnkPaths = new List<string>();
      foreach (string path in filePaths)
      {
        if (System.IO.Path.GetExtension(path).ToUpper() == ".TMC")
        {
          tmcPaths.Add(path);
        }
        else if (System.IO.Path.GetExtension(path).ToLower() == ".lnk")
        {
          lnkPaths.Add(path);
        }
      }

      if (lnkPaths.Count > 0)
      {
        Type t = Type.GetTypeFromCLSID(new Guid("72C24DD5-D70A-438B-8A42-98424B88AFB8"));
        dynamic shell = Activator.CreateInstance(t);
        List<string> shortcutPaths = new List<string>();
        foreach (string path in lnkPaths)
        {
          var shortcut = shell.CreateShortcut(path);
          shortcutPaths.Add(shortcut.TargetPath);
          System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shortcut);
        }
        System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shell);

        foreach (string path in shortcutPaths)
        {
          if (System.IO.Path.GetExtension(path).ToUpper() == ".TMC")
          {
            tmcPaths.Add(path);
          }
        }
      }

      if (tmcPaths.Count > 0)
      {
        if (type == "original")
          OriginalOpenFile(tmcPaths[0]);
        else
        {
          tmcPaths.Sort();
          OpenFiles(tmcPaths);
        }
      }
    }

    private void OpenFromClipboard()
    {
      var pathText = Clipboard.GetText();
      if (Clipboard.ContainsFileDropList())
      {
        //データを取得する（取得できなかった時はnull）
        System.Collections.Specialized.StringCollection files = Clipboard.GetFileDropList();
        if (files != null) pathText = files[0];
      }
      if (!string.IsNullOrEmpty(pathText) && File.Exists(pathText) && System.IO.Path.GetExtension(pathText).ToUpper() == ".TMC")
      {
        var result = MessageWindow.Show(this, pathText + "\r\n\r\n" + txt["ConfirmOpenFile"], txt["Info"], txt["btnOpen"], txt["Cancel"]);
        if (result == "OK")
        {
          OpenSingleFile(pathText);
        }
        Keyboard.Focus(mainWindow);
      }
    }

    //private void openCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    //{
    //  e.CanExecute = true;
    //}
    private void openCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var dlg = new CommonOpenFileDialog();
      dlg.IsFolderPicker = true;
      dlg.EnsureReadOnly = false;
      dlg.AllowNonFileSystemItems = false;

      dlg.InitialDirectory = currentFolder;

      if (dlg.ShowDialog() == CommonFileDialogResult.Ok)
      {
        OpenDir(dlg.FileName);
      }
    }

    /*
    private void openCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
      dlg.Filter = "TMC Files (.TMC)|*.TMC";
      if (tmcPath != "")
      {
        dlg.InitialDirectory = Path.GetDirectoryName(tmcPath);
        dlg.FileName = Path.GetFileName(tmcPath);
      }
      if (dlg.ShowDialog() == true)
      {
        OpenFile(dlg.FileName);
      }
    }
    */

    private void saveCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (!IsInitialized || dgDataList == null)
      {
        e.CanExecute = false;
        return;
      }

      bool canExecute = false;
      foreach (var item in dgDataList.SelectedItems)
      {
        var data = item as CheckData;
        if (data == null) continue;

        if (data.OffsetError || data.Section14Error || data.SectionSizeError || (data.NodecpError == true && CheckNodecp(data)))
          canExecute = true;
      }

      if (canExecute)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void saveCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      try
      {
        List<CheckData> saveList = new List<CheckData>();
        foreach (var item in dgDataList.SelectedItems)
        {
          var data = item as CheckData;
          if (data == null) continue;

          if (data.OffsetError || data.Section14Error || data.SectionSizeError || (data.NodecpError == true && CheckNodecp(data)))
            saveList.Add(data);
        }

        if (dgDataList.SelectedItems.Count != saveList.Count)
        {
          string fileList = "";

          foreach (var data in saveList)
          {
            fileList += "\r\n" + data.Path;
          }

          if (MessageWindow.Show(this, txt["ConfirmRepairThese"] + "\r\n" + fileList, txt["Confirm"], txt["Continue"], txt["Cancel"]) == "Cancel")
          {
            return;
          }
        }

        while(saveList.Count > 0)
        {
          var data = saveList[0];
          SaveFile(data);
          saveList.Remove(data);
          dataList.Remove(data);
        }

        MessageWindow.Show(this, txt["Saved"], txt["Info"]);
      }
      catch (Exception ex)
      {
        MessageWindow.Show(this, ex.Message + "\r\n\r\n" + ex.StackTrace, txt["Error"]);
      }
      finally
      {
        ClearStatus();
      }
    }

    private void repairAllCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (!IsInitialized || dgDataList == null)
      {
        e.CanExecute = false;
        return;
      }

      bool canExecute = false;
      foreach (var item in dgDataList.Items)
      {
        var data = item as CheckData;
        if (data == null) continue;

        if (data.OffsetError || data.Section14Error || data.SectionSizeError || (data.NodecpError == true && CheckNodecp(data)))
          canExecute = true;
      }

      if (canExecute)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void repairAllCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      try
      {
        List<CheckData> saveList = new List<CheckData>();
        foreach (var item in dgDataList.Items)
        {
          var data = item as CheckData;
          if (data == null) continue;

          if (data.OffsetError || data.Section14Error || data.SectionSizeError || (data.NodecpError == true && CheckNodecp(data)))
            saveList.Add(data);
        }

        if (dgDataList.Items.Count != saveList.Count)
        {
          string fileList = "";

          foreach (var data in saveList)
          {
            fileList += "\r\n" + data.Path;
          }

          if (MessageWindow.Show(this, txt["ConfirmRepairThese"] + "\r\n" + fileList, txt["Confirm"], txt["Continue"], txt["Cancel"]) == "Cancel")
          {
            return;
          }
        }

        while (saveList.Count > 0)
        {
          var data = saveList[0];
          SaveFile(data);
          saveList.Remove(data);
          dataList.Remove(data);
        }

        MessageWindow.Show(this, txt["Saved"], txt["Info"]);
      }
      catch (Exception ex)
      {
        MessageWindow.Show(this, ex.Message + "\r\n\r\n" + ex.StackTrace, txt["Error"]);
      }
      finally
      {
        ClearStatus();
      }
    }

    private void originalOpenCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (cbNodecpError.IsChecked == true)
        e.CanExecute = true;
    }
    private void originalOpenCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
      dlg.Filter = "TMC Files (.TMC)|*.TMC";

      var data = dgDataList.SelectedItem as CheckData;
      dlg.InitialDirectory = Path.GetDirectoryName(data.Path);

      dlg.FileName = "";
      if (dlg.ShowDialog() == true)
      {
        OriginalOpenFile(dlg.FileName);
      }
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      openCanceled = true;
    }

    private void gridOriginal_Drop(object sender, DragEventArgs e)
    {
      List<string> filePaths = ((string[])e.Data.GetData(DataFormats.FileDrop, false)).ToList();
      dropOpened = true;
      openDorpFile(filePaths, "original");
    }

    private void dgDataList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (!this.IsInitialized) return;

      ClearStatus();

      var data = dgDataList.SelectedItem as CheckData;

      if (data == null) return;

      if (dgDataList.SelectedItems.Count == 1)
      {
        if (data.OffsetError)
        {
          cbOffsetError.IsEnabled = true;
          cbOffsetError.IsChecked = true;
        }

        if (data.Section14Error)
        {
          cbSection14Error.IsEnabled = true;
          cbSection14Error.IsChecked = true;
        }

        if (data.SectionSizeError)
        {
          cbSectionSizeError.IsEnabled = true;
          cbSectionSizeError.IsChecked = true;
        }

        if (data.NodecpError)
        {
          cbNodecpError.IsEnabled = true;
          cbNodecpError.IsChecked = true;
        }
      }

      if (data.NeedOriginal)
      {
        gridOriginal.IsEnabled = true;
        textOrignalTmcPath.Path = data.OriginalPath;
      }

      panelError.IsEnabled = true;
    }



    public void DoEvents()
    {
      DispatcherFrame frame = new DispatcherFrame();
      Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Background, new DispatcherOperationCallback(ExitFrames), frame);
      Dispatcher.PushFrame(frame);
    }

    public object ExitFrames(object frames)
    {
      ((DispatcherFrame)frames).Continue = false;
      return null;
    }

    private void ClearStatus()
    {
      //textMessage.Text = "";
      panelError.IsEnabled = false;
      cbOffsetError.IsEnabled = false;
      cbOffsetError.IsChecked = false;
      cbSection14Error.IsEnabled = false;
      cbSection14Error.IsChecked = false;
      cbSectionSizeError.IsEnabled = false;
      cbSectionSizeError.IsChecked = false;
      cbNodecpError.IsEnabled = false;
      cbNodecpError.IsChecked = false;
      gridOriginal.IsEnabled = false;
      textOrignalTmcPath.Path = "";
    }

    private bool OpenCanceledCheck()
    {
      if (openCanceled)
      {
        var result = MessageWindow.Show(this, "処理を中止しますか？", txt["Info"], txt["OK"], txt["Cancel"]);
        if (result == "OK")
        {
          MessageWindow.Show(this, "処理を中止しました", txt["Info"]);
          openCanceled = false;
          return true;
        }
      }

      return false;
    }

    private bool OpenTmc(string filePath, byte[] bin)
    {
      CheckData checkData = new CheckData(filePath, bin);

      if (CheckError(checkData, bin))
      {
        //dgDataList.Items.Add(filePath);
        dataList.Add(checkData);
        return true;
      }
      else
      {
        return false;
      }
    }

    private void OpenFiles(List<string> files)
    {
      try
      {
        ClearStatus();
        btnOpen.IsEnabled = false;
        btnCancel.IsEnabled = true;
        btnRepairAll.IsEnabled = false;
        btnRepair.IsEnabled = false;
        cbCheckSubDir.IsEnabled = false;
        dgDataList.IsEnabled = false;
        panelError.IsEnabled = false;

        textStatus.Text = "";

        dataList = new ObservableCollection<CheckData>();
        dgDataList.DataContext = dataList;

        if (files.Count == 0) return;

        progressBar.Maximum = files.Count * 2;

        int count = 0;
        char[] charsToTrim = { '\0' };
        foreach (string filePath in files)
        {
          if (OpenCanceledCheck())
          {
            if (dataList.Count > 0) dataList.Clear();
            count = 0;
            break;
          }

          byte[] bin = System.IO.File.ReadAllBytes(filePath);

          if (Encoding.ASCII.GetString(bin, 0, 8).TrimEnd(charsToTrim) != "TMC" || BitConverter.ToUInt32(bin, 0x08) != 0x01010000)
          {
            progressBar.Value += 2;
            DoEvents();
            continue;
          }

          progressBar.Value += 1;
          DoEvents();


          if (OpenTmc(filePath, bin)) count++;


          progressBar.Value += 1;
          DoEvents();
        }
        progressBar.Value = 0;
        DoEvents();

        if (count > 0)
        {
          dgDataList.SelectedIndex = 0;
          DataGridRow row = (DataGridRow)dgDataList.ItemContainerGenerator.ContainerFromItem(dgDataList.SelectedItem);
          SetShiftSelectBase(dgDataList, row, 0);
          dgDataList.IsEnabled = true;
        }
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }
      finally
      {
        btnOpen.IsEnabled = true;
        btnCancel.IsEnabled = false;
        btnRepairAll.IsEnabled = true;
        btnRepair.IsEnabled = true;
        cbCheckSubDir.IsEnabled = true;

        CommandManager.InvalidateRequerySuggested();
      }

    }

    private void OpenDir(string dirPath)
    {
      OpenDir(new List<string>() { dirPath });
    }
    private void OpenDir(List<string> dirPaths)
    {
      try
      {
        List<string> files = new List<string>();
        foreach (var dirPath in dirPaths)
        {
          currentFolder = dirPath;
          if (cbCheckSubDir.IsChecked == true)
            files.AddRange(System.IO.Directory.GetFiles(dirPath, "*.tmc", System.IO.SearchOption.AllDirectories));
          else
            files.AddRange(System.IO.Directory.GetFiles(dirPath, "*.tmc", System.IO.SearchOption.TopDirectoryOnly));
        }

        OpenFiles(files);

        this.Activate();
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }
      finally
      {
      }
    }

    private void OpenSingleFile(string filePath)
    {
      try
      {
        ClearStatus();
        dgDataList.IsEnabled = false;

        dataList = new ObservableCollection<CheckData>();
        dgDataList.DataContext = dataList;

        byte[] bin = System.IO.File.ReadAllBytes(filePath);

        char[] charsToTrim = { '\0' };
        if (Encoding.ASCII.GetString(bin, 0, 8).TrimEnd(charsToTrim) != "TMC" || BitConverter.ToUInt32(bin, 0x08) != 0x01010000)
        {
          MessageWindow.Show(this, txt["UnsupportedFile"] + "\r\n" + filePath, txt["Error"]);
          return;
        }

        if (!OpenTmc(filePath, bin))
        {
          MessageWindow.Show(this, txt["NoProblem"] + "\r\n" + filePath, txt["Info"]);
        }
        else
        {
          dgDataList.IsEnabled = true;
        }

        //int idx = dgDataList.Items.IndexOf(filePath);
        //int idx = Array.FindIndex(this.Node.ToArray(), node => node.ObjIndex == i);

        //if (idx == -1)
        //{
        //  if (!OpenTmc(filePath, bin))
        //  {
        //    MessageWindow.Show(this, txt["NoProblem"] + "\r\n" + filePath, txt["Info"]);
        //  }
        //}
        //else
        //{
        //  if (!UpdateFile(idx))
        //  {
        //    dgDataList.Items.RemoveAt(idx);
        //    dataList.RemoveAt(idx);
        //    ClearStatus();
        //  }
        //}

        CommandManager.InvalidateRequerySuggested();

        this.Activate();
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }
    }

    private void OriginalOpenFile(string filePath)
    {
      try
      {
        foreach (var item in dgDataList.SelectedItems)
        {
          var data = item as CheckData;

          if (data.NeedOriginal)
          {
            ParseOriginal(filePath, data);
          }
        }

        var menuItem = menuOriginalFiles.Items[0] as MenuItem;
        if (menuItem.Name == "menuNotLoaded") menuOriginalFiles.Items.Clear();

        bool add = true;
        foreach (var item in menuOriginalFiles.Items)
        {
          var menuitem = item as MenuItem;
          if (menuitem.Header.ToString() == filePath) add = false;
        }

        if (add)
        {
          menuItem = new MenuItem();
          menuItem.Header = filePath;
          menuItem.Click += new RoutedEventHandler(menuOriginalFiles_Click);
          menuOriginalFiles.Items.Add(menuItem);
        }

        CommandManager.InvalidateRequerySuggested();
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }
    }

    private void ParseOriginal(string filePath, CheckData data)
    {
      byte[] bin = System.IO.File.ReadAllBytes(filePath);

      char[] charsToTrim = { '\0' };
      if (Encoding.ASCII.GetString(bin, 0, 8).TrimEnd(charsToTrim) != "TMC" || BitConverter.ToUInt32(bin, 0x08) != 0x01010000)
      {
        MessageWindow.Show(this, txt["UnsupportedFile"] + "\r\n" + filePath, txt["Error"]);
        return;
      }

      data.Ori = new TMCData(bin);

      if (data.Ori != null)
      {
        data.Ori.Path = filePath;
        data.Ori.WriteTime = System.IO.File.GetLastWriteTime(filePath);

        if (data.Ori.H.Count1 > 11 && data.Ori.H.Offsets[11] != 0) data.Ori.ParseCpf(bin);

        textOrignalTmcPath.Path = filePath;

        CommandManager.InvalidateRequerySuggested();
        this.Activate();
      }

      data.OriginalLoaded = true;
      data.Original = txt["OriginalLoaded"];
      data.OriginalPath = filePath;
    }

    private void menuOriginalFiles_Click(object sender, RoutedEventArgs e)
    {
      var menuItem = sender as MenuItem;

      foreach (var item in dgDataList.SelectedItems)
      {
        var data = item as CheckData;
        if (data == null) continue;

        if (data.NeedOriginal)
        {
          ParseOriginal(menuItem.Header.ToString(), data);
        }
      }
    }

    private bool CheckError(CheckData data, byte[] bin)
    {
      bool error = false;

      data.Tmc.H.Size = bin.Length;
      if (data.Tmc.H.Offsets[15] != 0 && BitConverter.ToUInt32(bin, data.Tmc.H.Offsets[15] + 8) != 16842752)
      {
        data.Tmc.H.Offsets[15] = 0;
        data.OffsetError = true;
        error = true;
      }

      if (data.Tmc.H.Offsets[14] != 0 && BitConverter.ToUInt32(bin, data.Tmc.H.Offsets[14] + 8) != 16842752 && data.PartBins[14].Count > 0x40)
      {
        data.Section14Error = true;
        error = true;
      }

      for (int i = 0; i < data.PartBins.Count; i++)
      {
        if (!checkSizeArray.Contains(i) || data.PartBins[i].Count == 0) continue;

        int size = BitConverter.ToInt32(data.PartBins[i].ToArray(), 0x10);
        if (size != data.PartBins[i].Count)
        {
          data.SectionSizeError = true;
          error = true;
          break;
        }
      }

      if (data.Tmc.NodeCp != null)
      {
        foreach (var nodecp in data.Tmc.NodeCp)
        {
          if (nodecp.cp.Count == 0)
          {
            gridOriginal.IsEnabled = true;
            data.Original = txt["OriginalNeed"];
            data.OriginalPath = txt["NeedOriginal"];
            data.NeedOriginal = true;
            data.NodecpError = true;
            error = true;
            break;
          }
          if (nodecp.Name != "customp")
          {
            data.NodecpError = true;
            error = true;
          }
        }
      }

      return error;
    }

    private bool CheckNodecp(CheckData data)
    {
      if (!data.NeedOriginal) return true;

      if (data.Ori == null || data.Ori.NodeCp == null || data.Ori.NodeCp.Count == 0) return false;

      foreach (var nodecp in data.Tmc.NodeCp)
      {
        if (nodecp.cp.Count > 0) continue;

        int idx = Array.FindIndex(data.Ori.NodeCp.ToArray(), elem => elem.Index == nodecp.Index);
        if (idx == -1) return false;
      }

      return true;
    }

    private void SaveFile(CheckData data)
    {
      try
      {
        if (data.OffsetError)
        {
          data.PartBins[15] = new List<byte>();
        }

        if (data.Section14Error)
        {
          data.PartBins[14] = new List<byte>(new byte[0x40]);
        }

        if (data.SectionSizeError)
        {
          for (int i = 0; i < data.Tmc.H.Count1; i++)
          {
            if (!checkSizeArray.Contains(i) || data.PartBins[i].Count == 0) continue;

            int size = BitConverter.ToInt32(data.PartBins[i].ToArray(), 0x10);
            if (size != data.PartBins[i].Count)
            {
              replaceByteList(data.PartBins[i], BitConverter.GetBytes(data.PartBins[i].Count), 0x10);
            }
          }
        }

        if (data.NodecpError)
        {
          for (int i = 0; i < data.Tmc.NodeCp.Count; i++)
          {
            if (data.Tmc.NodeCp[i].cp.Count == 0)
            {
              int idx = Array.FindIndex(data.Ori.NodeCp.ToArray(), elem => elem.Index == data.Tmc.NodeCp[i].Index);

              data.Tmc.NodeCp[i] = data.Ori.NodeCp[idx];
            }
          }

          data.PartBins[11] = BuildNodecpBin(data.PartBins[11], data.Tmc);
        }

        List<byte> exBn = new List<byte>();
        exBn.AddRange(data.HeaderBin);

        for (int i = 0; i < data.Tmc.H.Count1; i++)
        {
          if (data.PartBins[i].Count != 0)
          {
            replaceByteList(exBn, BitConverter.GetBytes(exBn.Count), 0x140 + (i * 4));
            exBn.AddRange(data.PartBins[i]);
          }
          else
          {
            replaceByteList(exBn, BitConverter.GetBytes(0), 0x140 + (i * 4));
          }
        }

        // 全体サイズ変更
        replaceByteList(exBn, BitConverter.GetBytes(exBn.Count), 0x10);

        updateChecking = false;

        string filePath = data.Tmc.Path;
        if (cbSameName.IsChecked == true)
        {
          string bakPath = data.Tmc.Path + ".bak";
          string baseName = bakPath;
          int count = 1;
          while (System.IO.File.Exists(bakPath))
          {
            bakPath = baseName + count;
            count++;
          }
          File.Move(data.Tmc.Path, bakPath);
        }
        else
        {
          filePath = data.Tmc.Path.Insert(data.Tmc.Path.Length - 4, " - Repaired");
          string baseName = filePath;
          int count = 1;
          while (System.IO.File.Exists(filePath))
          {
            count++;
            filePath = baseName.Insert(baseName.Length - 4, count.ToString());
          }
        }

        // 保存
        System.IO.File.WriteAllBytes(filePath, exBn.ToArray());

        updateChecking = true;
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }
    }

    private List<byte> BuildNodecpBin(List<byte> bin, TMCData tmcData)
    {
      var cpfBin = new List<byte>();
      cpfBin.AddRange(bin.Take(tmcData.CpfOffsets[0]));

      var nodecpBin = buildHeaderBaseBin("nodecp");
      var nodecpBins = new List<List<byte>>();


      for (int i = 0; i < tmcData.NodeCount; i++)
      {
        var custompBin = new List<byte>();

        int nodecp = Array.FindIndex(tmcData.NodeCp.ToArray(), node => node.Index == i);
        if (nodecp != -1)
        {
          custompBin = buildHeaderBaseBin("customp");

          var optionBin = new List<byte>();
          var paramBins = new List<List<byte>>();

          int count = 0;
          foreach (var cp in tmcData.NodeCp[nodecp].cp)
          {
            optionBin.AddRange(BitConverter.GetBytes(cp.Data1));
            optionBin.AddRange(BitConverter.GetBytes(count));

            var paramBin = new List<byte>();
            paramBin.AddRange(BitConverter.GetBytes(cp.Data2));
            if (cp.Data2 == 3)
              paramBin.AddRange(Encoding.ASCII.GetBytes(cp.Param));
            else
              paramBin.AddRange(BitConverter.GetBytes(cp.Param));

            if (paramBin.Count % 16 != 0) paramBin.AddRange(new byte[16 - (paramBin.Count % 16)]);

            paramBins.Add(paramBin);
            count++;
          }
          if (optionBin.Count % 16 != 0) optionBin.AddRange(new byte[16 - (optionBin.Count % 16)]);

          buildBin(custompBin, paramBins, optionBin, false, true);
        }
        nodecpBins.Add(custompBin);
      }

      buildBin(nodecpBin, nodecpBins, null, false, true);


      cpfBin.AddRange(nodecpBin);

      if (tmcData.CpfOffsets.Length > 1 && tmcData.CpfOffsets[1] != 0)
      {
        replaceByteList(cpfBin, BitConverter.GetBytes(cpfBin.Count), 0x34);
        cpfBin.AddRange(bin.Skip(tmcData.CpfOffsets[1]));
      }

      replaceByteList(cpfBin, BitConverter.GetBytes(cpfBin.Count), 0x10);

      return cpfBin;
    }



    private void CheckUpdated()
    {
      if (dataList == null) return;

      bool allYes = false;
      bool allNo = false;
      List<int> removeList = new List<int>();

      int index = 0;
      foreach (var data in dataList)
      {
        if (data.Tmc == null || !System.IO.File.Exists(data.Tmc.Path))
        {
          index++;
          continue;
        }

        var lastWriteTime = System.IO.File.GetLastWriteTime(data.Tmc.Path);
        if (data.Tmc.WriteTime.CompareTo(lastWriteTime) != 0)
        {
          string result = "";
          if (!allYes && !allNo)
          {
            result = MessageWindow.Show(this, txt["ConfirmFileUpdated"] + "\r\n\r\n" + data.Tmc.Path, txt["Confirm"], txt["Yes"], txt["AllNo"], txt["AllYes"], txt["No"]);
          }

          if (allYes || result == "OK")
          {
            if (!UpdateFile(index)) removeList.Add(index);
          }
          else if (result == "Other")
          {
            if (!UpdateFile(index)) removeList.Add(index);
            allYes = true;
          }
          else if (result == "Cancel")
          {
            data.Tmc.WriteTime = lastWriteTime;
            allNo = true;
          }
          else
          {
            data.Tmc.WriteTime = lastWriteTime;
          }
        }

        index++;
      }

      removeList.Sort();
      removeList.Reverse();
      foreach (var idx in removeList)
      {
        dataList.RemoveAt(idx);
      }
    }

    private bool UpdateFile(int index)
    {
      string filePath = dataList[index].Tmc.Path;

      byte[] bin = System.IO.File.ReadAllBytes(filePath);

      char[] charsToTrim = { '\0' };
      if (Encoding.ASCII.GetString(bin, 0, 8).TrimEnd(charsToTrim) != "TMC" || BitConverter.ToUInt32(bin, 0x08) != 0x01010000)
      {
        MessageWindow.Show(this, txt["UnsupportedFile"] + "\r\n" + filePath, txt["Error"]);
        return false;
      }

      CheckData checkData = new CheckData(filePath, bin);

      if (!CheckError(checkData, bin))
      {
        dataList[index].Tmc = checkData.Tmc;
        CommandManager.InvalidateRequerySuggested();
        return true;
      }
      else
      {
        CommandManager.InvalidateRequerySuggested();
        return false;
      }
    }
  }
}
