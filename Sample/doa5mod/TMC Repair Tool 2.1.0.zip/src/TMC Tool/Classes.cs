﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace TMC_Tool
{
  public class CheckData : INotifyPropertyChanged
  {
    public CheckData(string filePath, byte[] bin)
    {
      this.Tmc = new TMCData(bin);

      if (this.Tmc == null) return;

      this.Path = filePath;
      this.Original = "";
      this.Tmc.Path = filePath;
      this.Tmc.WriteTime = System.IO.File.GetLastWriteTime(filePath);

      if (this.Tmc.H.Count1 > 11 && this.Tmc.H.Offsets[11] != 0) this.Tmc.ParseCpf(bin);



      this.HeaderBin = bin.Take(this.Tmc.H.Offsets[0]).ToArray();

      var sizeDict = new Dictionary<int, int>();

      int lastOffset = this.Tmc.H.Size;
      for (int i = this.Tmc.H.Count1 - 1; i >= 0; i--)
      {
        sizeDict[i] = 0;
        if (this.Tmc.H.Offsets[i] != 0)
        {
          sizeDict[i] = lastOffset - this.Tmc.H.Offsets[i];
          lastOffset = this.Tmc.H.Offsets[i];
        }
      }

      this.PartBins = new List<List<byte>>();
      for (int i = 0; i < this.Tmc.H.Count1; i++)
      {
        var partBin = new List<byte>();
        if (this.Tmc.H.Offsets[i] != 0)
        {
          partBin.AddRange(bin.Skip(this.Tmc.H.Offsets[i]).Take(sizeDict[i]));
        }
        this.PartBins.Add(partBin);
      }
    }


    public bool OffsetError { get; set; }
    public bool Section14Error { get; set; }
    public bool SectionSizeError { get; set; }
    public bool NodecpError { get; set; }
    public bool NeedOriginal { get; set; }
    public bool OriginalLoaded { get; set; }

    private string _path;
    public string Path
    {
      get { return _path; }
      set
      {
        _path = value;
        OnPropertyChanged("Path");
      }
    }
    private string _original;
    public string Original
    {
      get { return _original; }
      set
      {
        _original = value;
        OnPropertyChanged("Original");
      }
    }
    public string OriginalPath { get; set; }

    public int Size { get; set; }
    public byte[] HeaderBin { get; set; }
    public List<List<byte>> PartBins { get; set; }

    //public byte[] Bin { get; private set; }
    public TMCData Tmc { get; set; }
    public TMCData Ori { get; set; }

    public event PropertyChangedEventHandler PropertyChanged;
    private void OnPropertyChanged(string name)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(name));
      }
    }
  }

  public class HeaderData
  {
    public HeaderData(int start, byte[] bin, bool checkFlag)
    {
      this.BUildHeaderData(start, bin, checkFlag);
    }
    public HeaderData(int start, byte[] bin)
    {
      this.BUildHeaderData(start, bin, true);
    }

    public void BUildHeaderData(int start, byte[] bin, bool checkFlag)
    {
      this.Start = start;
      this.Offsets = new List<int>(0);
      this.Sizes = new List<int>(0);

      if (checkFlag && BitConverter.ToUInt32(bin, start + 0x08) != 0x01010000) return;

      char[] charsToTrim = { '\0' };
      this.Name = Encoding.ASCII.GetString(bin, start, 8).TrimEnd(charsToTrim);
      this.Flg1 = BitConverter.ToUInt32(bin, start + 0x08);
      this.HSize = BitConverter.ToInt32(bin, start + 0x0C);
      this.Size = BitConverter.ToInt32(bin, start + 0x10);
      this.Count1 = BitConverter.ToInt32(bin, start + 0x14);
      this.Count2 = BitConverter.ToInt32(bin, start + 0x18);
      this.Count3 = BitConverter.ToInt32(bin, start + 0x1C);
      this.Offset1 = BitConverter.ToInt32(bin, start + 0x20);
      this.Offset2 = BitConverter.ToInt32(bin, start + 0x24);
      this.Offset3 = BitConverter.ToInt32(bin, start + 0x28);
      this.Flg2 = BitConverter.ToInt32(bin, start + 0x2C);

      for (int i = 0; i < this.Count1; i++)
      {
        this.Offsets.Add(BitConverter.ToInt32(bin, start + this.Offset1 + (i * 0x04)));
      }

      if (this.Offset2 > 0)
      {
        for (int i = 0; i < this.Count1; i++)
        {
          this.Sizes.Add(BitConverter.ToInt32(bin, start + this.Offset2 + (i * 0x04)));
        }
      }
    }

    public int Start { get; set; }
    public string Name { get; set; }
    public uint Flg1 { get; set; }
    public int HSize { get; set; }
    public int Size { get; set; }
    public int Count1 { get; set; }
    public int Count2 { get; set; }
    public int Count3 { get; set; }
    public int Offset1 { get; set; }
    public int Offset2 { get; set; }
    public int Offset3 { get; set; }
    public int Flg2 { get; set; }

    public List<int> Offsets { get; private set; }
    public List<int> Sizes { get; private set; }
  }

  public class TMCData
  {
    public TMCData(byte[] bin)
    {
      this.H = new HeaderData(0, bin);
    }

    public void ParseCpf(byte[] bin)
    {
      this.NodeCp = new List<Customp>();

      if (this.H.Offsets[11] == 0) return;

      int start = this.H.Offsets[11];
      HeaderData h = new HeaderData(start, bin);
      if (h.Offsets.Count == 0) return;

      this.CpfOffsets = h.Offsets.Select(elem => elem).ToArray();

      if (h.Offsets[0] != 0)
      {
        // nodecp
        HeaderData nodecpH = new HeaderData(start + h.Offsets[0], bin);
        this.NodeCount = nodecpH.Count1;
        for (int i = 0; i < nodecpH.Count1; i++)
        {
          if (nodecpH.Offsets[i] != 0)
          {
            var newNodeCp = new Customp(nodecpH.Start, nodecpH.Offsets[i], bin);
            newNodeCp.Index = i;
            this.NodeCp.Add(newNodeCp);
          }
        }
      }
    }



    public string Path { get; set; }
    public DateTime WriteTime { get; set; }

    public int NodeCount { get; set; }
    public int[] CpfOffsets { get; set; }

    public HeaderData H { get; private set; }

    public List<Customp> NodeCp { get; private set; }
  }

  // cpf
  public class Customp
  {
    public Customp(int start, int offset, byte[] bin)
    {
      this.cp = new List<CustompParam>();

      if (start == 0 && offset == 0) return;

      var cpH = new HeaderData(start + offset, bin);
      this.Offset = offset;
      this.Start = start + offset;
      this.Size = cpH.Size;
      this.Name = cpH.Name;

      char[] charsToTrim = { '\0' };
      for (int i = 0; i < cpH.Count1; i++)
      {
        var newCp = new CustompParam();
        newCp.Index = BitConverter.ToInt32(bin, (int)(cpH.Start + cpH.Offset3 + (8 * i) + 4));
        newCp.Data1 = BitConverter.ToUInt32(bin, (int)(cpH.Start + cpH.Offset3 + (8 * i)));
        newCp.Data2 = BitConverter.ToInt32(bin, (int)(cpH.Start + cpH.Offsets[i]));

        switch (newCp.Data2)
        {
          case 2:
            newCp.Param = BitConverter.ToSingle(bin, (int)(cpH.Start + cpH.Offsets[i] + 4));
            break;
          case 3:
            int datasize = 0;
            if (i == cpH.Count1 - 1)
              datasize = cpH.Size - cpH.Offsets[i] - 4;
            else
              datasize = cpH.Offsets[i + 1] - cpH.Offsets[i] - 4;
            newCp.Param = System.Text.Encoding.ASCII.GetString(bin.Skip((int)(cpH.Start + cpH.Offsets[i] + 4)).Take((int)datasize).ToArray()).TrimEnd(charsToTrim);
            break;
          default:
            newCp.Param = BitConverter.ToInt32(bin, (int)(cpH.Start + cpH.Offsets[i] + 4));
            break;
        }

        this.cp.Add(newCp);
      }
    }

    public int Offset { get; set; }
    public int Start { get; set; }
    public int Size { get; set; }
    public int Index { get; set; }
    public string Name { get; set; }

    public List<CustompParam> cp { get; private set; }
  }

  public class CustompParam
  {
    public CustompParam() { }

    public int Index { get; set; }
    public uint Data1 { get; set; }
    public int Data2 { get; set; }
    public dynamic Param { get; set; } // Data2が02ならfloat、03ならstring、それ以外ならint
  }
}
