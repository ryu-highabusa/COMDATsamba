﻿using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows;

namespace TMC_Tool
{
  public partial class MainWindow : Window
  {

    private void changeLanguage()
    {
      Dictionary<string, string> language = new Dictionary<string, string>();
      txt["btnOpen"] = "開く";
      txt["OK"] = "OK";
      txt["Cancel"] = "キャンセル";
      txt["Yes"] = "はい";
      txt["No"] = "いいえ";
      txt["Info"] = "情報";
      txt["Error"] = "エラー";
      txt["Caution"] = "注意";
      txt["Confirm"] = "確認";
      txt["Message"] = "メッセージ";
      txt["textStatus"] = "ファイルを開いて下さい";
      txt["ExitWithoutSave"] = "変更後保存されていません。このまま終了しますか？";
      txt["Exit"] = "終了する";
      txt["UnsupportedArea"] = "";
      txt["Overwrite"] = "ファイルを上書きしますか？";
      txt["OverwriteYes"] = "上書きする";
      txt["Saved"] = "保存しました";
      txt["UnsupportedFile"] = "対応しているファイルではありません";
      txt["FailedToReopen"] = "再読込に失敗しました";
      txt["ConfirmOpenFile"] = "このファイルを開きますか？";
      txt["ConfirmFileUpdated"] = "下記ファイルが更新されました。開きなおしますか？";

      txt["OpenDir"] = "フォルダを開いて下さい";

      txt["Continue"] = "続行";
      txt["AllYes"] = "全てはい";
      txt["AllNo"] = "全ていいえ";

      txt["NoProblem"] = "問題は見つかりませんでした";

      txt["NeedOriginal"] = "修復には正しい元ファイルを読み込む必要があります";
      txt["OriginalNeed"] = "必要";
      txt["OriginalLoaded"] = "読込済";

      txt["ConfirmRepairThese"] = "修復できないファイルがあります。以下のファイルのみ修復しますか？";



      string filePath = System.AppDomain.CurrentDomain.BaseDirectory + @"\Language.dat";
      if (!File.Exists(filePath))
      {
        return;
      }

      using (var sr = new StreamReader(filePath))
      {
        while (!sr.EndOfStream)
        {
          string[] inLine = sr.ReadLine().Split('\t');
          if (inLine.Length == 0)
          {
            continue;
          }
          else if (inLine[0] == "Type")
          {
            langType = inLine[2].Trim();
          }
          else if (inLine[0] == langType)
          {
            language[inLine[1].Trim()] = inLine[2].Trim();
          }
        }

        List<string> keys = new List<string>();
        foreach (var key in txt.Keys)
        {
          keys.Add(key);
        }
        foreach (string key in keys)
        {
          if (language.ContainsKey(key)) txt[key] = Regex.Unescape(language[key]);
        }
        
        if (language.ContainsKey("btnOpen")) btnOpen.Content = language["btnOpen"];
        if (language.ContainsKey("Cancel")) btnCancel.Content = language["Cancel"];
        if (language.ContainsKey("btnRepair")) btnRepair.Content = language["btnRepair"];
        if (language.ContainsKey("btnRepairAll")) btnRepairAll.Content = language["btnRepairAll"];
        if (language.ContainsKey("cbCheckSubDir")) cbCheckSubDir.Content = language["cbCheckSubDir"];
        if (language.ContainsKey("cbSameName")) cbSameName.Content = language["cbSameName"];
        if (language.ContainsKey("dgcPath")) dgcPath.Header = language["dgcPath"];
        if (language.ContainsKey("dgcOriginal")) dgcOriginal.Header = language["dgcOriginal"];
        if (language.ContainsKey("OffsetError")) cbOffsetError.Content = language["OffsetError"];
        if (language.ContainsKey("Section14Error")) cbSection14Error.Content = language["Section14Error"];
        if (language.ContainsKey("SectionSizeError")) cbSectionSizeError.Content = language["SectionSizeError"];
        if (language.ContainsKey("NodecpError")) cbNodecpError.Content = language["NodecpError"];
        if (language.ContainsKey("btnOriginalOpen")) btnOriginalOpen.Content = language["btnOriginalOpen"];
        if (language.ContainsKey("NotLoaded")) menuNotLoaded.Header = language["NotLoaded"];
      }
    }

  }
}
