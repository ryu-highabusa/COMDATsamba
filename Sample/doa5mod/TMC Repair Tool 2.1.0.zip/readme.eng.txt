
!!! Caution !!!

- What is also the author does not have the responsibility happening.
- Follow the law.



How to enable Language.dat (Delete file extension.)

Language.dat.disable => Language.dat





Sorry, more detailed information is not in English.

Please forgive me my lousy English.
(I was using Google a lot.)





Copyright 2015-now, dtk mnr

Released under the GPL v3.0 License.
http://www.gnu.org/licenses/gpl-3.0.txt
