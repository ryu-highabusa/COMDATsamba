
!!! Caution !!!

If you downloaded from direct url, this might be old version.
Check this url.
https://www.mediafire.com/folder/9zi2gt8dyllaj/doa5mod

You are not permitted to use this tool without your agreement of the following document.
https://www.mediafire.com/folder/rbhtrb7pjlrgr/License -> License.txt

You need to install .NET Framework 4.5.x or 4.6.x.
https://msdn.microsoft.com/library/5a4x27ek.aspx



How to enable Language.dat (Delete file extension.)

Language.dat.disable => Language.dat


If you can't open it on noesis after you save on this tool,
download the plug-in(for Noesis TMC Plugin Custom).

If you want use "Object Togglable Flag",
I recommend that you download "---C File Editor".

Download from here.
https://www.mediafire.com/folder/9zi2gt8dyllaj/doa5mod





Import : Import Object from other TMC File

Edit
  MtrCol             : Edit MtrCol
  matecp             : Edit matecp
  Texture Parameters : Edit Texture Parameters

Up Arrow   : Move up Sub Object
Down Arrow : Move down Sub Object
(Only enabled when Vertices Count is 0 and Indices Count is 0)



1st Table (Object/Sub Object)
Row of Gray Color is Object.

ID          : ID (Read Only)
Object Name : Object/Sub Object Name (Read Only)
Toggle/Type : Object -> Object/Glasses Togglable Flag (You will need to edit the ---C file) / Sub Object -> Type
BIdx        : Blend Indices Count (Read Only)
VGrp        : Vertices Group (Changeable if 0 Vertices and 0 Indices / Index)
VtxCt       : Vertices Count (Read Only)
IdxCt       : Indices Count (Read Only)
UV          : UV Count (Read Only)
Tex1        : Texture1 (Index)
Tex2        : Texture2 (Index)
Tex3        : Texture3 (Index)
Tex4        : Texture4 (Index)
Tex5        : Texture5 (Index)
TexType     : Texture Type (In many cases 0=DiffuseMap 1=NormalMap 2=SpecularMap* 3=EnvironmentMap)
Env         : Environment Map (Changeable if row contains Environment Map)
Trnsp       : Transparent
Dsid        : Double Sided
MCol        : MtrCol (Index)
mtcp        : matecp (Index)
Mtrl        : MCAMTRL (Index)
Z1          : Rendering Order 1 (Hex)
Z2          : Rendering Order 2
Cast        : Cast Shadow (1=Cast 2=NotCast 4=Unknown)
Recv        : Receive Shadow (1=Receive 2=NotReceive 4=Unknown)
Culling     : View Frustum Culling

* 2=DirtMask in the case of objects that use the alpha channel as specular map


2nd Table (Vertex Group/Index Group) (Read Only/It is possible to change some when vertex count is 0)

ID          : ID
VtxCt       : Vertices Count
IdxCt       : Indices Count
Object Name : Object Name
Use         : Using Count
Size        : Data Size of a Vertex
Pos         : Position
Type        : Data Type of Position
Nrm         : Normal
Type        : Data Type of Normal
Wgt         : Blend Weight
Type        : Data Type of Blend Weight
Bld         : Blend Indices
Type        : Data Type of Blend Indices
Col         : Color
Type        : Data Type of Color
Tan         : Tangent
Type        : Data Type of Tangent
UV Ct       : UV Count



Context Menu

- 1st Table

-> Object
Add Object...                          : Add Object
Rename Object...                       : Rename Object (It is possible to rename when current name beginning with "WGT_")
Clear Blend Indices                    : Clear Blend Indices (It is possible to change when vertex count of children is 0)
Cancel Clear Blend Indices             : Cancel Clear Blend Indices

-> Sub Object
Add Sub Object                         : Add Sub Object
Delete Sub Object                      : Delete Sub Object
Delete All Vertices And Indices        : Delete All Vertices And Indices of Selected Rows
Cancel Delete All Vertices And Indices : Cancel Delete All Vertices And Indices of Selected Rows
Get Material                           : Get Material from Other TMC File
Extract Mesh Data                      : Extract Mesh Data as tmcmesh File


- 2nd Table

Add                             : Add Vertex Group/Index Group (Enabled by Single Select)
Delete                          : Delete Vertex Group/Index Group (Enabled when vertex count is 0)
Delete All Vertices And Indices : Delete All Vertices And Indices of Sub Object
Cancel Changed                  : Cancel Changed





Sorry, more detailed information is not in English.

Please forgive me my lousy English.
(I was using Google a lot.)





Copyright 2015-now, dtk mnr

Released under the GPL v3.0 License.
http://www.gnu.org/licenses/gpl-3.0.txt
