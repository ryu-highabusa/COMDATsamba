﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Linq;
using TMC_Tool.ViewModels;
using Tmc;
using Language;

namespace TMC_Tool
{
  /// <summary>
  /// ObjGrpSelectWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class SelectObjGrpWindow : Window
  {
    private static SelectObjGrpWindowViewModel Data;

    private static Lang.Text Txt;

    private static bool dialogResult;

    public SelectObjGrpWindow()
    {
      InitializeComponent();

      this.MouseLeftButtonDown += (sender, e) => this.DragMove();
      this.ShowInTaskbar = false;

      Txt = MainWindow.Txt;

      title.Text = Txt.selectObjGrpTitle;
      dgcObjGrpName.Header = Txt.dgcObjGrpName;
      btnOk.Content = Txt.OK;
      btnCancel.Content = Txt.Cancel;

      Data = new SelectObjGrpWindowViewModel(this);
      this.DataContext = Data;
    }

    private void btnOk_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = true;
      this.Close();
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = false;
    }

    private void CheckBox_Click(object sender, RoutedEventArgs e)
    {
      CheckBox cb = sender as CheckBox;

      if (dgObject.SelectedItems.Count > 1)
      {
        foreach (ObjectItem obj in dgObject.SelectedItems)
        {
          obj.IsChecked = (bool)cb.IsChecked;
        }
      }
      if (dgObject.Items.Count == Data.Objects.Count(elem => elem.IsChecked == true))
        cbHeader.IsChecked = true;
      else
        cbHeader.IsChecked = false;

      if (Data.Objects.Count(elem => elem.IsChecked == true) > 0)
        Data.IsEnabledOk = true;
      else
        Data.IsEnabledOk = false;
    }

    private void HeaderCheckBox_Click(object sender, RoutedEventArgs e)
    {
      CheckBox cb = sender as CheckBox;

      foreach (var obj in Data.Objects)
      {
        obj.IsChecked = (bool)cb.IsChecked;
      }

      if (Data.Objects.Count(elem => elem.IsChecked == true) > 0)
        Data.IsEnabledOk = true;
      else
        Data.IsEnabledOk = false;
    }


    public static List<int> Show(Window owner, TmcData data, TmcData originalData)
    {
      var dlg = new SelectObjGrpWindow();
      dlg.Owner = owner;
      dlg.Owner.IsEnabled = false;

      Data.Init(data, originalData);

      dlg.ShowDialog();

      dlg.Owner.IsEnabled = true;
      dlg.Owner.Focus();

      if (dialogResult)
        return Data.GetChecked();
      else
        return null;
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      this.SizeToContent = SizeToContent.WidthAndHeight;
      if (this.ActualHeight > this.Owner.ActualHeight - 10)
      {
        this.MaxHeight = this.Owner.ActualHeight - 10;
        this.SizeToContent = SizeToContent.Manual;
        this.Height = this.Owner.ActualHeight;
      }
      this.Top = this.Owner.Top + (this.Owner.ActualHeight / 2) - (this.ActualHeight / 2);
      this.Left = this.Owner.Left + (this.Owner.ActualWidth / 2) - (this.ActualWidth / 2);
      this.MaxHeight = Double.PositiveInfinity;
    }
  }
}
