﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.ComponentModel;
using Tmc;
using Language;
using TMC_Tool.ViewModels;

namespace TMC_Tool
{
  /// <summary>
  /// EditMaterialWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class EditMatecpWindow : Window
  {
    private static Lang.Text Txt;

    private static EditMatecpWindowViewModel Data;

    private static bool dialogResult;

    private bool IsActivated = false;


    public EditMatecpWindow()
    {
      InitializeComponent();

      this.MouseLeftButtonDown += (sender, e) => this.DragMove();
      this.ShowInTaskbar = false;

      Txt = MainWindow.Txt;

      title.Text = Txt.editMatecpTitle;
      btnAdd.Content = Txt.Add;
      btnGet.Content = Txt.Get;
      btnDel.Content = Txt.Del;
      btnAddParam.Content = Txt.Add;
      btnDelParam.Content = Txt.Del;
      labelParams.Content = Txt.Parameter;
      labelInfluenceObj.Content = Txt.InfluenceObj;
      btnOk.Content = Txt.OK;
      btnCancel.Content = Txt.Cancel;

      Data = new EditMatecpWindowViewModel(this);
      this.DataContext = Data;
    }

    private void Window_Activated(object sender, EventArgs e)
    {
      if (!IsActivated) IsActivated = true;
    }

    private void Window_Closing(object sender, CancelEventArgs e)
    {
      e.Cancel = true;
      IsActivated = false;
      this.Hide();
      if (this.Owner != null) this.Owner.Activate();
    }

    private void btnOk_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = true;
      this.Close();
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = false;
    }

    private void dgCustomps_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (!this.IsInitialized) return;

      Data.CustompChanged();
    }

    private void tbParam_KeyDown(object sender, KeyEventArgs e)
    {
      Data.IsEnabledOk = true;
    }

    public EditMatecpWindowViewModel Show(Window owner, MainWindowViewModel mainData, int index)
    {
      this.Owner = owner;
      this.Owner.IsEnabled = false;
      Data.IsEnabledOk = false;
      MainWindow.DoEvents();

      Data.SetData(mainData, index);

      if (this.ActualHeight != 0)
      {
        this.Top = owner.Top + (owner.ActualHeight / 2) - (this.ActualHeight / 2);
        this.Left = owner.Left + (owner.ActualWidth / 2) - (this.ActualWidth / 2);
      }

      if (index != -1) dgCustomps.ScrollIntoView(dgCustomps.Items[index]);

      IsActivated = false;
      this.ShowDialog();

      Data.ResetState();
      
      this.Owner.IsEnabled = true;
      this.Owner.Focus();

      if (dialogResult)
        return Data;
      else
        return null;
    }
  }
}
