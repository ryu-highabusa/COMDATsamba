﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.ComponentModel;
using Tmc;
using TMC_Tool.ViewModels;
using TMC_Tool.Models;
using Language;

namespace TMC_Tool
{
  /// <summary>
  /// EditMaterialWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class GetMaterialWindow : Window
  {
    private static Lang.Text Txt;

    private static GetMaterialWindowViewModel Data;

    new private static bool DialogResult;

    private bool IsActivated = false;

    public GetMaterialWindow()
    {
      InitializeComponent();

      this.MouseLeftButtonDown += (sender, e) => this.DragMove();
      this.ShowInTaskbar = false;

      Data = new GetMaterialWindowViewModel(this);
      this.DataContext = Data;

      Txt = MainWindow.Txt;

      title.Text = Txt.getMatTitle;
      labelTmcFile.Content = Txt.getMatLabelTmcFile;
      labelGetObj.Content = Txt.getMatLabelGetObj;
      labelMatData.Content = Txt.getMatLabelMatData;
      rbMtrColAdd.Content = Txt.Add;
      rbMtrColReplace.Content = Txt.Replace;
      rbMateCpAdd.Content = Txt.Add;
      rbMateCpReplace.Content = Txt.Replace;
      rbMcaMtrlAdd.Content = Txt.Add;
      rbMcaMtrlReplace.Content = Txt.Replace;
      cbTexParam.Content = Txt.TextureParameters;
      textAlert.Text = Txt.getMatTextAlert;
      labelInfluenceObj.Content = Txt.InfluenceObj;
      btnOk.Content = Txt.OK;
      btnCancel.Content = Txt.Cancel;
    }

    private void Window_Activated(object sender, EventArgs e)
    {
      if (!IsActivated) IsActivated = true;
    }

    private void Window_Closing(object sender, CancelEventArgs e)
    {
      e.Cancel = true;
      IsActivated = false;
      this.Hide();
      if (this.Owner != null) this.Owner.Activate();
    }

    private void Window_DragOver(object sender, DragEventArgs e)
    {
      e.Handled = true;
      if (e.Data.GetDataPresent(DataFormats.FileDrop))
      {
        e.Effects = DragDropEffects.Copy;
      }
      else
      {
        e.Effects = DragDropEffects.None;
      }
    }

    private void Window_DragDrop(object sender, DragEventArgs e)
    {
      string[] filePaths = (string[])e.Data.GetData(DataFormats.FileDrop, false);
      if (Path.GetExtension(filePaths[0]).ToUpper() == ".TMC")
      {
        Data.Open(filePaths[0]);
      }
    }

    private void btnOk_Click(object sender, RoutedEventArgs e)
    {
      DialogResult = true;
      this.Close();
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      DialogResult = false;
    }

    private void cmbObject_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      ComboBox target = sender as ComboBox;

      if (target.IsMouseCaptured || target.IsKeyboardFocused) Data.CheckMaterialData();
    }

    private void cmbMat_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      ComboBox target = sender as ComboBox;

      if (target.IsMouseCaptured || target.IsKeyboardFocused) Data.BuildInfluenceObjList();
    }


    /// <summary>
    /// 表示
    /// </summary>
    /// <param name="owner">親ウィンドウ</param>
    /// <param name="tmcdata">TMCデータ</param>
    /// <param name="tables">表のデータ</param>
    /// <param name="objs">選択しているオブジェクトリスト</param>
    /// <param name="index">選択するマテリアルのインデックス</param>
    public MaterialData Show(Window owner, TmcData tmcdata, DataTables tables, List<ObjectData> objs, int index)
    {
      Data.Set(tmcdata, tables, objs);
      Data.BuildMatList();
      Data.InitState(null, index);

      return Show(owner);
    }

    /// <summary>
    /// 表示
    /// </summary>
    /// <param name="owner">親ウィンドウ</param>
    /// <param name="tmcdata">TMCデータ</param>
    /// <param name="tables">表のデータ</param>
    /// <param name="objs">選択しているオブジェクトリスト</param>
    /// <param name="mtrCols">MtrColリスト</param>
    /// <param name="index">選択するマテリアルのインデックス</param>
    public MaterialData Show(Window owner, TmcData tmcdata, DataTables tables, List<ObjectData> objs, List<MtrColData> mtrCols, int index)
    {
      Data.Set(tmcdata, tables, objs);
      Data.BuildMatList(mtrCols);
      Data.InitState("MtrCol", index);

      return Show(owner);
    }

    /// <summary>
    /// 表示
    /// </summary>
    /// <param name="owner">親ウィンドウ</param>
    /// <param name="tmcdata">TMCデータ</param>
    /// <param name="tables">表のデータ</param>
    /// <param name="objs">選択しているオブジェクトリスト</param>
    /// <param name="customps">custompリスト</param>
    /// <param name="index">選択するマテリアルのインデックス</param>
    public MaterialData Show(Window owner, TmcData tmcdata, DataTables tables, List<ObjectData> objs, List<CustomParameters> customps, int index)
    {
      Data.Set(tmcdata, tables, objs);
      Data.BuildMatList(customps);
      Data.InitState("matecp", index);

      return Show(owner);
    }

    /// <summary>
    /// 表示
    /// </summary>
    /// <param name="owner">親ウィンドウ</param>
    public MaterialData Show(Window owner)
    {
      this.Owner = owner;
      this.Owner.IsEnabled = false;
      MainWindow.DoEvents();

      if (this.ActualHeight != 0)
      {
        this.Top = this.Owner.Top + (this.Owner.ActualHeight / 2) - (this.ActualHeight / 2);
        this.Left = this.Owner.Left + (this.Owner.ActualWidth / 2) - (this.ActualWidth / 2);
      }

      IsActivated = false;
      this.ShowDialog();

      if (Data.Direct)
      {
        this.Owner.IsEnabled = true;
        this.Owner.Focus();
      }

      if (DialogResult)
        return Data.SetMaterialData();
      else
        return null;
    }

  }
}
