﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.ComponentModel;
using Tmc;
using TMC_Tool.ViewModels;
using Language;

namespace TMC_Tool
{
  /// <summary>
  /// EditMaterialWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class SelectTextureWindow : Window
  {
    public SelectTextureWindowViewModel Data;

    private static Lang.Text Txt;

    private static bool dialogResult;

    private bool IsActivated = false;


    public SelectTextureWindow(List<Textures> textures)
    {
      InitializeComponent();

      this.ShowInTaskbar = false;

      Txt = MainWindow.Txt;

      Data = new SelectTextureWindowViewModel();
      this.DataContext = Data;

      Data.Build(textures);
    }

    private void selectTextureWindow_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      if (e.LeftButton == MouseButtonState.Pressed) this.DragMove();
    }

    private void Window_Activated(object sender, EventArgs e)
    {
      if (!IsActivated)
      {
        ListBoxItem item = (ListBoxItem)(lbTextures.ItemContainerGenerator.ContainerFromIndex(lbTextures.SelectedIndex));
        item.Focus();

        IsActivated = true;
      }
    }

    private void Window_Closing(object sender, CancelEventArgs e)
    {
      e.Cancel = true;
      IsActivated = false;
      this.Hide();
      if (this.Owner != null) this.Owner.Activate();
    }

    private void btnOk_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = true;
      this.Close();
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = false;
    }

    private void lbTextures_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
      if (e.LeftButton != MouseButtonState.Pressed) return;

      dialogResult = true;
      this.Close();
    }

    public int Show(Window owner, int index, ObjectData obj, string header)
    {
      this.Owner = owner;
      this.Owner.IsEnabled = false;
      MainWindow.DoEvents();

      if (this.ActualHeight != 0)
      {
        this.Top = owner.Top + (owner.ActualHeight / 2) - (this.ActualHeight / 2);
        this.Left = owner.Left + (owner.ActualWidth / 2) - (this.ActualWidth / 2);
      }

      Data.Current = "[" + obj.Name + "] " + header + " : " + index;

      if (Data.Textures.Count > index)
        Data.SelectedIndex = index;
      else
        Data.SelectedIndex = -1;
      MainWindow.DoEvents();

      lbTextures.ScrollIntoView(lbTextures.SelectedItem);

      IsActivated = false;
      this.ShowDialog();

      this.Owner.IsEnabled = true;
      this.Owner.Focus();

      if (dialogResult)
        return Data.SelectedIndex;
      else
        return index;
    }
  }
}
