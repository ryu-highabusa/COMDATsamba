﻿using System.Collections.Generic;
using System.Windows;
using System.Data;
using Tmc;
using TMC_Tool.ViewModels;
using Language;

namespace TMC_Tool
{
  /// <summary>
  /// ObjGrpSelectWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class DeleteObjGrpWindow : Window
  {
    private static Lang.Text Txt;

    private static DeleteObjGrpWindowViewModel Data;

    new private static bool DialogResult;



    public DeleteObjGrpWindow()
    {
      InitializeComponent();

      this.MouseLeftButtonDown += (sender, e) => this.DragMove();
      this.ShowInTaskbar = false;


      Data = new DeleteObjGrpWindowViewModel();
      this.DataContext = Data;


      Txt = MainWindow.Txt;

      title.Text = Txt.deleteObjGrpTitle;
      tbDeleteTogether.Text = Txt.tbDeleteTogether;
      tbDeleteTogetherNote.Text = Txt.tbDeleteTogetherNote;
      cbAll.Content = Txt.DeleteAll;
      cbTexture.Content = Txt.Textures;
      cbPhysics.Content = Txt.Physics;
      cbBone.Content = Txt.Bones;
      cbNotDeleteBaseBones.Content = Txt.cbNotDeleteBaseBones;
      cbDeleteUnused.Content = Txt.cbDeleteUnused;
      tbDeleteUnusedNote.Text = Txt.tbDeleteUnusedNote;
      btnOk.Content = Txt.OK;
      btnCancel.Content = Txt.Cancel;
    }

    private void btnOk_Click(object sender, RoutedEventArgs e)
    {
      DialogResult = true;
      this.Close();
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      DialogResult = false;
    }

    public static DeleteObjGrpWindowViewModel Show(Window owner, TmcData tmcData, bool tmclLoaded)
    {
      var dlg = new DeleteObjGrpWindow();
      dlg.Owner = owner;
      dlg.Owner.IsEnabled = false;

      if (dlg.ActualHeight != 0)
      {
        dlg.Top = owner.Top + (owner.ActualHeight / 2) - (dlg.ActualHeight / 2);
        dlg.Left = owner.Left + (owner.ActualWidth / 2) - (dlg.ActualWidth / 2);
      }


      // チェックボックスの有効無効とチェック状態をセット
      Data.SetState(!tmclLoaded, tmcData.MateCp.Count == 0, tmcData.Mat == null, tmcData.H.Offsets[16] == 0);


      dlg.ShowDialog();

      dlg.Owner.IsEnabled = true;
      dlg.Owner.Focus();

      if (DialogResult)
        return Data;
      else
        return null;
    }
  }
}
