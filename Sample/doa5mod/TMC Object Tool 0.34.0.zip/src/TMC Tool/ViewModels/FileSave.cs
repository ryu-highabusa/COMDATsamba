﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text.RegularExpressions;
using Common;
using Tmc;
using TMC_Tool.Models;
using Message;

namespace TMC_Tool.ViewModels
{
  public partial class MainWindowViewModel : BindableBase
  {
    /// <summary>
    /// 保存します
    /// </summary>
    /// <param name="path">ファイルパス</param>
    /// <returns>保存出来たかどうか</returns>
    private bool Save(string path)
    {
      Window.IsEnabled = false;
      MainWindow.DoEvents();

      try
      {
        MainWindow.UpdateChecking = false;


        string filePathL = Path.ChangeExtension(path, ".TMCL");

        if (TextureRebuild && !File.Exists(path) && File.Exists(filePathL))
        {
          var result = MessageWindow.Show(Window, Txt.Overwrite + "\r\n\r\n" + filePathL, Txt.Confirm, Txt.OverwriteYes, Txt.Cancel);
          if (result == MessageWindow.Result.Cancel)
          {
            return false;
          }
        }

        Window.IsEnabled = false;
        MainWindow.DoEvents();


        var save = new Save(this);
        save.Do();


        if (save.ExBin.Count == 0) return false;

        // TMC保存
        File.WriteAllBytes(path, save.ExBin.ToArray());

        
        if (TextureRebuild)
        {
          // TMCL保存
          File.WriteAllBytes(filePathL, save.ExBinL.ToArray());
        }

        if (IsKeepData)
        {
          Status = TmcData.Path;
          TmcData.WriteTime = File.GetLastWriteTime(TmcData.Path);
        }
        else
        {
          ReOpenFile(path);
        }


        ShowTextBlockMessage(Txt.Saved);


        return true;
      }
      catch (Exception e)
      {
        MessageWindow.Show(Window, e.Message + "\r\n\r\n" + e.StackTrace, Txt.Error);
        return false;
      }
      finally
      {
        MainWindow.UpdateChecking = true;
        Window.IsEnabled = true;
        Window.Activate();
        Window.Focus();
      }
    }

    /// <summary>
    /// TMCのバックアップファイルを作成します
    /// </summary>
    /// <returns>バックアップファイルパス配列</returns>
    private string[] CreateBackup()
    {
      try
      {
        if (!File.Exists(TmcData.Path)) return null;

        string dirPath = Path.GetDirectoryName(TmcData.Path);
        string name = Path.GetFileNameWithoutExtension(TmcData.Path);

        List<string> files = Directory.GetFiles(dirPath, name + "*.TMC", SearchOption.TopDirectoryOnly).ToList();
        string regStr = name + @" - ([0-9]+)";
        int count = 1;

        foreach (string file in files)
        {
          string fileName = Path.GetFileNameWithoutExtension(file);

          MatchCollection mc = Regex.Matches(fileName, regStr);
          foreach (Match m in mc)
          {
            int num = int.Parse(m.Groups[1].Value);
            if (count <= num) count = num + 1;
          }
        }

        string[] paths = new string[2];
        paths[0] = dirPath + @"/" + name + " - " + count + ".TMC";
        paths[1] = dirPath + @"/" + name + " - " + count + ".TMCL";
        while (File.Exists(paths[0]) || (TextureRebuild && File.Exists(paths[1])))
        {
          count++;
          paths[0] = dirPath + @"/" + name + " - " + count + ".TMC";
          paths[1] = dirPath + @"/" + name + " - " + count + ".TMCL";
        }

        File.Move(TmcData.Path, paths[0]);

        if (TextureRebuild)
        {
          File.Move(TmclPath, paths[1]);
        }

        return paths;
      }
      catch (Exception e)
      {
        MessageWindow.Show(Window, e.Message + "\r\n\r\n" + e.StackTrace, Txt.Error);
        return null;
      }
    }
  }
}
