﻿using System;
using System.Windows;
using Common;

namespace TMC_Tool.ViewModels
{
  public class ExtractMeshWindowViewModel : BindableBase
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    public ExtractMeshWindowViewModel()
    {
      ExceptUnusedBlendIndex = true;
      CreateDirectory = true;
      WithFileName = true;
    }


    #region ExceptUnusedBlendIndex
    /// <summary>
    /// 未使用BlendIndexを除くかどうか
    /// </summary>
    private bool _ExceptUnusedBlendIndex;
    public bool ExceptUnusedBlendIndex
    {
      get => _ExceptUnusedBlendIndex;
      set => SetProperty(ref _ExceptUnusedBlendIndex, value);
    }
    #endregion

    #region CreateDirectory
    /// <summary>
    /// フォルダを作成するかどうか
    /// </summary>
    private bool _CreateDirectory;
    public bool CreateDirectory
    {
      get => _CreateDirectory;
      set => SetProperty(ref _CreateDirectory, value);
    }
    #endregion

    #region Overwrite
    /// <summary>
    /// 既存ファイルを上書きするかどうか
    /// </summary>
    private bool _Overwrite;
    public bool Overwrite
    {
      get => _Overwrite;
      set => SetProperty(ref _Overwrite, value);
    }
    #endregion

    #region WithFileName
    /// <summary>
    /// ファイル名：TMC名-オブジェクト名
    /// </summary>
    private bool _WithFileName;
    public bool WithFileName
    {
      get => _WithFileName;
      set => SetProperty(ref _WithFileName, value);
    }
    #endregion

    #region ObjectNameOnly
    /// <summary>
    /// ファイル名：オブジェクト名
    /// </summary>
    private bool _ObjectNameOnly;
    public bool ObjectNameOnly
    {
      get => _ObjectNameOnly;
      set => SetProperty(ref _ObjectNameOnly, value);
    }
    #endregion

  }

}
