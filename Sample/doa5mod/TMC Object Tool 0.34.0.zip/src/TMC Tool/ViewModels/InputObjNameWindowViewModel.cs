﻿using System;
using System.Windows;
using Common;

namespace TMC_Tool.ViewModels
{
  public class InputObjNameWindowViewModel : BindableBase
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    public InputObjNameWindowViewModel()
    {
      VisibilityPrefix = Visibility.Visible;
      PrefixText = "WGT_";
    }

    /// <summary>
    /// 
    /// </summary>
    public void CollapsePrefix()
    {
      VisibilityPrefix = Visibility.Collapsed;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name=""></param>
    public void SetData(DataTables tables)
    {
      Tables = tables;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name=""></param>
    /// <param name=""></param>
    public void CheckNameNum(string curName, bool freeName)
    {
      if (curName == "") return;

      string name = "";
      int idx = -1;
      int start = curName.IndexOf('_') + 1;

      if (!freeName && curName.Substring(0, 4) != "WGT_")
      {
        name = curName.Substring(start);
        idx = Array.FindIndex(Tables.Nodes.ToArray(), node => node.Name == "WGT_" + name);
        if (name != "" && idx == -1)
        {
          Name = name;
          IsEnabledOk = true;
          return;
        }
      }

      bool parsableNum = true;
      int num = 0;
      int numLength = 0;
      do
      {
        numLength++;
        parsableNum = Int32.TryParse(curName.Substring(curName.Length - numLength), out num);
      } while (parsableNum);
      numLength--;

      int countUp = 1;
      if (numLength > 0)
      {
        num = Int32.Parse(curName.Substring(curName.Length - numLength));
      }
      else
      {
        countUp++;
      }
      do
      {
        if (freeName)
        {
          name = curName.Substring(0, curName.Length - numLength) + (num + countUp).ToString("D" + numLength);
          idx = Array.FindIndex(Tables.Nodes.ToArray(), node => node.Name == name);
        }
        else
        {
          name = curName.Substring(start, curName.Length - 4 - numLength) + (num + countUp).ToString("D" + numLength);
          idx = Array.FindIndex(Tables.Nodes.ToArray(), node => node.Name == "WGT_" + name);
        }
        countUp++;
      } while (idx != -1);

      if (name != "")
      {
        Name = name;
        IsEnabledOk = true;
      }
    }

    /// <summary>
    /// 
    /// </summary>
    public void CheckObjGrpName()
    {
      int idx = Array.FindIndex(Tables.Nodes.ToArray(), node => node.Name == "WGT_" + Name);

      if (idx == -1)
        IsEnabledOk = true;
      else
        IsEnabledOk = false;
    }



    /// <summary>
    /// 表のデータ
    /// </summary>
    private static DataTables Tables;

    #region Name
    /// <summary>
    /// オブジェクト名
    /// </summary>
    private string _Name;
    public string Name
    {
      get => _Name;
      set
      {
        SetProperty(ref _Name, value);
        CheckObjGrpName();
      }
    }
    #endregion

    #region PrefixText
    /// <summary>
    /// オブジェクト名の先頭に付与するテキスト
    /// </summary>
    private string _PrefixText;
    public string PrefixText
    {
      get => _PrefixText;
      set => SetProperty(ref _PrefixText, value);
    }
    #endregion

    #region VisibilityPrefix
    /// <summary>
    /// オブジェクト名の先頭に付与するテキストの表示状態
    /// </summary>
    private Visibility _VisibilityPrefix;
    public Visibility VisibilityPrefix
    {
      get => _VisibilityPrefix;
      set => SetProperty(ref _VisibilityPrefix, value);
    }
    #endregion

    #region IsEnabledOk
    /// <summary>
    /// OKボタンの状態
    /// </summary>
    private bool _IsEnabledOk;
    public bool IsEnabledOk
    {
      get => _IsEnabledOk;
      set => SetProperty(ref _IsEnabledOk, value);
    }
    #endregion
  }
}
