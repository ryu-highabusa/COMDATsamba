﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Common;
using Tmc;
using TMC_Tool.Models;

namespace TMC_Tool.ViewModels
{
  public class SelectObjGrpWindowViewModel : BindableBase
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    public SelectObjGrpWindowViewModel(SelectObjGrpWindow window)
    {
      Window = window;
      Objects = new ObservableCollection<ObjectItem>();
    }

    public void Init(TmcData data, TmcData originalData)
    {
      if (Objects.Count > 0)
      {
        Objects.Clear();
      }

      for (int i = 0; i < data.ObjGrp.Count; i++)
      {
        int index = Array.FindIndex(originalData.ObjGrp.ToArray(), elem => elem.Name == data.ObjGrp[i].Name);

        if (
          (index != -1 && ConstData.CheckNames.Contains(data.ObjGrp[i].Name.Substring(0, 3))) ||
          data.Node[data.ObjGrp[i].Node].ObjIndex == -1
        )
        {
          continue;
        }

        //ObjectItem newItem = new ObjectItem(true, data.ObjGrp[i].Name, i, -1);
        ObjectItem newItem = new ObjectItem(false, data.ObjGrp[i].Name, i, -1);

        Objects.Add(newItem);
      }

      Window.cbHeader.IsChecked = false;
    }

    public List<int> GetChecked()
    {
      List<int> list = new List<int>();

      foreach (var obj in Objects)
      {
        if (obj.IsChecked) list.Add(obj.Grp);
      }

      return list;
    }



    /// <summary>
    /// オブジェクトリスト
    /// </summary>
    public ObservableCollection<ObjectItem> Objects { get; set; }

    /// <summary>
    /// 
    /// </summary>
    public SelectObjGrpWindow Window { get; set; }

    #region IsEnabledOk
    /// <summary>
    /// OKボタンの状態
    /// </summary>
    private bool _IsEnabledOk;
    public bool IsEnabledOk
    {
      get => _IsEnabledOk;
      set => SetProperty(ref _IsEnabledOk, value);
    }
    #endregion
  }

}
