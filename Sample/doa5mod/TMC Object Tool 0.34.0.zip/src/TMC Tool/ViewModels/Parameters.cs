﻿using System;
using Common;
using Tmc;

namespace TMC_Tool.ViewModels
{
  public class Parameters : BindableBase
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    public Parameters()
    {
      TypeVal = 0x854D87AE;
      Type = "0x" + TypeVal.ToString("X8") + " : Unknown";
      Data2 = 1;
      Param = 1;
    }

    public void Setparameters(CustompParam param)
    {
      Parent = param;
      string type = "Unknown";
      switch (param.Data1)
      {
        case 0x60121B1E:
          type = "Wet(Tex)";
          break;
        //case 0xD66548AD:
        //  type = "Wet(Col)";
        //  break;
        case 0xEB53FEEF:
          type = "Skin";
          break;
      }
      TypeVal = param.Data1;
      Type = "0x" + TypeVal.ToString("X8") + " : " + type;
      Data2 = param.Data2;
      Param = param.Param;
    }



    /// <summary>
    /// 
    /// </summary>
    public CustompParam Parent;

    #region Type
    /// <summary>
    /// 
    /// </summary>
    private string _Type;
    public string Type
    {
      get => _Type;
      set => SetProperty(ref _Type, value);
    }
    #endregion

    /// <summary>
    /// 
    /// </summary>
    public uint TypeVal;

    /// <summary>
    /// 
    /// </summary>
    public int Data2;

    #region Param
    /// <summary>
    /// 
    /// </summary>
    private float _Param;
    public float Param
    {
      get => _Param;
      set
      {
        SetProperty(ref _Param, value);
        if (Parent != null) Parent.Param = value;
      }
    }
    #endregion
  }
}
