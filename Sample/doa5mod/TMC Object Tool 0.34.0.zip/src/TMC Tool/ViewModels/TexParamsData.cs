﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Common;
using Tmc;

namespace TMC_Tool.ViewModels
{
  [Serializable]
  public class TexParamsData : BindableBase
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    public TexParamsData(ObjectPart obj)
    {
      BaseParams = new ObservableCollection<string>();
      ParamSets = new ObservableCollection<TexParameters>();

      if (BaseParams.Count > 0) BaseParams.Clear();
      if (ParamSets.Count > 0) ParamSets.Clear();

      BaseParams.Add(obj.TexParams[0].ToString("X2"));
      BaseParams.Add((obj.TexParams[1] / 0x10 * 0x10).ToString("X2"));
      BaseParams.Add((obj.TexParams[2] / 8 * 8).ToString("X2"));

      for (int i = 0; i < 5; i++)
      {
        var param = new TexParameters();

        if (i < obj.Tex.Count)
        {
          param.SetParams(obj.Tex[i]);
        }

        param.Name = "Tex" + (ParamSets.Count + 1);

        ParamSets.Add(param);
      }
    }

    public TexParamsData Clone()
    {
      // シリアル化した内容を保持しておくためのMemoryStreamを作成
      using (MemoryStream stream = new MemoryStream())
      {
        // バイナリシリアル化を行うためのフォーマッタを作成
        BinaryFormatter f = new BinaryFormatter();

        // 現在のインスタンスをシリアル化してMemoryStreamに格納
        f.Serialize(stream, this);

        // ストリームの位置を先頭に戻す
        stream.Position = 0L;

        // MemoryStreamに格納されている内容を逆シリアル化する
        return (TexParamsData)f.Deserialize(stream);
      }
    }



    public ObservableCollection<string> BaseParams { get; set; }

    public ObservableCollection<TexParameters> ParamSets { get; set; }

  }

}
