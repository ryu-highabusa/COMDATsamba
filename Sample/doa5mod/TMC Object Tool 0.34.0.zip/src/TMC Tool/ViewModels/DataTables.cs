﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using Tmc;
using TMC_Tool.Models;

namespace TMC_Tool.ViewModels
{
  public class DataTables
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    public DataTables()
    {
      ObjData = new ObservableCollection<ObjectData>();
      VIData = new ObservableCollection<VtxIdxGrpData>();
      Nodes = new List<NodeData>();
      PhysicsList = new List<Physics>();
      PhysicsIndicesSet = new List<List<PhysicsIndex>>();

      Textures = new ObservableCollection<int>();
      MtlCols = new ObservableCollection<int>();
      Matecps = new ObservableCollection<int>();
      Mcamtrls = new ObservableCollection<int>();

      ShadowParams = ConstData.ShadowParams;
      Z1s = ConstData.Z1s;
      Z2s = ConstData.Z2s;
      UVCounts = ConstData.UVCounts;
    }
    

    #region メソッド：データ編集

    /// <summary>
    /// 各種データをセットします
    /// </summary>
    public void SetData(TmcData tmcData)
    {
      TmcData = tmcData;

      TexCount = TmcData.Tex.Count;
      EnvironmentFlag = 1;

      if (Nodes.Count > 0) Nodes.Clear();
      if (PhysicsList.Count > 0) PhysicsList.Clear();
      if (PhysicsIndicesSet.Count > 0) PhysicsIndicesSet.Clear();

      if (Textures.Count > 0) Textures.Clear();
      if (MtlCols.Count > 0) MtlCols.Clear();
      if (Matecps.Count > 0) Matecps.Clear();
      if (Mcamtrls.Count > 0) Mcamtrls.Clear();

      for (int i = 0; i < TexCount; i++) Textures.Add(i);
      for (int i = 0; i < TmcData.ColGrp.Count; i++) MtlCols.Add(i);
      for (int i = 0; i < TmcData.MateCp.Count + 1; i++) Matecps.Add(i);
      if (TmcData.Mat != null) for (int i = -1; i < TmcData.Mat.Count; i++) Mcamtrls.Add(i);

      ObjCounts = new Dictionary<int, int>();

      int count = 0;
      int objIndex = 0;

      foreach (var grp in TmcData.ObjGrp)
      {
        if (grp.ChildCount == 0) continue;

        var newObj = new ObjectData();
        newObj.SetObjectData(TmcData, grp, null, count, -1);
        ObjCounts[newObj.ID] = 0;

        ObjData.Add(newObj);
        count++;
        objIndex = 0;

        foreach (var obj in grp.Obj)
        {
          newObj = new ObjectData();
          newObj.SetObjectData(TmcData, grp, obj, count, objIndex);
          ObjCounts[newObj.Grp]++;
          CheckObjectType(newObj);

          ObjData.Add(newObj);
          count++;
          objIndex++;
        }
      }

      for (int i = 0; i < TmcData.VtxGrp.Count; i++)
      {
        var newVI = new VtxIdxGrpData();
        newVI.SetVxtIdxGrpData(TmcData, i);
        VIData.Add(newVI);
      }

      SetNodes();

      SetPhysics();

      ManyObjects = (ObjData.Count > 50) ? true : false;
    }

    /// <summary>
    /// オブジェクトデータを追加
    /// </summary>
    /// <param name="referObj">参照オブジェクトデータ</param>
    /// <returns></returns>
    public ObjectData AddObjectData(ObjectData referObj)
    {
      int idx = ObjData.IndexOf(referObj);
      return AddObjectData(referObj, idx + 1);
    }
    /// <summary>
    /// オブジェクトデータを追加
    /// </summary>
    /// <param name="referObj">参照オブジェクトデータ</param>
    /// <param name="destIdx">挿入先インデックス</param>
    /// <returns></returns>
    public ObjectData AddObjectData(ObjectData referObj, int destIdx)
    {
      var newObj = referObj.Clone();

      newObj.VtxCount = 0;
      newObj.IdxCount = 0;
      //newObj.LastGrpIndex = -1;

      if (newObj.Grp != -1)
      {
        newObj.VtxIdxGruops = new ObservableCollection<int>();
        foreach (var vigrp in referObj.VtxIdxGruops)
        {
          newObj.VtxIdxGruops.Add(vigrp);
        }

        if (referObj.TexTypes.Count != 0)
        {
          string checkTexType = newObj.TexTypes[newObj.TexType].Replace(" ", "");
          newObj.TexTypes = new ObservableCollection<string>();
          newObj.SetTexType(newObj.UVCount, checkTexType);
        }

        newObj.IsDeleted = false;
        newObj.IsEditable = true;
        newObj.IsVgrpChanged = true;
      }

      ObjData.Insert(destIdx, newObj);

      return newObj;
    }

    /// <summary>
    /// 
    /// </summary>
    public void SetNodes()
    {
      foreach (var node in TmcData.Node)
      {
        var newNode = new NodeData(node);

        if (node.Master != -1) newNode.Master = TmcData.Node[node.Master].Name;

        foreach (var idx in TmcData.Hie[node.Index].Children)
        {
          newNode.Children.Add(TmcData.Node[idx].Name);
        }

        newNode.BoneLevel = TmcData.Hie[node.Index].BoneLevel;

        if (node.Blends != null)
        {
          foreach (var idx in node.Blends)
          {
            if (TmcData.Node.Count <= idx || idx == -1)
            {
              Console.WriteLine("Error in SetNodes : " + node.Name);
            }
            newNode.Blends.Add(TmcData.Node[idx].Name);
          }
        }

        if (node.ObjIndex != -1 && TmcData.ObjGrp[node.ObjIndex].ChildCount == 0) newNode.ObjIndex = -1;

        Nodes.Add(newNode);
      }
    }

    /// <summary>
    /// 
    /// </summary>
    public void SetPhysics()
    {
      if (TmcData.Physics != null)
      {
        foreach (var physics in TmcData.Physics)
        {
          var newPhysics = new Physics();
          newPhysics.Name = TmcData.Node[physics.Node].Name;
          newPhysics.Data = physics;
          newPhysics.DataIndex = -1;
          PhysicsList.Add(newPhysics);
        }
      }

      for (int i = 0; i < 2; i++)
      {
        var newIndices = new List<PhysicsIndex>();
        if (TmcData.AcsclsIndices != null)
        {
          foreach (var index in TmcData.AcsclsIndices[i])
          {
            var physicsIndex = new PhysicsIndex();
            physicsIndex.Index = index;
            physicsIndex.DataIndex = -1;
            physicsIndex.Name = TmcData.Node[index].Name;
            newIndices.Add(physicsIndex);
          }
        }
        PhysicsIndicesSet.Add(newIndices);
      }
    }

    /// <summary>
    /// 
    /// </summary>
    public void ResetObjectIndex()
    {
      int index = 0;
      int objGrpIndex = 0;
      int objIndex = 0;
      string grpName = "";
      foreach (var obj in ObjData)
      {
        obj.Index = index;
        index++;

        if (obj.Grp == -1)
        {
          obj.ID = objGrpIndex;
          objGrpIndex++;
          objIndex = 0;
          grpName = obj.Name;
          continue;
        }

        obj.Grp = objGrpIndex - 1;
        obj.ID = objIndex;
        obj.Name = grpName + "_" + objIndex.ToString("x");
        objIndex++;
      }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name=""></param>
    public void RebuildTexData(VtxIdxGrpData viData, MainWindowViewModel data)
    {
      foreach (ObjectData obj in ObjData)
      {
        if (obj.VtxGrp == viData.Index && obj.UVCount != viData.UVCount)
        {
          TmcData tmcData;
          if (viData.DataIndex != -1)
            tmcData = data.OtherTmcDataList[viData.DataIndex];
          else
            tmcData = TmcData;


          obj.UVCount = viData.UVCount;
          string checkTexType = ChangeTexCount(obj, tmcData.ObjGrp[obj.OriginalGrpIndex].Obj[obj.OriginalObjIndex]);
          obj.SetTexType(viData.UVCount, checkTexType);

          if (checkTexType.IndexOf("3") != -1)
            obj.ChangeableEnvMap = true;
          else
            obj.ChangeableEnvMap = false;
        }
      }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="obj">オブジェクトデータ</param>
    /// <param name=""></param>
    public void ChangeTexType(ObjectData obj, int val)
    {
      ChangeTexCount(obj, TmcData.ObjGrp[obj.OriginalGrpIndex].Obj[obj.OriginalObjIndex]);

      if (obj.TexTypes.Count > 0 && obj.TexTypes[val].IndexOf("3") != -1)
        obj.ChangeableEnvMap = true;
      else
        obj.ChangeableEnvMap = false;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="obj">オブジェクトデータ</param>
    /// <param name="obj">オブジェクトパートデータ</param>
    /// <returns></returns>
    public string ChangeTexCount(ObjectData obj, ObjectPart objPart)
    {
      string checkTexType = "";
      string curTexType = "";
      int texCount = obj.UVCount;

      if (obj.TexCount > 0 && obj.TexType == -1)
      {
        return checkTexType;
      }

      int?[] texs = new int?[] { obj.Tex1, obj.Tex2, obj.Tex3, obj.Tex4, obj.Tex5 };

      if (obj.TexTypes.Count != 0)
      {
        if (obj.TexTypes[obj.TexType] == "Error")
        {
          for (int i = 0; i < 5; i++)
          {
            texs[i] = null;
          }

          if (obj.UVCount > 0)
          {
            for (int i = 0; i < 5; i++)
            {
              if (texCount > i)
              {
                if (obj.RecentTexs[i] != null)
                  texs[i] = obj.RecentTexs[i];
                else if (objPart.TexCount > i)
                  texs[i] = objPart.Tex[i].Num;
                else
                  texs[i] = 0;
              }
              else
              {
                break;
              }
            }

            checkTexType = ConstData.TexTypesSet[obj.UVCount][0].Replace(" ", "");
          }
          else
            checkTexType = "";

          obj.Tex1 = texs[0];
          obj.Tex2 = texs[1];
          obj.Tex3 = texs[2];
          obj.Tex4 = texs[3];
          obj.Tex5 = texs[4];

          obj.TexCount = (byte)checkTexType.Length;

          return checkTexType;
        }

        curTexType = obj.TexTypes[obj.TexType].Replace(" ", "");

        if (obj.UVCount > 0)
        {
          int idx = Array.FindIndex(ConstData.TexTypesSet[obj.UVCount].ToArray(), elem => elem == obj.TexTypes[obj.TexType]);
          if (idx != -1)
          {
            texCount = curTexType.Length;
          }
        }
      }

      if (obj.TexCount > texCount)
      {
        for (int i = 0; i < 5; i++)
        {
          if (texCount > i)
          {
            checkTexType += curTexType[i];
          }
          else
          {
            if (texs[i] != null) obj.RecentTexs[i] = texs[i];
            if (curTexType.Length > i) obj.RecentTexTypes[i] = curTexType[i];
            texs[i] = null;
          }
        }
      }
      else
      {
        for (int i = 0; i < 5; i++)
        {
          if (obj.TexCount > i)
          {
            checkTexType += curTexType[i];
          }
          else
          {
            if (texCount > i)
            {
              if (obj.RecentTexs[i] != null)
                texs[i] = obj.RecentTexs[i];
              else if (objPart.TexCount > i)
                texs[i] = objPart.Tex[i].Num;
              else
                texs[i] = 0;
            }
            if (obj.RecentTexTypes[i] != null)
            {
              checkTexType += obj.RecentTexTypes[i];
            }
            else if (objPart.TexCount > i)
            {
              checkTexType += (byte)objPart.Tex[i].Type;
            }
          }
        }

        string tempTexType = "";
        if (texCount == 4)
        {
          if (checkTexType.IndexOf("3") != -1)
            tempTexType += "3";

          if (checkTexType.IndexOf("2") != -1 || checkTexType.IndexOf("1") == -1)
            tempTexType = "2" + tempTexType;

          if (checkTexType.IndexOf("1") != -1 || checkTexType.IndexOf("2") == -1)
            tempTexType = "1" + tempTexType;

          if (tempTexType.Length == 1)
          {
            if (tempTexType.IndexOf("1") == -1)
              tempTexType = "1" + tempTexType;
            else
              tempTexType = tempTexType + "2";
          }

          while (tempTexType.Length < 4)
          {
            tempTexType = "0" + tempTexType;
          }
          checkTexType = tempTexType;
        }
        else if (texCount == 5)
        {
          checkTexType = "00033";
        }
        else if (texCount == 3)
        {
          if (checkTexType.Length != 3)
          {
            if (checkTexType.IndexOf("3") != -1)
              tempTexType += "3";
            else if (checkTexType.IndexOf("2") != -1)
              tempTexType = "2" + tempTexType;

            if (checkTexType.IndexOf("1") != -1 || tempTexType.Length == 0)
              tempTexType = "1" + tempTexType;

            while (tempTexType.Length < 3)
            {
              tempTexType = "0" + tempTexType;
            }
            checkTexType = tempTexType;
          }
        }
        else if (texCount == 2)
        {
          if (checkTexType.Length != 2)
          {
            checkTexType = "00";
          }
        }
        else
        {
          checkTexType = "0";
        }
      }

      obj.Tex1 = texs[0];
      obj.Tex2 = texs[1];
      obj.Tex3 = texs[2];
      obj.Tex4 = texs[3];
      obj.Tex5 = texs[4];

      obj.TexCount = (byte)texCount;

      for (int i = 0; i < 5; i++)
      {
        if (i < texCount)
          obj.TexParam.ParamSets[i].IsEnabled = true;
        else
          obj.TexParam.ParamSets[i].IsEnabled = false;
      }

      return checkTexType;
    }

    /// <summary>
    /// 
    /// </summary>
    public void ReCalcGrpVyxIdxCount()
    {
      ushort[] declVtxCounts = new ushort[VIData.Count];
      int[] declIdxCounts = new int[VIData.Count];

      foreach (var obj in ObjData)
      {
        if (obj.Grp == -1) continue;

        declVtxCounts[(int)obj.VtxGrp] += (ushort)obj.VtxCount;
        declIdxCounts[(int)obj.VtxGrp] += (int)obj.IdxCount;
      }

      for (int i = 0; i < VIData.Count; i++)
      {
        VIData[i].VtxCount = declVtxCounts[i];
        VIData[i].IdxCount = declIdxCounts[i];
        if (VIData[i].VtxCount == 0 && VIData[i].ObjID != -1)
          VIData[i].IsEditable = true;
        else
          VIData[i].IsEditable = false;
      }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name=""></param>
    public void ReCalcGrpUseCount(int? grpID)
    {
      int[] useCounts = new int[VIData.Count];

      foreach (ObjectData obj in ObjData)
      {
        if (obj.Grp != -1) useCounts[(int)obj.VtxGrp] += 1;
      }

      foreach (VtxIdxGrpData viData in VIData)
      {
        if (grpID == null || viData.ObjID == grpID) viData.Use = useCounts[viData.Index];
      }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name=""></param>
    /// <returns></returns>
    public int InsertVIData(VtxIdxGrpData referData)
    {
      return InsertVIData(referData, -1, -1);
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name=""></param>
    /// <param name=""></param>
    /// <param name=""></param>
    /// <returns></returns>
    public int InsertVIData(VtxIdxGrpData referData, int destIdx, int objID)
    {
      if (objID == -1)
      {
        objID = referData.ObjID;
      }

      if (destIdx == -1)
      {
        Dictionary<int, int> objEndIndices = new Dictionary<int, int>();
        int startIndex = 0;
        int curID = VIData[0].ObjID;
        for (int i = 1; i < VIData.Count; i++)
        {
          if (curID == VIData[i].ObjID)
          {
            startIndex++;
          }
          else
          {
            objEndIndices[VIData[i - 1].ObjID] = startIndex;
            startIndex++;
          }
        }
        objEndIndices[VIData[VIData.Count - 1].ObjID] = startIndex;

        destIdx = objEndIndices[objID] + 1;
      }

      VtxIdxGrpData newVI = new VtxIdxGrpData();
      newVI.Index = -1;
      newVI.IsEditable = true;
      newVI.IsChanged = false;
      newVI.IsAdded = true;
      newVI.OriginalIndex = referData.OriginalIndex;
      newVI.OriginalDecl = referData.OriginalDecl;
      newVI.OriginalIdxGrp = referData.OriginalIdxGrp;
      newVI.VtxCount = 0;
      newVI.IdxCount = 0;
      newVI.ObjName = referData.ObjName;
      newVI.ObjID = objID;
      newVI.Use = 0;
      newVI.Datasize = referData.Datasize;
      newVI.Position = referData.Position;
      newVI.Normal = referData.Normal;
      newVI.BWeights = referData.BWeights;
      newVI.BIndices = referData.BIndices;
      newVI.Color = referData.Color;
      newVI.Tangent = referData.Tangent;
      newVI.UVCount = referData.UVCount;
      newVI.PositionType = referData.PositionType;
      newVI.NormalType = referData.NormalType;
      newVI.BWeightsType = referData.BWeightsType;
      newVI.BIndicesType = referData.BIndicesType;
      newVI.ColorType = referData.ColorType;
      newVI.TangentType = referData.TangentType;
      newVI.DataIndex = referData.DataIndex;

      VIData.Insert(destIdx, newVI);

      for (int i = VIData.Count - 1; i >= 0; i--)
      {
        foreach (var obj in ObjData)
        {
          // ObjDataのVtxGrpを再設定
          if (obj.Grp != -1 && obj.VtxGrp == VIData[i].Index && obj.DataIndex == VIData[i].DataIndex) obj.VtxGrp = i;
        }
        // VIDataのIndexを再設定
        VIData[i].Index = i;
      }

      return destIdx;
    }

    /// <summary>
    /// 
    /// </summary>
    public void ResetVtxIdxGruops()
    {
      // ObjDataのVtxIdxGruopsを再設定
      foreach (var obj in ObjData)
      {
        if (obj.Grp == -1) continue;

        int vtxGrp = (int)obj.VtxGrp;
        obj.VtxIdxGruops.Clear();
        foreach (var data in VIData)
        {
          if (obj.Grp == data.ObjID) obj.VtxIdxGruops.Add(data.Index);
        }
        obj.VtxGrp = vtxGrp;
      }
    }

    /// <summary>
    /// 
    /// </summary>
    public void ResetVIDataIdxGrp()
    {
      int count = 0;
      for (int i = 0; i < VIData.Count; i++)
      {
        if (VIData[i].Use == 0) continue;

        VIData[i].IdxGrp = count;
        count++;
      }
    }

    /// <summary>
    /// 
    /// </summary>
    public void ResetNodesObjIndex()
    {
      for (int i = 0; i < Nodes.Count; i++)
      {
        if (Nodes[i].ObjIndex == -1) continue;

        int idx = Array.FindIndex(ObjData.ToArray(), elem => elem.LastGrpIndex == Nodes[i].ObjIndex && (elem.DataIndex == Nodes[i].DataIndex || ConstData.CheckNames.Contains(Nodes[i].Name.Substring(0, 3))));
        if (idx == -1)
        {
          Nodes[i].ObjIndex = -1;
        }
        else
        {
          Nodes[i].ObjIndex = ObjData[idx].ID;
        }
      }
    }

    /// <summary>
    /// 
    /// </summary>
    public void ResetObjDataNode()
    {
      foreach (var objData in ObjData)
      {
        if (objData.Grp != -1) continue;

        int idx = Array.FindIndex(Nodes.ToArray(), elem => elem.Name == objData.Name);
        objData.Node = idx;
      }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="obj">オブジェクトデータ</param>
    public void CheckObjectType(ObjectData obj)
    {
      obj.Type = "";

      if (obj.Matecp != null && obj.Matecp < TmcData.MateCp.Count)
      {
        if (Array.FindIndex(TmcData.MateCp[(int)obj.Matecp].Cp.ToArray(), cp => cp.Data1 == 0xEB53FEEF) != -1)
        {
          obj.Type = "Skin";
        }
        else if (Array.FindIndex(TmcData.MateCp[(int)obj.Matecp].Cp.ToArray(), cp => cp.Data1 == 0x60121B1E) != -1)
        {
          obj.Type = "Wet(Tex)";
        }
      }
    }

    /// <summary>
    /// ノードを並び替え
    /// </summary>
    public void SortNodes()
    {
      var instanceNodes = new List<NodeData>();
      var baseNames = new Dictionary<string, string>();
      int count = 0;

      Nodes = Nodes.OrderBy(node => node.Name.ToLower(), StringComparer.Ordinal).ToList();

      while (Nodes.Count > count)
      {
        int position = Nodes[count].Name.IndexOf("Instance");
        if (position == -1)
        {
          count++;
        }
        else
        {
          position += 8;

          while (Nodes[count].Name.Length > position)
          {
            if (int.TryParse(Nodes[count].Name[position].ToString(), out int num))
            {
              position++;
            }
            else
            {
              break;
            }
          }
          baseNames[Nodes[count].Name] = Nodes[count].Name.Substring(0, position);

          instanceNodes.Add(Nodes[count]);
          Nodes.RemoveAt(count);
        }
      }

      var instanceNodesSet = new Dictionary<string, List<NodeData>>();
      foreach (var node in instanceNodes)
      {
        string baseName = baseNames[node.Name];

        if (!instanceNodesSet.ContainsKey(baseName))
        {
          var nodes = new List<NodeData>();
          instanceNodesSet[baseName] = nodes;
        }

        instanceNodesSet[baseName].Add(node);
      }

      foreach (var pair in instanceNodesSet)
      {
        Nodes.AddRange(pair.Value);
      }
    }

    #endregion



    public TmcData TmcData { get; set; }


    public Dictionary<int, int> ObjCounts { get; set; }

    public bool ManyObjects { get; set; }

    public int? TexCount { get; set; }

    public byte EnvironmentFlag { get; set; }


    public ObservableCollection<int> Textures { get; set; }

    public ObservableCollection<int> MtlCols { get; set; }

    public ObservableCollection<int> Matecps { get; set; }

    public ObservableCollection<int> Mcamtrls { get; set; }

    public int[] ShadowParams { get; set; }

    public string[] Z1s { get; set; }

    public int[] Z2s { get; set; }

    public byte[] UVCounts { get; set; }


    public ObservableCollection<ObjectData> ObjData { get; set; }

    public ObservableCollection<VtxIdxGrpData> VIData { get; set; }

    public List<NodeData> Nodes { get; set; }

    public List<Physics> PhysicsList { get; set; }

    public List<List<PhysicsIndex>> PhysicsIndicesSet { get; set; }

  }
}
