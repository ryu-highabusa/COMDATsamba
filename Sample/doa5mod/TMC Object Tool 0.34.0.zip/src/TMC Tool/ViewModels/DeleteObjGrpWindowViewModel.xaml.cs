﻿using Common;

namespace TMC_Tool.ViewModels
{
  public partial class DeleteObjGrpWindowViewModel : BindableBase
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    public DeleteObjGrpWindowViewModel()
    {
      DeleteAll = true;
      Texture = true;
      MtrCol = true;
      Matecp = true;
      Mcamtrl = true;
      Physics = true;
      Bone = true;
      NotDeleteBaseBones = true;
      DeleteUnuse = false;
    }

    public void SetState(bool disableTexture, bool disableMatecp, bool disableMcamtrl, bool disablePhysics)
    {
      IsEnabledTexture = !disableTexture;
      if (disableTexture) Texture = false;

      IsEnabledMatecp = !disableMatecp;
      if (disableMatecp) Matecp = false;

      IsEnabledMcamtrl = !disableMcamtrl;
      if (disableMcamtrl) Mcamtrl = false;

      IsEnabledPhysics = !disablePhysics;
      if (disablePhysics) Physics = false;
    }

    private void CheckedDeleteAll(bool? state)
    {
      if (state == null) return;

      CheckedDeleteAll((bool)state);
    }
    private void CheckedDeleteAll(bool state)
    {
      if (IsChanging) return;


      IsChanging = true;

      if (IsEnabledTexture) Texture = state;
      MtrCol = state;
      if (IsEnabledMatecp) Matecp = state;
      if (IsEnabledMcamtrl) Mcamtrl = state;
      if (IsEnabledPhysics) Physics = state;
      Bone = state;

      IsChanging = false;
    }

    private void CheckAllChecked()
    {
      if (IsChanging) return;


      IsChanging = true;


      bool allChecked = true;
      bool allUnchecked = true;

      if (IsEnabledTexture)
      {
        if (Texture)
          allUnchecked = false;
        else
          allChecked = false;
      }

      if (MtrCol)
        allUnchecked = false;
      else
        allChecked = false;

      if (IsEnabledMatecp)
      {
        if (Matecp)
          allUnchecked = false;
        else
          allChecked = false;
      }

      if (IsEnabledMcamtrl)
      {
        if (Mcamtrl)
          allUnchecked = false;
        else
          allChecked = false;
      }

      if (IsEnabledPhysics)
      {
        if (Physics)
          allUnchecked = false;
        else
          allChecked = false;
      }

      if (Bone)
        allUnchecked = false;
      else
        allChecked = false;


      if (allChecked)
        DeleteAll = true;
      else if (allUnchecked)
        DeleteAll = false;
      else
        DeleteAll = null;


      IsChanging = false;
    }



    #region DeleteAll
    /// <summary>
    /// 
    /// </summary>
    private bool? _DeleteAll;
    public bool? DeleteAll
    {
      get => _DeleteAll;
      set
      {
        SetProperty(ref _DeleteAll, value);
        CheckedDeleteAll(_DeleteAll);
      }
    }
    #endregion

    #region Texture
    /// <summary>
    /// 
    /// </summary>
    private bool _Texture;
    public bool Texture
    {
      get => _Texture;
      set
      {
        SetProperty(ref _Texture, value);
        CheckAllChecked();
      }
    }
    #endregion

    #region MtrCol
    /// <summary>
    /// 
    /// </summary>
    private bool _MtrCol;
    public bool MtrCol
    {
      get => _MtrCol;
      set
      {
        SetProperty(ref _MtrCol, value);
        CheckAllChecked();
      }
    }
    #endregion

    #region Matecp
    /// <summary>
    /// 
    /// </summary>
    private bool _Matecp;
    public bool Matecp
    {
      get => _Matecp;
      set
      {
        SetProperty(ref _Matecp, value);
        CheckAllChecked();
      }
    }
    #endregion

    #region Mcamtrl
    /// <summary>
    /// 
    /// </summary>
    private bool _Mcamtrl;
    public bool Mcamtrl
    {
      get => _Mcamtrl;
      set
      {
        SetProperty(ref _Mcamtrl, value);
        CheckAllChecked();
      }
    }
    #endregion

    #region Physics
    /// <summary>
    /// 
    /// </summary>
    private bool _Physics;
    public bool Physics
    {
      get => _Physics;
      set
      {
        SetProperty(ref _Physics, value);
        CheckAllChecked();
      }
    }
    #endregion

    #region Bone
    /// <summary>
    /// 
    /// </summary>
    private bool _Bone;
    public bool Bone
    {
      get => _Bone;
      set
      {
        SetProperty(ref _Bone, value);
        CheckAllChecked();
      }
    }
    #endregion

    #region NotDeleteBaseBones
    /// <summary>
    /// 
    /// </summary>
    private bool _NotDeleteBaseBones;
    public bool NotDeleteBaseBones
    {
      get => _NotDeleteBaseBones;
      set => SetProperty(ref _NotDeleteBaseBones, value);
    }
    #endregion

    #region DeleteUnuse
    /// <summary>
    /// 
    /// </summary>
    private bool _DeleteUnuse;
    public bool DeleteUnuse
    {
      get => _DeleteUnuse;
      set => SetProperty(ref _DeleteUnuse, value);
    }
    #endregion


    #region IsEnabled

    #region IsEnabledTexture
    /// <summary>
    /// 
    /// </summary>
    private bool _IsEnabledTexture;
    public bool IsEnabledTexture
    {
      get => _IsEnabledTexture;
      set => SetProperty(ref _IsEnabledTexture, value);
    }
    #endregion

    #region IsEnabledMatecp
    /// <summary>
    /// 
    /// </summary>
    private bool _IsEnabledMatecp;
    public bool IsEnabledMatecp
    {
      get => _IsEnabledMatecp;
      set => SetProperty(ref _IsEnabledMatecp, value);
    }
    #endregion

    #region IsEnabledMcamtrl
    /// <summary>
    /// 
    /// </summary>
    private bool _IsEnabledMcamtrl;
    public bool IsEnabledMcamtrl
    {
      get => _IsEnabledMcamtrl;
      set => SetProperty(ref _IsEnabledMcamtrl, value);
    }
    #endregion

    #region IsEnabledPhysics
    /// <summary>
    /// 
    /// </summary>
    private bool _IsEnabledPhysics;
    public bool IsEnabledPhysics
    {
      get => _IsEnabledPhysics;
      set => SetProperty(ref _IsEnabledPhysics, value);
    }
    #endregion

    #endregion

    /// <summary>
    /// チェック状態を変更中かどうか
    /// </summary>
    private bool IsChanging { get; set; }
  }
}
