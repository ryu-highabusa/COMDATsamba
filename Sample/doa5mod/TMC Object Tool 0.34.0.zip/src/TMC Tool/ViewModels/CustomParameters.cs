﻿using System;
using System.Collections.Generic;
using Common;
using Tmc;

namespace TMC_Tool.ViewModels
{
  public class CustomParameters : BindableBase
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    public CustomParameters(Customp customp, int count)
    {
      cp = new List<CustompParam>();

      if (customp == null) return;

      Index = customp.Index;
      OriginalIndex = customp.Index;
      Use = count;

      foreach (var param in customp.Cp)
      {
        var newCp = new CustompParam();
        newCp.Index = param.Index;
        newCp.Data1 = param.Data1;
        newCp.Data2 = param.Data2;
        newCp.Param = param.Param;
        cp.Add(newCp);
      }
      Count = cp.Count;
    }


    #region Index
    /// <summary>
    /// 
    /// </summary>
    private int _Index;
    public int Index
    {
      get => _Index;
      set => SetProperty(ref _Index, value);
    }
    #endregion

    /// <summary>
    /// 
    /// </summary>
    public int OriginalIndex { get; set; }

    #region Count
    /// <summary>
    /// 
    /// </summary>
    private int _Count;
    public int Count
    {
      get => _Count;
      set => SetProperty(ref _Count, value);
    }
    #endregion

    #region Use
    /// <summary>
    /// 
    /// </summary>
    private int _Use;
    public int Use
    {
      get => _Use;
      set => SetProperty(ref _Use, value);
    }
    #endregion

    /// <summary>
    /// 
    /// </summary>
    public List<CustompParam> cp { get; private set; }
  }
}
