﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Windows.Media.Imaging;
using ImageUtilities;
using System.Collections.ObjectModel;
using Common;
using Tmc;
using TMC_Tool.Models;

namespace TMC_Tool.ViewModels
{
  public class SelectTextureWindowViewModel : BindableBase
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    public SelectTextureWindowViewModel()
    {
      Textures = new ObservableCollection<TextureData>();
    }


    public void Build(List<Textures> textures)
    {
      foreach (var tex in textures)
      {
        Add(tex);
      }
    }

    public void Add(Textures tex)
    {
      System.Drawing.Bitmap bitmap = null;
      try
      {
        bitmap = DDS.GetBitmapArray(tex.Data)[0];
      }
      catch
      {
      }

      int displaySize = 150;

      int displayWidth = displaySize;
      int displayHeight = displaySize;

      int width = BitConverter.ToInt32(tex.Data, 0x10);
      int height = BitConverter.ToInt32(tex.Data, 0x0C);

      var image = new BitmapImage();

      if (bitmap != null)
      {
        image.BeginInit();

        image.CreateOptions = BitmapCreateOptions.None;
        image.CacheOption = BitmapCacheOption.OnLoad;
        if (width < displaySize && height < displaySize)
        {
          displayWidth = width;
          displayHeight = height;
        }
        else if (width > height)
          image.DecodePixelWidth = displaySize;
        else
          image.DecodePixelHeight = displaySize;

        var format = System.Drawing.Imaging.ImageFormat.Bmp;

        MemoryStream st = new MemoryStream();
        bitmap.Save(st, format);
        st.Seek(0, SeekOrigin.Begin);
        image.StreamSource = st;

        image.EndInit();

        bitmap.Dispose();
      }

      TextureData newTex = new TextureData();
      newTex.Source = image;
      newTex.Index = tex.ID;
      newTex.Width = displayWidth;
      newTex.Height = displayHeight;

      Textures.Add(newTex);
    }



    #region Objects
    /// <summary>
    /// オブジェクトリスト
    /// </summary>
    public ObservableCollection<TextureData> Textures { get; set; }
    #endregion

    #region SelectedIndex
    /// <summary>
    /// 選択しているインデックス
    /// </summary>
    private int _SelectedIndex;
    public int SelectedIndex
    {
      get => _SelectedIndex;
      set => SetProperty(ref _SelectedIndex, value);
    }
    #endregion

    #region Current
    /// <summary>
    /// 現在のテクスチャ設定情報
    /// </summary>
    private string _Current;
    public string Current
    {
      get => _Current;
      set => SetProperty(ref _Current, value);
    }
    #endregion

  }











}
