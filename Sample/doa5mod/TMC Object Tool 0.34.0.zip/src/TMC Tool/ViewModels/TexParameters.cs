﻿using System;
using Common;
using Tmc;

namespace TMC_Tool.ViewModels
{
  [Serializable]
  public class TexParameters : BindableBase
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    public TexParameters()
    {
    }

    public void SetParams(ObjectTextureData tex)
    {
      IsEnabled = true;

      USpeed = tex.Data[5];
      VSpeed = tex.Data[6];

      Count = tex.Data[9];
      Skip = tex.Data[10];
      FramesPerTex = tex.Data[12];
      if (tex.Data[11] > 0)
        Repeat = true;
      else
        Repeat = false;
    }

    public void ParamsCopy(TexParameters texParams)
    {
      USpeed = texParams.USpeed;
      VSpeed = texParams.VSpeed;
      Count = texParams.Count;
      Skip = texParams.Skip;
      FramesPerTex = texParams.FramesPerTex;
      Repeat = texParams.Repeat;
    }

    

    #region Name
    /// <summary>
    /// Name
    /// </summary>
    private string _Name;
    public string Name
    {
      get => _Name;
      set => SetProperty(ref _Name, value);
    }
    #endregion

    #region IsEnabled
    /// <summary>
    /// IsEnabled
    /// </summary>
    private bool _IsEnabled;
    public bool IsEnabled
    {
      get => _IsEnabled;
      set => SetProperty(ref _IsEnabled, value);
    }
    #endregion


    #region パラメータ

    #region USpeed
    /// <summary>
    /// USpeed
    /// </summary>
    private float _USpeed;
    public float USpeed
    {
      get => _USpeed;
      set => SetProperty(ref _USpeed, value);
    }
    #endregion

    #region VSpeed
    /// <summary>
    /// VSpeed
    /// </summary>
    private float _VSpeed;
    public float VSpeed
    {
      get => _VSpeed;
      set => SetProperty(ref _VSpeed, value);
    }
    #endregion

    #region Count
    /// <summary>
    /// Count
    /// </summary>
    private uint _Count;
    public uint Count
    {
      get => _Count;
      set => SetProperty(ref _Count, value);
    }
    #endregion

    #region Skip
    /// <summary>
    /// Skip
    /// </summary>
    private ushort _Skip;
    public ushort Skip
    {
      get => _Skip;
      set => SetProperty(ref _Skip, value);
    }
    #endregion

    #region FramesPerTex
    /// <summary>
    /// FramesPerTex
    /// </summary>
    private ushort _FramesPerTex;
    public ushort FramesPerTex
    {
      get => _FramesPerTex;
      set => SetProperty(ref _FramesPerTex, value);
    }
    #endregion

    #region Repeat
    /// <summary>
    /// Repeat
    /// </summary>
    private bool _Repeat;
    public bool Repeat
    {
      get => _Repeat;
      set => SetProperty(ref _Repeat, value);
    }
    #endregion

    #endregion
  }
}
