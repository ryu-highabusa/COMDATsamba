﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using Common;
using Tmc;
using Language;
using Message;
using TMC_Tool.Models;

namespace TMC_Tool.ViewModels
{
  public class EditMatecpWindowViewModel : BindableBase
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    public EditMatecpWindowViewModel(EditMatecpWindow window)
    {
      Window = window;
      Txt = MainWindow.Txt;
      Customps = new ObservableCollection<CustomParameters>();
      Params = new ObservableCollection<Parameters>();
      ParamListData = new SortedSet<uint>();
      ParamListItems = new ObservableCollection<string>();

      IsEnabledAddCustomp = true;
      IsEnabledGetCustomp = true;
    }


    public void SetData(MainWindowViewModel data, int index)
    {
      if (Customps.Count > 0) Customps.Clear();
      if (Params.Count > 0) Params.Clear();

      Data = data;
      Tables = data.Tables;

      foreach (var matecp in data.TmcData.MateCp)
      {
        int count = ReculcCustompUse(matecp, Tables);
        CustomParameters newCp = new CustomParameters(matecp, count);
        Customps.Add(newCp);
      }

      if (index != -1) SelectedCustompIndex = index;

      IsEnabledOk = false;
    }

    public int ReculcCustompUse(Customp cp, DataTables tables)
    {
      int count = 0;
      foreach (var obj in tables.ObjData)
      {
        if (obj.Grp != -1)
        {
          if (obj.Matecp == cp.Index) count++;
        }
      }
      return count;
    }

    public void SetParams(CustomParameters customp)
    {
      if (Params.Count != 0) Params.Clear();
      foreach (var param in customp.cp)
      {
        Parameters newParam = new Parameters();
        newParam.Setparameters(param);
        Params.Add(newParam);
      }
    }

    public void ResetCustompIndex()
    {
      int count = 0;
      foreach (var customp in Customps)
      {
        customp.Index = count;
        count++;
      }
    }

    public void ReflectChangeParams(int index)
    {
      Customps[index].cp.Clear();
      int count = 0;
      foreach (var param in Params)
      {
        var newCp = new CustompParam();
        newCp.Index = count;
        newCp.Data1 = param.TypeVal;
        newCp.Data2 = param.Data2;
        newCp.Param = param.Param;
        param.Parent = newCp;
        Customps[index].cp.Add(newCp);
        count++;
      }
      Customps[index].Count = Customps[index].cp.Count;
    }

    private void SortParamsByType()
    {
      Params = new ObservableCollection<Parameters>(Params.OrderBy(n => n.Type));
    }

    private void ParamListBuild()
    {
      if (ParamListItems.Count > 0) ParamListItems.Clear();
      ParamListData = new SortedSet<uint>();

      ParamListData.Add(0x60121B1E);
      ParamListData.Add(0x854D87AE);
      ParamListData.Add(0xA1314D12);
      ParamListData.Add(0xC65C0D8B);
      ParamListData.Add(0xD66548AD);
      ParamListData.Add(0xE8347F43);
      ParamListData.Add(0xEAD201FC);
      ParamListData.Add(0xEB53FEEF);

      foreach (var customp in Customps)
      {
        foreach (var cp in customp.cp)
        {
          ParamListData.Add(cp.Data1);
        }
      }

      foreach (var data in ParamListData)
      {
        string type = "Unknown";
        switch (data)
        {
          case 0x60121B1E:
            type = "Wet(Tex)";
            break;
          //case 0xD66548AD:
          //  type = "Wet(Col)";
          //  break;
          case 0xEB53FEEF:
            type = "Skin";
            break;
        }
        ParamListItems.Add("0x" + data.ToString("X8") + " : " + type);
      }

      if (ParamListItems.Count > 0)
      {
        SelectedComboBoxIndex = 0;
        IsEnableParamComboBox = true;
        CheckAddParamCommand();
      }
    }

    public bool CheckGettingMateCp(MaterialData gettingMat)
    {
      // 既に同じものがあるかチェック（置換の場合は置換先は除く）
      List<int> equalMateCp = new List<int>();
      foreach (var matecp in Customps)
      {
        if (!gettingMat.MateCpAdd && matecp.Index == gettingMat.MateCpTarget) continue;

        if (matecp.cp.Count != gettingMat.MateCp.Cp.Count) continue;

        for (int i = 0; i < matecp.cp.Count; i++)
        {
          if (
            matecp.cp[i].Data1 != gettingMat.MateCp.Cp[i].Data1 ||
            matecp.cp[i].Data2 != gettingMat.MateCp.Cp[i].Data2 ||
            matecp.cp[i].Param != gettingMat.MateCp.Cp[i].Param
            )
          {
            goto SkipAdd;
          }
        }
        equalMateCp.Add(matecp.Index);

        SkipAdd:;
      }

      // 同じものがあれば追加するか確認
      if (equalMateCp.Count > 0)
      {
        string str = Txt.ConfirmReplace;

        if (gettingMat.MateCpAdd) str = Txt.ConfirmAdd;

        string equalMateCpText = "   MateCp :";

        foreach (var mat in equalMateCp)
        {
          equalMateCpText += " " + mat;
        }

        var result = MessageWindow.Show(Window, Txt.SameMateCp + equalMateCpText + "\r\n" + str, Txt.Confirm, Txt.Yes, Txt.No);
        if (result == MessageWindow.Result.Cancel)
        {
          return false;
        }
      }

      return true;
    }


    public void CustompChanged()
    {
      if (Window.dgCustomps.SelectedItems.Count > 0)
      {
        string listText = "";

        foreach (var obj in Tables.ObjData)
        {
          foreach (var item in Window.dgCustomps.SelectedItems)
          {
            var customp = item as CustomParameters;
            if (obj.Matecp == customp.OriginalIndex)
            {
              if (listText != "") listText += "\r\n";
              listText += obj.Name;
            }
          }
        }

        if (listText != "")
          IsEnabledListInfluenceObj = true;
        else
          IsEnabledListInfluenceObj = false;

        ListInfluenceObj = listText;


        if (Window.dgCustomps.SelectedItems.Count == 1)
        {
          SetParams(Customps[SelectedCustompIndex]);

          IsEnabledDeleteCustomp = (Customps[SelectedCustompIndex].Use == 0);

          ParamListBuild();
        }
      }

      if (Window.dgCustomps.SelectedItems.Count != 1)
      {
        if (Params.Count != 0) Params.Clear();
        IsEnableParamComboBox = false;
        IsEnabledAddParam = false;
        IsEnabledDeleteParam = false;
      }
    }


    private void AddCustomp()
    {
      var newCustomp = new CustomParameters(null, 0);
      newCustomp.Index = Customps.Count;
      newCustomp.OriginalIndex = -1;

      var newCp = new CustompParam();
      newCp.Index = 0;
      newCp.Data1 = 0x854D87AE;
      newCp.Data2 = 1;
      newCp.Param = 1;

      newCustomp.cp.Add(newCp);

      newCustomp.Count = 1;
      Customps.Add(newCustomp);

      SelectedCustompIndex = Customps.Count - 1;

      Window.dgCustomps.ScrollIntoView(Window.dgCustomps.Items[SelectedCustompIndex]);

      IsEnabledOk = true;
    }

    private void GetCustomp()
    {
      int selIndex = -1;

      if (Window.dgCustomps.SelectedItems.Count == 1) selIndex = SelectedCustompIndex;

      var mat = new GetMaterials(Data);
      mat.GetData(Customps.ToList(), selIndex);
      MaterialData gettingMat = mat.Material;

      if (gettingMat == null || gettingMat.MateCp == null) return;


      bool result = CheckGettingMateCp(gettingMat);

      if (!result) return;


      Window.Owner.IsEnabled = false;

      if (gettingMat.MateCpAdd)
      {
        gettingMat.MateCp.Index = Customps.Count;

        var newCp = new CustomParameters(gettingMat.MateCp, 0);
        newCp.OriginalIndex = -1;

        Customps.Add(newCp);

        SelectedCustompIndex = Customps.Count - 1;

        Window.dgCustomps.ScrollIntoView(Window.dgCustomps.Items[SelectedCustompIndex]);
      }
      else
      {
        Customps[gettingMat.MateCpTarget].cp.Clear();

        foreach (var cp in gettingMat.MateCp.Cp)
        {
          Customps[gettingMat.MateCpTarget].cp.Add(cp);
        }

        if (selIndex != -1)
        {
          SelectedCustompIndex = -1;
          SelectedCustompIndex = selIndex;
        }
      }

      IsEnabledOk = true;
    }

    private void DeleteCustomp()
    {
      List<int> selectedIndices = new List<int>();

      foreach (var item in Window.dgCustomps.SelectedItems)
      {
        var customp = item as CustomParameters;
        if (customp.Use == 0) selectedIndices.Add(customp.Index);
      }

      selectedIndices.Sort();
      selectedIndices.Reverse();

      foreach (var index in selectedIndices)
      {
        Customps.RemoveAt(index);
      }

      ResetCustompIndex();

      IsEnabledOk = true;
    }


    private void AddParam()
    {
      try
      {
        if (SelectedComboBoxIndex == -1) return;


        //string type = cmbParam.SelectedValue.ToString();
        string type = ParamListItems[SelectedComboBoxIndex];
        string uintTxt = type.Substring(2).Split(' ')[0];

        // 排他確認
        var findParams = new List<Parameters>();
        string findText = "";
        foreach (var param in Params)
        {
          if (
            (uintTxt == "EB53FEEF" && (param.TypeVal == 0x60121B1E || param.TypeVal == 0xD66548AD)) ||
            ((uintTxt == "60121B1E" || uintTxt == "D66548AD") && param.TypeVal == 0xEB53FEEF)
          )
          {
            findParams.Add(param);
            findText += "\r\n" + param.Type;
          }
        }
        if (findParams.Count > 0)
        {
          var result = MessageWindow.Show(Window, Txt.ConfirmParamDelAndAdd + "\r\n" + findText, Txt.Confirm, Txt.DelAndAdd, Txt.No);
          if (result == MessageWindow.Result.Cancel)
          {
            return;
          }
          while (findParams.Count > 0)
          {
            Params.Remove(findParams[0]);
            findParams.RemoveAt(0);
          }
        }

        Parameters newParam = new Parameters();
        newParam.TypeVal = UInt32.Parse(uintTxt, NumberStyles.AllowHexSpecifier);
        newParam.Type = type;
        Params.Add(newParam);

        // ソート
        var tempParams = new ObservableCollection<Parameters>(Params.OrderBy(n => n.TypeVal));
        Params.Clear();
        foreach (var param in tempParams)
        {
          Params.Add(param);
        }

        ReflectChangeParams(SelectedCustompIndex);

        CheckAddParamCommand();
        IsEnabledOk = true;
      }
      catch
      {
        return;
      }
    }

    private void DeleteParam()
    {
      foreach (var item in Window.dgParams.SelectedItems)
      {
        var param = item as Parameters;
      }

      while (Window.dgParams.SelectedItems.Count > 0 && Params.Count > 1)
      {
        var param = Window.dgParams.SelectedItem as Parameters;
        Params.Remove(param);
      }

      ReflectChangeParams(SelectedCustompIndex);

      if (SelectedParamIndex != -1)
      {
        int selIndex = SelectedParamIndex;
        SelectedParamIndex = -1;
        SelectedParamIndex = selIndex;
      }

      if (Params.Count == 1) IsEnabledDeleteParam = false;

      IsEnabledOk = true;
    }

    private void CheckAddParamCommand()
    {
      int idx = Array.FindIndex(Params.ToArray(), elem => elem.TypeVal == ParamListData.ToArray()[SelectedComboBoxIndex]);
      if (idx == -1)
        IsEnabledAddParam = true;
      else
        IsEnabledAddParam = false;
    }


    public void ResetState()
    {
      if (Params != null && Params.Count != 0) Params.Clear();
      SelectedCustompIndex = -1;
      IsEnableParamComboBox = false;
      IsEnabledAddParam = false;
      IsEnabledDeleteParam = false;
    }


    #region コマンド：customp追加
    /// <summary>
    /// コマンド：customp追加
    /// </summary>
    private DelegateCommand _AddCustompCommand;
    public DelegateCommand AddCustompCommand
      => _AddCustompCommand ?? (_AddCustompCommand = new DelegateCommand(AddCustompCommandExecute, CanAddCustompExecute));

    /// <summary>
    /// コマンド：customp追加 の実行を行います。
    /// </summary>
    private void AddCustompCommandExecute()
    {
      AddCustomp();
    }

    /// <summary>
    /// コマンド：customp追加 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanAddCustompExecute()
    {
      if (IsEnabledAddCustomp)
        return true;
      else
        return false;
    }
    #endregion

    #region コマンド：customp取得
    /// <summary>
    /// コマンド：customp取得
    /// </summary>
    private DelegateCommand _GetCustompCommand;
    public DelegateCommand GetCustompCommand
      => _GetCustompCommand ?? (_GetCustompCommand = new DelegateCommand(GetCustompCommandExecute, CanGetCustompExecute));

    /// <summary>
    /// コマンド：customp取得 の実行を行います。
    /// </summary>
    private void GetCustompCommandExecute()
    {
      GetCustomp();
    }

    /// <summary>
    /// コマンド：customp取得 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanGetCustompExecute()
    {
      if (IsEnabledGetCustomp)
        return true;
      else
        return false;
    }
    #endregion

    #region コマンド：customp削除
    /// <summary>
    /// コマンド：customp削除
    /// </summary>
    private DelegateCommand _DeleteCustompCommand;
    public DelegateCommand DeleteCustompCommand
      => _DeleteCustompCommand ?? (_DeleteCustompCommand = new DelegateCommand(DeleteCustompCommandExecute, CanDeleteCustompExecute));

    /// <summary>
    /// コマンド：customp削除 の実行を行います。
    /// </summary>
    private void DeleteCustompCommandExecute()
    {
      DeleteCustomp();
    }

    /// <summary>
    /// コマンド：customp削除 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanDeleteCustompExecute()
    {
      if (IsEnabledDeleteCustomp)
        return true;
      else
        return false;
    }
    #endregion


    #region コマンド：パラメータ追加
    /// <summary>
    /// コマンド：パラメータ追加
    /// </summary>
    private DelegateCommand _AddParamCommand;
    public DelegateCommand AddParamCommand
      => _AddParamCommand ?? (_AddParamCommand = new DelegateCommand(AddParamCommandExecute, CanAddParamExecute));

    /// <summary>
    /// コマンド：パラメータ追加 の実行を行います。
    /// </summary>
    private void AddParamCommandExecute()
    {
      AddParam();
    }

    /// <summary>
    /// コマンド：パラメータ追加 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanAddParamExecute()
    {
      if (IsEnabledAddParam)
        return true;
      else
        return false;
    }
    #endregion

    #region コマンド：パラメータ削除
    /// <summary>
    /// コマンド：パラメータ削除
    /// </summary>
    private DelegateCommand _DeleteParamCommand;
    public DelegateCommand DeleteParamCommand
      => _DeleteParamCommand ?? (_DeleteParamCommand = new DelegateCommand(DeleteParamCommandExecute, CanDeleteParamExecute));

    /// <summary>
    /// コマンド：パラメータ削除 の実行を行います。
    /// </summary>
    private void DeleteParamCommandExecute()
    {
      DeleteParam();
    }

    /// <summary>
    /// コマンド：パラメータ削除 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanDeleteParamExecute()
    {
      if (IsEnabledDeleteParam)
        return true;
      else
        return false;
    }
    #endregion





    public EditMatecpWindow Window { get; set; }

    public MainWindowViewModel Data { get; set; }

    private static Lang.Text Txt;

    /// <summary>
    /// 表のデータ
    /// </summary>
    private static DataTables Tables;

    #region IsEnabledOk
    /// <summary>
    /// OKボタンの状態
    /// </summary>
    private bool _IsEnabledOk;
    public bool IsEnabledOk
    {
      get => _IsEnabledOk;
      set => SetProperty(ref _IsEnabledOk, value);
    }
    #endregion


    /// <summary>
    /// 
    /// </summary>
    public ObservableCollection<CustomParameters> Customps { get; set; }

    /// <summary>
    /// 
    /// </summary>
    public ObservableCollection<Parameters> Params { get; set; }


    #region メンバー：customp

    #region SelectedCustompIndex
    /// <summary>
    /// 
    /// </summary>
    private int _SelectedCustompIndex;
    public int SelectedCustompIndex
    {
      get => _SelectedCustompIndex;
      set => SetProperty(ref _SelectedCustompIndex, value);
    }
    #endregion

    public bool IsEnabledAddCustomp { get; set; }

    public bool IsEnabledGetCustomp { get; set; }

    public bool IsEnabledDeleteCustomp { get; set; }

    # endregion


    # region メンバー：パラメータ

    #region SelectedParamIndex
    /// <summary>
    /// 
    /// </summary>
    private int _SelectedParamIndex;
    public int SelectedParamIndex
    {
      get => _SelectedParamIndex;
      set
      {
        SetProperty(ref _SelectedParamIndex, value);

        IsEnabledDeleteParam = (Params.Count > 1);
      }
    }
    #endregion

    private SortedSet<uint> ParamListData { get; set; }

    public ObservableCollection<string> ParamListItems { get; set; }

    #region SelectedComboBoxIndex
    /// <summary>
    /// 
    /// </summary>
    private int _SelectedComboBoxIndex;
    public int SelectedComboBoxIndex
    {
      get => _SelectedComboBoxIndex;
      set
      {
        SetProperty(ref _SelectedComboBoxIndex, value);

        if (value != -1) CheckAddParamCommand();
      }
    }
    #endregion

    #region IsEnableParamComboBox
    /// <summary>
    /// パラメータコンボボックスが有効かどうか
    /// </summary>
    private bool _IsEnableParamComboBox;
    public bool IsEnableParamComboBox
    {
      get => _IsEnableParamComboBox;
      set => SetProperty(ref _IsEnableParamComboBox, value);
    }
    #endregion

    public bool IsEnabledAddParam { get; set; }

    public bool IsEnabledDeleteParam { get; set; }

    #endregion


    #region ListInfluenceObj
    /// <summary>
    /// 
    /// </summary>
    private string _ListInfluenceObj;
    public string ListInfluenceObj
    {
      get => _ListInfluenceObj;
      set => SetProperty(ref _ListInfluenceObj, value);
    }
    #endregion

    #region IsEnabledListInfluenceObj
    /// <summary>
    /// OKボタンの状態
    /// </summary>
    private bool _IsEnabledListInfluenceObj;
    public bool IsEnabledListInfluenceObj
    {
      get => _IsEnabledListInfluenceObj;
      set => SetProperty(ref _IsEnabledListInfluenceObj, value);
    }
    #endregion
  }

}
