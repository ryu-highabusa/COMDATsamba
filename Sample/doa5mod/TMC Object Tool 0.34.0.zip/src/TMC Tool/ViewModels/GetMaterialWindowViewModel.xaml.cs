﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Text;
using System.Windows;
using Common;
using Tmc;
using TMC_Tool.Models;
using Language;
using Message;

namespace TMC_Tool.ViewModels
{
  public partial class GetMaterialWindowViewModel : BindableBase
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    /// <param name="window">GetMaterialWindowインスタンス</param>
    public GetMaterialWindowViewModel(GetMaterialWindow window)
    {
      Window = window;

      Txt = MainWindow.Txt;

      Objects = new ObservableCollection<ObjectComboBoxItem>();

      MtlCols = new ObservableCollection<int>();
      Matecps = new ObservableCollection<int>();
      Mcamtrls = new ObservableCollection<int>();

      AddMtrCol = true;
      AddMatecp = true;
      AddMcamtrl = true;

      TexCount = "-";
    }

    /// <summary>
    /// 基本データをセット
    /// </summary>
    /// <param name="tmcdata">TMCデータ</param>
    /// <param name="tables">表のデータ</param>
    /// <param name="objs">選択しているオブジェクトリスト</param>
    public void Set(TmcData tmcdata, DataTables tables, List<ObjectData> selectedObjData)
    {
      TmcData = tmcdata;
      Tables = tables;
      SelectedObjData = selectedObjData;
    }

    /// <summary>
    /// 表示やチェック状態を初期化
    /// </summary>
    /// <param name="type">表示するマテリアルタイプ</param>
    /// <param name="index">選択するマテリアルのインデックス</param>
    public void InitState(string type, int index)
    {
      if (SelectedObjData == null)
      {
        VisibilityAlertText = Visibility.Collapsed;
      }
      else
      {
        VisibilityAlertText = Visibility.Visible;

        if (SelectedObjData.Count > 0)
        {
          SelectedMtlCol = (int)SelectedObjData[0].MtrCol;

          if (SelectedObjData[0].Matecp != null && SelectedObjData[0].Matecp != Tables.Matecps.Count - 1)
            SelectedMatecp = (int)SelectedObjData[0].Matecp;

          if (SelectedObjData[0].Mcamtrl != null && SelectedObjData[0].Mcamtrl != -1)
            SelectedMcamtrl = (int)SelectedObjData[0].Mcamtrl;
        }
      }

      if (type == "MtrCol" || type == "matecp" || type == "MCAMTRL")
      {
        Direct = false;
        VisibilityMtrCol = Visibility.Collapsed;
        VisibilityMatecp = Visibility.Collapsed;
        VisibilityMcamtrl = Visibility.Collapsed;
        VisibilityTextureParameters = Visibility.Collapsed;
        VisibilityAlertText = Visibility.Collapsed;
      }
      else
      {
        Direct = true;
        VisibilityMtrCol = Visibility.Visible;
        VisibilityMatecp = Visibility.Visible;
        VisibilityMcamtrl = Visibility.Visible;
        VisibilityTextureParameters = Visibility.Visible;
        VisibilityAlertText = Visibility.Visible;
      }

      if (type == "MtrCol")
      {
        MtrCol = true;
        VisibilityMtrCol = Visibility.Visible;
        if (index != -1) SelectedMtlCol = index;
      }
      else
        MtrCol = false;

      if (type == "matecp")
      {
        Matecp = true;
        VisibilityMatecp = Visibility.Visible;
        if (index != -1) SelectedMatecp = index;
      }
      else
        Matecp = false;

      if (type == "MCAMTRL")
      {
        Mcamtrl = true;
        VisibilityMcamtrl = Visibility.Visible;
        if (index != -1) SelectedMcamtrl = index;
      }
      else
        Mcamtrl = false;

      TextureParameters = false;
    }

    /// <summary>
    /// 各マテリアルのインデックスリストを構築
    /// </summary>
    public void BuildMatList()
    {
      if (MtlCols.Count > 0) MtlCols.Clear();
      foreach (var col in TmcData.ColGrp) MtlCols.Add(col.ID);
      if (MtlCols.Count > 0) SelectedMtlCol = MtlCols[0];

      if (Matecps.Count > 0) Matecps.Clear();
      foreach (var matecp in TmcData.MateCp) Matecps.Add(matecp.Index);
      if (Matecps.Count > 0) SelectedMatecp = Matecps[0];

      if (Mcamtrls.Count > 0) Mcamtrls.Clear();
      if (TmcData.Mat != null) foreach (var mat in TmcData.Mat) Mcamtrls.Add(mat.ID);
      if (Mcamtrls.Count > 0) SelectedMcamtrl = Mcamtrls[0];
    }

    /// <summary>
    /// MtrColのインデックスリストを構築
    /// </summary>
    public void BuildMatList(List<MtrColData> mtrCols)
    {
      if (MtlCols.Count > 0) MtlCols.Clear();
      foreach (var col in mtrCols) MtlCols.Add(col.Index);
      if (MtlCols.Count > 0) SelectedMtlCol = MtlCols[0];

      if (Matecps.Count > 0) Matecps.Clear();
      if (Mcamtrls.Count > 0) Mcamtrls.Clear();
    }

    /// <summary>
    /// custompのインデックスリストを構築
    /// </summary>
    public void BuildMatList(List<CustomParameters> customps)
    {
      if (Matecps.Count > 0) Matecps.Clear();
      foreach (var matecp in customps) Matecps.Add(matecp.Index);
      if (Matecps.Count > 0) SelectedMatecp = Matecps[0];

      if (MtlCols.Count > 0) MtlCols.Clear();
      if (Mcamtrls.Count > 0) Mcamtrls.Clear();
    }

    /// <summary>
    /// 変更されるオブジェクトリストテキストを構築
    /// </summary>
    public void BuildInfluenceObjList()
    {
      string listText = "";

      if (!MtrCol && !Matecp && !Mcamtrl && !TextureParameters)
      {
        IsEnabledListInfluenceObj = false;
        return;
      }
      else if ((!MtrCol || AddMtrCol) && (!Matecp || AddMatecp) && (!Mcamtrl || AddMcamtrl))
      {
        if (SelectedObjData != null)
        {
          foreach (var obj in SelectedObjData)
          {
            if (listText != "") listText += "\r\n";
            listText += obj.Name;
          }
          IsEnabledListInfluenceObj = true;
        }
      }
      else
      {
        foreach (var obj in Tables.ObjData)
        {
          if (obj.Grp == -1 || (IsEnabledComboBoxMatecp && obj.Matecp == Tables.Matecps.Count - 1)) continue;


          if (
            (IsEnabledComboBoxMtrCol && obj.MtrCol == SelectedMtlCol) ||
            (IsEnabledComboBoxMatecp && obj.Matecp == SelectedMatecp) ||
            (IsEnabledComboBoxMcamtrl && obj.Mcamtrl == SelectedMcamtrl) ||
            (
              ((MtrCol && AddMtrCol) || (Matecp && AddMatecp) || (Mcamtrl && AddMcamtrl) || (TextureParameters)) &&
              Array.FindIndex(SelectedObjData.ToArray(), elem => elem.Grp == obj.Grp && elem.ID == obj.ID) != -1
            )
          )
          {
            if (listText != "") listText += "\r\n";
            listText += obj.Name;
          }
        }
        if (listText != "")
          IsEnabledListInfluenceObj = true;
        else
          IsEnabledListInfluenceObj = false;
      }

      ListInfluenceObj = listText;
    }

    /// <summary>
    /// 選択したマテリアルを取得するTMCデータのオブジェクトのマテリアルデータをチェックして状態などを変更
    /// </summary>
    public void CheckMaterialData()
    {
      if (Objects.Count == 0) return;

      var grp = ReferTmcData.ObjGrp[SelectedItemObjects.Grp];
      var obj = ReferTmcData.ObjGrp[SelectedItemObjects.Grp].Obj[SelectedItemObjects.Obj];

      IsEnabledMtrCol = true;
      IsEnabledTextureParameters = true;

      if (ReferTmcData.MateCp.Count > 0 && ReferTmcData.Itable[grp.ID].Indices[obj.ID] != ReferTmcData.MateCp.Count)
        IsEnabledMatecp = true;
      else
        IsEnabledMatecp = false;

      if (TmcData.Mat != null && ReferTmcData.McaIdx != null && ReferTmcData.McaIdx[grp.ID].MatID[obj.ID] != -1)
        IsEnabledMcamtrl = true;
      else
        IsEnabledMcamtrl = false;

      TexCount = obj.TexCount.ToString();
    }

    /// <summary>
    /// マテリアルを取得するTMCデータのオブジェクトリストを構築
    /// </summary>
    private void BuildObjectList()
    {
      if (Objects.Count > 0) Objects.Clear();

      int grpCount = 0;
      foreach (var grp in ReferTmcData.ObjGrp)
      {
        int objCount = 0;
        foreach (var obj in grp.Obj)
        {
          string type = CheckMatecpType(grp, obj);

          var objItem = new ObjectComboBoxItem(grp.Name + "_" + obj.ID.ToString("x") + type, grpCount, objCount);

          Objects.Add(objItem);

          objCount++;
        }
        grpCount++;
      }

      if (Objects.Count > 0)
      {
        SelectedItemObjects = Objects[0];
        CheckMaterialData();
        IsEnabledComboBoxObjects = true;
      }
    }

    /// <summary>
    /// matecpのタイプをチェック
    /// </summary>
    /// <returns>matecpのタイプテキスト</returns>
    private string CheckMatecpType(ObjectGroup grp, ObjectPart obj)
    {
      if (ReferTmcData.Itable.Count == 0) return "";


      int matecpIndex = ReferTmcData.Itable[grp.ID].Indices[obj.ID];

      if (matecpIndex >= ReferTmcData.MateCp.Count) return "";


      string type = "";

      var cps = ReferTmcData.MateCp[matecpIndex].Cp;

      if (Array.FindIndex(cps.ToArray(), cp => cp.Data1 == 0xEB53FEEF) != -1)
      {
        type = " / Skin";
      }
      else if (Array.FindIndex(cps.ToArray(), cp => cp.Data1 == 0x60121B1E) != -1)
      {
        type = " / Wet(Tex)";
      }


      return type;
    }

    /// <summary>
    /// マテリアルを取得するTMCデータを開く
    /// </summary>
    /// <param name="path">ファイルパス</param>
    public void Open(string path)
    {
      try
      {
        IsEnabledComboBoxObjects = false;

        IsEnabledMtrCol = false;
        IsEnabledReplaceMtrCol = false;

        IsEnabledMatecp = false;
        IsEnabledReplaceMatecp = false;

        IsEnabledMcamtrl = false;
        IsEnabledReplaceMcamtrl = false;

        IsEnabledTextureParameters = false;

        ReferBin = File.ReadAllBytes(path);
        char[] charsToTrim = { '\0' };
        string Name = Encoding.ASCII.GetString(ReferBin, 0, 8).TrimEnd(charsToTrim);
        if (Name != "TMC")
        {
          MessageWindow.Show(Window, Txt.UnsupportedFile + "\r\n" + path, Txt.Error);
          return;
        }
        uint Flg1 = BitConverter.ToUInt32(ReferBin, 0x08);
        if (Flg1 != 16842752)
        {
          MessageWindow.Show(Window, Txt.UnsupportedFile + "\r\n" + path, Txt.Error);
          return;
        }

        ReferTmcData = new TmcData(ReferBin);
        ReferTmcData.ParseObjBaseData(ReferBin);
        ReferTmcData.ParseMtrColor(ReferBin);
        if (ReferTmcData.H.Offsets[12] != 0) ReferTmcData.ParseMCAPack(ReferBin);

        if (ReferTmcData != null)
        {
          BuildObjectList();

          if (MtrCol)
          {
            if (SelectedObjData.Count <= 1) IsEnabledReplaceMtrCol = true;
            if (VisibilityMtrCol == Visibility.Visible) IsEnabledOk = true;
          }
          if (Matecp)
          {
            if (SelectedObjData.Count <= 1 && TmcData.MateCp.Count > 0) IsEnabledReplaceMatecp = true;
            if (VisibilityMatecp == Visibility.Visible) IsEnabledOk = true;
          }
          if (Mcamtrl)
          {
            if (SelectedObjData.Count <= 1) IsEnabledReplaceMcamtrl = true;
            if (VisibilityMcamtrl == Visibility.Visible) IsEnabledOk = true;
          }

          FilePath = path;
        }
      }
      catch (Exception e)
      {
        MessageWindow.Show(Window, e.Message + "\r\n\r\n" + e.StackTrace, Txt.Error);
      }
    }

    /// <summary>
    /// MaterialDataに各種データをセットして取得
    /// </summary>
    /// <returns>MaterialData</returns>
    public MaterialData SetMaterialData()
    {
      MaterialData gettingMat = new MaterialData();

      int grpID = SelectedItemObjects.Grp;
      int objID = SelectedItemObjects.Obj;

      // MtrCol
      if (MtrCol)
      {
        MtrColorGroup col = ReferTmcData.ColGrp[ReferTmcData.ObjGrp[grpID].Obj[objID].MtrColor];

        int target = -1;
        if (ReplaceMtrCol) target = SelectedMtlCol;

        gettingMat.SetColData(col.Start - col.Offset, col.Offset, ReferBin, target);
      }

      // matecp
      if (IsEnabledMatecp && Matecp)
      {
        Customp cp = ReferTmcData.MateCp[ReferTmcData.Itable[grpID].Indices[objID]];

        int target = -1;
        if (ReplaceMatecp) target = SelectedMatecp;

        gettingMat.SetMateCpData(cp.Start - cp.Offset, cp.Offset, ReferBin, target);
      }

      // MCAMTRL
      if (IsEnabledMcamtrl && Mcamtrl)
      {
        Material mat = ReferTmcData.Mat[ReferTmcData.McaIdx[grpID].MatID[objID]];

        int target = -1;
        if (ReplaceMcamtrl) target = SelectedMcamtrl;

        gettingMat.SetMatData(mat.Start - mat.Offset, mat.Offset, ReferBin, target);
      }

      // TexParam
      if (TextureParameters)
      {
        gettingMat.SetObjTexData(ReferTmcData.ObjGrp[grpID].Obj[objID], ReferBin);
      }


      return gettingMat;
    }

    #region コマンド：開く
    /// <summary>
    /// コマンド：開く
    /// </summary>
    private DelegateCommand _OpenCommand;
    public DelegateCommand OpenCommand
      => _OpenCommand ?? (_OpenCommand = new DelegateCommand(OpenExecute, () => true));

    /// <summary>
    /// コマンド：開く の実行を行います。
    /// </summary>
    private void OpenExecute()
    {
      Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
      dlg.Filter = "TMC Files (.TMC)|*.TMC";
      if (ReferTmcData != null && String.IsNullOrEmpty(ReferTmcData.Path))
      {
        dlg.InitialDirectory = Path.GetDirectoryName(ReferTmcData.Path);
        dlg.FileName = Path.GetFileName(ReferTmcData.Path);
      }
      if (dlg.ShowDialog() == true)
      {
        Open(dlg.FileName);
      }
    }
    #endregion



    /// <summary>
    /// 言語テキスト
    /// </summary>
    private static Lang.Text Txt;

    /// <summary>
    /// GetMaterialWindow
    /// </summary>
    private static GetMaterialWindow Window { get; set; }

    /// <summary>
    /// TMCデータ
    /// </summary>
    private static TmcData TmcData;

    /// <summary>
    /// マテリアルを取得するTMCのバイナリ
    /// </summary>
    private static byte[] ReferBin;

    /// <summary>
    /// マテリアルを取得するTMCデータ
    /// </summary>
    private static TmcData ReferTmcData;

    /// <summary>
    /// 表のデータ
    /// </summary>
    private static DataTables Tables;

    /// <summary>
    /// 選択されているオブジェクトデータ
    /// </summary>
    private static List<ObjectData> SelectedObjData;

    /// <summary>
    /// チェック状態を変更中かどうか
    /// </summary>
    private bool IsChanging { get; set; }

    /// <summary>
    /// 
    /// </summary>
    public bool Direct { get; set; }


    #region FilePath
    /// <summary>
    /// 参照TMCファイルのファイルパス
    /// </summary>
    private string _FilePath;
    public string FilePath
    {
      get => _FilePath;
      set => SetProperty(ref _FilePath, value);
    }
    #endregion

    /// <summary>
    /// オブジェクトコンボボックスのオブジェクトリスト
    /// </summary>
    public ObservableCollection<ObjectComboBoxItem> Objects { get; set; }

    #region SelectedItemObjects
    /// <summary>
    /// オブジェクトコンボボックスのSelectedItem
    /// </summary>
    private ObjectComboBoxItem _SelectedItemObjects;
    public ObjectComboBoxItem SelectedItemObjects
    {
      get => _SelectedItemObjects;
      set => SetProperty(ref _SelectedItemObjects, value);
    }
    #endregion

    #region IsEnabledComboBoxObjects
    /// <summary>
    /// cmbObjectの状態
    /// </summary>
    private bool _IsEnabledComboBoxObjects;
    public bool IsEnabledComboBoxObjects
    {
      get => _IsEnabledComboBoxObjects;
      set => SetProperty(ref _IsEnabledComboBoxObjects, value);
    }
    #endregion

    #region TexCount
    /// <summary>
    /// 取得するオブジェクトのテキスト数
    /// </summary>
    private string _TexCount;
    public string TexCount
    {
      get => _TexCount;
      set => SetProperty(ref _TexCount, value);
    }
    #endregion

    #region ListInfluenceObj
    /// <summary>
    /// 
    /// </summary>
    private string _ListInfluenceObj;
    public string ListInfluenceObj
    {
      get => _ListInfluenceObj;
      set => SetProperty(ref _ListInfluenceObj, value);
    }
    #endregion

    #region IsEnabledListInfluenceObj
    /// <summary>
    /// OKボタンの状態
    /// </summary>
    private bool _IsEnabledListInfluenceObj;
    public bool IsEnabledListInfluenceObj
    {
      get => _IsEnabledListInfluenceObj;
      set => SetProperty(ref _IsEnabledListInfluenceObj, value);
    }
    #endregion

    #region IsEnabledOk
    /// <summary>
    /// OKボタンの状態
    /// </summary>
    private bool _IsEnabledOk;
    public bool IsEnabledOk
    {
      get => _IsEnabledOk;
      set => SetProperty(ref _IsEnabledOk, value);
    }
    #endregion


    #region MtrCol
    /// <summary>
    /// 
    /// </summary>
    private bool _MtrCol;
    public bool MtrCol
    {
      get => _MtrCol;
      set
      {
        SetProperty(ref _MtrCol, value);

        if (value)
        {
          if (SelectedObjData.Count <= 1)
            IsEnabledReplaceMtrCol = true;
          else
            AddMtrCol = true;

          BuildInfluenceObjList();

          if (!IsEnabledMtrCol) return;

          IsEnabledOk = true;
        }
        else
        {
          IsEnabledReplaceMtrCol = false;

          BuildInfluenceObjList();

          if (!Matecp && !Mcamtrl && !TextureParameters) IsEnabledOk = false;
        }
      }
    }
    #endregion

    #region Matecp
    /// <summary>
    /// 
    /// </summary>
    private bool _Matecp;
    public bool Matecp
    {
      get => _Matecp;
      set
      {
        SetProperty(ref _Matecp, value);

        if (value)
        {
          if (SelectedObjData.Count <= 1 && TmcData.MateCp.Count > 0)
            IsEnabledReplaceMatecp = true;
          else
            AddMatecp = true;

          BuildInfluenceObjList();

          if (!IsEnabledMatecp) return;

          IsEnabledOk = true;
        }
        else
        {
          IsEnabledReplaceMatecp = false;

          BuildInfluenceObjList();

          if (!MtrCol && !Mcamtrl && !TextureParameters) IsEnabledOk = false;
        }
      }
    }
    #endregion

    #region Mcamtrl
    /// <summary>
    /// 
    /// </summary>
    private bool _Mcamtrl;
    public bool Mcamtrl
    {
      get => _Mcamtrl;
      set
      {
        SetProperty(ref _Mcamtrl, value);

        if (value)
        {
          if (SelectedObjData.Count <= 1)
            IsEnabledReplaceMcamtrl = true;
          else
            AddMcamtrl = true;

          BuildInfluenceObjList();

          if (!IsEnabledMtrCol) return;

          IsEnabledOk = true;
        }
        else
        {
          IsEnabledReplaceMcamtrl = false;

          BuildInfluenceObjList();

          if (!MtrCol && !Matecp && !TextureParameters) IsEnabledOk = false;
        }
      }
    }
    #endregion

    #region TextureParameters
    /// <summary>
    /// 
    /// </summary>
    private bool _TextureParameters;
    public bool TextureParameters
    {
      get => _TextureParameters;
      set
      {
        SetProperty(ref _TextureParameters, value);

        if (value)
        {
          BuildInfluenceObjList();
          IsEnabledOk = true;
        }
        else
        {
          BuildInfluenceObjList();
          if (!MtrCol && !Matecp && !Mcamtrl) IsEnabledOk = false;
        }
      }
    }
    #endregion


    #region IsEnabled

    #region IsEnabledMtrCol
    /// <summary>
    /// 
    /// </summary>
    private bool _IsEnabledMtrCol;
    public bool IsEnabledMtrCol
    {
      get => _IsEnabledMtrCol;
      set => SetProperty(ref _IsEnabledMtrCol, value);
    }
    #endregion

    #region IsEnabledMatecp
    /// <summary>
    /// 
    /// </summary>
    private bool _IsEnabledMatecp;
    public bool IsEnabledMatecp
    {
      get => _IsEnabledMatecp;
      set => SetProperty(ref _IsEnabledMatecp, value);
    }
    #endregion

    #region IsEnabledMcamtrl
    /// <summary>
    /// 
    /// </summary>
    private bool _IsEnabledMcamtrl;
    public bool IsEnabledMcamtrl
    {
      get => _IsEnabledMcamtrl;
      set => SetProperty(ref _IsEnabledMcamtrl, value);
    }
    #endregion

    #region IsEnabledTextureParameters
    /// <summary>
    /// 
    /// </summary>
    private bool _IsEnabledTextureParameters;
    public bool IsEnabledTextureParameters
    {
      get => _IsEnabledTextureParameters;
      set => SetProperty(ref _IsEnabledTextureParameters, value);
    }
    #endregion

    #endregion


    #region IsEnabledReplace

    #region IsEnabledReplaceMtrCol
    /// <summary>
    /// 
    /// </summary>
    private bool _IsEnabledReplaceMtrCol;
    public bool IsEnabledReplaceMtrCol
    {
      get => _IsEnabledReplaceMtrCol;
      set
      {
        SetProperty(ref _IsEnabledReplaceMtrCol, value);

        IsEnabledComboBoxMtrCol = (value && ReplaceMtrCol);
      }
    }
    #endregion

    #region IsEnabledReplaceMatecp
    /// <summary>
    /// 
    /// </summary>
    private bool _IsEnabledReplaceMatecp;
    public bool IsEnabledReplaceMatecp
    {
      get => _IsEnabledReplaceMatecp;
      set
      {
        SetProperty(ref _IsEnabledReplaceMatecp, value);

        IsEnabledComboBoxMatecp = (value && ReplaceMatecp);
      }
    }
    #endregion

    #region IsEnabledReplaceMcamtrl
    /// <summary>
    /// 
    /// </summary>
    private bool _IsEnabledReplaceMcamtrl;
    public bool IsEnabledReplaceMcamtrl
    {
      get => _IsEnabledReplaceMcamtrl;
      set
      {
        SetProperty(ref _IsEnabledReplaceMcamtrl, value);

        IsEnabledComboBoxMcamtrl = (value && ReplaceMcamtrl);
      }
    }
    #endregion

    #endregion


    #region IsEnabledComboBox

    #region IsEnabledComboBoxMtrCol
    /// <summary>
    /// 
    /// </summary>
    private bool _IsEnabledComboBoxMtrCol;
    public bool IsEnabledComboBoxMtrCol
    {
      get => _IsEnabledComboBoxMtrCol;
      set => SetProperty(ref _IsEnabledComboBoxMtrCol, value);
    }
    #endregion

    #region IsEnabledComboBoxMatecp
    /// <summary>
    /// 
    /// </summary>
    private bool _IsEnabledComboBoxMatecp;
    public bool IsEnabledComboBoxMatecp
    {
      get => _IsEnabledComboBoxMatecp;
      set => SetProperty(ref _IsEnabledComboBoxMatecp, value);
    }
    #endregion

    #region IsEnabledComboBoxMcamtrl
    /// <summary>
    /// 
    /// </summary>
    private bool _IsEnabledComboBoxMcamtrl;
    public bool IsEnabledComboBoxMcamtrl
    {
      get => _IsEnabledComboBoxMcamtrl;
      set => SetProperty(ref _IsEnabledComboBoxMcamtrl, value);
    }
    #endregion

    #endregion


    #region RadioButtonのチェック状態

    #region AddMtrCol
    /// <summary>
    /// 
    /// </summary>
    private bool _AddMtrCol;
    public bool AddMtrCol
    {
      get => _AddMtrCol;
      set
      {
        SetProperty(ref _AddMtrCol, value);

        if (!value) BuildInfluenceObjList();
      }
    }
    #endregion

    #region ReplaceMtrCol
    /// <summary>
    /// 
    /// </summary>
    private bool _ReplaceMtrCol;
    public bool ReplaceMtrCol
    {
      get => _ReplaceMtrCol;
      set
      {
        SetProperty(ref _ReplaceMtrCol, value);

        IsEnabledComboBoxMtrCol = (value && IsEnabledReplaceMtrCol);

        if (!value) BuildInfluenceObjList();
      }
    }
    #endregion

    #region AddMatecp
    /// <summary>
    /// 
    /// </summary>
    private bool _AddMatecp;
    public bool AddMatecp
    {
      get => _AddMatecp;
      set
      {
        SetProperty(ref _AddMatecp, value);

        if (!value) BuildInfluenceObjList();
      }
    }
    #endregion

    #region ReplaceMatecp
    /// <summary>
    /// 
    /// </summary>
    private bool _ReplaceMatecp;
    public bool ReplaceMatecp
    {
      get => _ReplaceMatecp;
      set
      {
        SetProperty(ref _ReplaceMatecp, value);

        IsEnabledComboBoxMatecp = (value && IsEnabledReplaceMatecp);

        if (!value) BuildInfluenceObjList();
      }
    }
    #endregion

    #region AddMcamtrl
    /// <summary>
    /// 
    /// </summary>
    private bool _AddMcamtrl;
    public bool AddMcamtrl
    {
      get => _AddMcamtrl;
      set
      {
        SetProperty(ref _AddMcamtrl, value);

        if (!value) BuildInfluenceObjList();
      }
    }
    #endregion

    #region ReplaceMcamtrl
    /// <summary>
    /// 
    /// </summary>
    private bool _ReplaceMcamtrl;
    public bool ReplaceMcamtrl
    {
      get => _ReplaceMcamtrl;
      set
      {
        SetProperty(ref _ReplaceMcamtrl, value);

        IsEnabledComboBoxMcamtrl = (value && IsEnabledReplaceMcamtrl);

        if (!value) BuildInfluenceObjList();
      }
    }
    #endregion

    #endregion


    #region Visibility

    #region VisibilityMtrCol
    /// <summary>
    /// 
    /// </summary>
    private Visibility _VisibilityMtrCol;
    public Visibility VisibilityMtrCol
    {
      get => _VisibilityMtrCol;
      set => SetProperty(ref _VisibilityMtrCol, value);
    }
    #endregion

    #region VisibilityMatecp
    /// <summary>
    /// 
    /// </summary>
    private Visibility _VisibilityMatecp;
    public Visibility VisibilityMatecp
    {
      get => _VisibilityMatecp;
      set => SetProperty(ref _VisibilityMatecp, value);
    }
    #endregion

    #region VisibilityMcamtrl
    /// <summary>
    /// 
    /// </summary>
    private Visibility _VisibilityMcamtrl;
    public Visibility VisibilityMcamtrl
    {
      get => _VisibilityMcamtrl;
      set => SetProperty(ref _VisibilityMcamtrl, value);
    }
    #endregion

    #region VisibilityTextureParameters
    /// <summary>
    /// 
    /// </summary>
    private Visibility _VisibilityTextureParameters;
    public Visibility VisibilityTextureParameters
    {
      get => _VisibilityTextureParameters;
      set => SetProperty(ref _VisibilityTextureParameters, value);
    }
    #endregion

    #region VisibilityAlertText
    /// <summary>
    /// 
    /// </summary>
    private Visibility _VisibilityAlertText;
    public Visibility VisibilityAlertText
    {
      get => _VisibilityAlertText;
      set => SetProperty(ref _VisibilityAlertText, value);
    }
    #endregion

    #endregion


    public ObservableCollection<int> MtlCols { get; set; }

    public ObservableCollection<int> Matecps { get; set; }

    public ObservableCollection<int> Mcamtrls { get; set; }

    #region SelectedMtlCol
    /// <summary>
    /// 
    /// </summary>
    private int _SelectedMtlCol;
    public int SelectedMtlCol
    {
      get => _SelectedMtlCol;
      set => SetProperty(ref _SelectedMtlCol, value);
    }
    #endregion

    #region SelectedMatecp
    /// <summary>
    /// 
    /// </summary>
    private int _SelectedMatecp;
    public int SelectedMatecp
    {
      get => _SelectedMatecp;
      set => SetProperty(ref _SelectedMatecp, value);
    }
    #endregion

    #region SelectedMcamtrl
    /// <summary>
    /// 
    /// </summary>
    private int _SelectedMcamtrl;
    public int SelectedMcamtrl
    {
      get => _SelectedMcamtrl;
      set => SetProperty(ref _SelectedMcamtrl, value);
    }
    #endregion

  }
}
