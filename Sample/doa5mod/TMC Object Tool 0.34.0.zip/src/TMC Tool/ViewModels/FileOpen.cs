﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Common;
using Tmc;
using TMC_Tool.Models;
using Message;

namespace TMC_Tool.ViewModels
{
  public partial class MainWindowViewModel : BindableBase
  {
    /// <summary>
    /// ドロップされたファイルを開きます
    /// </summary>
    /// <param name="paths">ファイルパスリスト</param>
    public async void OpenDorpFile(List<string> paths, bool isImport)
    {
      if (paths.Count < 1) return;

      try
      {
        List<string> tmcPaths = new List<string>();
        List<string> lnkPaths = new List<string>();
        foreach (string path in paths)
        {
          if (System.IO.Path.GetExtension(path).ToUpper() == ".TMC")
          {
            tmcPaths.Add(path);
          }
          else if (System.IO.Path.GetExtension(path).ToLower() == ".lnk")
          {
            lnkPaths.Add(path);
          }
        }

        if (lnkPaths.Count > 0)
        {
          Type t = Type.GetTypeFromCLSID(new Guid("72C24DD5-D70A-438B-8A42-98424B88AFB8"));
          dynamic shell = Activator.CreateInstance(t);
          List<string> shortcutPaths = new List<string>();
          foreach (string path in lnkPaths)
          {
            var shortcut = shell.CreateShortcut(path);
            shortcutPaths.Add(shortcut.TargetPath);
            System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shortcut);
          }
          System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shell);

          foreach (string path in shortcutPaths)
          {
            if (System.IO.Path.GetExtension(path).ToUpper() == ".TMC")
            {
              tmcPaths.Add(path);
            }
          }
        }


        if (tmcPaths.Count == 0) return;


        if (isImport)
        {
          var import = new Import(this);
          import.Do(tmcPaths[0]);
        }
        else
        {
          string appPath = System.Reflection.Assembly.GetExecutingAssembly().Location;

          if (tmcPaths.Count >= 5)
          {
            if (MessageWindow.Show(Window, tmcPaths.Count + " " + Txt.ConfirmOpenMany, Txt.Confirm, Txt.btnOpen, Txt.Cancel) == MessageWindow.Result.Cancel)
            {
              return;
            }
          }

          Open(tmcPaths[0]);

          for (int i = 1; i < tmcPaths.Count; i++)
          {
            await Task.Run(() => System.Diagnostics.Process.Start(appPath, "\"" + tmcPaths[i] + "\""));
          }
        }
      }
      catch (Exception e)
      {
        MessageWindow.Show(Window, e.Message + "\r\n\r\n" + e.StackTrace, Txt.Error);
      }
    }

    /// <summary>
    /// クリップボードのパステキストからファイルを開きます
    /// </summary>
    public void OpenFromClipboard()
    {
      var pathText = Clipboard.GetText();
      if (Clipboard.ContainsFileDropList())
      {
        //データを取得する（取得できなかった時はnull）
        System.Collections.Specialized.StringCollection files = Clipboard.GetFileDropList();
        if (files != null) pathText = files[0];
      }
      if (!string.IsNullOrEmpty(pathText) && File.Exists(pathText) && (Path.GetExtension(pathText).ToUpper() == ".TMC"))
      {
        var result = MessageWindow.Show(Window, pathText + "\r\n\r\n" + Txt.ConfirmOpenFile, Txt.Info, Txt.btnOpen, Txt.Cancel);
        if (result == MessageWindow.Result.OK)
        {
          Open(pathText);
        }
        Keyboard.Focus(Window);
      }
    }

    /// <summary>
    /// ファイルを開きます
    /// </summary>
    /// <param name="path">ファイルパス</param>
    public void Open(string path)
    {
      Window.IsEnabled = false;
      MainWindow.DoEvents();

      try
      {
        IsEnabledEditMtrCol = false;
        IsEnabledEditMatecp = false;

        IsEnableMain = false;
        IsModified = false;
        ObjGrpRebuild = false;
        TextureRebuild = false;
        Status = Txt.textStatus;

        OtherTmcDataList = new List<TmcData>();

        if (Tables.ObjData.Count > 0) Tables.ObjData.Clear();
        if (Tables.VIData.Count > 0) Tables.VIData.Clear();


        bool result = SetTmcData(path);

        if (!result) return;


        LoadTextures();

        Tables.SetData(TmcData);

        IsEnabledEditMtrCol = true;
        //if (TmcData.MateCp.Count > 0) IsEnabledEditMatecp = true;
        IsEnabledEditMatecp = true;

        Status = TmcData.Path;

        IsEnableMain = true;
      }
      catch (Exception e)
      {
        TmcData = null;
        MessageWindow.Show(Window, e.Message + "\r\n\r\n" + e.StackTrace, Txt.Error);
      }
      finally
      {
        Window.IsEnabled = true;
        Window.Activate();
        Window.Focus();

        CommandManager.InvalidateRequerySuggested();
      }
    }

    /// <summary>
    /// ファイルを開きTmcDataに設定します
    /// </summary>
    /// <param name="path">ファイルパス</param>
    /// <returns>TmcDataに設定出来たかどうか</returns>
    private bool SetTmcData(string path)
    {
      byte[] bin = null;

      // null when Revert
      if (path != null || TmcData == null || TmcData.Bin == null)
      {
        bin = File.ReadAllBytes(path);
        char[] charsToTrim = { '\0' };
        string name = Encoding.ASCII.GetString(bin, 0, 8).TrimEnd(charsToTrim);
        if (name != "TMC" && name != "tmcmesh")
        {
          Window.Activate();
          MessageWindow.Show(Window, Txt.UnsupportedFile + "\r\n" + path, Txt.Error);
          return false;
        }
        if (BitConverter.ToUInt32(bin, 8) != 0x01010000)
        {
          Window.Activate();
          MessageWindow.Show(Window, Txt.UnsupportedFile + "\r\n" + path, Txt.Error);
          return false;
        }
      }
      else
      {
        bin = TmcData.Bin;
      }

      if (path == null && TmcData != null)
      {
        path = TmcData.Path;
      }

      TmcData = ParseTmc(bin);

      if (TmcData == null) return false;


      TmcData.Path = path;
      TmcData.WriteTime = File.GetLastWriteTime(path);

      // for broken TMC
      TmcData.H.Size = bin.Length;
      if (TmcData.H.Count1 > 15 && TmcData.H.Offsets[15] != 0 && BitConverter.ToUInt32(bin, TmcData.H.Offsets[15] + 8) != 16842752)
      {
        TmcData.H.Offsets[15] = 0;
      }

      TmcData.Bin = bin;


      return true;
    }

    /// <summary>
    /// TMCデータをパースします
    /// </summary>
    /// <returns>TMCデータ</returns>
    public TmcData ParseTmc(byte[] bin)
    {
      TmcData tmcData = new TmcData(bin);

      if (tmcData == null) return null;

      tmcData.ParseObjBaseData(bin);
      tmcData.ParseTextureData(bin);
      tmcData.ParseMtrColor(bin);
      tmcData.ParseMdlInfo(bin);
      tmcData.ParseHieLayer(bin);
      tmcData.ParseBoneOffsetMatrices(bin);
      //tmcData.ParseVertexData(bin, tmcData.H.Offsets[2]);
      if (tmcData.H.Count1 > 12 && tmcData.H.Offsets[12] != 0) tmcData.ParseMCAPack(bin);
      if (tmcData.H.Count1 > 16 && tmcData.H.Offsets[16] != 0) tmcData.ParseACSCLS(bin);

      return tmcData;
    }

    /// <summary>
    /// テクスチャを読み込みます
    /// </summary>
    private void LoadTextures()
    {
      IsTmclLoaded = true;
      TmclPath = Path.ChangeExtension(TmcData.Path, ".TMCL");
      if (!File.Exists(TmclPath))
      {
        string[] separators = { " - " };
        TmclPath = Path.ChangeExtension(TmcData.Path.Split(separators, StringSplitOptions.RemoveEmptyEntries)[0], ".TMCL");

        if (!File.Exists(TmclPath))
        {
          IsTmclLoaded = false;
          TmclPath = "";
        }
      }

      if (IsTmclLoaded)
      {
        var lHeaderH = new HeaderData(TmcData.Bin, TmcData.H.Offsets[7]);
        int lOffset = BitConverter.ToInt32(TmcData.Bin, lHeaderH.Start + lHeaderH.Offset1);

        byte[] binL = System.IO.File.ReadAllBytes(TmclPath);

        BinLHeader = binL.Take(0x80).ToArray();

        foreach (var tex in TmcData.Tex)
        {
          if (tex.InL)
          {
            tex.Data = binL.Skip(lOffset + tex.Offset).Take(tex.Size).ToArray();
          }
          else
          {
            tex.Data = TmcData.Bin.Skip(TmcData.H.Offsets[1] + tex.Offset).Take(tex.Size).ToArray();
          }
        }

        SelectTextureWindow = new SelectTextureWindow(TmcData.Tex);
      }
    }

    /// <summary>
    /// 保存後に再読込します
    /// </summary>
    private void ReOpenFile(string path)
    {
      try
      {
        byte[] bin = File.ReadAllBytes(path);
        TmcData = ParseTmc(bin);

        if (TmcData == null)
        {
          throw new Exception(Txt.FailedToReopen);
        }

        OtherTmcDataList = new List<TmcData>();

        TmcData.Path = path;
        TmcData.WriteTime = File.GetLastWriteTime(path);

        LoadTextures();

        // 各種状態フラグをリセット
        Tables.TmcData = TmcData;
        int count = 0;
        int objIndex = 0;
        foreach (var grp in TmcData.ObjGrp)
        {
          Tables.ObjData[count].OriginalGrpIndex = grp.ID;
          Tables.ObjData[count].LastGrpIndex = grp.ID;
          Tables.ObjData[count].IsAdded = false;
          Tables.ObjData[count].IsBlendCleared = false;
          Tables.ObjData[count].DataIndex = -1;
          count++;
          objIndex = 0;

          foreach (var objPart in grp.Obj)
          {
            var obj = Tables.ObjData[count];
            obj.IsDeleted = false;
            obj.IsVgrpChanged = false;
            obj.IsAdded = false;
            obj.ID = (byte)objIndex;
            obj.Name = grp.Name + "_" + obj.ID.ToString("x");
            obj.OriginalObjIndex = objIndex;
            obj.OriginalGrpIndex = grp.ID;
            obj.LastGrpIndex = -1;
            obj.DataIndex = -1;
            Tables.CheckObjectType(obj);

            count++;
            objIndex++;
          }
        }

        foreach (var viData in Tables.VIData)
        {
          viData.IsChanged = false;
          viData.IsAdded = false;
          viData.OriginalIndex = viData.Index;
          viData.DataIndex = -1;

          foreach (var grp in TmcData.ObjGrp)
          {
            for (int i = 0; i < grp.Decl.Count; i++)
            {
              if (grp.Decl[i].VtxGrpIndex == viData.Index)
              {
                viData.IdxGrp = grp.Decl[i].IdxGrpIndex;
                viData.OriginalIdxGrp = grp.Decl[i].IdxGrpIndex;
                viData.OriginalDecl = i;
                break;
              }
            }
          }
        }

        if (Tables.Nodes.Count > 0) Tables.Nodes.Clear();
        Tables.SetNodes();

        if (Tables.PhysicsList.Count > 0) Tables.PhysicsList.Clear();
        if (Tables.PhysicsIndicesSet.Count > 0) Tables.PhysicsIndicesSet.Clear();
        Tables.SetPhysics();

        IsModified = false;
        ObjGrpRebuild = false;
        TextureRebuild = false;

        Status = path;
      }
      catch (Exception e)
      {
        MessageWindow.Show(Window, e.Message + "\r\n\r\n" + e.StackTrace, Txt.Error);
      }
    }
  }
}
