﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using Common;
using Tmc;
using Language;
using Message;
using TMC_Tool.Models;

namespace TMC_Tool.ViewModels
{
  public class EditMtrColWindowViewModel : BindableBase
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    public EditMtrColWindowViewModel(EditMtrColWindow window)
    {
      Window = window;
      Txt = MainWindow.Txt;
      MtrCols = new ObservableCollection<MtrColData>();
      Params = new ObservableCollection<float?>();
      for (int i = 0; i < 4 * 13; i++)
      {
        Params.Add(null);
      }

      IsEnabledAdd = true;
      IsEnabledGet = true;
    }

    public void InitParamsInput()
    {
      var labelParams = new List<Label>();
      for (int i = 0; i < 13; i++)
      {
        var label = new Label();
        label.Height = 30;
        label.Margin = new Thickness(0, 0, 0, 3);
        labelParams.Add(label);
      }

      for (int i = 0; i < ConstData.MtrlColLabels.Length; i++)
      {
        labelParams[i].Content = ConstData.MtrlColLabels[i];
      }

      foreach (var label in labelParams)
      {
        Window.panelLabel.Children.Add(label);
      }

      ParamTextBoxSet = new List<TextBox>();

      for (int i = 0; i < 13; i++)
      {
        var panel = new StackPanel();
        panel.Orientation = Orientation.Horizontal;

        for (int j = 0; j < 4; j++)
        {
          var tb = new TextBox();
          tb.Name = "tb_" + i + "_" + j;
          tb.Width = 50;
          tb.Margin = new Thickness(0, 0, 2, 3);
          tb.PreviewKeyDown += Window.tbParam_PreviewKeyDown;
          tb.KeyDown += Window.tbParam_KeyDown;
          tb.LostFocus += Window.tbParam_LostFocus;
          tb.MouseDoubleClick += Window.tb_MouseDoubleClick;

          Binding binding = new Binding("Params[" + (4 * i + j) + "]");
          tb.SetBinding(TextBox.TextProperty, binding);

          panel.Children.Add(tb);

          ParamTextBoxSet.Add(tb);
        }

        Window.panelParams.Children.Add(panel);
      }
    }

    public void SetData(MainWindowViewModel data, int index)
    {
      if (MtrCols.Count > 0) MtrCols.Clear();

      Data = data;
      Tables = data.Tables;

      foreach (var grp in data.TmcData.ColGrp)
      {
        int count = ReculcMtrColUse(grp, Tables);
        var mtrCol = new MtrColData(grp, count);
        MtrCols.Add(mtrCol);
      }

      SelectedIndex = index;
      IsEnabledOk = false;
    }

    public int ReculcMtrColUse(MtrColorGroup col, DataTables tables)
    {
      int count = 0;
      foreach (var obj in tables.ObjData)
      {
        if (obj.Grp != -1)
        {
          if (obj.MtrCol == col.ID) count++;
        }
      }
      return count;
    }

    public void ResetMtrColIndex()
    {
      int count = 0;
      foreach (var mtrCol in MtrCols)
      {
        mtrCol.Index = count;
        count++;
      }
    }

    public bool CheckGettingMtrCol(MaterialData gettingMat)
    {
      // 既に同じものがあるかチェック（置換の場合は置換先は除く）
      List<int> equalMtrCol = new List<int>();

      foreach (var mtrCol in MtrCols)
      {
        if (!gettingMat.ColAdd && mtrCol.Index == gettingMat.ColTarget) continue;
        for (int i = 0; i < mtrCol.Colors.Count; i++)
        {
          for (int j = 0; j < mtrCol.Colors[i].Length; j++)
          {
            if (mtrCol.Colors[i][j] != gettingMat.Col.Color[i][j])
            {
              goto SkipAdd;
            }
          }
        }
        equalMtrCol.Add(mtrCol.Index);

        SkipAdd:;
      }

      // 同じものがあれば追加するか確認
      if (equalMtrCol.Count > 0)
      {
        string str = Txt.ConfirmReplace;
        if (gettingMat.ColAdd) str = Txt.ConfirmAdd;

        string equalMtrColText = "   MtrCol :";
        foreach (var col in equalMtrCol)
        {
          equalMtrColText += " " + col;
        }
        var result = MessageWindow.Show(Window, Txt.SameMtrCol + equalMtrColText + "\r\n" + str, Txt.Confirm, Txt.Yes, Txt.No);
        if (result == MessageWindow.Result.Cancel)
        {
          return false;
        }
      }

      return true;
    }


    public void SelectionChanged()
    {
      if (Window.dgMtrCols.SelectedItems.Count > 0)
      {
        string listText = "";
        foreach (var obj in Tables.ObjData)
        {
          foreach (MtrColData mtrCol in Window.dgMtrCols.SelectedItems)
          {
            if (obj.MtrCol == mtrCol.OriginalIndex)
            {
              if (listText != "") listText += "\r\n";
              listText += obj.Name;
            }
          }
        }

        IsEnabledListInfluenceObj = (listText != "");

        ListInfluenceObj = listText;


        if (Window.dgMtrCols.SelectedItems.Count == 1)
        {
          IsEnabledParams = true;

          var mtrCol = MtrCols[SelectedIndex];

          //値をセットする
          for (int i = 0; i < mtrCol.Colors.Count; i++)
          {
            for (int j = 0; j < mtrCol.Colors[i].Length; j++)
            {
              Params[4 *i + j] = mtrCol.Colors[i][j];
            }
          }

          IsEnabledDelete = (mtrCol.Use == 0);
        }
      }

      if (Window.dgMtrCols.SelectedItems.Count != 1)
      {
        IsEnabledParams = false;

        for (int i = 0; i < 4 * 13; i++)
        {
          Params[i] = null;
        }
      }
    }

    public bool ParamPreviewKeyDown(Key key, TextBox textBox)
    {
      if (key != Key.Enter && key != Key.Down && key != Key.Up && key != Key.Right && key != Key.Left) return false;


      var n = textBox.Name.Split('_');
      int row = Int32.Parse(n[1]);
      int col = Int32.Parse(n[2]);

      if (key == Key.Up)
      {
        if (row < 1) return true;
        row--;
      }
      else if (key == Key.Down)
      {
        if (row > 11) return true;
        row++;
      }
      else if (key == Key.Left)
      {
        if (textBox != null && (textBox.SelectionStart != 0 || textBox.SelectionLength != 0))
        {
          return false;
        }
        if (col < 1) return true;
        col--;
      }
      else if (key == Key.Right)
      {
        if (textBox != null && textBox.Text != "" && (textBox.SelectionStart != textBox.Text.Length || textBox.SelectionLength != 0))
        {
          return false;
        }
        if (col > 2) return true;
        col++;
      }
      else if (key == Key.Enter)
      {
        if (row > 11 && col > 2) return true;

        if (col < 3)
        {
          col++;
        }
        else if (row < 12)
        {
          row++;
          col = 0;
        }
      }

      ParamTextBoxSet[4 * row + col].Focus();
      ParamTextBoxSet[4 * row + col].SelectAll();


      return true;
    }

    public bool ParamKeyDown(Key key, TextBox textBox)
    {
      IsEnabledOk = true;

      return RestrictionKey.PositiveNum(key, textBox);
    }

    public void ParamLostFocus(TextBox textBox)
    {
      var n = textBox.Name.Split('_');
      int row = Int32.Parse(n[1]);
      int col = Int32.Parse(n[2]);

      MtrCols[SelectedIndex].Colors[row][col] = Single.Parse(textBox.Text);
    }


    public void Add()
    {
      var newMtrCol = new MtrColData(null, 0);
      newMtrCol.Index = MtrCols.Count;
      newMtrCol.OriginalIndex = -1;

      if (Window.dgMtrCols.SelectedItems.Count == 1)
      {
        foreach (var color in MtrCols[SelectedIndex].Colors)
        {
          newMtrCol.Colors.Add(color);
        }
      }
      else
      {
        //初期化カラーを設定
        newMtrCol.Colors.Add(new float[] { 0.3f, 0.3f, 0.3f, 1 });
        newMtrCol.Colors.Add(new float[] { 1, 1, 1, 1 });
        newMtrCol.Colors.Add(new float[] { 1, 1, 1, 0 });
        newMtrCol.Colors.Add(new float[] { 0, 0, 0, 1 });
        newMtrCol.Colors.Add(new float[] { 1, 1, 1, 1 });
        newMtrCol.Colors.Add(new float[] { 1, 1, 1, 1 });
        newMtrCol.Colors.Add(new float[] { 0, 0, 0, 0 });
        newMtrCol.Colors.Add(new float[] { 0, 0, 0, 0 });
        newMtrCol.Colors.Add(new float[] { 0, 0, 0, 1 });
        newMtrCol.Colors.Add(new float[] { 1, 1, 1, 1 });
        newMtrCol.Colors.Add(new float[] { 1, 1, 1, 0 });
        newMtrCol.Colors.Add(new float[] { 1, 1, 0.3f, 1 });
        newMtrCol.Colors.Add(new float[] { 0, 0, 0, 0 });
      }

      MtrCols.Add(newMtrCol);

      SelectedIndex = MtrCols.Count - 1;
      Window.dgMtrCols.ScrollIntoView(Window.dgMtrCols.Items[SelectedIndex]);

      IsEnabledOk = true;
    }

    public void Get()
    {
      int selIndex = -1;
      if (Window.dgMtrCols.SelectedItems.Count == 1) selIndex = SelectedIndex;


      var mat = new GetMaterials(Data);
      mat.GetData(MtrCols.ToList(), selIndex);
      MaterialData gettingMat = mat.Material;

      if (gettingMat == null || gettingMat.Col == null) return;

      bool result = CheckGettingMtrCol(gettingMat);
      if (!result) return;


      Window.Owner.IsEnabled = false;

      if (gettingMat.ColAdd)
      {
        gettingMat.Col.ID = MtrCols.Count;

        var newMtrCol = new MtrColData(gettingMat.Col, 0);
        newMtrCol.OriginalIndex = -1;
        MtrCols.Add(newMtrCol);

        SelectedIndex = MtrCols.Count - 1;

        Window.dgMtrCols.ScrollIntoView(Window.dgMtrCols.Items[SelectedIndex]);
      }
      else
      {
        MtrCols[gettingMat.ColTarget].Colors.Clear();

        foreach (var col in gettingMat.Col.Color)
        {
          MtrCols[gettingMat.ColTarget].Colors.Add(col);
        }

        if (selIndex != -1)
        {
          SelectedIndex = -1;
          SelectedIndex = selIndex;
        }
      }

      IsEnabledOk = true;
    }

    public void Delete()
    {
      List<int> selectedIndices = new List<int>();

      foreach (MtrColData mtrCol in Window.dgMtrCols.SelectedItems)
      {
        if (mtrCol.Use == 0) selectedIndices.Add(mtrCol.Index);
      }

      selectedIndices.Sort();
      selectedIndices.Reverse();

      foreach (var index in selectedIndices)
      {
        MtrCols.RemoveAt(index);
      }

      ResetMtrColIndex();

      IsEnabledOk = true;
    }


    #region コマンド：追加
    /// <summary>
    /// コマンド：追加
    /// </summary>
    private DelegateCommand _AddCommand;
    public DelegateCommand AddCommand
      => _AddCommand ?? (_AddCommand = new DelegateCommand(AddCommandExecute, CanAddExecute));

    /// <summary>
    /// コマンド：追加 の実行を行います。
    /// </summary>
    private void AddCommandExecute()
    {
      Add();
    }

    /// <summary>
    /// コマンド：追加 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanAddExecute()
    {
      if (IsEnabledAdd)
        return true;
      else
        return false;
    }
    #endregion

    #region コマンド：取得
    /// <summary>
    /// コマンド：取得
    /// </summary>
    private DelegateCommand _GetCommand;
    public DelegateCommand GetCommand
      => _GetCommand ?? (_GetCommand = new DelegateCommand(GetCommandExecute, CanGetExecute));

    /// <summary>
    /// コマンド：取得 の実行を行います。
    /// </summary>
    private void GetCommandExecute()
    {
      Get();
    }

    /// <summary>
    /// コマンド：取得 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanGetExecute()
    {
      if (IsEnabledGet)
        return true;
      else
        return false;
    }
    #endregion

    #region コマンド：削除
    /// <summary>
    /// コマンド：削除
    /// </summary>
    private DelegateCommand _DeleteCommand;
    public DelegateCommand DeleteCommand
      => _DeleteCommand ?? (_DeleteCommand = new DelegateCommand(DeleteCommandExecute, CanDeleteExecute));

    /// <summary>
    /// コマンド：削除 の実行を行います。
    /// </summary>
    private void DeleteCommandExecute()
    {
      Delete();
    }

    /// <summary>
    /// コマンド：削除 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanDeleteExecute()
    {
      if (IsEnabledDelete)
        return true;
      else
        return false;
    }
    #endregion



    public EditMtrColWindow Window { get; set; }

    public MainWindowViewModel Data { get; set; }

    private static Lang.Text Txt;

    /// <summary>
    /// 表のデータ
    /// </summary>
    private static DataTables Tables;

    #region IsEnabledOk
    /// <summary>
    /// OKボタンの状態
    /// </summary>
    private bool _IsEnabledOk;
    public bool IsEnabledOk
    {
      get => _IsEnabledOk;
      set => SetProperty(ref _IsEnabledOk, value);
    }
    #endregion

    #region IsEnabledParams
    /// <summary>
    /// パラメータ群の状態
    /// </summary>
    private bool _IsEnabledParams;
    public bool IsEnabledParams
    {
      get => _IsEnabledParams;
      set => SetProperty(ref _IsEnabledParams, value);
    }
    #endregion


    /// <summary>
    /// 
    /// </summary>
    public ObservableCollection<MtrColData> MtrCols { get; set; }

    /// <summary>
    /// 
    /// </summary>
    public ObservableCollection<float?> Params { get; set; }

    private static List<TextBox> ParamTextBoxSet;


    #region SelectedIndex
    /// <summary>
    /// 
    /// </summary>
    private int _SelectedIndex;
    public int SelectedIndex
    {
      get => _SelectedIndex;
      set => SetProperty(ref _SelectedIndex, value);
    }
    #endregion

    public bool IsEnabledAdd { get; set; }

    public bool IsEnabledGet { get; set; }

    public bool IsEnabledDelete { get; set; }


    #region ListInfluenceObj
    /// <summary>
    /// 
    /// </summary>
    private string _ListInfluenceObj;
    public string ListInfluenceObj
    {
      get => _ListInfluenceObj;
      set => SetProperty(ref _ListInfluenceObj, value);
    }
    #endregion

    #region IsEnabledListInfluenceObj
    /// <summary>
    /// OKボタンの状態
    /// </summary>
    private bool _IsEnabledListInfluenceObj;
    public bool IsEnabledListInfluenceObj
    {
      get => _IsEnabledListInfluenceObj;
      set => SetProperty(ref _IsEnabledListInfluenceObj, value);
    }
    #endregion
  }

}
