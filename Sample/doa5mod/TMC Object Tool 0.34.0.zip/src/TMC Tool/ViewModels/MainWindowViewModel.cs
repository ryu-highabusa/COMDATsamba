﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using Common;
using Tmc;
using TMC_Tool.Models;
using Language;
using Message;

namespace TMC_Tool.ViewModels
{
  public partial class MainWindowViewModel : BindableBase
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    public MainWindowViewModel(MainWindow window)
    {
      Window = window;

      Txt = MainWindow.Txt;

      Tables = new DataTables();

      Edit = new Edit(this);

      SetWindowTitle();

      storyFadeTextMessage = (Storyboard)Window.FindResource("fadeTextMessage");

      GetMatWindow = new GetMaterialWindow();
      EditMtrColWindow = new EditMtrColWindow();
      EditMatecpWindow = new EditMatecpWindow();
      EditTexParamWindow = new EditTexParamWindow(this);
      ExtractMeshWindow = new ExtractMeshWindow();


      // プロパティ初期化
      Status = Txt.textStatus;

      AlertBg = new SolidColorBrush(Color.FromRgb(0xFF, 0x55, 0x55));

      IsEnableCreateBackup = true;
    }


    /// <summary>
    /// Windowのタイトルをセットします
    /// </summary>
    private void SetWindowTitle()
    {
      System.Reflection.Assembly thisAssem = System.Reflection.Assembly.GetExecutingAssembly();
      System.Version ver = thisAssem.GetName().Version;
      WindowTitle = thisAssem.GetName().Name + " " + ver.Major + "." + ver.Minor + "." + ver.Build;
    }

    /// <summary>
    /// ファイルが変更された場合の処理
    /// </summary>
    public void Modified()
    {
      if (!IsModified)
      {
        IsModified = true;
        Status = TmcData.Path + "*";
      }
    }

    /// <summary>
    /// オブジェクトの順番を入れ替えます
    /// </summary>
    private void SwapObjectOrder(bool down)
    {
      var obj = Window.dgObject.SelectedItem as ObjectData;

      Tables.ObjData.Remove(obj);
      if (down)
        Tables.ObjData.Insert(obj.Index + 1, obj);
      else
        Tables.ObjData.Insert(obj.Index - 1, obj);

      int index = obj.Index;
      int id = obj.ID;
      string name = obj.Name;

      var changed = Tables.ObjData[obj.Index];

      obj.Index = changed.Index;
      obj.ID = changed.ID;
      obj.Name = changed.Name;

      changed.Index = index;
      changed.ID = id;
      changed.Name = name;

      obj.IsVgrpChanged = true;

      Window.dgObject.SelectedItem = obj;

      Modified();
    }


    
    #region メソッド：編集

    /// <summary>
    /// MtrColを編集
    /// </summary>
    private void EditMtrCol()
    {
      int selIndex = -1;
      if (Window.dgObject.SelectedItems.Count == 1)
      {
        var item = Window.dgObject.SelectedItem as ObjectData;
        if (item.Grp != -1) selIndex = (int)item.MtrCol;
      }

      int colCount = TmcData.ColGrp.Count;
      int[] replaceIndices = Enumerable.Repeat<int>(-1, colCount).ToArray();

      var data = EditMtrColWindow.Show(Window, this, selIndex);
      if (data == null) return;

      // TmcData.ColGrpを追加
      foreach (var mtrCol in data.MtrCols)
      {
        var newColGrp = new MtrColorGroup(null, 0, 0);
        newColGrp.ID = mtrCol.Index;
        foreach (var color in mtrCol.Colors)
        {
          newColGrp.Color.Add(color);
        }

        if (mtrCol.OriginalIndex != -1)
        {
          newColGrp.Offset = TmcData.ColGrp[mtrCol.OriginalIndex].Offset;
          newColGrp.Start = TmcData.ColGrp[mtrCol.OriginalIndex].Start;
          replaceIndices[mtrCol.OriginalIndex] = mtrCol.Index;
        }
        TmcData.ColGrp.Add(newColGrp);
      }
      // 既存のColGrpを削除
      for (int i = 0; i < colCount; i++)
      {
        TmcData.ColGrp.RemoveAt(0);
      }

      // プルダウン再設定 増加時
      if (data.MtrCols.Count > colCount)
      {
        int remaining = data.MtrCols.Count - colCount;
        while (remaining > 0)
        {
          Tables.MtlCols.Add(Tables.MtlCols.Count);
          remaining--;
        }
      }

      // 各オブジェクトのMColを差し替え
      foreach (var obj in Tables.ObjData)
      {
        if (obj.Grp == -1) continue;

        if (obj.MtrCol == colCount)
        {
          obj.MtrCol = data.MtrCols.Count;
        }
        else
        {
          obj.MtrCol = replaceIndices[(int)obj.MtrCol];
        }
      }

      // プルダウン再設定 減少時
      if (data.MtrCols.Count < colCount)
      {
        int remaining = colCount - data.MtrCols.Count;
        while (remaining > 0)
        {
          Tables.MtlCols.RemoveAt(Tables.MtlCols.Count - 1);
          remaining--;
        }
      }

      Modified();
    }

    /// <summary>
    /// matecpを編集
    /// </summary>
    private void EditMatecp()
    {
      int selIndex = -1;
      if (Window.dgObject.SelectedItems.Count == 1)
      {
        var item = Window.dgObject.SelectedItem as ObjectData;
        if (item.Matecp != null && item.Matecp != TmcData.MateCp.Count) selIndex = (int)item.Matecp;
      }

      int cpCount = TmcData.MateCp.Count;
      int[] replaceIndices = Enumerable.Repeat<int>(-1, cpCount).ToArray();

      var data = EditMatecpWindow.Show(Window, this, selIndex);
      if (data == null) return;

      // TmcData.MateCpを追加
      foreach (var customp in data.Customps)
      {
        var newMateCp = new Customp(null, 0, 0);
        newMateCp.Index = customp.Index;
        foreach (var cp in customp.cp)
        {
          newMateCp.Cp.Add(cp);
        }

        if (customp.OriginalIndex != -1)
        {
          newMateCp.Offset = TmcData.MateCp[customp.OriginalIndex].Offset;
          newMateCp.Start = TmcData.MateCp[customp.OriginalIndex].Start;
          newMateCp.Size = TmcData.MateCp[customp.OriginalIndex].Size;
          replaceIndices[customp.OriginalIndex] = customp.Index;
        }
        TmcData.MateCp.Add(newMateCp);
      }
      // 既存のmatecpを削除
      for (int i = 0; i < cpCount; i++)
      {
        TmcData.MateCp.RemoveAt(0);
      }

      // プルダウン再設定 増加時
      if (data.Customps.Count > cpCount)
      {
        int remaining = data.Customps.Count - cpCount;
        while (remaining > 0)
        {
          Tables.Matecps.Add(Tables.Matecps.Count);
          remaining--;
        }
      }

      // 各オブジェクトのmtcpを差し替え
      foreach (var obj in Tables.ObjData)
      {
        if (obj.Grp == -1) continue;

        if (obj.Matecp == null || obj.Matecp == cpCount)
        {
          if (data.Customps.Count == 0)
            obj.Matecp = null;
          else
            obj.Matecp = data.Customps.Count;
        }
        else
        {
          obj.Matecp = replaceIndices[(int)obj.Matecp];
        }

        Tables.CheckObjectType(obj);
      }

      // プルダウン再設定 減少時
      if (data.Customps.Count < cpCount)
      {
        int remaining = cpCount - data.Customps.Count;
        while (remaining > 0)
        {
          Tables.Matecps.RemoveAt(Tables.Matecps.Count - 1);
          remaining--;
        }
      }

      Modified();
    }

    /// <summary>
    /// テクスチャパラメータを編集
    /// </summary>
    private void EditTexParam()
    {
      if (EditTexParamWindow.Visibility != Visibility.Visible)
      {
        if (Window.dgObject.SelectedItems.Count == 1)
        {
          var obj = Window.dgObject.SelectedItem as ObjectData;
          EditTexParamWindow.Show(Window, obj);
        }
        else
        {
          EditTexParamWindow.Show(Window, null);
        }
      }
      else
        EditTexParamWindow.Hide();
    }

    #endregion



    /// <summary>
    /// 
    /// </summary>
    public void CheckEnableTransparent(List<ObjectData> objects)
    {
      string objListText = "";
      var objList = new List<ObjectData>();

      foreach (var obj in objects)
      {
        if (obj.Matecp != null && obj.Matecp < TmcData.MateCp.Count)
        {
          if (Array.FindIndex(TmcData.MateCp[(int)obj.Matecp].Cp.ToArray(), cp => cp.Data1 == 0xEB53FEEF) != -1 ||
            Array.FindIndex(TmcData.MateCp[(int)obj.Matecp].Cp.ToArray(), cp => cp.Data1 == 0x60121B1E) != -1)
          {
            objList.Add(obj);
            objListText += "\r\n" + obj.Name;
          }
        }
      }

      if (objList.Count == 0) return;

      if (MessageWindow.Show(Window, Txt.ConfirmUnableTransparent + "\r\n" + objListText, Txt.Confirm, Txt.Yes, Txt.No) == MessageWindow.Result.Cancel)
      {
        foreach (var obj in objList)
        {
          obj.Transparent = 0;
        }
      }
    }

    /// <summary>
    /// 
    /// </summary>
    public void SetVIDataChanged(string p, VtxIdxGrpData item, bool isChecked)
    {
      if (p == "Normal" && isChecked)
      {
        item.NormalType = "Float3";
      }
      else if (p == "BWeights")
      {
        item.BIndices = item.BWeights;
        if (isChecked)
        {
          item.BWeightsType = "Dec4";
          item.BIndicesType = "Byte4";
        }
      }
      else if (p == "BIndices")
      {
        item.BWeights = item.BIndices;
        if (isChecked)
        {
          item.BWeightsType = "Dec4";
          item.BIndicesType = "Byte4";
        }
      }
      else if (p == "Tangent" && isChecked)
      {
        item.TangentType = "Float4";
      }

      item.ReCalcDataSize();
    }



    /// <summary>
    /// オブジェクトDataGridのメニューの状態を変更
    /// </summary>
    /// <param name="dataGrid">DataGridオブジェクト</param>
    public void CheckMenuStateObject(DataGrid dataGrid)
    {
      bool isSelectedGroupOnly = true;
      foreach (ObjectData obj in dataGrid.SelectedItems)
      {
        if (obj.Grp != -1)
        {
          isSelectedGroupOnly = false;
          break;
        }
      }

      if (isSelectedGroupOnly)
      {
        // オブジェクトグループ用メニューを表示
        VisibilityMenuObjGrp = Visibility.Visible;

        // オブジェクト用メニューを非表示
        VisibilityMenuObj = Visibility.Collapsed;


        MainWindow.DoEvents();


        Edit.CommandStateObjectGroup(dataGrid);
      }
      else
      {
        // オブジェクトグループ用メニューを非表示
        VisibilityMenuObjGrp = Visibility.Collapsed;

        // オブジェクト用メニューを表示
        VisibilityMenuObj = Visibility.Visible;


        Edit.CommandStateObject(dataGrid);
      }
    }




    /// <summary>
    /// ファイルが更新されているかを確認して読み込み直すかそのままにするかを選択します
    /// </summary>
    public void CheckUpdated()
    {
      try
      {
        if (TmcData == null || !File.Exists(TmcData.Path)) return;

        var lastWriteTimeTmc = File.GetLastWriteTime(TmcData.Path);
        if (TmcData.WriteTime.CompareTo(lastWriteTimeTmc) != 0)
        {
          if (MessageWindow.Show(Window, Txt.ConfirmFileUpdated + "\r\n\r\n" + TmcData.Path, Txt.Confirm, Txt.Yes, Txt.No) == MessageWindow.Result.OK)
          {
            Open(TmcData.Path);
          }
          else
          {
            TmcData.WriteTime = lastWriteTimeTmc;
          }
        }
      }
      catch (Exception e)
      {
        MessageWindow.Show(Window, e.Message + "\r\n\r\n" + e.StackTrace, Txt.Error);
      }
    }





    public MainWindow Window { get; set; }

    public static Lang.Text Txt;

    public Brush AlertBg;

    /// <summary>
    /// TMCLのヘッダ部分のバイナリ
    /// </summary>
    public byte[] BinLHeader { get; set; }

    /// <summary>
    /// TMCデータ
    /// </summary>
    public TmcData TmcData { get; set; }

    /// <summary>
    /// TMCLファイルパス
    /// </summary>
    public string TmclPath { get; set; }

    /// <summary>
    /// インポートしたファイルパスのリスト
    /// </summary>
    public List<string> ImportedPaths { get; set; } = new List<string>();

    /// <summary>
    /// インポートしたTMCデータのリスト
    /// </summary>
    public List<TmcData> OtherTmcDataList;


    #region Window

    /// <summary>
    /// GetMaterialWindow
    /// </summary>
    public GetMaterialWindow GetMatWindow { get; set; }

    /// <summary>
    /// EditMtrColWindow
    /// </summary>
    public EditMtrColWindow EditMtrColWindow { get; set; }

    /// <summary>
    /// EditMatecpWindow
    /// </summary>
    public EditMatecpWindow EditMatecpWindow { get; set; }

    /// <summary>
    /// SelectTextureWindow
    /// </summary>
    public SelectTextureWindow SelectTextureWindow { get; set; }

    /// <summary>
    /// EditTexParamWindow
    /// </summary>
    public EditTexParamWindow EditTexParamWindow { get; set; }

    /// <summary>
    /// ExtractMeshWindow
    /// </summary>
    public ExtractMeshWindow ExtractMeshWindow { get; set; }

    #endregion


    #region WindowTitle
    /// <summary>
    /// Windowタイトル
    /// </summary>
    private string _WindowTitle;
    public string WindowTitle
    {
      get => _WindowTitle;
      set => SetProperty(ref _WindowTitle, value);
    }
    #endregion

    #region Status
    /// <summary>
    /// ステータスバーのテキスト
    /// </summary>
    private string _Status;
    public string Status
    {
      get => _Status;
      set => SetProperty(ref _Status, value);
    }
    #endregion

    #region IsModified
    /// <summary>
    /// ファイルが更新されているかどうか
    /// </summary>
    private bool _IsModified;
    public bool IsModified
    {
      get => _IsModified;
      set => SetProperty(ref _IsModified, value);
    }
    #endregion

    #region IsTmclLoaded
    /// <summary>
    /// TMCLファイルがロードされているかどうか
    /// </summary>
    private bool _IsTmclLoaded;
    public bool IsTmclLoaded
    {
      get => _IsTmclLoaded;
      set => SetProperty(ref _IsTmclLoaded, value);
    }
    #endregion

    #region ObjGrpRebuild
    /// <summary>
    /// オブジェクトグループを再構築するかどうか
    /// </summary>
    private bool _ObjGrpRebuild;
    public bool ObjGrpRebuild
    {
      get => _ObjGrpRebuild;
      set => SetProperty(ref _ObjGrpRebuild, value);
    }
    #endregion

    #region TextureRebuild
    /// <summary>
    /// テクスチャを再構築するかどうか
    /// </summary>
    private bool _TextureRebuild;
    public bool TextureRebuild
    {
      get => _TextureRebuild;
      set => SetProperty(ref _TextureRebuild, value);
    }
    #endregion


    #region Tables
    /// <summary>
    /// 表のデータ
    /// </summary>
    private DataTables _Tables;
    public DataTables Tables
    {
      get => _Tables;
      set => SetProperty(ref _Tables, value);
    }
    #endregion


    #region IsEnableMain
    /// <summary>
    /// メイン部分が有効かどうか
    /// </summary>
    private bool _IsEnableMain;
    public bool IsEnableMain
    {
      get => _IsEnableMain;
      set => SetProperty(ref _IsEnableMain, value);
    }
    #endregion

    #region IsEnableCreateBackup
    /// <summary>
    /// 上書き保存（バックアップを作成）を有効にできるかどうか
    /// </summary>
    public bool IsEnableCreateBackup { get; set; }
    #endregion

    #region IsEnableExtract
    /// <summary>
    /// 抽出を有効にできるかどうか
    /// </summary>
    private bool _IsEnableExtract;
    public bool IsEnableExtract
    {
      get => _IsEnableExtract;
      set => SetProperty(ref _IsEnableExtract, value);
    }
    #endregion

    #region IsKeepData
    /// <summary>
    /// 保存しても元のデータの値を保持して再試行可能にするが有効かどうか
    /// </summary>
    private bool _IsKeepData;
    public bool IsKeepData
    {
      get => _IsKeepData;
      set => SetProperty(ref _IsKeepData, value);
    }
    #endregion
        
    #region IsEnabledEditMtrCol
    /// <summary>
    /// MtrColの編集が可能かどうか
    /// </summary>
    private bool _IsEnabledEditMtrCol;
    public bool IsEnabledEditMtrCol
    {
      get => _IsEnabledEditMtrCol;
      set => SetProperty(ref _IsEnabledEditMtrCol, value);
    }
    #endregion

    #region IsEnabledEditMatecp
    /// <summary>
    /// matecpの編集が可能かどうか
    /// </summary>
    private bool _IsEnabledEditMatecp;
    public bool IsEnabledEditMatecp
    {
      get => _IsEnabledEditMatecp;
      set => SetProperty(ref _IsEnabledEditMatecp, value);
    }
    #endregion


    #region VisibilityMenuObjGrp
    /// <summary>
    /// オブジェクトグループのコンテキストメニューの表示状態
    /// </summary>
    private Visibility _VisibilityMenuObjGrp;
    public Visibility VisibilityMenuObjGrp
    {
      get => _VisibilityMenuObjGrp;
      set => SetProperty(ref _VisibilityMenuObjGrp, value);
    }
    #endregion

    #region VisibilityMenuObj
    /// <summary>
    /// オブジェクトのコンテキストメニューの表示状態
    /// </summary>
    private Visibility _VisibilityMenuObj;
    public Visibility VisibilityMenuObj
    {
      get => _VisibilityMenuObj;
      set => SetProperty(ref _VisibilityMenuObj, value);
    }
    #endregion


    #region Edit
    /// <summary>
    /// 編集
    /// </summary>
    private Edit _Edit;
    public Edit Edit
    {
      get => _Edit;
      set => SetProperty(ref _Edit, value);
    }
    #endregion





    #region コマンド：開く
    /// <summary>
    /// コマンド：開く
    /// </summary>
    private DelegateCommand _OpenCommand;
    public DelegateCommand OpenCommand
      => _OpenCommand ?? (_OpenCommand = new DelegateCommand(OpenExecute, () => true));

    /// <summary>
    /// コマンド：開く の実行を行います。
    /// </summary>
    public void OpenExecute()
    {
      Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
      dlg.Filter = "TMC Files (.TMC)|*.TMC";
      if (TmcData != null && String.IsNullOrEmpty(TmcData.Path))
      {
        dlg.InitialDirectory = Path.GetDirectoryName(TmcData.Path);
        dlg.FileName = Path.GetFileName(TmcData.Path);
      }
      if (dlg.ShowDialog() == true)
      {
        Open(dlg.FileName);
      }
    }
    #endregion

    #region コマンド：復帰
    /// <summary>
    /// コマンド：復帰
    /// </summary>
    private DelegateCommand _RevertCommand;
    public DelegateCommand RevertCommand
      => _RevertCommand ?? (_RevertCommand = new DelegateCommand(RevertExecute, CanRevertExecute));

    /// <summary>
    /// コマンド：復帰 の実行を行います。
    /// </summary>
    private void RevertExecute()
    {
      Open(TmcData.Path);
    }

    /// <summary>
    /// コマンド：復帰 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanRevertExecute()
    {
      if (TmcData != null && File.Exists(TmcData.Path) && IsModified)
        return true;
      else
        return false;
    }
    #endregion

    #region コマンド：上書き保存
    /// <summary>
    /// コマンド：上書き保存
    /// </summary>
    private DelegateCommand _SaveCommand;
    public DelegateCommand SaveCommand
      => _SaveCommand ?? (_SaveCommand = new DelegateCommand(SaveExecute, CanSaveExecute));

    /// <summary>
    /// コマンド：上書き保存 の実行を行います。
    /// </summary>
    public void SaveExecute()
    {
      var result = MessageWindow.Show(Window, Txt.Overwrite, Txt.Confirm, Txt.OverwriteYes, Txt.Cancel);
      if (result == MessageWindow.Result.OK)
      {
        Save(TmcData.Path);
      }
    }

    /// <summary>
    /// コマンド：上書き保存 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    public bool CanSaveExecute()
    {
      if (IsModified)
        return true;
      else
        return false;
    }
    #endregion

    #region コマンド：上書き保存（バックアップを作成）
    /// <summary>
    /// コマンド：上書き保存（バックアップを作成）
    /// </summary>
    private DelegateCommand _SaveWithBackupCommand;
    public DelegateCommand SaveWithBackupCommand
      => _SaveWithBackupCommand ?? (_SaveWithBackupCommand = new DelegateCommand(SaveWithBackupExecute, CanSaveWithBackupExecute));

    /// <summary>
    /// コマンド：上書き保存（バックアップを作成） の実行を行います。
    /// </summary>
    public void SaveWithBackupExecute()
    {
      string[] paths = CreateBackup();
      if (paths != null)
      {
        if (!Save(TmcData.Path))
        {
          if (File.Exists(paths[0])) File.Move(paths[0], TmcData.Path);
          if (TextureRebuild)
          {
            if (File.Exists(paths[1])) File.Move(paths[1], TmcData.Path);
          }
        }
      }
      else
      {
        MessageWindow.Show(Window, Txt.FailedToCreateBackup, Txt.Error);
      }
    }

    /// <summary>
    /// コマンド：上書き保存（バックアップを作成） が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    public bool CanSaveWithBackupExecute()
    {
      if (IsModified && IsEnableCreateBackup)
        return true;
      else
        return false;
    }
    #endregion

    #region コマンド：別名で保存
    /// <summary>
    /// コマンド：別名で保存
    /// </summary>
    private DelegateCommand _SaveAsCommand;
    public DelegateCommand SaveAsCommand
      => _SaveAsCommand ?? (_SaveAsCommand = new DelegateCommand(SaveAsExecute, CanSaveAsExecute));

    /// <summary>
    /// コマンド：別名で保存 の実行を行います。
    /// </summary>
    public void SaveAsExecute()
    {
      Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
      dlg.InitialDirectory = Path.GetDirectoryName(TmcData.Path);
      dlg.FileName = Path.GetFileName(TmcData.Path);
      dlg.Filter = "TMC Files (.TMC)|*.TMC";

      if (dlg.ShowDialog() == true)
      {
        Save(dlg.FileName);
      }
    }

    /// <summary>
    /// コマンド：別名で保存 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    public bool CanSaveAsExecute()
    {
      if (TmcData != null)
        return true;
      else
        return false;
    }
    #endregion


    #region コマンド：インポート
    /// <summary>
    /// コマンド：インポート
    /// </summary>
    private DelegateCommand _ImportCommand;
    public DelegateCommand ImportCommand
      => _ImportCommand ?? (_ImportCommand = new DelegateCommand(ImportCommandExecute, CanImportExecute));

    /// <summary>
    /// コマンド：インポート の実行を行います。
    /// </summary>
    private void ImportCommandExecute()
    {
      Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
      dlg.Filter = "TMC Files (.TMC)|*.TMC";
      if (ImportedPaths.Count != 0)
      {
        dlg.InitialDirectory = Path.GetDirectoryName(ImportedPaths.Last());
        dlg.FileName = Path.GetFileName(ImportedPaths.Last());
      }
      else if (TmcData.Path != "")
      {
        dlg.InitialDirectory = Path.GetDirectoryName(TmcData.Path);
        dlg.FileName = Path.GetFileName(TmcData.Path);
      }
      if (dlg.ShowDialog() == true)
      {
        var import = new Import(this);
        import.Do(dlg.FileName);
      }
    }

    /// <summary>
    /// コマンド：インポート が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanImportExecute()
    {
      if (TmcData != null && IsTmclLoaded)
        return true;
      else
        return false;
    }
    #endregion


    #region コマンド：MtrColを編集
    /// <summary>
    /// コマンド：MtrColを編集
    /// </summary>
    private DelegateCommand _EditMtrColCommand;
    public DelegateCommand EditMtrColCommand
      => _EditMtrColCommand ?? (_EditMtrColCommand = new DelegateCommand(EditMtrColCommandExecute, CanEditMtrColExecute));

    /// <summary>
    /// コマンド：MtrColを編集 の実行を行います。
    /// </summary>
    private void EditMtrColCommandExecute()
    {
      EditMtrCol();
    }

    /// <summary>
    /// コマンド：MtrColを編集 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanEditMtrColExecute()
    {
      if (IsEnabledEditMtrCol)
        return true;
      else
        return false;
    }
    #endregion

    #region コマンド：matecpを編集
    /// <summary>
    /// コマンド：matecpを編集
    /// </summary>
    private DelegateCommand _EditMatecpCommand;
    public DelegateCommand EditMatecpCommand
      => _EditMatecpCommand ?? (_EditMatecpCommand = new DelegateCommand(EditMatecpCommandExecute, CanEditMatecpExecute));

    /// <summary>
    /// コマンド：matecpを編集 の実行を行います。
    /// </summary>
    private void EditMatecpCommandExecute()
    {
      EditMatecp();
    }

    /// <summary>
    /// コマンド：matecpを編集 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanEditMatecpExecute()
    {
      if (IsEnabledEditMatecp)
        return true;
      else
        return false;
    }
    #endregion

    #region コマンド：テクスチャパラメータを編集
    /// <summary>
    /// コマンド：テクスチャパラメータを編集
    /// </summary>
    private DelegateCommand _EditTexParamCommand;
    public DelegateCommand EditTexParamCommand
      => _EditTexParamCommand ?? (_EditTexParamCommand = new DelegateCommand(EditTexParamCommandExecute, () => true));

    /// <summary>
    /// コマンド：テクスチャパラメータを編集 の実行を行います。
    /// </summary>
    private void EditTexParamCommandExecute()
    {
      EditTexParam();
    }
    #endregion


    #region コマンド：オブジェクトを上に移動
    /// <summary>
    /// コマンド：オブジェクトを上に移動
    /// </summary>
    private DelegateCommand _ObjectMoveUpCommand;
    public DelegateCommand ObjectMoveUpCommand
      => _ObjectMoveUpCommand ?? (_ObjectMoveUpCommand = new DelegateCommand(ObjectMoveUpCommandExecute, CanObjectMoveUpExecute));

    /// <summary>
    /// コマンド：オブジェクトを上に移動 の実行を行います。
    /// </summary>
    private void ObjectMoveUpCommandExecute()
    {
      SwapObjectOrder(false);
    }

    /// <summary>
    /// コマンド：オブジェクトを上に移動 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanObjectMoveUpExecute()
    {
      if (TmcData != null && Window.dgObject.SelectedItems.Count == 1)
      {
        var obj = Window.dgObject.SelectedItem as ObjectData;

        if (obj == null || obj.Grp == -1 || obj.VtxCount > 0 || obj.IdxCount > 0 || obj.ID < 1)
          return false;
        else
          return true;
      }
      else
        return false;
    }
    #endregion

    #region コマンド：オブジェクトを下に移動
    /// <summary>
    /// コマンド：オブジェクトを下に移動
    /// </summary>
    private DelegateCommand _ObjectMoveDownCommand;
    public DelegateCommand ObjectMoveDownCommand
      => _ObjectMoveDownCommand ?? (_ObjectMoveDownCommand = new DelegateCommand(ObjectMoveDownCommandExecute, CanObjectMoveDownExecute));

    /// <summary>
    /// コマンド：オブジェクトを下に移動 の実行を行います。
    /// </summary>
    private void ObjectMoveDownCommandExecute()
    {
      SwapObjectOrder(true);
    }

    /// <summary>
    /// コマンド：オブジェクトを下に移動 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanObjectMoveDownExecute()
    {
      if (TmcData != null && Window.dgObject.SelectedItems.Count == 1)
      {
        var obj = Window.dgObject.SelectedItem as ObjectData;

        if (
          obj == null || obj.Grp == -1 || obj.VtxCount > 0 || obj.IdxCount > 0 ||
          obj.Index > Tables.ObjData.Count - 2 || Tables.ObjData[obj.Index + 1].Grp == -1
        )
          return false;
        else
          return true;
      }
      else
        return false;
    }
    #endregion


    #region コマンド：クリップボードのパステキストからファイルを開く
    /// <summary>
    /// コマンド：クリップボードのパステキストからファイルを開く
    /// </summary>
    private DelegateCommand _PathPasteCommand;
    public DelegateCommand PathPasteCommand
      => _PathPasteCommand ?? (_PathPasteCommand = new DelegateCommand(PathPasteCommandExecute, () => true));

    /// <summary>
    /// コマンド：クリップボードのパステキストからファイルを開く の実行を行います。
    /// </summary>
    public void PathPasteCommandExecute()
    {
      OpenFromClipboard();
    }
    #endregion

    #region コマンド：終了
    /// <summary>
    /// コマンド：終了
    /// </summary>
    private DelegateCommand _CloseCommand;
    public DelegateCommand CloseCommand
      => _CloseCommand ?? (_CloseCommand = new DelegateCommand(CloseCommandExecute, () => true));

    /// <summary>
    /// コマンド：終了 の実行を行います。
    /// </summary>
    public void CloseCommandExecute()
    {
      if (IsModified)
      {
        if (MessageWindow.Show(Window, Txt.ExitWithoutSave, Txt.Confirm, Txt.Exit, Txt.Cancel) == MessageWindow.Result.Cancel)
        {
          return;
        }
      }

      Window.Close();
    }
    #endregion



    #region SlideMessageText
    /// <summary>
    /// スライド表示メッセージのテキスト
    /// </summary>
    private string _SlideMessageText;
    public string SlideMessageText
    {
      get => _SlideMessageText;
      set => SetProperty(ref _SlideMessageText, value);
    }
    #endregion

    #region SlideMessageBackground
    /// <summary>
    /// スライド表示メッセージの背景
    /// </summary>
    private Brush _SlideMessageBackground;
    public Brush SlideMessageBackground
    {
      get => _SlideMessageBackground;
      set => SetProperty(ref _SlideMessageBackground, value);
    }
    #endregion

    #region storyFadeTextMessage
    /// <summary>
    /// スライド表示メッセージのストーリーボード
    /// </summary>
    private Storyboard storyFadeTextMessage;
    #endregion

    #region メソッド：SlideMessage
    public void ShowTextBlockMessage(string text)
    {
      ShowTextBlockMessage(text, new SolidColorBrush(Color.FromRgb(0x00, 0x88, 0xDD)));
    }
    public void ShowTextBlockMessage(string text, Brush background)
    {
      SlideMessageBackground = background;
      SlideMessageText = text;
      storyFadeTextMessage.SeekAlignedToLastTick(new TimeSpan(0, 0, 0));
      storyFadeTextMessage.Stop();
      storyFadeTextMessage.Begin();
    }
    public void FadeTextMessageAnimation_Completed()
    {
      storyFadeTextMessage.Stop();
      SlideMessageText = "";
    }
    #endregion

  }

}
