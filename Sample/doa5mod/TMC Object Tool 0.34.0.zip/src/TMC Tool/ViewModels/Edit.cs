﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Controls;
using Common;
using Tmc;
using TMC_Tool.Models;
using Language;
using Message;

namespace TMC_Tool.ViewModels
{
  public class Edit : BindableBase
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    public Edit(MainWindowViewModel data)
    {
      Txt = MainWindow.Txt;
      Data = data;
      Window = data.Window;
      Tables = data.Tables;
      IsEnabledGetMaterials = true;
      IsEnabledAddObj = true;
    }

    /// <summary>
    /// コンストラクタ
    /// </summary>
    public Edit(Import import)
    {
      Txt = MainWindow.Txt;
      Data = import.Data;
      Window = import.Window;
      Tables = import.Data.Tables;
      IsEnabledGetMaterials = true;
      IsEnabledAddObj = true;
    }



    #region メソッド：コマンドの有効無効

    /// <summary>
    /// オブジェクトグループ用コマンドの状態を変更
    /// </summary>
    /// <param name="dataGrid">DataGridオブジェクト</param>
    public void CommandStateObjectGroup(DataGrid dataGrid)
    {
      // 追加・リネーム・削除
      bool addable = false;
      bool renamable = false;
      bool deletable = false;

      if (dataGrid.SelectedItems.Count == 1)
      {
        addable = true;

        var item = dataGrid.SelectedItem as ObjectData;
        if (item.Name.Substring(0, 4) == "WGT_" || Data.TmcData.Physics == null || Data.TmcData.Physics.Count == 0)
        {
          renamable = true;
        }
      }

      var ObjGrpCount = Tables.ObjData.Where(elem => elem.Grp == -1).Count();
      if (ObjGrpCount > dataGrid.SelectedItems.Count)
      {
        deletable = true;
      }

      IsEnabledAddObjGrp = addable;
      IsEnabledRenameObjGrp = renamable;
      IsEnabledDeleteObjGrp = deletable;


      // BlendIdxの削除
      bool deletableBlendIdx = false;
      bool cancelableDeleteBlendIdx = false;
      foreach (ObjectData item in dataGrid.SelectedItems)
      {
        if (!item.IsBlendCleared && CheckDeletableBlendIdx(item))
        {
          deletableBlendIdx = true;
        }
        if (item.IsBlendCleared)
        {
          cancelableDeleteBlendIdx = true;
        }
      }

      IsEnabledClearBlendIdx = deletableBlendIdx;
      IsEnabledCancelClearBlendIdx = cancelableDeleteBlendIdx;
    }

    /// <summary>
    /// BlendIdxを削除できるかどうかをチェック
    /// </summary>
    /// <param name="objData">オブジェクトデータ</param>
    /// <returns>BlendIdxを削除できるかどうか</returns>
    private bool CheckDeletableBlendIdx(ObjectData objData)
    {
      if (Data.TmcData.Node[Tables.Nodes[objData.Node].AddedIndex].ChildCount == 0)
      {
        return false;
      }

      int vtxCount = 0;
      int idxCount = 0;
      foreach (var obj in Tables.ObjData)
      {
        if (obj.Grp == objData.ID)
        {
          vtxCount += (int)obj.VtxCount;
          idxCount += (int)obj.IdxCount;
        }
      }
      if (vtxCount > 0 || idxCount > 0)
      {
        return false;
      }

      return true;
    }

    /// <summary>
    /// オブジェクト用コマンドの状態を変更
    /// </summary>
    /// <param name="dataGrid">DataGridオブジェクト</param>
    public void CommandStateObject(DataGrid dataGrid)
    {
      bool dataDeletable = false;
      bool dataDeleted = false;
      bool vgrpChanged = false;
      bool vtxIdxGrpDataChanged = false;

      foreach (ObjectData objData in dataGrid.SelectedItems)
      {
        if (objData.Grp != -1)
        {
          if (Tables.VIData[(int)objData.VtxGrp].IsChanged)
          {
            vtxIdxGrpDataChanged = true;
          }
          else if (objData.IsVgrpChanged)
          {
            vgrpChanged = true;
          }
          else if (objData.IsDeleted)
          {
            dataDeleted = true;
          }
          else if (!objData.IsDeleted && !(objData.VtxCount == 0 && objData.IdxCount == 0 && !objData.IsDeleted))
          {
            dataDeletable = true;
          }
        }
      }

      if (vtxIdxGrpDataChanged)
      {
        IsEnabledDeleteData = false;
        IsEnabledCancelDeleteData = false;
      }
      else
      {
        IsEnabledDeleteData = dataDeletable;
        IsEnabledCancelDeleteData = (dataDeleted && !vgrpChanged);
      }
    }

    #endregion


    #region メソッド：オブジェクトグループ

    /// <summary>
    /// オブジェクトグループ名を入力して設定します
    /// </summary>
    /// <param name="grp">オブジェクトグループデータ</param>
    /// <param name="addObjGrp">オブジェクトグループ追加かどうか</param>
    /// <returns>オブジェクトグループ名</returns>
    private string InputObjName(ObjectData grp, bool addObjGrp)
    {
      return InputObjNameWindow.Show(Window, Data.TmcData, Tables, grp.Name, addObjGrp);
    }

    /// <summary>
    /// オブジェクトグループを追加します
    /// </summary>
    /// <param name="newName">新しい名前</param>
    /// <param name="grp">オブジェクトグループデータ</param>
    /// <param name="otherTables">インポートしている表データ</param>
    /// <returns>追加したオブジェクトグループのノードインデックス</returns>
    public int AddObjGrp(string newName, ObjectData grp, DataTables otherTables)
    {
      List<ObjectData> newObjects = new List<ObjectData>();
      int grpID = grp.ID;

      // インスタンスのマスターを再設定
      foreach (var node in Tables.Nodes)
      {
        if (node.Master == grp.Name) node.Master = newName;
      }

      TmcData data;
      DataTables tables;
      if (otherTables == null)
      {
        data = Data.TmcData;
        tables = Tables;
      }
      else
      {
        data = Data.OtherTmcDataList[grp.DataIndex];
        tables = otherTables;
      }

      Nodes originalNode = data.Node[tables.Nodes[grp.Node].OriginalIndex];


      // 追加するノード名が既にあればインデックスを返して、なければノードを追加してインデックスを返す
      int newNodeIndex = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == newName);
      if (newNodeIndex == -1)
      {
        // ノードを追加
        var newNode = new NodeData(originalNode);
        newNode.DataIndex = grp.DataIndex;
        if (data.Hie[originalNode.Index].Parent != -1 && grp.DataIndex == -1)
        {
          int parent = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == data.Node[data.Hie[originalNode.Index].Parent].Name);
          if (parent != -1)
            Tables.Nodes[parent].Children.Add(newName);
        }
        newNode.Name = newName;
        newNode.IsAdded = true;

        Tables.Nodes.Add(newNode);
        Tables.SortNodes();

        newNodeIndex = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == newNode.Name);
      }

      foreach (var node in tables.Nodes[grp.Node].Blends)
      {
        Tables.Nodes[newNodeIndex].Blends.Add(node);
      }


      // オブジェクトグループの挿入位置を割り出す
      var grpNames = Tables.ObjData.Where(obj => obj.Grp == -1).Select(obj => obj.Name).ToList();
      grpNames.Add(newName);
      grpNames = grpNames.OrderBy(name => name.ToLower(), StringComparer.Ordinal).ToList();

      int destIdx = -1;
      int grpIdx = grpNames.IndexOf(newName);
      if (grpIdx < grpNames.Count - 1)
      {
        destIdx = Array.FindIndex(Tables.ObjData.ToArray(), obj => obj.Name == grpNames[grpIdx + 1]);
      }
      else
      {
        destIdx = Tables.ObjData.Count;
      }

      // グループ内のオブジェクトをリスト化
      List<ObjectData> originalObjects = tables.ObjData.Where(obj => obj.Grp == grpID).ToList();

      // オブジェクトグループ作成と挿入
      var newGrp = Tables.AddObjectData(grp, destIdx);
      newGrp.Name = newName;
      newGrp.Node = newNodeIndex;
      newGrp.DataIndex = grp.DataIndex;
      newGrp.IsBlendCleared = false;
      if (newGrp.Toggle == -1)
        newGrp.Toggle = 0;
      else
        newGrp.Toggle = grp.Toggle;

      // オブジェクト作成と挿入
      int count = 1;
      foreach (var objData in originalObjects)
      {
        var newObj = Tables.AddObjectData(objData, destIdx + count);
        newObj.Grp = newGrp.ID;
        newObjects.Add(newObj);
        newObj.DataIndex = grp.DataIndex;

        if (otherTables != null)
        {
          newObj.VtxCount = objData.VtxCount;
          newObj.IdxCount = objData.IdxCount;
          newObj.IsEditable = false;
          newObj.IsVgrpChanged = false;
        }

        count++;
      }

      if (otherTables != null)
      {
        newGrp.VtxCount = grp.VtxCount;
        newGrp.IdxCount = grp.IdxCount;
      }

      // インデックスを再設定
      Tables.ResetObjectIndex();

      // オブジェクトグループのノードを再設定
      Tables.ResetObjDataNode();

      // ノードのObjIndexを再設定
      Tables.ResetNodesObjIndex();

      if (otherTables != null || Tables.Nodes[newNodeIndex].ObjIndex == -1)
      {
        foreach (var objData in Tables.ObjData)
        {
          if (objData.Grp == -1 && objData.Name == newName) Tables.Nodes[newNodeIndex].ObjIndex = objData.ID;
        }
      }

      // 頂点グループを追加
      List<VtxIdxGrpData> originalVtxGrps = tables.VIData.Where(vi => vi.ObjID == grpID).ToList();
      int destIdxVtxGrp = -1;
      if (grpIdx < grpNames.Count - 1)
      {
        destIdxVtxGrp = Array.FindIndex(Tables.VIData.ToArray(), elem => elem.ObjName == grpNames[grpIdx + 1]);
      }
      else
      {
        destIdxVtxGrp = Tables.VIData.Count;
      }

      count = 0;
      foreach (var item in originalVtxGrps)
      {
        Tables.InsertVIData(item, destIdxVtxGrp + count, grpIdx);
        var viData = Tables.VIData[destIdxVtxGrp + count];
        viData.ObjName = grpNames[grpIdx];
        viData.DataIndex = grp.DataIndex;

        if (otherTables != null)
        {
          viData.VtxCount = item.VtxCount;
          viData.IdxCount = item.IdxCount;
          viData.IsEditable = false;
          viData.IsAdded = false;
        }

        count++;
      }

      var convertVIGrp = new Dictionary<int, int>();
      count = 0;
      foreach (var viData in originalVtxGrps)
      {
        convertVIGrp[viData.Index] = destIdxVtxGrp + count;
        count++;
      }


      // 頂点グループのObjIDを再設定
      foreach (var viData in Tables.VIData)
      {
        viData.ObjID = grpNames.IndexOf(viData.ObjName);
      }

      // オブジェクトのVtxIdxGruopsを再設定
      Tables.ResetVtxIdxGruops();

      // オブジェクトの頂点グループ・Idxグループを再設定
      foreach (var objData in newObjects)
      {
        objData.VtxGrp = convertVIGrp[(int)objData.VtxGrp];
        Tables.VIData[(int)objData.VtxGrp].Use++;
      }

      // 頂点グループのIdxGrpを再設定
      Tables.ResetVIDataIdxGrp();

      // LastGrpIndexを再設定
      foreach (var objData in Tables.ObjData)
      {
        if (objData.Grp == -1) objData.LastGrpIndex = objData.ID;
      }

      Data.Modified();
      Data.ObjGrpRebuild = true;

      // Tables.ObjCountsを再設定
      foreach (var objData in Tables.ObjData)
      {
        if (objData.Grp == -1)
        {
          Tables.ObjCounts[objData.ID] = 0;
        }
        else
        {
          Tables.ObjCounts[objData.Grp]++;
        }
      }

      // 複製したオブジェクトグループを選択
      Window.dgObject.SelectedIndex = -1;
      Window.dgObject.SelectedItem = newGrp;
      Window.dgObject.ScrollIntoView(Window.dgObject.SelectedItem);

      return newNodeIndex;
    }

    /// <summary>
    /// オブジェクトグループの名前を変更します
    /// </summary>
    /// <param name="newName">新しい名前</param>
    /// <param name="grp">オブジェクトグループデータ</param>
    private void RenameObjGrp(string newName, ObjectData grp)
    {
      int grpID = grp.ID;
      string oldName = grp.Name;

      // インスタンスのマスターを再設定
      foreach (var node in Tables.Nodes)
      {
        if (node.Master == oldName) node.Master = newName;
      }

      grp.Name = newName;

      var originalNodeIndex = Data.TmcData.Node[Tables.Nodes[grp.Node].OriginalIndex].Index;
      if (Data.TmcData.Hie[originalNodeIndex].Parent != -1)
      {
        int parent = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == Data.TmcData.Node[Data.TmcData.Hie[originalNodeIndex].Parent].Name);
        Tables.Nodes[parent].Children.Remove(oldName);
        Tables.Nodes[parent].Children.Add(newName);
      }

      Tables.Nodes[grp.Node].Name = newName;
      Tables.SortNodes();

      // オブジェクトグループのノードを再設定
      Tables.ResetObjDataNode();

      // 頂点グループ・IdxグループのObjName変更
      foreach (var viData in Tables.VIData)
      {
        if (viData.ObjName == oldName) viData.ObjName = newName;
      }

      // オブジェクトグループの順番変更
      var grpNames = Tables.ObjData.Where(obj => obj.Grp == -1).Select(obj => obj.Name).ToList();
      grpNames = grpNames.OrderBy(name => name.ToLower(), StringComparer.Ordinal).ToList();

      var objDataList = new List<ObjectData>();
      foreach (var grpName in grpNames)
      {
        foreach (var objData in Tables.ObjData)
        {
          if (objData.Grp == -1)
          {
            if (objData.Name == grpName) objDataList.Add(objData);
          }
          else
          {
            int grpIndex = Array.FindIndex(Tables.ObjData.ToArray(), elem => elem.ID == objData.Grp && elem.Grp == -1);
            if (Tables.ObjData[grpIndex].Name == grpName) objDataList.Add(objData);
          }
        }
      }

      // 既存ObjDataをクリア
      Tables.ObjData.Clear();

      // 新規リストからObjDataに追加
      foreach (var objData in objDataList)
      {
        Tables.ObjData.Add(objData);
      }

      // インデックスを再設定
      Tables.ResetObjectIndex();

      // ノードのObjIndexを再設定
      Tables.ResetNodesObjIndex();

      // ACSCLSのインデックスリストのNameを変更
      foreach (var indices in Tables.PhysicsIndicesSet)
      {
        int index = Array.FindIndex(indices.ToArray(), elem => elem.Name == oldName);
        if (index != -1)
        {
          indices[index].Name = newName;
          break;
        }
      }

      // PhysicsListのNameを変更
      foreach (var physics in Tables.PhysicsList)
      {
        if (physics.Name == oldName) physics.Name = newName;
      }

      // 頂点グループ・Idxグループの順番変更
      var viDataList = new List<VtxIdxGrpData>();
      var convertVIGrp = new Dictionary<int, int>();
      foreach (var grpName in grpNames)
      {
        foreach (var viData in Tables.VIData)
        {
          if (viData.ObjName == grpName)
          {
            convertVIGrp[viData.Index] = viDataList.Count;
            viData.Index = viDataList.Count;
            viDataList.Add(viData);
          }
        }
      }

      // 既存VIDataをクリア
      Tables.VIData.Clear();

      // 新規リストからVIDataに追加
      foreach (var viData in viDataList)
      {
        Tables.VIData.Add(viData);
      }


      // 頂点グループのObjIDを再設定
      foreach (var viData in Tables.VIData)
      {
        viData.ObjID = grpNames.IndexOf(viData.ObjName);
      }

      // オブジェクトのVtxIdxGruopsを再設定
      Tables.ResetVtxIdxGruops();

      // オブジェクトの頂点グループ・Idxグループを再設定
      foreach (var objData in Tables.ObjData)
      {
        if (objData.Grp == -1) continue;
        objData.VtxGrp = (byte)convertVIGrp[(int)objData.VtxGrp];
      }

      // 頂点グループのIdxGrpを再設定
      Tables.ResetVIDataIdxGrp();

      // LastGrpIndexを再設定
      foreach (var objData in Tables.ObjData)
      {
        if (objData.Grp == -1) objData.LastGrpIndex = objData.ID;
      }

      Data.Modified();
      Data.ObjGrpRebuild = true;
    }

    #endregion



    #region コマンド：オブジェクトグループ

    #region コマンド：オブジェクトグループを追加
    /// <summary>
    /// コマンド：オブジェクトグループを追加
    /// </summary>
    private DelegateCommand _AddObjGrpCommand;
    public DelegateCommand AddObjGrpCommand
      => _AddObjGrpCommand ?? (_AddObjGrpCommand = new DelegateCommand(AddObjGrpExecute, () => IsEnabledAddObjGrp));

    /// <summary>
    /// コマンド：オブジェクトグループを追加 の実行を行います。
    /// </summary>
    private void AddObjGrpExecute()
    {
      try
      {
        if (Window.dgObject.SelectedItems.Count > 1) return;

        ObjectData grpData = Window.dgObject.SelectedItem as ObjectData;
        if (grpData.Grp != -1) return;

        // オブジェクトグループ名を入力して設定
        string newName = InputObjName(grpData, true);
        if (newName == null) return;

        AddObjGrp(newName, grpData, null);
      }
      catch (Exception ex)
      {
        MessageWindow.Show(Window, ex.Message + "\r\n\r\n" + ex.StackTrace, Txt.Error);
      }
    }
    #endregion

    #region コマンド：オブジェクトグループの名前を変更
    /// <summary>
    /// コマンド：オブジェクトグループの名前を変更
    /// </summary>
    private DelegateCommand _RenameObjGrpCommand;
    public DelegateCommand RenameObjGrpCommand
      => _RenameObjGrpCommand ?? (_RenameObjGrpCommand = new DelegateCommand(RenameObjGrpExecute, () => IsEnabledRenameObjGrp));

    /// <summary>
    /// コマンド：オブジェクトグループの名前を変更 の実行を行います。
    /// </summary>
    private void RenameObjGrpExecute()
    {
      try
      {
        if (Window.dgObject.SelectedItems.Count > 1) return;

        ObjectData grpData = Window.dgObject.SelectedItem as ObjectData;
        if (grpData.Grp != -1) return;

        // オブジェクトグループ名を入力して設定
        string newName = InputObjName(grpData, false);
        if (newName == null) return;

        RenameObjGrp(newName, grpData);
      }
      catch (Exception ex)
      {
        MessageWindow.Show(Window, ex.Message + "\r\n\r\n" + ex.StackTrace, Txt.Error);
      }
    }
    #endregion

    #region コマンド：オブジェクトグループを削除
    /// <summary>
    /// コマンド：オブジェクトグループを削除
    /// </summary>
    private DelegateCommand _DeleteObjGrpCommand;
    public DelegateCommand DeleteObjGrpCommand
      => _DeleteObjGrpCommand ?? (_DeleteObjGrpCommand = new DelegateCommand(DeleteObjGrpExecute, () => IsEnabledDeleteObjGrp));

    /// <summary>
    /// コマンド：オブジェクトグループを削除 の実行を行います。
    /// </summary>
    private void DeleteObjGrpExecute()
    {
      try
      {
        DeleteObjectGroup.Do(Data);

        if (Data.TextureRebuild)
        {
          Data.Modified();
          Data.Status = Data.TmcData.Path + "* <TMCL*>";
        }
      }
      catch (Exception ex)
      {
        MessageWindow.Show(Window, ex.Message + "\r\n\r\n" + ex.StackTrace, Txt.Error);
      }
    }
    #endregion

    #region コマンド：Blend Indexを削除
    /// <summary>
    /// コマンド：Blend Indexを削除
    /// </summary>
    private DelegateCommand _ClearBlendIdxCommand;
    public DelegateCommand ClearBlendIdxCommand
      => _ClearBlendIdxCommand ?? (_ClearBlendIdxCommand = new DelegateCommand(ClearBlendIdxExecute, () => IsEnabledClearBlendIdx));

    /// <summary>
    /// コマンド：Blend Indexを削除 の実行を行います。
    /// </summary>
    private void ClearBlendIdxExecute()
    {
      try
      {
        var deletableObjects = new List<ObjectData>();
        string blendIndicesList = "";
        int blendIndicesCount = 0;

        foreach (ObjectData objData in Window.dgObject.SelectedItems)
        {
          if (objData.Grp != -1 || objData.IsBlendCleared || !CheckDeletableBlendIdx(objData)) continue;

          deletableObjects.Add(objData);

          blendIndicesCount += Tables.Nodes[objData.Node].Blends.Count;

          blendIndicesList += "\r\n\r\n[" + objData.Name + "]";

          foreach (var name in Tables.Nodes[objData.Node].Blends)
          {
            blendIndicesList += "\r\n" + name;
          }
        }

        string confirmText = Txt.ConfirmBlendIdxClear;
        confirmText = confirmText.Replace("*", blendIndicesCount.ToString());
        confirmText += blendIndicesList;

        var result = MessageWindow.Show(Window, confirmText, Txt.Confirm, Txt.OK, Txt.Cancel);
        if (result == MessageWindow.Result.OK)
        {
          foreach (var objData in deletableObjects)
          {
            objData.BlendIndicesCount = 0;
            objData.IsBlendCleared = true;
            Tables.Nodes[objData.Node].IsBlendCleared = true;

            Data.Modified();
          }
        }
      }
      catch (Exception ex)
      {
        MessageWindow.Show(Window, ex.Message + "\r\n\r\n" + ex.StackTrace, Txt.Error);
      }
    }
    #endregion

    #region コマンド：Blend Indexの削除を取り消し
    /// <summary>
    /// コマンド：Blend Indexの削除を取り消し
    /// </summary>
    private DelegateCommand _CancelClearBlendIdxCommand;
    public DelegateCommand CancelClearBlendIdxCommand
      => _CancelClearBlendIdxCommand ?? (_CancelClearBlendIdxCommand = new DelegateCommand(CancelClearBlendIdxExecute, () => IsEnabledCancelClearBlendIdx));

    /// <summary>
    /// コマンド：Blend Indexの削除を取り消し の実行を行います。
    /// </summary>
    private void CancelClearBlendIdxExecute()
    {
      try
      {
        foreach (ObjectData objData in Window.dgObject.SelectedItems)
        {
          if (objData.Grp != -1) continue;

          objData.BlendIndicesCount = Data.TmcData.Node[Tables.Nodes[objData.Node].AddedIndex].ChildCount;
          objData.IsBlendCleared = false;
          Tables.Nodes[objData.Node].IsBlendCleared = false;
        }
      }
      catch (Exception ex)
      {
        MessageWindow.Show(Window, ex.Message + "\r\n\r\n" + ex.StackTrace, Txt.Error);
      }
    }
    #endregion

    #endregion


    #region コマンド：オブジェクト

    #region コマンド：オブジェクトを追加
    /// <summary>
    /// コマンド：オブジェクトを追加
    /// </summary>
    private DelegateCommand _AddObjCommand;
    public DelegateCommand AddObjCommand
      => _AddObjCommand ?? (_AddObjCommand = new DelegateCommand(AddObjExecute, () => IsEnabledAddObj));

    /// <summary>
    /// コマンド：オブジェクトを追加 の実行を行います。
    /// </summary>
    private void AddObjExecute()
    {
      try
      {
        List<ObjectData> newObjects = new List<ObjectData>();

        foreach (ObjectData objData in Window.dgObject.SelectedItems)
        {
          if (objData.Grp == -1) continue;

          var newObj = Tables.AddObjectData(objData);
          newObjects.Add(newObj);
        }

        if (newObjects.Count == 0) return;

        Data.Modified();

        Window.dgObject.SelectedIndex = -1;
        foreach (var obj in newObjects)
        {
          Window.dgObject.SelectedItems.Add(obj);
        }

        Tables.ResetObjectIndex();
      }
      catch (Exception ex)
      {
        MessageWindow.Show(Window, ex.Message + "\r\n\r\n" + ex.StackTrace, Txt.Error);
      }
    }
    #endregion

    #region コマンド：オブジェクトを削除
    /// <summary>
    /// コマンド：オブジェクトを削除
    /// </summary>
    private DelegateCommand _DeleteObjCommand;
    public DelegateCommand DeleteObjCommand
      => _DeleteObjCommand ?? (_DeleteObjCommand = new DelegateCommand(DeleteObjExecute, CanDeleteObjExecute));

    /// <summary>
    /// コマンド：オブジェクトを削除 の実行を行います。
    /// </summary>
    private void DeleteObjExecute()
    {
      try
      {
        var result = MessageWindow.Show(Window, Txt.ConfirmObjDelete, Txt.Confirm, Txt.OK, Txt.Cancel);
        if (result == MessageWindow.Result.OK)
        {
          while (Window.dgObject.SelectedItems.Count > 0)
          {
            ObjectData objData = Window.dgObject.SelectedItem as ObjectData;
            if (objData.Grp == -1 || Tables.ObjCounts[objData.Grp] <= 1)
            {
              Window.dgObject.SelectedItems.Remove(Window.dgObject.SelectedItem);
              continue;
            }

            Tables.ObjCounts[objData.Grp]--;
            Tables.ObjData.Remove(objData);

            Data.Modified();
          }

          Tables.ResetObjectIndex();
          Tables.ReCalcGrpVyxIdxCount();
          Tables.ReCalcGrpUseCount(null);
        }
      }
      catch (Exception ex)
      {
        MessageWindow.Show(Window, ex.Message + "\r\n\r\n" + ex.StackTrace, Txt.Error);
      }
    }

    /// <summary>
    /// コマンド：オブジェクトを削除 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanDeleteObjExecute()
    {
      foreach (ObjectData obj in Window.dgObject.SelectedItems)
      {
        if (obj.Grp != -1 && Tables.ObjCounts[obj.Grp] > 1)
        {
          return true;
        }
      }

      return false;
    }
    #endregion

    #region コマンド：頂点・Idxを全て削除
    /// <summary>
    /// コマンド：頂点・Idxを全て削除
    /// </summary>
    private DelegateCommand _DeleteDataCommand;
    public DelegateCommand DeleteDataCommand
      => _DeleteDataCommand ?? (_DeleteDataCommand = new DelegateCommand(DeleteDataExecute, () => IsEnabledDeleteData));

    /// <summary>
    /// コマンド：頂点・Idxを全て削除 の実行を行います。
    /// </summary>
    private void DeleteDataExecute()
    {
      try
      {
        var result = MessageWindow.Show(Window, Txt.ConfirmAllDelete, Txt.Confirm, Txt.OK, Txt.Cancel);
        if (result == MessageWindow.Result.OK)
        {
          foreach (ObjectData objData in Window.dgObject.SelectedItems)
          {
            if (objData.Grp == -1 || (objData.VtxCount == 0 && objData.IdxCount == 0)) continue;

            objData.IsDeleted = true;
            objData.IsEditable = true;
            objData.VtxCount = 0;
            objData.IdxCount = 0;

            Data.Modified();
          }
          Tables.ReCalcGrpVyxIdxCount();
        }
      }
      catch (Exception ex)
      {
        MessageWindow.Show(Window, ex.Message + "\r\n\r\n" + ex.StackTrace, Txt.Error);
      }
    }
    #endregion

    #region コマンド：全て削除を取り消し
    /// <summary>
    /// コマンド：全て削除を取り消し
    /// </summary>
    private DelegateCommand _CancelDeleteDataCommand;
    public DelegateCommand CancelDeleteDataCommand
      => _CancelDeleteDataCommand ?? (_CancelDeleteDataCommand = new DelegateCommand(CancelDeleteDataExecute, () => IsEnabledCancelDeleteData));

    /// <summary>
    /// コマンド：全て削除を取り消し の実行を行います。
    /// </summary>
    private void CancelDeleteDataExecute()
    {
      try
      {
        var resettedObjDataList = new List<ObjectData>();

        foreach (ObjectData selectedObjData in Window.dgObject.SelectedItems)
        {
          if (selectedObjData.Grp == -1) continue;

          TmcData data;
          if (selectedObjData.DataIndex != -1)
            data = Data.OtherTmcDataList[selectedObjData.DataIndex];
          else
            data = Data.TmcData;

          selectedObjData.IsDeleted = false;
          selectedObjData.IsEditable = false;
          selectedObjData.VtxCount = data.ObjGrp[selectedObjData.OriginalGrpIndex].Obj[selectedObjData.OriginalObjIndex].VtxCount;
          selectedObjData.IdxCount = data.ObjGrp[selectedObjData.OriginalGrpIndex].Obj[selectedObjData.OriginalObjIndex].IdxCount;

          foreach (var objData in Tables.ObjData)
          {
            if (objData.Grp != -1) continue;

            if (objData.ID == selectedObjData.Grp)
            {
              resettedObjDataList.Add(objData);
            }
          }
        }

        foreach (var objData in resettedObjDataList)
        {
          objData.BlendIndicesCount = Data.TmcData.Node[Tables.Nodes[objData.Node].AddedIndex].ChildCount;
          objData.IsBlendCleared = false;
          Tables.Nodes[objData.Node].IsBlendCleared = false;
        }


        Tables.ReCalcGrpVyxIdxCount();
      }
      catch (Exception ex)
      {
        MessageWindow.Show(Window, ex.Message + "\r\n\r\n" + ex.StackTrace, Txt.Error);
      }
    }
    #endregion

    #region コマンド：マテリアル情報を取得して変更
    /// <summary>
    /// コマンド：マテリアル情報を取得して変更
    /// </summary>
    private DelegateCommand _GetMaterialsCommand;
    public DelegateCommand GetMaterialsCommand
      => _GetMaterialsCommand ?? (_GetMaterialsCommand = new DelegateCommand(GetMaterialsExecute, () => IsEnabledGetMaterials));

    /// <summary>
    /// コマンド：マテリアル情報を取得して変更 の実行を行います。
    /// </summary>
    private void GetMaterialsExecute()
    {
      try
      {
        var mat = new GetMaterials(Data);
        mat.Get();
      }
      catch (Exception ex)
      {
        MessageWindow.Show(Window, ex.Message + "\r\n\r\n" + ex.StackTrace, Txt.Error);
      }
    }
    #endregion

    #region コマンド：メッシュデータを抽出
    /// <summary>
    /// コマンド：メッシュデータを抽出
    /// </summary>
    private DelegateCommand _ExtractMeshesCommand;
    public DelegateCommand ExtractMeshesCommand
      => _ExtractMeshesCommand ?? (_ExtractMeshesCommand = new DelegateCommand(ExtractMeshesExecute, CanExtractMeshesExecute));

    /// <summary>
    /// コマンド：メッシュデータを抽出 の実行を行います。
    /// </summary>
    private void ExtractMeshesExecute()
    {
      try
      {
        var options = Data.ExtractMeshWindow.Show(Window);
        if (options == null) return;

        List<ObjectData> objects = new List<ObjectData>();
        foreach (ObjectData objData in Window.dgObject.SelectedItems)
        {
          if (objData.Grp != -1 && objData.VtxCount > 1 && objData.IdxCount > 2) objects.Add(objData);
        }

        var extract = new ExtractMeshes(Data, options, objects);
        int extractedCount = extract.Do();

        if (extractedCount > 0)
          Data.ShowTextBlockMessage(Txt.Extracted + " / " + extractedCount);
        else
          Data.ShowTextBlockMessage(Txt.NotExtracted, Data.AlertBg);
      }
      catch (Exception ex)
      {
        MessageWindow.Show(Window, ex.Message + "\r\n\r\n" + ex.StackTrace, Txt.Error);
      }
    }

    /// <summary>
    /// コマンド：メッシュデータを抽出 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanExtractMeshesExecute()
    {
      foreach (ObjectData objData in Window.dgObject.SelectedItems)
      {
        if (objData.Grp != -1 && objData.VtxCount > 1 && objData.IdxCount > 2)
        {
          TmcData tmcData;

          if (objData.DataIndex == -1)
            tmcData = Data.TmcData;
          else
            tmcData = Data.OtherTmcDataList[objData.DataIndex];

          if (tmcData.Node[tmcData.ObjGrp[objData.OriginalGrpIndex].Node].ObjIndex > -1) return true;
        }
      }

      return false;
    }
    #endregion

    #endregion


    #region コマンド：頂点・Idxグループ

    #region コマンド：既存の頂点・Idxグループを元に追加
    /// <summary>
    /// コマンド：既存の頂点・Idxグループを元に追加
    /// </summary>
    private DelegateCommand _AddVtxIdxGrpCommand;
    public DelegateCommand AddVtxIdxGrpCommand
      => _AddVtxIdxGrpCommand ?? (_AddVtxIdxGrpCommand = new DelegateCommand(AddVtxIdxGrpExecute, CanAddVtxIdxGrpExecute));

    /// <summary>
    /// コマンド：既存の頂点・Idxグループを元に追加 の実行を行います。
    /// </summary>
    private void AddVtxIdxGrpExecute()
    {
      try
      {
        var result = MessageWindow.Show(Window, Txt.ConfirmAddVtxGrp, Txt.Confirm, Txt.OK, Txt.Cancel);
        if (result == MessageWindow.Result.OK)
        {
          VtxIdxGrpData grp = Window.dgVtxIdxGrp.SelectedItem as VtxIdxGrpData;

          int addIndex = Tables.InsertVIData(grp);
          Tables.ResetVtxIdxGruops();
          Tables.ResetVIDataIdxGrp();
          Window.dgVtxIdxGrp.SelectedIndex = addIndex;
          Window.dgVtxIdxGrp.ScrollIntoView(Window.dgVtxIdxGrp.Items[addIndex]);

          Data.Modified();
        }
      }
      catch (Exception ex)
      {
        MessageWindow.Show(Window, ex.Message + "\r\n\r\n" + ex.StackTrace, Txt.Error);
      }
    }

    /// <summary>
    /// コマンド：既存の頂点・Idxグループを元に追加 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanAddVtxIdxGrpExecute()
    {
      if (Window.dgVtxIdxGrp.SelectedItems.Count == 1)
      {
        VtxIdxGrpData item = Window.dgVtxIdxGrp.SelectedItem as VtxIdxGrpData;
        if (item.ObjID != -1) return true;
      }

      return false;
    }
    #endregion

    #region コマンド：削除（頂点・Idxグループ）
    /// <summary>
    /// コマンド：削除（頂点・Idxグループ）
    /// </summary>
    private DelegateCommand _DeleteVtxIdxGrpCommand;
    public DelegateCommand DeleteVtxIdxGrpCommand
      => _DeleteVtxIdxGrpCommand ?? (_DeleteVtxIdxGrpCommand = new DelegateCommand(DeleteVtxIdxGrpExecute, CanDeleteVtxIdxGrpExecute));

    /// <summary>
    /// コマンド：削除（頂点・Idxグループ） の実行を行います。
    /// </summary>
    private void DeleteVtxIdxGrpExecute()
    {
      try
      {
        var result = MessageWindow.Show(Window, Txt.ConfirmDelVtxGrp, Txt.Confirm, Txt.OK, Txt.Cancel);
        if (result == MessageWindow.Result.OK)
        {
          List<int> selectedIndices = new List<int>();
          foreach (VtxIdxGrpData grp in Window.dgVtxIdxGrp.SelectedItems)
          {
            if (grp.Use == 0) selectedIndices.Add(grp.Index);
          }

          byte newVtxGrp = 0;
          byte newIdxGrp = 0;
          for (int i = 0; i < Tables.VIData.Count; i++)
          {
            if (selectedIndices.Contains(i))
            {
              continue;
            }
            foreach (var obj in Tables.ObjData)
            {
              // ObjDataのVtxGrpを再設定
              if (obj.Grp != -1 && obj.VtxGrp == Tables.VIData[i].Index) obj.VtxGrp = newVtxGrp;

              // ObjDataのフラグ再設定
              if (obj.Grp != -1 && obj.VtxGrp == Tables.VIData[i].Index) obj.VtxGrp = newVtxGrp;
            }
            // VIDataのIndexを再設定
            Tables.VIData[i].Index = newVtxGrp;
            newVtxGrp++;

            if (Tables.VIData[i].ObjID != -1)
            {
              // VIDataのIdxGrpを再設定
              Tables.VIData[i].IdxGrp = newIdxGrp;
              newIdxGrp++;
            }
          }

          selectedIndices.Sort();
          selectedIndices.Reverse();
          foreach (var idx in selectedIndices)
          {
            Tables.VIData.RemoveAt(idx);
          }

          // ObjDataのVtxIdxGruopsを再設定
          foreach (var objData in Tables.ObjData)
          {
            if (objData.Grp != -1)
            {
              byte vtxGrp = (byte)objData.VtxGrp;
              objData.VtxIdxGruops.Clear();
              foreach (var data in Tables.VIData)
              {
                if (objData.Grp == data.ObjID) objData.VtxIdxGruops.Add((byte)data.Index);
              }
              objData.VtxGrp = vtxGrp;
            }
          }

          Data.Modified();
        }
      }
      catch (Exception ex)
      {
        MessageWindow.Show(Window, ex.Message + "\r\n\r\n" + ex.StackTrace, Txt.Error);
      }
    }

    /// <summary>
    /// コマンド：削除（頂点・Idxグループ） が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanDeleteVtxIdxGrpExecute()
    {
      foreach (VtxIdxGrpData grp in Window.dgVtxIdxGrp.SelectedItems)
      {
        if (grp.Use == 0) return true;
      }

      return false;
    }
    #endregion

    #region コマンド：頂点・Idxを全て削除（頂点・Idxグループ）
    /// <summary>
    /// コマンド：頂点・Idxを全て削除（頂点・Idxグループ）
    /// </summary>
    private DelegateCommand _DeleteDataGrpCommand;
    public DelegateCommand DeleteDataGrpCommand
      => _DeleteDataGrpCommand ?? (_DeleteDataGrpCommand = new DelegateCommand(DeleteDataGrpExecute, CanDeleteDataGrpExecute));

    /// <summary>
    /// コマンド：頂点・Idxを全て削除（頂点・Idxグループ） の実行を行います。
    /// </summary>
    private void DeleteDataGrpExecute()
    {
      try
      {
        var result = MessageWindow.Show(Window, Txt.ConfirmAllDataDelete, Txt.Confirm, Txt.OK, Txt.Cancel);
        if (result == MessageWindow.Result.OK)
        {
          foreach (VtxIdxGrpData grp in Window.dgVtxIdxGrp.SelectedItems)
          {
            foreach (var obj in Tables.ObjData)
            {
              if (obj.VtxGrp == grp.Index && (obj.VtxCount != 0 || obj.IdxCount != 0))
              {
                obj.IsDeleted = true;
                obj.IsEditable = true;
                obj.VtxCount = 0;
                obj.IdxCount = 0;
              }
            }
          }

          Data.Modified();

          Tables.ReCalcGrpVyxIdxCount();
        }
      }
      catch (Exception ex)
      {
        MessageWindow.Show(Window, ex.Message + "\r\n\r\n" + ex.StackTrace, Txt.Error);
      }
    }

    /// <summary>
    /// コマンド：頂点・Idxを全て削除（頂点・Idxグループ） が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanDeleteDataGrpExecute()
    {
      foreach (VtxIdxGrpData grp in Window.dgVtxIdxGrp.SelectedItems)
      {
        foreach (var obj in Tables.ObjData)
        {
          if (obj.VtxGrp == grp.Index && (obj.VtxCount != 0 || obj.IdxCount != 0))
          {
            return true;
          }
        }
      }

      return false;
    }
    #endregion

    #region コマンド：変更を取り消し
    /// <summary>
    /// コマンド：変更を取り消し
    /// </summary>
    private DelegateCommand _CancelChangeVtxIdxGrpCommand;
    public DelegateCommand CancelChangeVtxIdxGrpCommand
      => _CancelChangeVtxIdxGrpCommand ?? (_CancelChangeVtxIdxGrpCommand = new DelegateCommand(CancelChangeVtxIdxGrpExecute, CanCancelChangeVtxIdxGrpExecute));

    /// <summary>
    /// コマンド：変更を取り消し の実行を行います。
    /// </summary>
    private void CancelChangeVtxIdxGrpExecute()
    {
      try
      {
        foreach (VtxIdxGrpData grp in Window.dgVtxIdxGrp.SelectedItems)
        {
          grp.ResetVxtIdxGrpData(Data.TmcData, grp.OriginalIndex);
        }
      }
      catch (Exception ex)
      {
        MessageWindow.Show(Window, ex.Message + "\r\n\r\n" + ex.StackTrace, Txt.Error);
      }
    }

    /// <summary>
    /// コマンド：変更を取り消し が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanCancelChangeVtxIdxGrpExecute()
    {
      foreach (VtxIdxGrpData grp in Window.dgVtxIdxGrp.SelectedItems)
      {
        if (grp.IsChanged) return true;
      }

      return false;
    }
    #endregion

    #endregion



    /// <summary>
    /// MainWindowViewModel
    /// </summary>
    public MainWindowViewModel Data { get; set; }

    /// <summary>
    /// 言語テキスト
    /// </summary>
    public static Lang.Text Txt;

    /// <summary>
    /// MainWindow
    /// </summary>
    public MainWindow Window { get; set; }

    /// <summary>
    /// 表のデータ
    /// </summary>
    public DataTables Tables { get; set; }



    #region プロパティ：オブジェクトグループ

    #region IsEnabledAddObjGrp
    /// <summary>
    /// AddObjGrpが有効かどうか
    /// </summary>
    private bool _IsEnabledAddObjGrp;
    public bool IsEnabledAddObjGrp
    {
      get => _IsEnabledAddObjGrp;
      set => SetProperty(ref _IsEnabledAddObjGrp, value);
    }
    #endregion

    #region IsEnabledRenameObjGrp
    /// <summary>
    /// RenameObjGrpが有効かどうか
    /// </summary>
    private bool _IsEnabledRenameObjGrp;
    public bool IsEnabledRenameObjGrp
    {
      get => _IsEnabledRenameObjGrp;
      set => SetProperty(ref _IsEnabledRenameObjGrp, value);
    }
    #endregion

    #region IsEnabledDeleteObjGrp
    /// <summary>
    /// DeleteObjGrpが有効かどうか
    /// </summary>
    private bool _IsEnabledDeleteObjGrp;
    public bool IsEnabledDeleteObjGrp
    {
      get => _IsEnabledDeleteObjGrp;
      set => SetProperty(ref _IsEnabledDeleteObjGrp, value);
    }
    #endregion

    #region IsEnabledClearBlendIdx
    /// <summary>
    /// ClearBlendIdxが有効かどうか
    /// </summary>
    private bool _IsEnabledClearBlendIdx;
    public bool IsEnabledClearBlendIdx
    {
      get => _IsEnabledClearBlendIdx;
      set => SetProperty(ref _IsEnabledClearBlendIdx, value);
    }
    #endregion

    #region IsEnabledCancelClearBlendIdx
    /// <summary>
    /// CancelClearBlendIdxが有効かどうか
    /// </summary>
    private bool _IsEnabledCancelClearBlendIdx;
    public bool IsEnabledCancelClearBlendIdx
    {
      get => _IsEnabledCancelClearBlendIdx;
      set => SetProperty(ref _IsEnabledCancelClearBlendIdx, value);
    }
    #endregion

    #endregion

    #region プロパティ：オブジェクト

    #region IsEnabledAddObj
    /// <summary>
    /// AddObjが有効かどうか
    /// </summary>
    private bool _IsEnabledAddObj;
    public bool IsEnabledAddObj
    {
      get => _IsEnabledAddObj;
      set => SetProperty(ref _IsEnabledAddObj, value);
    }
    #endregion

    #region IsEnabledDeleteData
    /// <summary>
    /// DeleteDataが有効かどうか
    /// </summary>
    private bool _IsEnabledDeleteData;
    public bool IsEnabledDeleteData
    {
      get => _IsEnabledDeleteData;
      set => SetProperty(ref _IsEnabledDeleteData, value);
    }
    #endregion

    #region IsEnabledCancelDeleteData
    /// <summary>
    /// CancelDeleteDataが有効かどうか
    /// </summary>
    private bool _IsEnabledCancelDeleteData;
    public bool IsEnabledCancelDeleteData
    {
      get => _IsEnabledCancelDeleteData;
      set => SetProperty(ref _IsEnabledCancelDeleteData, value);
    }
    #endregion

    #region IsEnabledGetMaterials
    /// <summary>
    /// GetMaterialが有効かどうか
    /// </summary>
    private bool _IsEnabledGetMaterials;
    public bool IsEnabledGetMaterials
    {
      get => _IsEnabledGetMaterials;
      set => SetProperty(ref _IsEnabledGetMaterials, value);
    }
    #endregion

    #endregion
  }
}
