﻿using System;
using System.Collections.Generic;
using Common;
using Tmc;

namespace TMC_Tool.ViewModels
{
  public class MtrColData : BindableBase
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    public MtrColData(MtrColorGroup grp, int count)
    {
      Colors = new List<float[]>();

      if (grp == null) return;

      Index = grp.ID;
      OriginalIndex = grp.ID;
      Use = count;

      foreach (var col in grp.Color)
      {
        var color = new float[col.Length];
        Array.Copy(col, color, col.Length);
        Colors.Add(color);
      }
    }


    #region Index
    /// <summary>
    /// 
    /// </summary>
    private int _Index;
    public int Index
    {
      get => _Index;
      set => SetProperty(ref _Index, value);
    }
    #endregion

    /// <summary>
    /// 
    /// </summary>
    public int OriginalIndex { get; set; }

    #region Count
    /// <summary>
    /// 
    /// </summary>
    private int _Count;
    public int Count
    {
      get => _Count;
      set => SetProperty(ref _Count, value);
    }
    #endregion

    #region Use
    /// <summary>
    /// 
    /// </summary>
    private int _Use;
    public int Use
    {
      get => _Use;
      set => SetProperty(ref _Use, value);
    }
    #endregion

    /// <summary>
    /// 
    /// </summary>
    public List<float[]> Colors { get; set; }
  }
}
