﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Common;
using Tmc;
using TMC_Tool.Models;

namespace TMC_Tool.ViewModels
{
  [Serializable]
  public class ObjectData : BindableBase
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    public ObjectData()
    {
    }

    /// <summary>
    /// オブジェクトデータをセット
    /// </summary>
    /// <param name="data">TMCデータ</param>
    /// <param name="grp">オブジェクトグループ</param>
    /// <param name="obj">オブジェクト</param>
    /// <param name="count">オブジェクトカウント</param>
    /// <param name="objIndex">オブジェクトインデックス</param>
    public void SetObjectData(TmcData data, ObjectGroup grp, ObjectPart obj, int count, int objIndex)
    {
      VtxIdxGruops = new ObservableCollection<int>();
      TexTypes = new ObservableCollection<string>();
      TexDataList = new List<dynamic[]>();

      IsEditable = false;
      IsDeleted = false;
      IsVgrpChanged = false;
      Index = count;
      OriginalObjIndex = objIndex;
      LastGrpIndex = -1;
      DataIndex = -1;

      Node = -1;
      Toggle = -1;
      BlendIndicesCount = -1;
      UVCount = -1;
      TexType = -1;
      CastShadow = -1;
      ReceiveShadow = -1;
      Type = "";

      RecentTexs = new int?[5];
      RecentTexTypes = new char?[5];

      if (obj == null)
      {
        SetData(data, grp);
      }
      else
      {
        SetData(data, grp, obj);
      }
    }

    /// <summary>
    /// オブジェクトデータをセット（グループ）
    /// </summary>
    /// <param name="data">TMCデータ</param>
    /// <param name="grp">オブジェクトグループ</param>
    private void SetData(TmcData data, ObjectGroup grp)
    {
      Name = grp.Name;
      ID = grp.ID;
      Grp = -1;
      OriginalGrpIndex = grp.ID;
      LastGrpIndex = grp.ID;
      Node = grp.Node;

      int totalVtxCount = 0;
      int totalIdxCount = 0;
      foreach (var decl in grp.Decl)
      {
        totalVtxCount += decl.VtxCount;
        totalIdxCount += decl.IdxCount;
      }
      VtxCount = totalVtxCount;
      IdxCount = totalIdxCount;


      if (data.ObjGrp.Count > 1 &&
        data.NodeCp.Count > 0 &&
        !System.Text.RegularExpressions.Regex.IsMatch(grp.Name, @"WGT_(rtm|battle|.uku1?|[0-9]p)[^0-9]*$")
      )
      {
        Toggle = 0; //0xBB474F4B
                    //Glasses = 0; //0xA50A10E2
        if (grp.NodeCp != -1)
        {
          foreach (var cp in data.NodeCp[grp.NodeCp].Cp)
          {
            if (cp.Data1 == 0xBB474F4B && cp.Param == 0)
            {
              Toggle = 1;
            }
            else if (cp.Data1 == 0xBB474F4B && cp.Param == 1)
            {
              Toggle = 2;
            }
            else if (cp.Data1 == 0xA50A10E2 && cp.Param == 0)
            {
              Toggle = 3;
            }
            else if (cp.Data1 == 0xA50A10E2 && cp.Param == 1)
            {
              Toggle = 4;
            }
          }
        }
      }
      if (grp.Node != -1) BlendIndicesCount = data.Node[grp.Node].ChildCount;

      EnvironmentMap = -1;

      Transparent = -1;

      //Z1 = data.ObjInfo[grp.ID].Z1.ToString("X2");
      Z2 = data.ObjInfo[grp.ID].Z2;

      Culling = (decimal)data.ObjInfo[grp.ID].FParams[20];
    }

    /// <summary>
    /// オブジェクトデータをセット（オブジェクト）
    /// </summary>
    /// <param name="data">TMCデータ</param>
    /// <param name="grp">オブジェクトグループ</param>
    /// <param name="obj">オブジェクト</param>
    private void SetData(TmcData data, ObjectGroup grp, ObjectPart obj)
    {
      for (int i = 0; i < grp.Decl.Count; i++) VtxIdxGruops.Add(grp.Decl[i].VtxGrpIndex);

      Name = grp.Name + "_" + obj.ID.ToString("x");
      ID = obj.ID;
      Grp = grp.ID;
      OriginalGrpIndex = grp.ID;

      //OriginalDecl = obj.DeclIndex;
      VtxGrp = obj.VtxGrpIndex;
      //IdxGrp = grp.Decl[obj.DeclIndex].IdxGrpIndex;
      VtxCount = obj.VtxCount;
      IdxCount = obj.IdxCount;
      OriginalTexCount = (byte)obj.TexCount;
      TexCount = (byte)obj.TexCount;
      UVCount = data.VtxGrp[obj.VtxGrpIndex].UVCount;

      int?[] texs = new int?[5];
      string checkTexType = "";
      for (byte i = 0; i < 5; i++)
      {
        if (obj.TexCount > i)
        {
          texs[i] = obj.Tex[i].Num;
          checkTexType += obj.Tex[i].Type;
          TexDataList.Add(obj.Tex[i].Data);
        }
      }
      Tex1 = texs[0];
      Tex2 = texs[1];
      Tex3 = texs[2];
      Tex4 = texs[3];
      Tex5 = texs[4];

      if (obj.TexCount > 0) SetTexType(UVCount, checkTexType);

      TexParam = new TexParamsData(obj);


      // Irregular Check
      //if (TexType != -1 && TexTypes[TexType] == "Error")
      //{
      //  System.Windows.MessageBox.Show("TexType Irregular -> " + Name + " / " + checkTexType);
      //}

      EnvironmentMap = obj.TexParams[2] % 8;
      if (checkTexType.IndexOf("3") != -1)
      {
        ChangeableEnvMap = true;
      }

      if (obj.Transparent1 != 0)
        Transparent = 1;
      else if (obj.Transparent2 != 0)
        Transparent = 2;
      else
        Transparent = 0;

      DoubleSided = (obj.DoubleSided == 0) ? false : true;
      MtrCol = obj.MtrColor;

      if (data.Itable.Count > 0) Matecp = data.Itable[grp.ID].Indices[obj.ID];
      if (data.McaIdx != null) Mcamtrl = data.McaIdx[grp.ID].MatID[obj.ID];

      Z1 = data.ObjInfo[grp.ID].Info[obj.ID].Z1.ToString("X2");
      Z2 = data.ObjInfo[grp.ID].Info[obj.ID].Z2;

      CastShadow = data.ObjInfo[grp.ID].Info[obj.ID].Params[2];
      ReceiveShadow = data.ObjInfo[grp.ID].Info[obj.ID].Params[3];

      Culling = (decimal)data.ObjInfo[grp.ID].Info[obj.ID].FParams[20];

      IsEditable = (VtxCount == 0 && IdxCount == 0) ? true : false;
    }


    #region Common

    /// <summary>
    /// 
    /// </summary>
    public int Index { get; set; }

    #region ID
    /// <summary>
    /// 
    /// </summary>
    private int _ID;
    public int ID
    {
      get => _ID;
      set => SetProperty(ref _ID, value);
    }
    #endregion

    /// <summary>
    /// 
    /// </summary>
    public int OriginalObjIndex { get; set; }

    /// <summary>
    /// 
    /// </summary>
    public int Grp { get; set; }

    /// <summary>
    /// 
    /// </summary>
    public int OriginalGrpIndex { get; set; }

    /// <summary>
    /// 
    /// </summary>
    public int LastGrpIndex { get; set; }

    #region Name
    /// <summary>
    /// 
    /// </summary>
    private string _Name;
    public string Name
    {
      get => _Name;
      set => SetProperty(ref _Name, value);
    }
    #endregion

    #region VtxCount
    /// <summary>
    /// 
    /// </summary>
    private int? _VtxCount;
    public int? VtxCount
    {
      get => _VtxCount;
      set => SetProperty(ref _VtxCount, value);
    }
    #endregion

    #region IdxCount
    /// <summary>
    /// 
    /// </summary>
    private int? _IdxCount;
    public int? IdxCount
    {
      get => _IdxCount;
      set => SetProperty(ref _IdxCount, value);
    }
    #endregion

    /// <summary>
    /// 
    /// </summary>
    public int DataIndex { get; set; }

    #region IsEditable
    /// <summary>
    /// 
    /// </summary>
    private bool _IsEditable;
    public bool IsEditable
    {
      get => _IsEditable;
      set => SetProperty(ref _IsEditable, value);
    }
    #endregion

    #region IsDeleted
    /// <summary>
    /// 
    /// </summary>
    private bool _IsDeleted;
    public bool IsDeleted
    {
      get => _IsDeleted;
      set => SetProperty(ref _IsDeleted, value);
    }
    #endregion

    #region IsVgrpChanged
    /// <summary>
    /// 
    /// </summary>
    private bool _IsVgrpChanged;
    public bool IsVgrpChanged
    {
      get => _IsVgrpChanged;
      set => SetProperty(ref _IsVgrpChanged, value);
    }
    #endregion

    #region IsAdded
    /// <summary>
    /// 
    /// </summary>
    private bool _IsAdded;
    public bool IsAdded
    {
      get => _IsAdded;
      set => SetProperty(ref _IsAdded, value);
    }
    #endregion

    #region IsBlendCleared
    /// <summary>
    /// 
    /// </summary>
    private bool _IsBlendCleared;
    public bool IsBlendCleared
    {
      get => _IsBlendCleared;
      set => SetProperty(ref _IsBlendCleared, value);
    }
    #endregion

    #endregion


    #region Object Group

    /// <summary>
    /// 
    /// </summary>
    public int Node { get; set; }

    #region Toggle
    /// <summary>
    /// 
    /// </summary>
    private int _Toggle;
    public int Toggle
    {
      get => _Toggle;
      set => SetProperty(ref _Toggle, value);
    }
    #endregion

    #region BlendIndicesCount
    /// <summary>
    /// 
    /// </summary>
    private int _BlendIndicesCount;
    public int BlendIndicesCount
    {
      get => _BlendIndicesCount;
      set => SetProperty(ref _BlendIndicesCount, value);
    }
    #endregion

    #endregion


    #region Object

    #region VtxGrp
    /// <summary>
    /// 
    /// </summary>
    private int? _VtxGrp;
    public int? VtxGrp
    {
      get => _VtxGrp;
      set => SetProperty(ref _VtxGrp, value);
    }
    #endregion

    /// <summary>
    /// 
    /// </summary>
    public byte? OriginalTexCount { get; set; }

    /// <summary>
    /// 
    /// </summary>
    public byte? TexCount { get; set; }

    #region UVCount
    /// <summary>
    /// 
    /// </summary>
    private int _UVCount;
    public int UVCount
    {
      get => _UVCount;
      set => SetProperty(ref _UVCount, value);
    }
    #endregion

    #region Tex1
    /// <summary>
    /// 
    /// </summary>
    private int? _Tex1;
    public int? Tex1
    {
      get => _Tex1;
      set => SetProperty(ref _Tex1, value);
    }
    #endregion

    #region Tex2
    /// <summary>
    /// 
    /// </summary>
    private int? _Tex2;
    public int? Tex2
    {
      get => _Tex2;
      set => SetProperty(ref _Tex2, value);
    }
    #endregion

    #region Tex3
    /// <summary>
    /// 
    /// </summary>
    private int? _Tex3;
    public int? Tex3
    {
      get => _Tex3;
      set => SetProperty(ref _Tex3, value);
    }
    #endregion

    #region Tex4
    /// <summary>
    /// 
    /// </summary>
    private int? _Tex4;
    public int? Tex4
    {
      get => _Tex4;
      set => SetProperty(ref _Tex4, value);
    }
    #endregion

    #region Tex5
    /// <summary>
    /// 
    /// </summary>
    private int? _Tex5;
    public int? Tex5
    {
      get => _Tex5;
      set => SetProperty(ref _Tex5, value);
    }
    #endregion

    /// <summary>
    /// 
    /// </summary>
    public int?[] RecentTexs { get; set; }

    /// <summary>
    /// 
    /// </summary>
    public char?[] RecentTexTypes { get; set; }

    #region TexType
    /// <summary>
    /// 
    /// </summary>
    private int _TexType;
    public int TexType
    {
      get => _TexType;
      set => SetProperty(ref _TexType, value);
    }
    #endregion

    /// <summary>
    /// 
    /// </summary>
    public List<dynamic[]> TexDataList { get; set; }

    #region EnvironmentMap
    /// <summary>
    /// 
    /// </summary>
    private int _EnvironmentMap;
    public int EnvironmentMap
    {
      get => _EnvironmentMap;
      set => SetProperty(ref _EnvironmentMap, value);
    }
    #endregion

    #region ChangeableEnvMap
    /// <summary>
    /// 
    /// </summary>
    private bool _ChangeableEnvMap;
    public bool ChangeableEnvMap
    {
      get => _ChangeableEnvMap;
      set => SetProperty(ref _ChangeableEnvMap, value);
    }
    #endregion

    #region Transparent
    /// <summary>
    /// 
    /// </summary>
    private int _Transparent;
    public int Transparent
    {
      get => _Transparent;
      set => SetProperty(ref _Transparent, value);
    }
    #endregion

    #region DoubleSided
    /// <summary>
    /// 
    /// </summary>
    private bool? _DoubleSided;
    public bool? DoubleSided
    {
      get => _DoubleSided;
      set => SetProperty(ref _DoubleSided, value);
    }
    #endregion

    #region MtrCol
    /// <summary>
    /// 
    /// </summary>
    private int? _MtrCol;
    public int? MtrCol
    {
      get => _MtrCol;
      set => SetProperty(ref _MtrCol, value);
    }
    #endregion

    #region Matecp
    /// <summary>
    /// 
    /// </summary>
    private int? _Matecp;
    public int? Matecp
    {
      get => _Matecp;
      set => SetProperty(ref _Matecp, value);
    }
    #endregion

    #region Type
    /// <summary>
    /// 
    /// </summary>
    private string _Type;
    public string Type
    {
      get => _Type;
      set => SetProperty(ref _Type, value);
    }
    #endregion

    #region Mcamtrl
    /// <summary>
    /// 
    /// </summary>
    private int? _Mcamtrl;
    public int? Mcamtrl
    {
      get => _Mcamtrl;
      set => SetProperty(ref _Mcamtrl, value);
    }
    #endregion

    #region Z1
    /// <summary>
    /// 
    /// </summary>
    private string _Z1;
    public string Z1
    {
      get => _Z1;
      set => SetProperty(ref _Z1, value);
    }
    #endregion

    #region Z2
    /// <summary>
    /// 
    /// </summary>
    private int _Z2;
    public int Z2
    {
      get => _Z2;
      set => SetProperty(ref _Z2, value);
    }
    #endregion

    #region CastShadow
    /// <summary>
    /// 
    /// </summary>
    private int _CastShadow;
    public int CastShadow
    {
      get => _CastShadow;
      set => SetProperty(ref _CastShadow, value);
    }
    #endregion

    #region ReceiveShadow
    /// <summary>
    /// 
    /// </summary>
    private int _ReceiveShadow;
    public int ReceiveShadow
    {
      get => _ReceiveShadow;
      set => SetProperty(ref _ReceiveShadow, value);
    }
    #endregion

    #region Culling
    /// <summary>
    /// 
    /// </summary>
    private decimal _Culling;
    public decimal Culling
    {
      get => _Culling;
      set => SetProperty(ref _Culling, value);
    }
    #endregion

    #endregion


    /// <summary>
    /// 
    /// </summary>
    public void SetTexType(int uvCount, string checkTexType)
    {
      if (TexTypes.Count != 0) TexTypes.Clear();
      TexType = -1;

      if (uvCount > 0)
      {
        for (int i = 0; i < ConstData.TexTypesSet[uvCount].Length; i++) TexTypes.Add(ConstData.TexTypesSet[uvCount][i]);

        for (int i = 0; i < TexTypes.Count; i++)
        {
          if (checkTexType == ConstData.TexTypesSet[uvCount][i].Replace(" ", ""))
          {
            TexType = i;
            break;
          }
        }

        if (TexType == -1)
        {
          TexType = TexTypes.Count;
          TexTypes.Add("Error");
        }
      }
    }


    #region TexParam
    /// <summary>
    /// テクスチャパラメータ
    /// </summary>
    private TexParamsData _TexParam;
    public TexParamsData TexParam
    {
      get => _TexParam;
      set => SetProperty(ref _TexParam, value);
    }
    #endregion

    /// <summary>
    /// VtxIdxGruops
    /// </summary>
    public ObservableCollection<int> VtxIdxGruops { get; set; }

    /// <summary>
    /// TexTypes
    /// </summary>
    public ObservableCollection<string> TexTypes { get; set; }



    /// <summary>
    /// ObjectDataを複製
    /// </summary>
    public ObjectData Clone()
    {
      ObjectData cloned = (ObjectData)MemberwiseClone();

      // 参照型フィールドの複製を作成する
      if (RecentTexs != null)
      {
        cloned.RecentTexs = (int?[])RecentTexs.Clone();
      }
      if (RecentTexTypes != null)
      {
        cloned.RecentTexTypes = (char?[])RecentTexTypes.Clone();
      }
      if (TexParam != null)
      {
        cloned.TexParam = TexParam.Clone();
      }

      return cloned;
    }
  }
}
