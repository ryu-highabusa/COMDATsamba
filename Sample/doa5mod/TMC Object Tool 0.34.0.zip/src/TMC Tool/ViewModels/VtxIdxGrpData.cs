﻿using System;
using System.Collections.ObjectModel;
using Common;
using Tmc;

namespace TMC_Tool.ViewModels
{
  [Serializable]
  public class VtxIdxGrpData : BindableBase
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    public VtxIdxGrpData()
    {
      IdxGrp = -1;
      OriginalIdxGrp = -1;
      ObjID = -1;
      DataIndex = -1;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name=""></param>
    /// <param name=""></param>
    public void SetVxtIdxGrpData(TmcData data, int idx)
    {
      IsEditable = false;
      Index = idx;
      OriginalIndex = idx;

      foreach (ObjectGroup grp in data.ObjGrp)
      {
        ushort[] declVtxCounts = new ushort[grp.Decl.Count];
        int[] declIdxCounts = new int[grp.Decl.Count];
        int[] useCounts = new int[grp.Decl.Count];

        if (grp.ChildCount == 0) continue;

        foreach (ObjectPart obj in grp.Obj)
        {
          declVtxCounts[obj.DeclIndex] += obj.VtxCount;
          declIdxCounts[obj.DeclIndex] += obj.IdxCount;
          useCounts[obj.DeclIndex] += 1;
        }

        for (int i = 0; i < grp.Decl.Count; i++)
        {
          if (grp.Decl[i].VtxGrpIndex == idx)
          {
            IdxGrp = grp.Decl[i].IdxGrpIndex;
            OriginalIdxGrp = grp.Decl[i].IdxGrpIndex;
            ObjName = grp.Name;
            ObjID = grp.ID;
            Use = useCounts[i];
            OriginalDecl = i;
            VtxCount = declVtxCounts[i];
            IdxCount = declIdxCounts[i];

            IsEditable = (VtxCount == 0 && IdxCount == 0) ? true : false;
            break;
          }
        }
      }

      if (ObjID == -1) return;

      var vtxGrp = data.VtxGrp[idx];

      Datasize = String.Format("0x{0:X2}", (byte)vtxGrp.DataSize);

      Position = (vtxGrp.Position != -1);
      PositionType = DeclType(vtxGrp.Position);

      Normal = (vtxGrp.Normal != -1);
      NormalType = DeclType(vtxGrp.Normal);

      BWeights = (vtxGrp.BlendWeight.Count > 0);
      if (BWeights)
        BWeightsType = DeclType(vtxGrp.BlendWeight[0]);
      else
        BWeightsType = "";

      BIndices = (vtxGrp.BlendIndices.Count > 0);
      if (BIndices)
        BIndicesType = DeclType(vtxGrp.BlendIndices[0]);
      else
        BIndicesType = "";

      Color = (vtxGrp.Color != -1);
      ColorType = DeclType(vtxGrp.Color);

      Tangent = (vtxGrp.Tangent != -1);
      TangentType = DeclType(vtxGrp.Tangent);

      UVCount = (byte)vtxGrp.UVCount;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name=""></param>
    /// <param name=""></param>
    public void ResetVxtIdxGrpData(TmcData data, int idx)
    {
      if (!IsChanged) return;

      var vtxGrp = data.VtxGrp[idx];

      Datasize = String.Format("0x{0:X2}", (byte)vtxGrp.DataSize);

      Position = (vtxGrp.Position != -1);

      Normal = (vtxGrp.Normal != -1);

      BWeights = (vtxGrp.BlendWeight.Count > 0);

      BIndices = (vtxGrp.BlendIndices.Count > 0);

      Color = (vtxGrp.Color != -1);

      Tangent = (vtxGrp.Tangent != -1);

      UVCount = (byte)vtxGrp.UVCount;

      IsChanged = false;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name=""></param>
    public void ReCalcDataSize()
    {
      string curDatasize = Datasize;


      int datasize = 0;
      if (Position)
      {
        if (PositionType == "Float4")
          datasize += 0x10;
        else
          datasize += 0x0C;
      }
      if (Normal)
      {
        if (NormalType == "Float4")
          datasize += 0x10;
        else
          datasize += 0x0C;
      }
      if (BWeights)
      {
        if (BWeightsType == "Float4")
          datasize += 0x10;
        else
          datasize += 4;
      }
      if (BIndices) datasize += 4;
      if (Color) datasize += 4;
      if (Tangent)
      {
        if (BWeightsType == "Float4") datasize += 0x0C;
        datasize += 0x10;
      }
      datasize += UVCount * 4;

      if (BWeightsType == "Float4" && datasize % 0x10 != 0) datasize += 0x10 - datasize % 0x10;

      Datasize = String.Format("0x{0:X2}", datasize);


      if (Datasize != curDatasize && !IsAdded) IsChanged = true;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name=""></param>
    /// <returns></returns>
    private static string DeclType(int num)
    {
      string type = "";
      switch (num)
      {
        case 2:
          type = "Float3";
          break;
        case 3:
          type = "Float4";
          break;
        case 5:
          type = "Byte4";
          break;
        case 13:
          type = "Dec4";
          break;
        case -1:
          type = "";
          break;
        default:
          type = "Other";
          break;
      }
      return type;
    }


    
    #region IsEditable
    /// <summary>
    /// 
    /// </summary>
    private bool _IsEditable;
    public bool IsEditable
    {
      get => _IsEditable;
      set => SetProperty(ref _IsEditable, value);
    }
    #endregion

    #region IsChanged
    /// <summary>
    /// 
    /// </summary>
    private bool _IsChanged;
    public bool IsChanged
    {
      get => _IsChanged;
      set => SetProperty(ref _IsChanged, value);
    }
    #endregion

    #region IsAdded
    /// <summary>
    /// 
    /// </summary>
    private bool _IsAdded;
    public bool IsAdded
    {
      get => _IsAdded;
      set => SetProperty(ref _IsAdded, value);
    }
    #endregion

    #region Index
    /// <summary>
    /// 
    /// </summary>
    private int _Index;
    public int Index
    {
      get => _Index;
      set => SetProperty(ref _Index, value);
    }
    #endregion

    /// <summary>
    /// 
    /// </summary>
    public int OriginalIndex { get; set; }

    /// <summary>
    /// 
    /// </summary>
    public int IdxGrp { get; set; }

    /// <summary>
    /// 
    /// </summary>
    public int OriginalIdxGrp { get; set; }

    #region VtxCount
    /// <summary>
    /// 
    /// </summary>
    private ushort _VtxCount;
    public ushort VtxCount
    {
      get => _VtxCount;
      set => SetProperty(ref _VtxCount, value);
    }
    #endregion

    #region IdxCount
    /// <summary>
    /// 
    /// </summary>
    private int _IdxCount;
    public int IdxCount
    {
      get => _IdxCount;
      set => SetProperty(ref _IdxCount, value);
    }
    #endregion

    /// <summary>
    /// 
    /// </summary>
    public string ObjName { get; set; }

    /// <summary>
    /// 
    /// </summary>
    public int ObjID { get; set; }

    #region Use
    /// <summary>
    /// 
    /// </summary>
    private int _Use;
    public int Use
    {
      get => _Use;
      set => SetProperty(ref _Use, value);
    }
    #endregion

    #region Datasize
    /// <summary>
    /// 
    /// </summary>
    private string _Datasize;
    public string Datasize
    {
      get => _Datasize;
      set => SetProperty(ref _Datasize, value);
    }
    #endregion

    /// <summary>
    /// 
    /// </summary>
    public int? OriginalDecl { get; set; }


    /// <summary>
    /// 
    /// </summary>
    public bool Position { get; set; }

    #region Normal
    /// <summary>
    /// 
    /// </summary>
    private bool _Normal;
    public bool Normal
    {
      get => _Normal;
      set => SetProperty(ref _Normal, value);
    }
    #endregion

    #region BWeights
    /// <summary>
    /// 
    /// </summary>
    private bool _BWeights;
    public bool BWeights
    {
      get => _BWeights;
      set => SetProperty(ref _BWeights, value);
    }
    #endregion

    #region BIndices
    /// <summary>
    /// 
    /// </summary>
    private bool _BIndices;
    public bool BIndices
    {
      get => _BIndices;
      set => SetProperty(ref _BIndices, value);
    }
    #endregion

    #region Color
    /// <summary>
    /// 
    /// </summary>
    private bool _Color;
    public bool Color
    {
      get => _Color;
      set => SetProperty(ref _Color, value);
    }
    #endregion

    #region Tangent
    /// <summary>
    /// 
    /// </summary>
    private bool _Tangent;
    public bool Tangent
    {
      get => _Tangent;
      set => SetProperty(ref _Tangent, value);
    }
    #endregion

    #region UVCount
    /// <summary>
    /// 
    /// </summary>
    private byte _UVCount;
    public byte UVCount
    {
      get => _UVCount;
      set => SetProperty(ref _UVCount, value);
    }
    #endregion


    /// <summary>
    /// 
    /// </summary>
    public string PositionType { get; set; }

    #region NormalType
    /// <summary>
    /// 
    /// </summary>
    private string _NormalType;
    public string NormalType
    {
      get => _NormalType;
      set => SetProperty(ref _NormalType, value);
    }
    #endregion

    #region BWeightsType
    /// <summary>
    /// 
    /// </summary>
    private string _BWeightsType;
    public string BWeightsType
    {
      get => _BWeightsType;
      set => SetProperty(ref _BWeightsType, value);
    }
    #endregion

    #region BIndicesType
    /// <summary>
    /// 
    /// </summary>
    private string _BIndicesType;
    public string BIndicesType
    {
      get => _BIndicesType;
      set => SetProperty(ref _BIndicesType, value);
    }
    #endregion

    #region ColorType
    /// <summary>
    /// 
    /// </summary>
    private string _ColorType;
    public string ColorType
    {
      get => _ColorType;
      set => SetProperty(ref _ColorType, value);
    }
    #endregion

    #region TangentType
    /// <summary>
    /// 
    /// </summary>
    private string _TangentType;
    public string TangentType
    {
      get => _TangentType;
      set => SetProperty(ref _TangentType, value);
    }
    #endregion


    /// <summary>
    /// 
    /// </summary>
    public int DataIndex { get; set; }


    /// <summary>
    /// 
    /// </summary>
    public ObservableCollection<int> VtxIdxGruops { get; set; }
  }
}
