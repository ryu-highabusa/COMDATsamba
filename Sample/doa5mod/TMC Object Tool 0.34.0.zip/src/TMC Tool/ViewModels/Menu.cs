﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Media3D;
using SystemHalf;
using Common;
using Tmc;
using TMC_Tool.Models;
using Language;
using Message;

namespace TMC_Tool.ViewModels
{
  public class Menu : BindableBase
  {
    public Menu(MainWindowViewModel data)
    {
      Data = data;
      IsEnabledGetMaterials = true;
      IsEnabledAddObj = true;
    }



    #region メソッド：コンテキストメニュー

    /// <summary>
    /// オブジェクトDataGridのメニューの状態を変更
    /// </summary>
    /// <param name="dataGrid">DataGridオブジェクト</param>
    public void CheckMenuStateObject(DataGrid dataGrid)
    {
      bool isSelectedGroupOnly = true;
      foreach (ObjectData obj in dataGrid.SelectedItems)
      {
        if (obj.Grp != -1)
        {
          isSelectedGroupOnly = false;
          break;
        }
      }

      if (isSelectedGroupOnly)
      {
        MenuStateObjectGroup(dataGrid);
      }
      else
      {
        MenuStateObject(dataGrid);
      }
    }

    /// <summary>
    /// オブジェクトグループ用メニューの状態を変更
    /// </summary>
    /// <param name="dataGrid">DataGridオブジェクト</param>
    public void MenuStateObjectGroup(DataGrid dataGrid)
    {
      // オブジェクトグループ用メニューを表示
      VisibilityMenuObjGrp = Visibility.Visible;

      // オブジェクト用メニューを非表示
      VisibilityMenuObj = Visibility.Collapsed;


      // 追加・リネーム・削除
      bool addable = false;
      bool renamable = false;
      bool deletable = false;

      if (dataGrid.SelectedItems.Count == 1)
      {
        addable = true;

        var item = dataGrid.SelectedItem as ObjectData;
        if (item.Name.Substring(0, 4) == "WGT_" || Data.TmcData.Physics == null || Data.TmcData.Physics.Count == 0)
        {
          renamable = true;
        }
      }

      var ObjGrpCount = Data.ObjData.Where(elem => elem.Grp == -1).Count();
      if (ObjGrpCount > dataGrid.SelectedItems.Count)
      {
        deletable = true;
      }

      IsEnabledAddObjGrp = addable;
      IsEnabledRenameObjGrp = renamable;
      IsEnabledDeleteObjGrp = deletable;


      // BlendIdxの削除
      bool deletableBlendIdx = false;
      bool cancelableDeleteBlendIdx = false;
      foreach (ObjectData item in dataGrid.SelectedItems)
      {
        if (!item.IsBlendCleared && CheckDeletableBlendIdx(item))
        {
          deletableBlendIdx = true;
        }
        if (item.IsBlendCleared)
        {
          cancelableDeleteBlendIdx = true;
        }
      }

      IsEnabledClearBlendIdx = deletableBlendIdx;
      IsEnabledCancelClearBlendIdx = cancelableDeleteBlendIdx;
    }

    /// <summary>
    /// BlendIdxを削除できるかどうかをチェック
    /// </summary>
    /// <param name="objData">オブジェクトデータ</param>
    private bool CheckDeletableBlendIdx(ObjectData objData)
    {
      if (Data.TmcData.Node[Data.Nodes[objData.Node].AddedIndex].ChildCount == 0)
      {
        return false;
      }

      int vtxCount = 0;
      int idxCount = 0;
      foreach (var obj in Data.ObjData)
      {
        if (obj.Grp == objData.ID)
        {
          vtxCount += (int)obj.VtxCount;
          idxCount += (int)obj.IdxCount;
        }
      }
      if (vtxCount > 0 || idxCount > 0)
      {
        return false;
      }

      return true;
    }

    /// <summary>
    /// オブジェクト用メニューの状態を変更
    /// </summary>
    /// <param name="dataGrid">DataGridオブジェクト</param>
    public void MenuStateObject(DataGrid dataGrid)
    {
      // オブジェクトグループ用メニューを非表示
      VisibilityMenuObjGrp = Visibility.Collapsed;

      // オブジェクト用メニューを表示
      VisibilityMenuObj = Visibility.Visible;


      bool deletable = false;
      bool dataDeletable = false;
      bool dataDeleted = false;
      bool vgrpChanged = false;
      bool vtxIdxGrpDataChanged = false;
      bool dataExtractable = false;

      foreach (ObjectData obj in dataGrid.SelectedItems)
      {
        if (obj.Grp != -1)
        {
          if (Data.ObjCounts[obj.Grp] > 1)
          {
            deletable = true;
          }

          if (obj.VtxCount > 1 && obj.IdxCount > 2)
          {
            TmcData data;

            if (obj.DataIndex == -1)
              data = Data.TmcData;
            else
              data = Data.OtherTmcDataList[obj.DataIndex];

            if (data.Node[data.ObjGrp[obj.OriginalGrpIndex].Node].ObjIndex > -1) dataExtractable = true;
          }

          if (Data.VIData[(int)obj.VtxGrp].IsChanged)
          {
            vtxIdxGrpDataChanged = true;
          }
          else if (obj.IsVgrpChanged)
          {
            vgrpChanged = true;
          }
          else if (obj.IsDeleted)
          {
            dataDeleted = true;
          }
          else if (!obj.IsDeleted && !(obj.VtxCount == 0 && obj.IdxCount == 0 && !obj.IsDeleted))
          {
            dataDeletable = true;
          }
        }
      }


      IsEnabledDeleteObj = deletable;

      if (vtxIdxGrpDataChanged)
      {
        IsEnabledDeleteData = false;
        IsEnabledCancelDeleteData = false;
        IsEnabledExtractMeshes = false;
        return;
      }

      IsEnabledDeleteData = dataDeletable;
      IsEnabledCancelDeleteData = (dataDeleted && !vgrpChanged);
      IsEnabledExtractMeshes = dataExtractable;
    }

    /// <summary>
    /// 頂点・IdxグループDataGridのメニューの状態を変更
    /// </summary>
    /// <param name="dataGrid">DataGridオブジェクト</param>
    public void CheckMenuStateVtxIdxGrp(DataGrid dataGrid)
    {
      bool deletable = false;
      bool deletableData = false;
      bool changed = false;

      foreach (VtxIdxGrpData grp in dataGrid.SelectedItems)
      {
        if (grp.Use == 0) deletable = true;

        foreach (var obj in Data.ObjData)
        {
          if (obj.VtxGrp == grp.Index && (obj.VtxCount != 0 || obj.IdxCount != 0))
          {
            deletableData = true;
            break;
          }
        }

        if (grp.IsChanged) changed = true;
      }

      if (dataGrid.SelectedItems.Count == 1)
      {
        VtxIdxGrpData item = dataGrid.SelectedItem as VtxIdxGrpData;
        if (item.ObjID != -1) IsEnabledAddVtxIdxGrp = true;
      }

      IsEnabledDeleteVtxIdxGrp = deletable;

      IsEnabledDeleteDataGrp = deletableData;

      IsEnabledCancelChangeVtxIdxGrp = changed;
    }

    #endregion



    #region コマンド：オブジェクトグループを追加
    /// <summary>
    /// コマンド：オブジェクトグループを追加
    /// </summary>
    private DelegateCommand _AddObjGrpCommand;
    public DelegateCommand AddObjGrpCommand
      => _AddObjGrpCommand ?? (_AddObjGrpCommand = new DelegateCommand(AddObjGrpExecute, () => IsEnabledAddObjGrp));

    /// <summary>
    /// コマンド：オブジェクトグループを追加 の実行を行います。
    /// </summary>
    private void AddObjGrpExecute()
    {
      Console.WriteLine("オブジェクトグループを追加");
    }
    #endregion

    #region コマンド：オブジェクトグループの名前を変更
    /// <summary>
    /// コマンド：オブジェクトグループの名前を変更
    /// </summary>
    private DelegateCommand _RenameObjGrpCommand;
    public DelegateCommand RenameObjGrpCommand
      => _RenameObjGrpCommand ?? (_RenameObjGrpCommand = new DelegateCommand(RenameObjGrpExecute, () => IsEnabledRenameObjGrp));

    /// <summary>
    /// コマンド：オブジェクトグループの名前を変更 の実行を行います。
    /// </summary>
    private void RenameObjGrpExecute()
    {
      Console.WriteLine("オブジェクトグループの名前を変更");
    }
    #endregion

    #region コマンド：オブジェクトグループを削除
    /// <summary>
    /// コマンド：オブジェクトグループを削除
    /// </summary>
    private DelegateCommand _DeleteObjGrpCommand;
    public DelegateCommand DeleteObjGrpCommand
      => _DeleteObjGrpCommand ?? (_DeleteObjGrpCommand = new DelegateCommand(DeleteObjGrpExecute, () => IsEnabledDeleteObjGrp));

    /// <summary>
    /// コマンド：オブジェクトグループを削除 の実行を行います。
    /// </summary>
    private void DeleteObjGrpExecute()
    {
      Console.WriteLine("オブジェクトグループを削除");
    }
    #endregion

    #region コマンド：Blend Indexを削除
    /// <summary>
    /// コマンド：Blend Indexを削除
    /// </summary>
    private DelegateCommand _ClearBlendIdxCommand;
    public DelegateCommand ClearBlendIdxCommand
      => _ClearBlendIdxCommand ?? (_ClearBlendIdxCommand = new DelegateCommand(ClearBlendIdxExecute, () => IsEnabledClearBlendIdx));

    /// <summary>
    /// コマンド：Blend Indexを削除 の実行を行います。
    /// </summary>
    private void ClearBlendIdxExecute()
    {
      Console.WriteLine("Blend Indexを削除");
    }
    #endregion

    #region コマンド：Blend Indexの削除を取り消し
    /// <summary>
    /// コマンド：Blend Indexの削除を取り消し
    /// </summary>
    private DelegateCommand _CancelClearBlendIdxCommand;
    public DelegateCommand CancelClearBlendIdxCommand
      => _CancelClearBlendIdxCommand ?? (_CancelClearBlendIdxCommand = new DelegateCommand(CancelClearBlendIdxExecute, () => IsEnabledCancelClearBlendIdx));

    /// <summary>
    /// コマンド：Blend Indexの削除を取り消し の実行を行います。
    /// </summary>
    private void CancelClearBlendIdxExecute()
    {
      Console.WriteLine("Blend Indexの削除を取り消し");
    }
    #endregion



    #region コマンド：オブジェクトを追加
    /// <summary>
    /// コマンド：オブジェクトを追加
    /// </summary>
    private DelegateCommand _AddObjCommand;
    public DelegateCommand AddObjCommand
      => _AddObjCommand ?? (_AddObjCommand = new DelegateCommand(AddObjExecute, () => IsEnabledAddObj));

    /// <summary>
    /// コマンド：オブジェクトを追加 の実行を行います。
    /// </summary>
    private void AddObjExecute()
    {
      Console.WriteLine("オブジェクトを追加");
    }
    #endregion

    #region コマンド：オブジェクトを削除
    /// <summary>
    /// コマンド：オブジェクトを削除
    /// </summary>
    private DelegateCommand _DeleteObjCommand;
    public DelegateCommand DeleteObjCommand
      => _DeleteObjCommand ?? (_DeleteObjCommand = new DelegateCommand(DeleteObjExecute, () => IsEnabledDeleteObj));

    /// <summary>
    /// コマンド：オブジェクトを削除 の実行を行います。
    /// </summary>
    private void DeleteObjExecute()
    {
      Console.WriteLine("オブジェクトを削除");
    }
    #endregion

    #region コマンド：頂点・Idxを全て削除
    /// <summary>
    /// コマンド：頂点・Idxを全て削除
    /// </summary>
    private DelegateCommand _DeleteDataCommand;
    public DelegateCommand DeleteDataCommand
      => _DeleteDataCommand ?? (_DeleteDataCommand = new DelegateCommand(DeleteDataExecute, () => IsEnabledDeleteData));

    /// <summary>
    /// コマンド：頂点・Idxを全て削除 の実行を行います。
    /// </summary>
    private void DeleteDataExecute()
    {
      Console.WriteLine("頂点・Idxを全て削除");
    }
    #endregion

    #region コマンド：全て削除を取り消し
    /// <summary>
    /// コマンド：全て削除を取り消し
    /// </summary>
    private DelegateCommand _CancelDeleteDataCommand;
    public DelegateCommand CancelDeleteDataCommand
      => _CancelDeleteDataCommand ?? (_CancelDeleteDataCommand = new DelegateCommand(CancelDeleteDataExecute, () => IsEnabledCancelDeleteData));

    /// <summary>
    /// コマンド：全て削除を取り消し の実行を行います。
    /// </summary>
    private void CancelDeleteDataExecute()
    {
      Console.WriteLine("全て削除を取り消し");
    }
    #endregion

    #region コマンド：マテリアル情報を取得して変更
    /// <summary>
    /// コマンド：マテリアル情報を取得して変更
    /// </summary>
    private DelegateCommand _GetMaterialsCommand;
    public DelegateCommand GetMaterialsCommand
      => _GetMaterialsCommand ?? (_GetMaterialsCommand = new DelegateCommand(GetMaterialsExecute, () => IsEnabledGetMaterials));

    /// <summary>
    /// コマンド：マテリアル情報を取得して変更 の実行を行います。
    /// </summary>
    private void GetMaterialsExecute()
    {
      Console.WriteLine("マテリアル情報を取得して変更");
    }
    #endregion

    #region コマンド：メッシュデータを抽出
    /// <summary>
    /// コマンド：メッシュデータを抽出
    /// </summary>
    private DelegateCommand _ExtractMeshesCommand;
    public DelegateCommand ExtractMeshesCommand
      => _ExtractMeshesCommand ?? (_ExtractMeshesCommand = new DelegateCommand(ExtractMeshesExecute, () => IsEnabledExtractMeshes));

    /// <summary>
    /// コマンド：メッシュデータを抽出 の実行を行います。
    /// </summary>
    private void ExtractMeshesExecute()
    {
      Console.WriteLine("メッシュデータを抽出");
    }
    #endregion



    #region コマンド：既存の頂点・Idxグループを元に追加
    /// <summary>
    /// コマンド：既存の頂点・Idxグループを元に追加
    /// </summary>
    private DelegateCommand _AddVtxIdxGrpCommand;
    public DelegateCommand AddVtxIdxGrpCommand
      => _AddVtxIdxGrpCommand ?? (_AddVtxIdxGrpCommand = new DelegateCommand(AddVtxIdxGrpExecute, () => IsEnabledAddVtxIdxGrp));

    /// <summary>
    /// コマンド：既存の頂点・Idxグループを元に追加 の実行を行います。
    /// </summary>
    private void AddVtxIdxGrpExecute()
    {
      Console.WriteLine("既存の頂点・Idxグループを元に追加");
    }
    #endregion

    #region コマンド：削除（頂点・Idxグループ）
    /// <summary>
    /// コマンド：削除（頂点・Idxグループ）
    /// </summary>
    private DelegateCommand _DeleteVtxIdxGrpCommand;
    public DelegateCommand DeleteVtxIdxGrpCommand
      => _DeleteVtxIdxGrpCommand ?? (_DeleteVtxIdxGrpCommand = new DelegateCommand(DeleteVtxIdxGrpExecute, () => IsEnabledDeleteVtxIdxGrp));

    /// <summary>
    /// コマンド：削除（頂点・Idxグループ） の実行を行います。
    /// </summary>
    private void DeleteVtxIdxGrpExecute()
    {
      Console.WriteLine("削除（頂点・Idxグループ）");
    }
    #endregion

    #region コマンド：頂点・Idxを全て削除（頂点・Idxグループ）
    /// <summary>
    /// コマンド：頂点・Idxを全て削除（頂点・Idxグループ）
    /// </summary>
    private DelegateCommand _DeleteDataGrpCommand;
    public DelegateCommand DeleteDataGrpCommand
      => _DeleteDataGrpCommand ?? (_DeleteDataGrpCommand = new DelegateCommand(DeleteDataGrpExecute, () => IsEnabledDeleteDataGrp));

    /// <summary>
    /// コマンド：頂点・Idxを全て削除（頂点・Idxグループ） の実行を行います。
    /// </summary>
    private void DeleteDataGrpExecute()
    {
      Console.WriteLine("頂点・Idxを全て削除（頂点・Idxグループ）");
    }
    #endregion

    #region コマンド：変更を取り消し
    /// <summary>
    /// コマンド：変更を取り消し
    /// </summary>
    private DelegateCommand _CancelChangeVtxIdxGrpCommand;
    public DelegateCommand CancelChangeVtxIdxGrpCommand
      => _CancelChangeVtxIdxGrpCommand ?? (_CancelChangeVtxIdxGrpCommand = new DelegateCommand(CancelChangeVtxIdxGrpExecute, () => IsEnabledCancelChangeVtxIdxGrp));

    /// <summary>
    /// コマンド：変更を取り消し の実行を行います。
    /// </summary>
    private void CancelChangeVtxIdxGrpExecute()
    {
      Console.WriteLine("変更を取り消し");
    }
    #endregion



    /// <summary>
    /// MainWindowViewModelデータ
    /// </summary>
    public MainWindowViewModel Data { get; set; }


    #region プロパティ：コンテキストメニュー - オブジェクトグループ

    #region VisibilityMenuObjGrp
    /// <summary>
    /// オブジェクトグループのコンテキストメニューの表示状態
    /// </summary>
    private Visibility _VisibilityMenuObjGrp;
    public Visibility VisibilityMenuObjGrp
    {
      get => _VisibilityMenuObjGrp;
      set => SetProperty(ref _VisibilityMenuObjGrp, value);
    }
    #endregion

    #region IsEnabledAddObjGrp
    /// <summary>
    /// AddObjGrpが有効かどうか
    /// </summary>
    private bool _IsEnabledAddObjGrp;
    public bool IsEnabledAddObjGrp
    {
      get => _IsEnabledAddObjGrp;
      set => SetProperty(ref _IsEnabledAddObjGrp, value);
    }
    #endregion

    #region IsEnabledRenameObjGrp
    /// <summary>
    /// RenameObjGrpが有効かどうか
    /// </summary>
    private bool _IsEnabledRenameObjGrp;
    public bool IsEnabledRenameObjGrp
    {
      get => _IsEnabledRenameObjGrp;
      set => SetProperty(ref _IsEnabledRenameObjGrp, value);
    }
    #endregion

    #region IsEnabledDeleteObjGrp
    /// <summary>
    /// DeleteObjGrpが有効かどうか
    /// </summary>
    private bool _IsEnabledDeleteObjGrp;
    public bool IsEnabledDeleteObjGrp
    {
      get => _IsEnabledDeleteObjGrp;
      set => SetProperty(ref _IsEnabledDeleteObjGrp, value);
    }
    #endregion

    #region IsEnabledClearBlendIdx
    /// <summary>
    /// ClearBlendIdxが有効かどうか
    /// </summary>
    private bool _IsEnabledClearBlendIdx;
    public bool IsEnabledClearBlendIdx
    {
      get => _IsEnabledClearBlendIdx;
      set => SetProperty(ref _IsEnabledClearBlendIdx, value);
    }
    #endregion

    #region IsEnabledCancelClearBlendIdx
    /// <summary>
    /// CancelClearBlendIdxが有効かどうか
    /// </summary>
    private bool _IsEnabledCancelClearBlendIdx;
    public bool IsEnabledCancelClearBlendIdx
    {
      get => _IsEnabledCancelClearBlendIdx;
      set => SetProperty(ref _IsEnabledCancelClearBlendIdx, value);
    }
    #endregion

    #endregion

    #region プロパティ：コンテキストメニュー - オブジェクト

    #region VisibilityMenuObj
    /// <summary>
    /// オブジェクトのコンテキストメニューの表示状態
    /// </summary>
    private Visibility _VisibilityMenuObj;
    public Visibility VisibilityMenuObj
    {
      get => _VisibilityMenuObj;
      set => SetProperty(ref _VisibilityMenuObj, value);
    }
    #endregion

    #region IsEnabledAddObj
    /// <summary>
    /// AddObjが有効かどうか
    /// </summary>
    private bool _IsEnabledAddObj;
    public bool IsEnabledAddObj
    {
      get => _IsEnabledAddObj;
      set => SetProperty(ref _IsEnabledAddObj, value);
    }
    #endregion

    #region IsEnabledDeleteObj
    /// <summary>
    /// DeleteObjが有効かどうか
    /// </summary>
    private bool _IsEnabledDeleteObj;
    public bool IsEnabledDeleteObj
    {
      get => _IsEnabledDeleteObj;
      set => SetProperty(ref _IsEnabledDeleteObj, value);
    }
    #endregion

    #region IsEnabledDeleteData
    /// <summary>
    /// DeleteDataが有効かどうか
    /// </summary>
    private bool _IsEnabledDeleteData;
    public bool IsEnabledDeleteData
    {
      get => _IsEnabledDeleteData;
      set => SetProperty(ref _IsEnabledDeleteData, value);
    }
    #endregion

    #region IsEnabledCancelDeleteData
    /// <summary>
    /// CancelDeleteDataが有効かどうか
    /// </summary>
    private bool _IsEnabledCancelDeleteData;
    public bool IsEnabledCancelDeleteData
    {
      get => _IsEnabledCancelDeleteData;
      set => SetProperty(ref _IsEnabledCancelDeleteData, value);
    }
    #endregion

    #region IsEnabledGetMaterials
    /// <summary>
    /// GetMaterialが有効かどうか
    /// </summary>
    private bool _IsEnabledGetMaterials;
    public bool IsEnabledGetMaterials
    {
      get => _IsEnabledGetMaterials;
      set => SetProperty(ref _IsEnabledGetMaterials, value);
    }
    #endregion

    #region IsEnabledExtractMeshes
    /// <summary>
    /// ExtractMeshesが有効かどうか
    /// </summary>
    private bool _IsEnabledExtractMeshes;
    public bool IsEnabledExtractMeshes
    {
      get => _IsEnabledExtractMeshes;
      set => SetProperty(ref _IsEnabledExtractMeshes, value);
    }
    #endregion

    #endregion

    #region プロパティ：コンテキストメニュー - 頂点・Idxグループ

    #region IsEnabledAddVtxIdxGrp
    /// <summary>
    /// AddVtxIdxGrpが有効かどうか
    /// </summary>
    private bool _IsEnabledAddVtxIdxGrp;
    public bool IsEnabledAddVtxIdxGrp
    {
      get => _IsEnabledAddVtxIdxGrp;
      set => SetProperty(ref _IsEnabledAddVtxIdxGrp, value);
    }
    #endregion

    #region IsEnabledDeleteVtxIdxGrp
    /// <summary>
    /// DeleteVtxIdxGrpが有効かどうか
    /// </summary>
    private bool _IsEnabledDeleteVtxIdxGrp;
    public bool IsEnabledDeleteVtxIdxGrp
    {
      get => _IsEnabledDeleteVtxIdxGrp;
      set => SetProperty(ref _IsEnabledDeleteVtxIdxGrp, value);
    }
    #endregion

    #region IsEnabledDeleteDataGrp
    /// <summary>
    /// DeleteDataGrpが有効かどうか
    /// </summary>
    private bool _IsEnabledDeleteDataGrp;
    public bool IsEnabledDeleteDataGrp
    {
      get => _IsEnabledDeleteDataGrp;
      set => SetProperty(ref _IsEnabledDeleteDataGrp, value);
    }
    #endregion

    #region IsEnabledCancelChangeVtxIdxGrp
    /// <summary>
    /// CancelChangeVtxIdxGrpが有効かどうか
    /// </summary>
    private bool _IsEnabledCancelChangeVtxIdxGrp;
    public bool IsEnabledCancelChangeVtxIdxGrp
    {
      get => _IsEnabledCancelChangeVtxIdxGrp;
      set => SetProperty(ref _IsEnabledCancelChangeVtxIdxGrp, value);
    }
    #endregion

    #endregion
  }
}
