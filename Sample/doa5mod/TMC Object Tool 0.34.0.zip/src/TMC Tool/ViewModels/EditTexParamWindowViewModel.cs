﻿using System;
using System.Windows;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Common;
using Language;
using Message;

namespace TMC_Tool.ViewModels
{
  public class EditTexParamWindowViewModel : BindableBase
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    public EditTexParamWindowViewModel(EditTexParamWindow window, MainWindowViewModel data)
    {
      Txt = MainWindow.Txt;
      Window = window;
      MainData = data;
    }

    public void SetData(ObjectData obj)
    {
      CheckModified = false;

      if (obj == null || obj.Grp == -1)
      {
        ParamsData = null;
        IsEnabled = false;
      }
      else
      {
        ParamsData = obj.TexParam;
        IsEnabled = true;

        if (ParamsData.ParamSets.Count > 0)
        {
          SelectedIndex = 0;
        }
      }

      CheckModified = true;
    }

    public void SelectionChanged()
    {
      CheckModified = false;

      if (SelectedIndex == -1 || Window.dgTextures.SelectedItems.Count > 1)
      {
        Params = null;
        IsEnabledParams = false;
      }
      else
      {
        Params = ParamsData.ParamSets[SelectedIndex];
        IsEnabledParams = Params.IsEnabled;
      }

      CheckModified = true;
    }

    private object GetDataFromClipboard()
    {
      try
      {
        IDataObject clipboardData = Clipboard.GetDataObject();
        if (clipboardData != null)
        {
          if (clipboardData.GetDataPresent(typeof(MemoryStream)))
          {
            using (MemoryStream stream = clipboardData.GetData(typeof(MemoryStream)) as MemoryStream)
            {
              BinaryFormatter bf = new BinaryFormatter();
              return bf.Deserialize(stream);
            }
          }
        }
        return null;
      }
      catch (Exception e)
      {
        MessageWindow.Show(Window, e.Message + "\r\n\r\n" + e.StackTrace, Txt.Error);
        return null;
      }
    }


    #region メインウィンドウコマンド

    #region コマンド：開く
    /// <summary>
    /// コマンド：開く
    /// </summary>
    private DelegateCommand _OpenCommand;
    public DelegateCommand OpenCommand
      => _OpenCommand ?? (_OpenCommand = new DelegateCommand(MainData.OpenExecute, () => true));
    #endregion

    #region コマンド：上書き保存
    /// <summary>
    /// コマンド：上書き保存
    /// </summary>
    private DelegateCommand _SaveCommand;
    public DelegateCommand SaveCommand
      => _SaveCommand ?? (_SaveCommand = new DelegateCommand(MainData.SaveExecute, MainData.CanSaveExecute));
    #endregion

    #region コマンド：上書き保存（バックアップを作成）
    /// <summary>
    /// コマンド：上書き保存（バックアップを作成）
    /// </summary>
    private DelegateCommand _SaveWithBackupCommand;
    public DelegateCommand SaveWithBackupCommand
      => _SaveWithBackupCommand ?? (_SaveWithBackupCommand = new DelegateCommand(MainData.SaveWithBackupExecute, MainData.CanSaveWithBackupExecute));
    #endregion

    #region コマンド：別名で保存
    /// <summary>
    /// コマンド：別名で保存
    /// </summary>
    private DelegateCommand _SaveAsCommand;
    public DelegateCommand SaveAsCommand
      => _SaveAsCommand ?? (_SaveAsCommand = new DelegateCommand(MainData.SaveAsExecute, MainData.CanSaveAsExecute));
    #endregion

    #region コマンド：クリップボードのパステキストからファイルを開く
    /// <summary>
    /// コマンド：クリップボードのパステキストからファイルを開く
    /// </summary>
    private DelegateCommand _PathPasteCommand;
    public DelegateCommand PathPasteCommand
      => _PathPasteCommand ?? (_PathPasteCommand = new DelegateCommand(MainData.PathPasteCommandExecute, () => true));
    #endregion

    #region コマンド：終了
    /// <summary>
    /// コマンド：終了
    /// </summary>
    private DelegateCommand _CloseCommand;
    public DelegateCommand CloseCommand
      => _CloseCommand ?? (_CloseCommand = new DelegateCommand(MainData.CloseCommandExecute, () => true));
    #endregion

    #endregion


    #region コマンド：パラメータをコピー
    /// <summary>
    /// コマンド：パラメータをコピー
    /// </summary>
    private DelegateCommand _CopyParamsCommand;
    public DelegateCommand CopyParamsCommand
      => _CopyParamsCommand ?? (_CopyParamsCommand = new DelegateCommand(CopyParamsExecute, CanCopyParamsExecute));

    /// <summary>
    /// コマンド：パラメータをコピー の実行を行います。
    /// </summary>
    public void CopyParamsExecute()
    {
      if (SelectedIndex == -1 || Window.dgTextures.SelectedItems.Count > 1) return;

      var texParams = ParamsData.ParamSets[SelectedIndex];
      if (texParams != null)
      {
        BinaryFormatter bf = new BinaryFormatter();
        MemoryStream ms = new MemoryStream();
        bf.Serialize(ms, texParams);
        Clipboard.SetDataObject(ms);
      }
    }

    /// <summary>
    /// コマンド：パラメータをコピー が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    public bool CanCopyParamsExecute()
    {
      if (SelectedIndex == -1 || Window.dgTextures.SelectedItems.Count > 1)
        return false;
      else
        return true;
    }
    #endregion

    #region コマンド：パラメータを貼り付け
    /// <summary>
    /// コマンド：パラメータを貼り付け
    /// </summary>
    private DelegateCommand _PasteParamsCommand;
    public DelegateCommand PasteParamsCommand
      => _PasteParamsCommand ?? (_PasteParamsCommand = new DelegateCommand(PasteParamsExecute, CanPasteParamsExecute));

    /// <summary>
    /// コマンド：パラメータを貼り付け の実行を行います。
    /// </summary>
    public void PasteParamsExecute()
    {
      foreach (TexParameters texParams in Window.dgTextures.SelectedItems)
      {
        texParams.ParamsCopy(ClipboardParams);
      }

      MainData.Modified();
    }

    /// <summary>
    /// コマンド：パラメータを貼り付け が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    public bool CanPasteParamsExecute()
    {
      ClipboardParams = null;
      var data = GetDataFromClipboard();
      if (data is TexParameters)
        ClipboardParams = data as TexParameters;

      if (ClipboardParams != null)
        return true;
      else
        return false;
    }
    #endregion

    #region コマンド：ウィンドウを閉じる
    /// <summary>
    /// コマンド：ウィンドウを閉じる
    /// </summary>
    private DelegateCommand _CloseWindowCommand;
    public DelegateCommand CloseWindowCommand
      => _CloseWindowCommand ?? (_CloseWindowCommand = new DelegateCommand(CloseWindowCommandExecute, () => true));

    /// <summary>
    /// コマンド：ウィンドウを閉じる の実行を行います。
    /// </summary>
    public void CloseWindowCommandExecute()
    {
      Window.Close();
    }
    #endregion



    private Lang.Text Txt;

    private MainWindowViewModel MainData;

    private EditTexParamWindow Window { get; set; }

    public bool CheckModified { get; set; }

    #region IsEnabled
    /// <summary>
    /// IsEnabled
    /// </summary>
    private bool _IsEnabled;
    public bool IsEnabled
    {
      get => _IsEnabled;
      set => SetProperty(ref _IsEnabled, value);
    }
    #endregion

    #region IsEnabledParams
    /// <summary>
    /// IsEnabledParams
    /// </summary>
    private bool _IsEnabledParams;
    public bool IsEnabledParams
    {
      get => _IsEnabledParams;
      set => SetProperty(ref _IsEnabledParams, value);
    }
    #endregion

    #region ParamsData
    /// <summary>
    /// ParamsData
    /// </summary>
    private TexParamsData _ParamsData;
    public TexParamsData ParamsData
    {
      get => _ParamsData;
      set => SetProperty(ref _ParamsData, value);
    }
    #endregion

    #region Params
    /// <summary>
    /// 
    /// </summary>
    private TexParameters _Params;
    public TexParameters Params
    {
      get => _Params;
      set => SetProperty(ref _Params, value);
    }
    #endregion

    #region ClipboardParams
    /// <summary>
    /// ClipboardParams
    /// </summary>
    private TexParameters _ClipboardParams;
    public TexParameters ClipboardParams
    {
      get => _ClipboardParams;
      set => SetProperty(ref _ClipboardParams, value);
    }
    #endregion

    #region SelectedIndex
    /// <summary>
    /// 
    /// </summary>
    private int _SelectedIndex;
    public int SelectedIndex
    {
      get => _SelectedIndex;
      set => SetProperty(ref _SelectedIndex, value);
    }
    #endregion

  }

}
