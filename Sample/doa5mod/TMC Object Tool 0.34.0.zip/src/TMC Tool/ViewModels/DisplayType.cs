﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows.Media.Media3D;
using System.ComponentModel;
using System.Linq;
using Tmc;

namespace TMC_Tool.ViewModels
{
  public class DisplayType
  {
    private string _type;
    public string Type
    {
      get { return _type; }
      set { _type = value; }
    }
  }
}
