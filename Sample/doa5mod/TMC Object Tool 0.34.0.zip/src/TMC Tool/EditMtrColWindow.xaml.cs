﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.ComponentModel;
using Tmc;
using Language;
using TMC_Tool.ViewModels;

namespace TMC_Tool
{
  /// <summary>
  /// EditMaterialWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class EditMtrColWindow : Window
  {
    private static Lang.Text Txt;

    private static EditMtrColWindowViewModel Data;

    private static bool dialogResult;

    private bool IsActivated = false;

    public EditMtrColWindow()
    {
      InitializeComponent();

      Data = new EditMtrColWindowViewModel(this);
      this.DataContext = Data;

      Data.InitParamsInput();

      this.MouseLeftButtonDown += (sender, e) => this.DragMove();
      this.ShowInTaskbar = false;

      Txt = MainWindow.Txt;

      title.Text = Txt.editMtrColTitle;
      btnAdd.Content = Txt.Add;
      btnGet.Content = Txt.Get;
      btnDel.Content = Txt.Del;
      labelInfluenceObj.Content = Txt.InfluenceObj;
      btnOk.Content = Txt.OK;
      btnCancel.Content = Txt.Cancel;
    }

    private void Window_Activated(object sender, EventArgs e)
    {
      if (!IsActivated) IsActivated = true;
    }

    private void Window_Closing(object sender, CancelEventArgs e)
    {
      e.Cancel = true;
      IsActivated = false;
      this.Hide();
      if (this.Owner != null) this.Owner.Activate();
    }

    private void btnOk_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = true;
      this.Close();
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = false;
    }

    private void dgMtrCols_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (!this.IsInitialized) return;

      Data.SelectionChanged();
    }

    public void tbParam_PreviewKeyDown(object sender, KeyEventArgs e)
    {
      TextBox textBox = sender as TextBox;

      e.Handled = Data.ParamPreviewKeyDown(e.Key, textBox);
    }

    public void tbParam_KeyDown(object sender, KeyEventArgs e)
    {
      TextBox textBox = sender as TextBox;

      e.Handled = Data.ParamKeyDown(e.Key, textBox);
    }

    public void tbParam_LostFocus(object sender, RoutedEventArgs e)
    {
      TextBox textBox = sender as TextBox;

      Data.ParamLostFocus(textBox);
    }

    public void tb_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (target == null) return;
      target.SelectAll();
    }


    public EditMtrColWindowViewModel Show(Window owner, MainWindowViewModel mainData, int index)
    {
      this.Owner = owner;
      this.Owner.IsEnabled = false;
      MainWindow.DoEvents();

      Data.SetData(mainData, index);

      if (this.ActualHeight != 0)
      {
        this.Top = owner.Top + (owner.ActualHeight / 2) - (this.ActualHeight / 2);
        this.Left = owner.Left + (owner.ActualWidth / 2) - (this.ActualWidth / 2);
      }

      if (index != -1)
      {
        dgMtrCols.ScrollIntoView(dgMtrCols.Items[index]);
      }

      IsActivated = false;
      this.ShowDialog();

      this.Owner.IsEnabled = true;
      this.Owner.Focus();

      if (dialogResult)
        return Data;
      else
        return null;
    }
  }
}
