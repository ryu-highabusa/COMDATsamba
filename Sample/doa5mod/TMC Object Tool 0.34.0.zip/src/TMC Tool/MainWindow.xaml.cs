﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Data;
using System.Reflection;
using System.ComponentModel;
using TMC_Tool.ViewModels;
using Language;
using Message;

namespace TMC_Tool
{
  /// <summary>
  /// MainWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class MainWindow : Window
  {
    private static MainWindowViewModel Data;

    public static Lang lang;
    public static Lang.Text Txt;

    private static bool appStarted = false;
    public static bool UpdateChecking = true;

    private static bool cellEdited = false;

    private static bool dragFlag;
    private static Point offset;
    private static bool togetherMove = true;
    private static double currentLeft;
    private static double currentTop;



    public MainWindow()
    {
      InitializeComponent();

      lang = new Lang(this);
      Txt = lang.Txt;
      MessageWindow.SetTxt(Txt);

      Data = new MainWindowViewModel(this);
      this.DataContext = Data;


      DisplayType[] visibleTypes = dgObject.Resources["VisibleTypes"] as DisplayType[];
      visibleTypes[1].Type = Txt.Visible;
      visibleTypes[2].Type = Txt.Hidden;
      visibleTypes[3].Type = Txt.Glasses + "1";
      visibleTypes[4].Type = Txt.Glasses + "2";

      Application.Current.ShutdownMode = ShutdownMode.OnMainWindowClose;
    }

    private void mainWindow_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      if (e.LeftButton == MouseButtonState.Released) return;

      dragFlag = true; // ドラッグ開始
      offset = e.GetPosition(this); // 開始位置の記録

      if (this.Left == Data.EditTexParamWindow.Left && this.Top + this.ActualHeight == Data.EditTexParamWindow.Top)
        togetherMove = true;
      else
        togetherMove = false;

      this.CaptureMouse();
      if (e.ClickCount > 1)
        this.ReleaseMouseCapture();
    }

    private void mainWindow_MouseMove(object sender, MouseEventArgs e)
    {
      if (dragFlag) // ドラッグ時のみ
      {
        Point p = e.GetPosition(this); // 現在のマウス座標
        // ウィンドウを移動
        this.Left += p.X - offset.X;
        this.Top += p.Y - offset.Y;
        // ウィンドウを追従
        if (togetherMove)
        {
          Data.EditTexParamWindow.Left += p.X - offset.X;
          Data.EditTexParamWindow.Top += p.Y - offset.Y;
        }
      }
    }

    private void mainWindow_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
      dragFlag = false; // ドラッグ終了
      this.ReleaseMouseCapture();
    }

    private void mainWindow_MouseLeave(object sender, MouseEventArgs e)
    {
      dragFlag = false; // ドラッグ終了
      this.ReleaseMouseCapture();
    }

    private void mainWindow_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
      Point p = e.GetPosition(this); // 現在のマウス座標
      if (p.Y < 28 && p.X < this.ActualWidth - 90)
      {
        if (this.WindowState == WindowState.Normal)
        {
          currentLeft = this.Left;
          currentTop = this.Top;
          this.WindowState = WindowState.Maximized;
        }
        else
        {
          this.WindowState = WindowState.Normal;
          this.Left = currentLeft;
          this.Top = currentTop;
        }
      }
    }

    private void mainWindow_Loaded(object sender, RoutedEventArgs e)
    {
      List<string> cmds = System.Environment.GetCommandLineArgs().ToList();
      cmds.RemoveAt(0);
      Data.OpenDorpFile(cmds, false);
    }

    private void mainWindow_DragOver(object sender, DragEventArgs e)
    {
      e.Handled = true;
      if (e.Data.GetDataPresent(DataFormats.FileDrop))
      {
        if ((e.KeyStates & DragDropKeyStates.ControlKey) != 0)
          e.Effects = DragDropEffects.Copy;
        else
          e.Effects = DragDropEffects.Move;
      }
      else
      {
        e.Effects = DragDropEffects.None;
      }
    }

    private void mainWindow_DragDrop(object sender, DragEventArgs e)
    {
      List<string> filePaths = ((string[])e.Data.GetData(DataFormats.FileDrop, false)).ToList();
      if ((e.KeyStates & DragDropKeyStates.ControlKey) != 0)
        Data.OpenDorpFile(filePaths, true);
      else
        Data.OpenDorpFile(filePaths, false);
    }

    private void mainWindow_IsEnabledChanged(object sender, DependencyPropertyChangedEventArgs e)
    {
      if (Data.EditTexParamWindow.Visibility == Visibility.Visible)
      {
        Data.EditTexParamWindow.IsEnabled = this.IsEnabled;
      }
    }

    private void dgObject_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (Data.EditTexParamWindow.Visibility != Visibility.Visible) return;

      if (dgObject.SelectedItems.Count == 1)
      {
        var obj = dgObject.SelectedItem as ObjectData;
        Data.EditTexParamWindow.Data.SetData(obj);
      }
      else
      {
        Data.EditTexParamWindow.Data.SetData(null);
      }
    }

    private void ComboBox_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      if (!Data.IsTmclLoaded) return;

      ComboBox target = sender as ComboBox;

      SourceUpdate(dgObject);

      DataGridRow dataGridRow = Common.Styles.FindVisualParent<DataGridRow>(target);
      var curItem = dataGridRow.Item as ObjectData;

      if (!dgObject.SelectedItems.Contains(curItem)) dgObject.SelectedItem = curItem;

      DataGridCell cell = Common.Styles.FindVisualParent<DataGridCell>(target);

      int lastSelectedIndex = target.SelectedIndex;
      int index = Data.SelectTextureWindow.Show(this, lastSelectedIndex, curItem, cell.Column.Header.ToString());

      if (index == -1 || lastSelectedIndex == index) return;

      if (dgObject.SelectedItems.Count > 1)
      {
        var b = BindingOperations.GetBinding(target, ComboBox.SelectedItemProperty) as Binding;
        if (b == null || b.Path == null)
        {
          return;
        }
        var p = b.Path.Path;
        if (string.IsNullOrEmpty(p)) return;
        var i = p.LastIndexOf('.');

        if (i < 0)
        {
          Type type = target.DataContext.GetType();
          PropertyInfo pi = type.GetProperty(p);

          int val = index;

          foreach (var selItem in dgObject.SelectedItems)
          {
            var item = selItem as ObjectData;

            dynamic valDist = pi.GetValue(Data.Tables.ObjData[dgObject.Items.IndexOf(item)]);
            if (valDist != null)
            {
              pi.SetValue(Data.Tables.ObjData[dgObject.Items.IndexOf(item)], val, null);
            }
          }
        }
      }
      else
      {
        target.SelectedIndex = index;
      }

      Data.Modified();
      CommandManager.InvalidateRequerySuggested();
    }

    private void ComboBox_PreviewMouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
      e.Handled = true;
    }

    private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      ComboBox target = sender as ComboBox;

      if (!Data.IsModified && (target.IsMouseCaptured || target.IsKeyboardFocused))
      {
        Data.Modified();
        CommandManager.InvalidateRequerySuggested();
      }

      if (target.IsMouseCaptured || target.IsKeyboardFocused)
      {
        DataGrid dataGrid = Common.Styles.FindVisualParent<DataGrid>(target);
        DataGridRow dataGridRow = Common.Styles.FindVisualParent<DataGridRow>(target);
        dynamic curItem;
        dynamic data = Data.Tables.ObjData;
        if (dataGrid.Name == "dgObject")
        {
          curItem = dataGridRow.Item as ObjectData;
        }
        else
        {
          data = Data.Tables.VIData;
          curItem = dataGridRow.Item as VtxIdxGrpData;
        }

        bool selIndex = false;

        var b = BindingOperations.GetBinding(target, ComboBox.SelectedItemProperty) as Binding;
        if (b == null || b.Path == null)
        {
          b = BindingOperations.GetBinding(target, ComboBox.SelectedIndexProperty) as Binding;
          if (b == null || b.Path == null)
          {
            return;
          }
          selIndex = true;
        }
        var p = b.Path.Path;
        if (string.IsNullOrEmpty(p)) return;
        var i = p.LastIndexOf('.');

        if (i < 0)
        {
          List<ObjectData> unableTransparentObjects = new List<ObjectData>();

          if (dataGrid.SelectedItems.Count > 1)
          {
            Type type = target.DataContext.GetType();
            PropertyInfo pi = type.GetProperty(p);

            dynamic val = target.SelectedItem;
            if (selIndex)
            {
              val = target.SelectedIndex;
            }

            foreach (var selItem in dataGrid.SelectedItems)
            {
              dynamic item;
              if (dataGrid.Name == "dgObject")
              {
                item = selItem as ObjectData;
              }
              else
              {
                item = selItem as VtxIdxGrpData;
              }

              dynamic valDist = pi.GetValue(data[dataGrid.Items.IndexOf(item)]);
              if (valDist != null && !((p == "Toggle" || p == "Glasses" || p == "Transparent" || p == "CastShadow" || p == "ReceiveShadow") && valDist == -1))
              {
                if (p == "TexType")
                {
                  if (item.UVCount == curItem.UVCount)
                  {
                    pi.SetValue(data[dataGrid.Items.IndexOf(item)], val, null);
                    Data.Tables.ChangeTexType(item, val);
                  }
                }
                else if (p == "EnvironmentMap")
                {
                  if (item.ChangeableEnvMap)
                  {
                    pi.SetValue(data[dataGrid.Items.IndexOf(item)], val, null);
                  }
                }
                else if (p == "Transparent")
                {
                  pi.SetValue(data[dataGrid.Items.IndexOf(item)], val, null);
                  if (val > 0) unableTransparentObjects.Add(item);
                }
                else if (p == "Matecp")
                {
                  pi.SetValue(data[dataGrid.Items.IndexOf(item)], val, null);
                  Data.Tables.CheckObjectType(item);
                }
                else if (p == "VtxGrp")
                {
                  if (item.VtxIdxGruops.IndexOf(val) != -1)
                  {
                    pi.SetValue(data[dataGrid.Items.IndexOf(item)], val, null);
                    Data.Tables.RebuildTexData(Data.Tables.VIData[item.VtxGrp], Data);
                    Data.Tables.ReCalcGrpUseCount(item.Grp);
                    Data.Tables.ResetVIDataIdxGrp();
                    item.IsVgrpChanged = true;
                  }
                }
                else if (p == "UVCount" && item.IsEditable)
                {
                  pi.SetValue(data[dataGrid.Items.IndexOf(item)], val, null);
                  Data.Tables.RebuildTexData(item, Data);
                  item.ReCalcDataSize();
                }
                else if (dataGrid.Name != "dgVtxIdxGrp")
                {
                  pi.SetValue(data[dataGrid.Items.IndexOf(item)], val, null);
                }
              }
            }

            if (unableTransparentObjects.Count > 0)
            {
              Data.CheckEnableTransparent(unableTransparentObjects);
            }
          }
          else
          {
            if (p == "TexType")
            {
              Data.Tables.ChangeTexType(curItem, (int)curItem.TexType);
            }
            else if (p == "Transparent" && target.SelectedIndex > 0)
            {
              unableTransparentObjects.Add(curItem);
              Data.CheckEnableTransparent(unableTransparentObjects);
            }
            else if (p == "Matecp")
            {
              Data.Tables.CheckObjectType(curItem);
            }
            else if (p == "VtxGrp")
            {
              Data.Tables.RebuildTexData(Data.Tables.VIData[curItem.VtxGrp], Data);
              Data.Tables.ReCalcGrpUseCount(curItem.Grp);
              Data.Tables.ResetVIDataIdxGrp();
              curItem.IsVgrpChanged = true;
            }
            else if (p == "UVCount")
            {
              Data.Tables.RebuildTexData(curItem, Data);
              curItem.ReCalcDataSize();
            }
          }
        }
      }
    }

    private void CheckBox_Click(object sender, RoutedEventArgs e)
    {
      CheckBox target = sender as CheckBox;

      Data.Modified();

      DataGrid dataGrid = Common.Styles.FindVisualParent<DataGrid>(target);
      DataGridRow dataGridRow = Common.Styles.FindVisualParent<DataGridRow>(target);
      dynamic data = Data.Tables.ObjData;
      dynamic curItem = dataGridRow.Item as ObjectData;
      if (dataGrid.Name == "dgVtxIdxGrp")
      {
        data = Data.Tables.VIData;
        curItem = dataGridRow.Item as VtxIdxGrpData;
      }
      var b = BindingOperations.GetBinding(target, CheckBox.IsCheckedProperty) as Binding;
      if (b == null || b.Path == null)
      {
        return;
      }
      var p = b.Path.Path;
      if (string.IsNullOrEmpty(p)) return;
      var i = p.LastIndexOf('.');

      if (i < 0)
      {
        if (dataGrid.SelectedItems.Count > 1)
        {
          Type type = target.DataContext.GetType();
          PropertyInfo pi = type.GetProperty(p);

          if (dataGrid.Name == "dgObject")
          {
            foreach (ObjectData item in dataGrid.SelectedItems)
            {
              dynamic valDist = pi.GetValue(data[dataGrid.Items.IndexOf(item)]);
              if (valDist != null)
              {
                pi.SetValue(data[dataGrid.Items.IndexOf(item)], (bool)target.IsChecked, null);
              }
            }
          }
          else if (dataGrid.Name == "dgVtxIdxGrp")
          {
            foreach (VtxIdxGrpData item in dataGrid.SelectedItems)
            {
              dynamic valDist = pi.GetValue(data[dataGrid.Items.IndexOf(item)]);
              if (valDist != null && item.IsEditable)
              {
                pi.SetValue(data[dataGrid.Items.IndexOf(item)], (bool)target.IsChecked, null);
                Data.SetVIDataChanged(p, item, (bool)target.IsChecked);
              }
            }
          }
        }
        else
        {
          if (dataGrid.Name == "dgVtxIdxGrp")
          {
            Data.SetVIDataChanged(p, curItem, (bool)target.IsChecked);
          }
        }
      }
    }

    private void ComboBox_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
    {
      ComboBox target = sender as ComboBox;
      DataGrid dataGrid = Common.Styles.FindVisualParent<DataGrid>(target);
      DataGridRow row = Common.Styles.FindVisualParent<DataGridRow>(target);
      if (!row.IsSelected)
      {
        var item = row.Item;
        dataGrid.SelectedIndex = dataGrid.Items.IndexOf(item);
        SetShiftSelectBase(dataGrid, row, 0);
      }
    }


    private void EditCell_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      DataGridCell cell = sender as DataGridCell;
      if (cell != null && !cell.IsEditing && !cell.IsReadOnly)
      {
        if (!cell.IsFocused)
        {
          cell.Focus();
        }

        DataGridRow row = Common.Styles.FindVisualParent<DataGridRow>(cell);
        if (row != null && !row.IsSelected)
        {
          dgObject.SelectedIndex = -1;
          row.IsSelected = true;
        }

        dgObject.BeginEdit();
      }
    }

    private void CellTextBox_KeyUp(object sender, KeyEventArgs e)
    {
      bool updated = false;

      TextBox target = sender as TextBox;

      if ((Key.D0 <= e.Key && e.Key <= Key.D9) || (Key.NumPad0 <= e.Key && e.Key <= Key.NumPad9))
      {
        updated = true;
      }
      else if (e.Key == Key.Decimal || e.Key == Key.OemPeriod)
      {
        if (target.Text.IndexOf(".") < 0 || target.SelectedText.IndexOf(".") >= 0)
        {
          updated = true;
        }
      }
      else if (e.Key == Key.Divide || e.Key == Key.Subtract)
      {
        if ((target.Text == target.SelectedText || target.SelectionStart == 0) &&
            (target.Text.IndexOf("-") < 0 || target.SelectedText.IndexOf("-") >= 0))
        {
          updated = true;
        }
      }
      else
      {
        DataGrid dataGrid = Common.Styles.FindVisualParent<DataGrid>(target);
        DataGridRow dataGridRow = Common.Styles.FindVisualParent<DataGridRow>(target);
        var curItem = dataGridRow.Item as ObjectData;
        var data = Data.Tables.ObjData;

        var b = BindingOperations.GetBinding(target, TextBox.TextProperty) as Binding;
        if (b == null || b.Path == null)
        {
          return;
        }
        var p = b.Path.Path;
        if (string.IsNullOrEmpty(p)) return;
        var i = p.LastIndexOf('.');

        if (i < 0)
        {
          if (p == "Culling" && curItem.Culling.ToString() != target.Text)
          {
            updated = true;
          }
        }
      }


      if (updated)
      {
        cellEdited = true;

        Data.Modified();
      }
    }

    private void CellTextBox_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (target.IsFocused == false)
      {
        target.Focus();
        e.Handled = true;
      }
    }

    private void CellTextBox_GotFocus(object sender, RoutedEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (target == null) return;
      target.SelectAll();
    }

    private void dgObject_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
    {
      if (dgObject.SelectedItems.Count > 1 && cellEdited)
      {
        DataGrid target = sender as DataGrid;
        var tb = e.EditingElement as TextBox;

        if (!decimal.TryParse(tb.Text, out decimal val)) return;

        var b = BindingOperations.GetBinding(tb, TextBox.TextProperty) as Binding;
        if (b == null || b.Path == null)
        {
          return;
        }
        var p = b.Path.Path;
        if (string.IsNullOrEmpty(p)) return;
        var i = p.LastIndexOf('.');

        if (i < 0)
        {
          Type type = tb.DataContext.GetType();
          PropertyInfo pi = type.GetProperty(p);

          foreach (var selItem in dgObject.SelectedItems)
          {
            var item = selItem as ObjectData;

            dynamic valDist = pi.GetValue(Data.Tables.ObjData[dgObject.Items.IndexOf(item)]);
            if (valDist != null)
            {
              pi.SetValue(Data.Tables.ObjData[dgObject.Items.IndexOf(item)], val, null);
            }
          }

          Data.Modified();
        }
      }

      cellEdited = false;
    }

    public static void SourceUpdate(DataGrid dataGrid)
    {
      TextBox textBox = Keyboard.FocusedElement as TextBox;

      if (dataGrid == null || textBox == null) return;

      BindingExpression ex = textBox.GetBindingExpression(TextBox.TextProperty);
      if (ex != null) ex.UpdateSource();

      IEditableCollectionView collectionView = (IEditableCollectionView)CollectionViewSource.GetDefaultView(dataGrid.Items);
      if (collectionView != null)
      {
        dataGrid.CommitEdit();
        if (collectionView.IsEditingItem) collectionView.CommitEdit();
      }
    }


    private void dgObject_ContextMenuOpening(object sender, ContextMenuEventArgs e)
    {
      try
      {
        DataGrid dataGrid = sender as DataGrid;
        if (dataGrid.SelectedItems.Count == 0)
        {
          e.Handled = true;
          return;
        }

        Data.CheckMenuStateObject(dataGrid);
      }
      catch (Exception ex)
      {
        MessageWindow.Show(this, ex.Message + "\r\n\r\n" + ex.StackTrace, Txt.Error);
      }
    }
  }
}
