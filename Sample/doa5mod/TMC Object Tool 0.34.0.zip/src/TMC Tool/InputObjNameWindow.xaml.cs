﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.ComponentModel;
using Common;
using Tmc;
using TMC_Tool.ViewModels;
using Language;

namespace TMC_Tool
{
  /// <summary>
  /// EditMaterialWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class InputObjNameWindow : Window
  {
    private static Lang.Text Txt;

    private static InputObjNameWindowViewModel Data;

    private static bool dialogResult;

    private bool IsActivated = false;

    public InputObjNameWindow()
    {
      InitializeComponent();

      this.MouseLeftButtonDown += (sender, e) => this.DragMove();
      this.ShowInTaskbar = false;

      Txt = MainWindow.Txt;

      title.Text = Txt.inputObjNameTitle;
      btnOk.Content = Txt.OK;
      btnCancel.Content = Txt.Cancel;
    }

    private void Window_Activated(object sender, EventArgs e)
    {
      if (!IsActivated)
      {
        IsActivated = true;
        tbName.Focus();
        tbName.SelectAll();
      }
    }

    private void Window_Closing(object sender, CancelEventArgs e)
    {
      e.Cancel = true;
      IsActivated = false;
      this.Hide();
      if (this.Owner != null) this.Owner.Activate();
    }

    private void btnOk_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = true;
      this.Close();
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = false;
    }

    private void tbName_KeyDown(object sender, KeyEventArgs e)
    {
      ModifierKeys modifierKeys = Keyboard.Modifiers;

      if (e.Key == Key.Enter && btnOk.IsEnabled == true)
      {
        dialogResult = true;
        this.Close();
      }

      e.Handled = RestrictionKey.ForName(e.Key);
    }

    private void tb_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (target == null) return;
      target.SelectAll();
    }

    public static string Show(Window owner, TmcData tmcData, DataTables tables, string curName, bool addObjGrp)
    {
      var dlg = new InputObjNameWindow();
      dlg.Owner = owner;
      dlg.Owner.IsEnabled = false;

      Data = new InputObjNameWindowViewModel();
      dlg.DataContext = Data;

      Data.SetData(tables);

      if (dlg.ActualHeight != 0)
      {
        dlg.Top = owner.Top + (owner.ActualHeight / 2) - (dlg.ActualHeight / 2);
        dlg.Left = owner.Left + (owner.ActualWidth / 2) - (dlg.ActualWidth / 2);
      }

      bool freeName = (tmcData.Physics == null || tmcData.Physics.Count == 0);

      if (freeName)
        Data.CollapsePrefix();

      if (addObjGrp)
        Data.CheckNameNum(curName, freeName);
      else if (freeName)
        Data.Name = curName;
      else
        Data.Name = curName.Substring(4);

      dlg.IsActivated = false;
      dlg.ShowDialog();

      dlg.Owner.IsEnabled = true;
      dlg.Owner.Focus();

      if (dialogResult)
        return freeName ? Data.Name : "WGT_" + Data.Name;
      else
        return null;
    }
  }
}
