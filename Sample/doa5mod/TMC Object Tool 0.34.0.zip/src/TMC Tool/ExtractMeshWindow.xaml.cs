﻿using System;
using System.Windows;
using System.ComponentModel;
using Language;
using TMC_Tool.ViewModels;

namespace TMC_Tool
{
  /// <summary>
  /// ObjGrpSelectWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class ExtractMeshWindow : Window
  {
    private static ExtractMeshWindowViewModel Data;

    private static Lang.Text Txt;

    private static bool dialogResult;
    private bool IsActivated = false;

    public ExtractMeshWindow()
    {
      InitializeComponent();

      this.MouseLeftButtonDown += (sender, e) => this.DragMove();
      this.ShowInTaskbar = false;

      Txt = MainWindow.Txt;

      title.Text = Txt.extractMeshDataTitle;

      gbFileName.Header = Txt.tbFileName;
      rbWithFileName.Content = Txt.rbWithFileName;
      rbObjectNameOnly.Content = Txt.rbObjectNameOnly;
      cbExceptUnusedBlendIndex.Content = Txt.ExceptUnusedBlendIndex;
      cbCreateDir.Content = Txt.cbCreateDir;
      cbOverwrite.Content = Txt.cbOverwrite;

      btnExtract.Content = Txt.btnExtract;
      btnCancel.Content = Txt.Cancel;

      Data = new ExtractMeshWindowViewModel();
      this.DataContext = Data;
    }

    private void Window_Activated(object sender, EventArgs e)
    {
      if (!IsActivated)
      {
        IsActivated = true;
      }
    }

    private void Window_Closing(object sender, CancelEventArgs e)
    {
      e.Cancel = true;
      IsActivated = false;
      this.Hide();
      if (this.Owner != null) this.Owner.Activate();
    }

    private void btnExtract_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = true;
      this.Close();
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = false;
    }
    
    public ExtractMeshWindowViewModel Show(Window owner)
    {
      this.Owner = owner;
      this.Owner.IsEnabled = false;

      if (this.ActualHeight != 0)
      {
        this.Top = owner.Top + (owner.ActualHeight / 2) - (this.ActualHeight / 2);
        this.Left = owner.Left + (owner.ActualWidth / 2) - (this.ActualWidth / 2);
      }

      this.ShowDialog();

      this.Owner.IsEnabled = true;
      this.Owner.Focus();

      if (dialogResult)
        return Data;
      else
        return null;
    }
  }
}
