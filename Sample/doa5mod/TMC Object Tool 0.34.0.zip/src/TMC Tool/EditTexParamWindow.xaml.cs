﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.ComponentModel;
using Language;
using TMC_Tool.ViewModels;

namespace TMC_Tool
{
  /// <summary>
  /// EditTexParamWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class EditTexParamWindow : Window
  {
    private static Lang.Text Txt;

    private MainWindow Window;

    private static MainWindowViewModel MainData;

    public EditTexParamWindowViewModel Data;


    public EditTexParamWindow(MainWindowViewModel data)
    {
      InitializeComponent();

      this.MouseLeftButtonDown += (sender, e) => this.DragMove();
      this.ShowInTaskbar = false;

      Txt = MainWindow.Txt;

      MainData = data;

      title.Text = Txt.TextureParameters;

      labelBaseParam.Content = Txt.BaseParameters;
      labelBaseParamNote.Content = Txt.NoteHex;

      labelAnimationSlide.Content = Txt.AnimationSlide;
      labelSpeedU.Content = Txt.SpeedU;
      labelSpeedV.Content = Txt.SpeedV;

      labelAnimationMultiple.Content = Txt.AnimationMultiple;
      labelCount.Content = Txt.Count;
      labelSkip.Content = Txt.Skip;
      labelFramesPerTex.Content = Txt.FramesPerTex;
      cbRepeat.Content = Txt.Repeat;

      texParamsCopy.Header = Txt.Copy;
      texParamsPaste.Header = Txt.Paste;

      Data = new EditTexParamWindowViewModel(this, data);
      this.DataContext = Data;
    }

    private void Window_Closing(object sender, CancelEventArgs e)
    {
      e.Cancel = true;
      this.Hide();
      if (this.Owner != null) this.Owner.Activate();
    }

    private void editMatecpWindow_MouseDown(object sender, MouseButtonEventArgs e)
    {
      mainPanel.Focus();
    }

    private void dgTextures_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (!this.IsInitialized || Data == null) return;

      Data.SelectionChanged();
    }

    private void dgTextures_ContextMenuOpening(object sender, ContextMenuEventArgs e)
    {
      dgTextures.Focus();

      // なぜか有効になる事への対応
      if (dgTextures.SelectedIndex == -1 || dgTextures.SelectedItems.Count > 1)
        texParamsCopy.IsEnabled = false;
      else
        texParamsCopy.IsEnabled = true;
    }

    private void tbHex_KeyDown(object sender, KeyEventArgs e)
    {
      TextBox target = sender as TextBox;
      ModifierKeys modifierKeys = Keyboard.Modifiers;

      if (e.Key == Key.System || e.Key == Key.Tab)
      {
        e.Handled = false;
      }
      else if (target.SelectionLength == 0 && target.Text.Length > 1)
      {
        e.Handled = true;
      }
      else if ((Key.D0 <= e.Key && e.Key <= Key.D9) || (Key.NumPad0 <= e.Key && e.Key <= Key.NumPad9))
      {
        e.Handled = false;
        MainData.Modified();
      }
      else if (e.Key.GetHashCode() >= 44 && e.Key.GetHashCode() <= 49)
      {
        e.Handled = false;
        MainData.Modified();
      }
      else
      {
        e.Handled = true;
      }
    }

    private void TextBoxNum_KeyDown(object sender, KeyEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (e.Key == Key.System || e.Key == Key.Tab)
      {
        e.Handled = false;
      }
      else if ((Key.D0 <= e.Key && e.Key <= Key.D9) || (Key.NumPad0 <= e.Key && e.Key <= Key.NumPad9))
      {
        e.Handled = false;
        MainData.Modified();
      }
      else if (e.Key == Key.Decimal || e.Key == Key.OemPeriod)
      {
        if (target.Text.IndexOf(".") < 0 || target.SelectedText.IndexOf(".") >= 0)
        {
          e.Handled = false;
          MainData.Modified();
        }
        else
        {
          e.Handled = true;
        }
      }
      else if (e.Key == Key.Subtract || e.Key == Key.OemMinus)
      {
        if ((target.Text == target.SelectedText || target.SelectionStart == 0) &&
            (target.Text.IndexOf("-") < 0 || target.SelectedText.IndexOf("-") >= 0))
        {
          e.Handled = false;
          MainData.Modified();
        }
        else
        {
          e.Handled = true;
        }
      }
      else
      {
        e.Handled = true;
      }
    }

    private void TextBoxUint_KeyDown(object sender, KeyEventArgs e)
    {
      if (e.Key == Key.System || e.Key == Key.Tab)
      {
        e.Handled = false;
      }
      else if ((Key.D0 <= e.Key && e.Key <= Key.D9) || (Key.NumPad0 <= e.Key && e.Key <= Key.NumPad9))
      {
        e.Handled = false;
        MainData.Modified();
      }
      else
      {
        e.Handled = true;
      }
    }

    private void TextBox_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (target == null) return;
      target.SelectAll();
    }

    private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
    {
      if (Data.CheckModified)
      {
        MainData.Modified();
      }
    }

    private void CheckBox_CheckChanged(object sender, RoutedEventArgs e)
    {
      MainData.Modified();
    }

    
    public void Show(Window owner, ObjectData obj)
    {
      this.Owner = owner;
      Window = owner as MainWindow;

      Data.SetData(obj);

      this.Top = owner.Top + owner.ActualHeight;
      this.Left = owner.Left;

      this.Show();
    }
  }
}
