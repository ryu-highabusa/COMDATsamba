﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Threading.Tasks;

namespace ImageUtilities
{
  public static class DDS
  {
    public static Bitmap[] GetBitmapArray(string path) { return GetBitmapArray(path, new ParallelOptions()); }
    public static Bitmap[] GetBitmapArray(byte[] binary) { return GetBitmapArray(binary, new ParallelOptions()); }
    public static Bitmap[] GetBitmapArray(Stream stream) { return GetBitmapArray(stream, new ParallelOptions()); }
    public static Bitmap[] GetBitmapArray(string path, ParallelOptions options)
    {
      using (var stream = new FileStream(path, FileMode.Open, FileAccess.Read))
      {
        return GetBitmapArray(stream, options);
      }
    }
    public static Bitmap[] GetBitmapArray(byte[] binary, ParallelOptions options)
    {
      using (var stream = new MemoryStream(binary, false))
      {
        return GetBitmapArray(stream, options);
      }
    }
    public static Bitmap[] GetBitmapArray(Stream stream, ParallelOptions options)
    {
      using (var r = new BinaryReader(stream))
      {
        var dwMagic = r.ReadInt32();
        if (dwMagic != 0x20534444) throw new ArgumentException("Not DDS file.");

        var header = new DDS_HEADER(r);

        var depth = (header.dwFlags & DDS_HEADER.DDSD_DEPTH) != 0 && header.dwDepth > 0 ? header.dwDepth : 1;
        var bitmapList = new List<Bitmap>();
        var w = header.dwWidth;
        var h = header.dwHeight;

        int count;
        Func<byte[], int, int, ParallelOptions, Bitmap> imageReader;

        if ((header.ddspf.dwFlags & DDS_PIXELFORMAT.DDPF_RGB) != 0)
        {
          if ((header.ddspf.dwFlags & DDS_PIXELFORMAT.DDPF_ALPHAPIXELS) != 0)
          {
            count = w * h << 2;
            imageReader = readLinear32;
          }
          else
          {
            count = w * h * 3;
            imageReader = readLinear24;
          }
        }
        else if ((header.ddspf.dwFlags & DDS_PIXELFORMAT.DDPF_FOURCC) != 0)
        {
          switch (header.ddspf.dwFourCC)
          {
            case DDS_PIXELFORMAT.FOURCC_DXT1:
              count = ((h + 3) >> 2) * (((w + 3) >> 2) << 3);
              imageReader = uncompDXT1;
              break;
            case DDS_PIXELFORMAT.FOURCC_DXT2:
              count = ((h + 3) >> 2) * (((w + 3) >> 2) << 4);
              imageReader = uncompDXT2;
              break;
            case DDS_PIXELFORMAT.FOURCC_DXT3:
              count = ((h + 3) >> 2) * (((w + 3) >> 2) << 4);
              imageReader = uncompDXT3;
              break;
            case DDS_PIXELFORMAT.FOURCC_DXT4:
              count = ((h + 3) >> 2) * (((w + 3) >> 2) << 4);
              imageReader = uncompDXT4;
              break;
            case DDS_PIXELFORMAT.FOURCC_DXT5:
              count = ((h + 3) >> 2) * (((w + 3) >> 2) << 4);
              imageReader = uncompDXT5;
              break;
            default:
              throw new NotSupportedException($"0x{header.ddspf.dwFourCC.ToString("X")} is not supported.");
          }
        }
        else if ((header.ddspf.dwFlags & DDS_PIXELFORMAT.DDPF_FOURCC) == 0 && header.ddspf.dwRGBBitCount == 0x10 &&
                  header.ddspf.dwRBitMask == 0xFF && header.ddspf.dwGBitMask == 0xFF00 &&
                  header.ddspf.dwBBitMask == 0x00 && header.ddspf.dwABitMask == 0x00)
        {
          count = w * h << 3;
          imageReader = uncompV8U8;
        }
        else if ((header.ddspf.dwFlags & DDS_PIXELFORMAT.DDPF_LUMINANCE) != 0)
        {
          count = w * h;
          imageReader = readLinear8;
        }
        else
        {
          throw new NotSupportedException("Not supported.");
        }

        for (var i = 0; i < depth; i++)
        {
          var data = r.ReadBytes(count);
          if (data.Length < count) break;
          bitmapList.Add(imageReader(data, w, h, options));
        }

        return bitmapList.ToArray();
      }
    }

    #region DXT
    private unsafe struct CallStackBuffer4 { public fixed uint Pointer[4]; }
    private unsafe struct CallStackBuffer8 { public fixed uint Pointer[8]; }

    #region DXT1
    private static Bitmap uncompDXT1(byte[] data, int w, int h, ParallelOptions options)
    {
      var ceilingW = ((w + 3) >> 2) << 2;
      var ceilingH = ((h + 3) >> 2) << 2;
      var res = new Bitmap(ceilingW, ceilingH, PixelFormat.Format32bppArgb);
      try
      {
        var res_img = res.LockBits(new Rectangle(0, 0, res.Width, res.Height), ImageLockMode.ReadWrite, PixelFormat.Format32bppArgb);
        try
        {
          unsafe
          {
            fixed (byte* pData = data)
            {
              var adrData = pData;
              var iCount8 = ceilingW << 1;
              Parallel.For(0, ceilingH >> 2, options, j =>
              {
                var offset = iCount8 * j;
                j <<= 2;
                for (var i = 0; i < w; i += 4)
                {
                  decompBlockDXT1(i, j, adrData + offset + (i << 1), res_img);
                }
              });
            }
          }
        }
        finally
        {
          res.UnlockBits(res_img);
        }
      }
      catch
      {
        res.Dispose();
        throw;
      }

      return res;
    }

    private static unsafe void decompBlockDXT1(int x, int y, byte* block, BitmapData image)
    {
      CallStackBuffer4 argbBuffer; uint* argb = argbBuffer.Pointer;
      GetARGB0123(block, argb);

      var code = *(uint*)(block + 4);

      var adr = (byte*)image.Scan0;
      var Stride = image.Stride;

      for (var j = 0; j < 4; j++)
      {
        var line = ((uint*)(adr + (y + j) * Stride)) + x;
        for (var i = 0; i < 4; i++)
        {
          var positionCode = (byte)((code >> (((j << 2) + i) << 1)) & 0x03);
          line[i] = argb[positionCode];
          }
        }
      }

    private static unsafe void GetRGB0123(byte* block, uint* rgb)
    {
      var color0 = (uint)(block[8] | block[9] << 8);
      var color1 = (uint)(block[10] | block[11] << 8);

      uint r0, g0, b0, r1, g1, b1;
      GetRGB(color0, out r0, out g0, out b0);
      GetRGB(color1, out r1, out g1, out b1);

      rgb[0] = r0 << 16 | g0 << 8 | b0;
      rgb[1] = r1 << 16 | g1 << 8 | b1;
      rgb[2] = (((r0 << 1) + r1) / 3) << 16 | (((g0 << 1) + g1) / 3) << 8 | (((b0 << 1) + b1) / 3);
      rgb[3] = ((r0 + (r1 << 1)) / 3) << 16 | ((g0 + (g1 << 1)) / 3) << 8 | ((b0 + (b1 << 1)) / 3);
    }
    #endregion

    #region DXT2345
    #region DXT23
    private static unsafe Bitmap uncompDXT2(byte[] data, int w, int h, ParallelOptions options)
    {
      return uncompDXT2345(data, w, h, options, PixelFormat.Format32bppPArgb, decompBlockDXT23);
    }

    private static unsafe Bitmap uncompDXT3(byte[] data, int w, int h, ParallelOptions options)
      {
      return uncompDXT2345(data, w, h, options, PixelFormat.Format32bppArgb, decompBlockDXT23);
    }

    private static unsafe void decompBlockDXT23(int x, int y, byte* block, BitmapData image)
        {
      CallStackBuffer4 rgbBuffer; uint* rgb = rgbBuffer.Pointer;
      GetRGB0123(block, rgb);

      var code = *(uint*)(block + 12);

      var adr = (byte*)image.Scan0;
      var Stride = image.Stride;
      var alphaIndex = 0;
      for (var j = 0; j < 4; j++)
          {
        var line = ((uint*)(adr + (y + j) * Stride)) + x;
        for (var i0 = 0; i0 < 4; i0 += 2)
            {
          var alphaBlock = (uint)block[alphaIndex++];
          for (int i = i0, shift = 0; shift <= 4; i++, shift += 4)
              {
            var a = ((0x0F & (alphaBlock >> shift)) * 0x11) << 24;
            var colorCode = (code >> (((j << 2) + i) << 1)) & 0x03;
            line[i] = a | rgb[colorCode];
              }
          }
        }
      }
    #endregion

    #region DXT45
    private static unsafe Bitmap uncompDXT4(byte[] data, int w, int h, ParallelOptions options)
      {
      return uncompDXT2345(data, w, h, options, PixelFormat.Format32bppPArgb, decompBlockDXT45);
      }

    private static unsafe Bitmap uncompDXT5(byte[] data, int w, int h, ParallelOptions options)
    {
      return uncompDXT2345(data, w, h, options, PixelFormat.Format32bppArgb, decompBlockDXT45);
    }

    private static unsafe void decompBlockDXT45(int x, int y, byte* block, BitmapData image)
    {
      CallStackBuffer4 rgbBuffer; uint* rgb = rgbBuffer.Pointer;
      GetRGB0123(block, rgb);

      var alpha0 = (uint)block[0];
      var alpha1 = (uint)block[1];
      CallStackBuffer8 aBuffer; uint* a = aBuffer.Pointer;
      a[0] = alpha0 << 24;
      a[1] = alpha1 << 24;
      if (alpha0 > alpha1)
      {
        a[2] = ((6 * alpha0 + 1 * alpha1) / 7) << 24;
        a[3] = ((5 * alpha0 + 2 * alpha1) / 7) << 24;
        a[4] = ((4 * alpha0 + 3 * alpha1) / 7) << 24;
        a[5] = ((3 * alpha0 + 4 * alpha1) / 7) << 24;
        a[6] = ((2 * alpha0 + 5 * alpha1) / 7) << 24;
        a[7] = ((1 * alpha0 + 6 * alpha1) / 7) << 24;
              }
      else
      {
        a[2] = ((4 * alpha0 + 1 * alpha1) / 5) << 24;
        a[3] = ((3 * alpha0 + 2 * alpha1) / 5) << 24;
        a[4] = ((2 * alpha0 + 3 * alpha1) / 5) << 24;
        a[5] = ((1 * alpha0 + 4 * alpha1) / 5) << 24;
        a[6] = 0x00000000;
        a[7] = 0xFF000000;
      }

      const int bitOffset = 2;
      var alphaCode1 = *(uint*)(block + (bitOffset + 2));
      var alphaCode2 = (uint)*(ushort*)(block + bitOffset);

      var code = *(uint*)(block + 12);

      var adr = (byte*)image.Scan0;
      var Stride = image.Stride;
      for (var j = 0; j < 4; j++)
      {
        var line = ((uint*)(adr + (y + j) * Stride)) + x;
        for (var i = 0; i < 4; i++)
        {
          var alphaCodeIndex = 3 * ((j << 2) + i);

          uint alphaCode;
          if (alphaCodeIndex <= 12)
            alphaCode = (alphaCode2 >> alphaCodeIndex) & 0x07;
          else if (alphaCodeIndex == 15)
            alphaCode = (alphaCode2 >> 15) | ((alphaCode1 << 1) & 0x06);
          else
            alphaCode = (alphaCode1 >> (alphaCodeIndex - 16)) & 0x07;

          var colorCode = (code >> (((j << 2) + i) << 1)) & 0x03;

          line[i] = a[alphaCode] | rgb[colorCode];
        }
      }
    }
    #endregion

    unsafe delegate void DecompBlockDXT(int x, int y, byte* block, BitmapData image);
    private static Bitmap uncompDXT2345(byte[] data, int w, int h, ParallelOptions options, PixelFormat pixelFormat, DecompBlockDXT decompBlockDXT)
    {
      var ceilingW = ((w + 3) >> 2) << 2;
      var ceilingH = ((h + 3) >> 2) << 2;
      var res = new Bitmap(ceilingW, ceilingH, pixelFormat);
      try
      {
        var res_img = res.LockBits(new Rectangle(0, 0, res.Width, res.Height), ImageLockMode.ReadWrite, pixelFormat);
      try
      {
        unsafe
        {
          fixed (byte* pData = data)
          {
            var adrData = pData;
            var iCount16 = ceilingW << 2;
            Parallel.For(0, ceilingH >> 2, options, j =>
            {
              var offset = iCount16 * j;
              j <<= 2;
              for (var i = 0; i < w; i += 4)
              {
                  decompBlockDXT(i, j, adrData + offset + (i << 2), res_img);
              }
            });
          }
        }
      }
      finally
      {
        res.UnlockBits(res_img);
      }
    }
      catch
    {
        res.Dispose();
        throw;
      }

      return res;
    }

    private static unsafe void GetARGB0123(byte* block, uint* argb)
    {
      var color0 = (uint)(block[0] | block[1] << 8);
      var color1 = (uint)(block[2] | block[3] << 8);

      uint r0, g0, b0, r1, g1, b1;
      GetRGB(color0, out r0, out g0, out b0);
      GetRGB(color1, out r1, out g1, out b1);

      argb[0] = 0xff000000 | r0 << 16 | g0 << 8 | b0;
      argb[1] = 0xff000000 | r1 << 16 | g1 << 8 | b1;
      if (color0 > color1)
      {
        argb[2] = 0xff000000 | (((r0 << 1) + r1) / 3) << 16 | (((g0 << 1) + g1) / 3) << 8 | (((b0 << 1) + b1) / 3);
        argb[3] = 0xff000000 | ((r0 + (r1 << 1)) / 3) << 16 | ((g0 + (g1 << 1)) / 3) << 8 | ((b0 + (b1 << 1)) / 3);
      }
          else
          {
        argb[2] = 0xff000000 | ((r0 + r1) >> 1) << 16 | ((g0 + g1) >> 1) << 8 | ((b0 + b1) >> 1);
        argb[3] = 0x00000000;
      }
    }
    #endregion

    #region V8U8
    private static Bitmap uncompV8U8(byte[] data, int w, int h, ParallelOptions options)
    {
      var res = new Bitmap(w, h, PixelFormat.Format24bppRgb);
      try
      {
        var res_img = res.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.ReadWrite, PixelFormat.Format24bppRgb);
        try
        {
          unsafe
          {
            var adr = (byte*)res_img.Scan0;
            var Stride = res_img.Stride;
            fixed (byte* pData = data)
            {
              var adrData = pData;
              var w2 = w << 1;
              Parallel.For(0, h, options, y =>
              {
                var yStride = y * Stride;
                var posData = y * w2;
                for (var x = 0; x < w; x++)
                {
                  var pos = (x * 3) + yStride;
                  var red = adrData[posData++];
                  var green = adrData[posData++];

                  adr[pos + 0] = 0xFF;
                  adr[pos + 1] = (byte)(0x7F - green);
                  adr[pos + 2] = (byte)(0x7F - red);
                }
              });
            }
          }
        }
        finally
        {
          res.UnlockBits(res_img);
        }
      }
      catch
      {
        res.Dispose();
        throw;
      }

      return res;
    }
    #endregion

    private static void GetRGB(uint color, out uint r, out uint g, out uint b)
    {
      uint temp;

      temp = (color >> 11) * 255 + 16;
      r = ((temp >> 5) + temp) >> 5;
      temp = ((color & 0x07E0) >> 5) * 255 + 32;
      g = ((temp >> 6) + temp) >> 6;
      temp = (color & 0x001F) * 255 + 16;
      b = ((temp >> 5) + temp) >> 5;
    }
    #endregion

    #region Linear
    private static Bitmap readLinear32(byte[] data, int w, int h, ParallelOptions options)
    {
      var res = new Bitmap(w, h, PixelFormat.Format32bppArgb);
      try
      {
        var res_img = res.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.ReadWrite, PixelFormat.Format32bppArgb);
        try
        {
          unsafe
          {
            var adr = (byte*)res_img.Scan0;
            var Stride = res_img.Stride;
            fixed (byte* pData = data)
            {
              var adrData = (int*)pData;
              Parallel.For(0, h, options, y =>
              {
                var yStride = y * Stride;
                var posData = y * w;
                for (var x = 0; x < w; x++)
                {
                  var pos = (x << 2) + yStride;
                  *(int*)(adr + pos) = adrData[posData++];
                }
              });
            }
          }
        }
        finally
        {
          res.UnlockBits(res_img);
        }
      }
      catch
      {
        res.Dispose();
        throw;
      }

      return res;
    }

    private static Bitmap readLinear24(byte[] data, int w, int h, ParallelOptions options)
    {
      var res = new Bitmap(w, h, PixelFormat.Format24bppRgb);
      try
      {
        var res_img = res.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.ReadWrite, PixelFormat.Format24bppRgb);
        try
        {
          unsafe
          {
            var adr = (byte*)res_img.Scan0;
            var Stride = res_img.Stride;
            var w3 = w * 3;
            fixed (byte* pData = data)
            {
              var adrData = pData;
              Parallel.For(0, h, options, y =>
              {
                var pos = y * Stride;
                var posData = y * w3;
                for (var x = 0; x < w3; x++)
                {
                  adr[pos++] = adrData[posData++];
                }
              });
            }
          }
        }
        finally
        {
          res.UnlockBits(res_img);
        }
      }
      catch
      {
        res.Dispose();
        throw;
      }

      return res;
    }

    private static Bitmap readLinear8(byte[] data, int w, int h, ParallelOptions options)
    {
      var res = new Bitmap(w, h, PixelFormat.Format8bppIndexed);
      try
      {
        var res_img = res.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.ReadWrite, PixelFormat.Format8bppIndexed);
        try
        {
          unsafe
          {
            var adr = (byte*)res_img.Scan0;
            var Stride = res_img.Stride;
            fixed (byte* pData = data)
            {
              var adrData = pData;
              Parallel.For(0, h, options, y =>
              {
                var pos = y * Stride;
                var posData = y * w;
                for (var x = 0; x < w; x++)
                {
                  adr[pos++] = adrData[posData++];
                }
              });
            }
          }

          ColorPalette palette = res.Palette;
          for (int i = 0; i < palette.Entries.Length; ++i)
          {
            Color clr = Color.FromArgb(i, i, i);
            palette.Entries[i] = clr;
          }
          res.Palette = palette;
        }
        finally
        {
          res.UnlockBits(res_img);
        }
      }
      catch
      {
        res.Dispose();
        throw;
      }

      return res;
    }
    #endregion

    private class DDS_HEADER
    {
      public DDS_HEADER(BinaryReader r)
      {
        dwSize = r.ReadInt32();
        dwFlags = r.ReadUInt32();
        dwHeight = r.ReadInt32();
        dwWidth = r.ReadInt32();
        dwPitchOrLinearSize = r.ReadInt32();
        dwDepth = r.ReadInt32();
        dwMipMapCount = r.ReadInt32();
        for (var i = 0; i < 11; ++i) dwReserved1[i] = r.ReadInt32();
        ddspf = new DDS_PIXELFORMAT(r);
        dwCaps = r.ReadInt32();
        dwCaps2 = r.ReadInt32();
        dwCaps3 = r.ReadInt32();
        dwCaps4 = r.ReadInt32();
        dwReserved2 = r.ReadInt32();
      }

      public void SetToBinary(BinaryWriter w)
      {
        w.Write(dwSize);
        w.Write(dwFlags);
        w.Write(dwHeight);
        w.Write(dwWidth);
        w.Write(dwPitchOrLinearSize);
        w.Write(dwDepth);
        w.Write(dwMipMapCount);
        for (var i = 0; i < 11; ++i) w.Write(dwReserved1[i]);
        ddspf.SetToBinary(w);
        w.Write(dwCaps);
        w.Write(dwCaps2);
        w.Write(dwCaps3);
        w.Write(dwCaps4);
        w.Write(dwReserved2);
      }

      public DDS_HEADER(int width, int height, DDS_FORMAT format)
      {
        dwSize = 124;
        dwFlags = DDSD_HEIGHT | DDSD_WIDTH | DDSD_PITCH | DDSD_DEPTH | DDSD_MIPMAPCOUNT | DDSD_PIXELFORMAT;

        dwHeight = height;
        dwWidth = width;
        switch (format)
        {
          case DDS_FORMAT.A8B8G8R8: dwPitchOrLinearSize = width << 2; break;
        }
        dwDepth = 1;
        dwMipMapCount = 1;
        ddspf = new DDS_PIXELFORMAT(format);
      }

      #region Flags
      public const uint DDSD_CAPS = 0x00000001;
      public const uint DDSD_HEIGHT = 0x00000002;
      public const uint DDSD_WIDTH = 0x00000004;
      public const uint DDSD_PITCH = 0x00000008;
      public const uint DDSD_PIXELFORMAT = 0x00001000;
      public const uint DDSD_MIPMAPCOUNT = 0x00020000;
      public const uint DDSD_LINEARSIZE = 0x00080000;
      public const uint DDSD_DEPTH = 0x00800000;
      #endregion

      public int dwSize;
      public uint dwFlags;
      public int dwHeight;
      public int dwWidth;
      public int dwPitchOrLinearSize;
      public int dwDepth;
      public int dwMipMapCount;
      public int[] dwReserved1 = new int[11];
      public DDS_PIXELFORMAT ddspf;
      public int dwCaps;
      public int dwCaps2;
      public int dwCaps3;
      public int dwCaps4;
      public int dwReserved2;
    }

    private class DDS_PIXELFORMAT
    {
      public DDS_PIXELFORMAT(BinaryReader r)
      {
        dwSize = r.ReadInt32();
        dwFlags = r.ReadUInt32();
        dwFourCC = r.ReadUInt32();
        dwRGBBitCount = r.ReadInt32();
        dwRBitMask = r.ReadInt32();
        dwGBitMask = r.ReadInt32();
        dwBBitMask = r.ReadInt32();
        dwABitMask = r.ReadInt32();
      }

      public void SetToBinary(BinaryWriter w)
      {
        w.Write(dwSize);
        w.Write(dwFlags);
        w.Write(dwFourCC);
        w.Write(dwRGBBitCount);
        w.Write(dwRBitMask);
        w.Write(dwGBitMask);
        w.Write(dwBBitMask);
        w.Write(dwABitMask);
      }

      public DDS_PIXELFORMAT(DDS_FORMAT format)
      {
        switch (format)
        {
          case DDS_FORMAT.A8B8G8R8:
            dwSize = 32;
            dwFlags = DDPF_ALPHAPIXELS | DDPF_RGB;// | DDPF_LUMINANCE;
            dwFourCC = 0;
            dwRGBBitCount = 32;
            dwRBitMask = 0x00ff0000;
            dwGBitMask = 0x0000ff00;
            dwBBitMask = 0x000000ff;
            dwABitMask = unchecked((int)0xff000000);
            break;
        }
      }

      #region pixelformat values
      public const uint DDPF_ALPHAPIXELS = 0x00000001;
      public const uint DDPF_FOURCC = 0x00000004;
      public const uint DDPF_RGB = 0x00000040;
      public const uint DDPF_LUMINANCE = 0x00020000;
      #endregion

      #region fourccs
      public const uint FOURCC_DXT1 = 0x31545844;
      public const uint FOURCC_DXT2 = 0x32545844;
      public const uint FOURCC_DXT3 = 0x33545844;
      public const uint FOURCC_DXT4 = 0x34545844;
      public const uint FOURCC_DXT5 = 0x35545844;
      public const uint FOURCC_DX10 = 0x30315844;
      public const uint FOURCC_ATI1 = 0x31495441;
      public const uint FOURCC_ATI2 = 0x32495441;
      public const uint FOURCC_RXGB = 0x42475852;
      public const uint FOURCC_DOLLARNULL = 0x24;
      public const uint FOURCC_oNULL = 0x6f;
      public const uint FOURCC_pNULL = 0x70;
      public const uint FOURCC_qNULL = 0x71;
      public const uint FOURCC_rNULL = 0x72;
      public const uint FOURCC_sNULL = 0x73;
      public const uint FOURCC_tNULL = 0x74;
      #endregion

      public int dwSize;
      public uint dwFlags;
      public uint dwFourCC;
      public int dwRGBBitCount;
      public int dwRBitMask;
      public int dwGBitMask;
      public int dwBBitMask;
      public int dwABitMask;
    }
  }

  public enum DDS_FORMAT
  {
    A8B8G8R8
  }
}
