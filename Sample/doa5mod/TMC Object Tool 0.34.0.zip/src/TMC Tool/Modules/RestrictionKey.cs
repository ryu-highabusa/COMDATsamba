﻿using System;
using System.Windows.Controls;
using System.Windows.Input;

namespace Common
{
  public class RestrictionKey
  {
    /// <summary>
    /// 小数を含んだ数のみ入力可能
    /// </summary>
    /// <param name="key">入力されたキー</param>
    /// <param name="textBox">入力中のテキストボックス</param>
    /// <returns>入力されたキーが無効かどうか</returns>
    public static bool Num(Key key, TextBox textBox)
    {
      if (key == Key.System || key == Key.Tab)
      {
        return false;
      }
      else if ((Key.D0 <= key && key <= Key.D9) || (Key.NumPad0 <= key && key <= Key.NumPad9))
      {
        return false;
      }
      else if (key == Key.Decimal || key == Key.OemPeriod)
      {
        if (textBox.Text.IndexOf(".") < 0 || textBox.SelectedText.IndexOf(".") >= 0)
        {
          return false;
        }
        else
        {
          return true;
        }
      }
      else if (key == Key.Subtract || key == Key.OemMinus)
      {
        if ((textBox.Text == textBox.SelectedText || textBox.SelectionStart == 0) &&
            (textBox.Text.IndexOf("-") < 0 || textBox.SelectedText.IndexOf("-") >= 0))
        {
          return false;
        }
        else
        {
          return true;
        }
      }
      else
      {
        return true;
      }
    }

    /// <summary>
    /// 小数を含んだ正の数のみ入力可能
    /// </summary>
    /// <param name="key">入力されたキー</param>
    /// <param name="textBox">入力中のテキストボックス</param>
    /// <returns>入力されたキーが無効かどうか</returns>
    public static bool PositiveNum(Key key, TextBox textBox)
    {
      if (key == Key.System || key == Key.Tab)
      {
        return false;
      }
      else if ((Key.D0 <= key && key <= Key.D9) || (Key.NumPad0 <= key && key <= Key.NumPad9))
      {
        return false;
      }
      else if (key == Key.Decimal || key == Key.OemPeriod)
      {
        if (textBox.Text.IndexOf(".") < 0 || textBox.SelectedText.IndexOf(".") >= 0)
        {
          return false;
        }
        else
        {
          return true;
        }
      }
      else
      {
        return true;
      }
    }

    /// <summary>
    /// 正の整数のみ入力可能
    /// </summary>
    /// <param name="key">入力されたキー</param>
    /// <returns>入力されたキーが無効かどうか</returns>
    public static bool Uint(Key key)
    {
      if (key == Key.System || key == Key.Tab)
      {
        return false;
      }
      else if ((Key.D0 <= key && key <= Key.D9) || (Key.NumPad0 <= key && key <= Key.NumPad9))
      {
        return false;
      }
      else
      {
        return true;
      }
    }

    /// <summary>
    /// 正の整数と区切りのカンマのみ入力可能
    /// </summary>
    /// <param name="key">入力されたキー</param>
    /// <returns>入力されたキーが無効かどうか</returns>
    public static bool Uints(Key key)
    {
      if (key == Key.System || key == Key.Tab)
      {
        return false;
      }
      else if ((Key.D0 <= key && key <= Key.D9) || (Key.NumPad0 <= key && key <= Key.NumPad9))
      {
        return false;
      }
      else if (key == Key.OemComma)
      {
        return false;
      }
      else
      {
        return true;
      }
    }

    /// <summary>
    /// 名前に必要な文字のみ入力可能
    /// </summary>
    /// <param name="key">入力されたキー</param>
    /// <returns>入力されたキーが無効かどうか</returns>
    public static bool ForName(Key key)
    {
      ModifierKeys modifierKeys = Keyboard.Modifiers;

      if (key == Key.System || key == Key.Tab)
      {
        return false;
      }
      else if ((Key.D0 <= key && key <= Key.D9) || (Key.NumPad0 <= key && key <= Key.NumPad9))
      {
        return false;
      }
      else if (key.GetHashCode() >= 44 && key.GetHashCode() <= 69)
      {
        return false;
      }
      else if (key == Key.OemBackslash && (modifierKeys & ModifierKeys.Shift) != ModifierKeys.None)
      {
        return false;
      }
      else
      {
        return true;
      }
    }

  }
}
