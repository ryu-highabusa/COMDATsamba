﻿using System;
using System.Collections.Generic;
using System.Text;
using Common;

namespace Tmc
{
  public class TmcUtils
  {
    /// <summary>
    /// ヘッダバイナリのベースを構築します
    /// </summary>
    /// <param name="name">ヘッダ名</param>
    /// <returns>サイズ0x30のbyteリスト</returns>
    public static List<byte> BuildHeaderBaseBin(string name)
    {
      var bin = new List<byte>();
      bin.AddRange(Encoding.ASCII.GetBytes(name));
      if (bin.Count != 8) bin.AddRange(new byte[8 - bin.Count]);
      bin.AddRange(new byte[8] { 0, 0, 1, 1, 0x30, 0, 0, 0 });
      bin.AddRange(new byte[0x20]);
      return bin;
    }

    /// <summary>
    /// ヘッダバイナリと子バイナリリストからバイナリデータを構築します
    /// </summary>
    /// <param name="bin">ヘッダバイナリ</param>
    /// <param name="childBins">子バイナリリスト</param>
    /// <param name="optionBin">追加バイナリ</param>
    /// <param name="addSize">サイズデータを付加するかどうか</param>
    /// <param name="emptySkip">子バイナリが空の場合にヘッダのオフセットを0にするかどうか</param>
    /// <param name="staticSize">固定サイズ（0で無効）</param>
    public static void BuildBin(List<byte> bin, List<List<byte>> childBins, List<byte> optionBin, bool addSize, bool emptySkip)
    {
      BuildBin(bin, childBins, optionBin, addSize, emptySkip, 0);
    }
    public static void BuildBin(List<byte> bin, List<List<byte>> childBins, List<byte> optionBin, bool addSize, bool emptySkip, int staticSize)
    {
      int basesize = bin.Count;
      int offsetsize = 4 * ((childBins.Count + 3) / 4 * 4);
      int count = 0;

      ByteListUtils.Replace(bin, BitConverter.GetBytes(bin.Count), 0x20);

      // オフセット部分追加
      bin.AddRange(new byte[offsetsize]);

      // サイズ部分追加
      if (addSize)
      {
        ByteListUtils.Replace(bin, BitConverter.GetBytes(bin.Count), 0x24);
        bin.AddRange(new byte[offsetsize]);
      }

      if (optionBin != null)
      {
        ByteListUtils.Replace(bin, BitConverter.GetBytes(bin.Count), 0x28);
        bin.AddRange(optionBin);
      }

      // 固定サイズ
      if (staticSize != 0)
      {
        if (bin.Count < staticSize) bin.AddRange(new byte[staticSize - bin.Count]);
      }

      for (int i = 0; i < childBins.Count; i++)
      {
        if (!emptySkip || childBins[i].Count != 0)
        {
          // オフセット変更と追加
          ByteListUtils.Replace(bin, BitConverter.GetBytes(bin.Count), basesize + (4 * i));
          if (addSize) ByteListUtils.Replace(bin, BitConverter.GetBytes(childBins[i].Count), basesize + offsetsize + (4 * i));
          bin.AddRange(childBins[i]);
          count++;
        }
      }

      // 個数変更
      ByteListUtils.Replace(bin, BitConverter.GetBytes(childBins.Count), 0x14);
      ByteListUtils.Replace(bin, BitConverter.GetBytes(count), 0x18);

      // binサイズ変更
      ByteListUtils.Replace(bin, BitConverter.GetBytes(bin.Count), 0x10);
    }
  }
}
