﻿using System;
using System.Globalization;

namespace Common
{
  public class HexTextUtils
  {
    /// <summary>
    /// 16進数文字列をUIntの数値に変換します
    /// </summary>
    /// <param name="str">16進数文字列</param>
    /// <returns>UIntの数値</returns>
    public static uint ToUInt(string str)
    {
      byte[] bytes = BitConverter.GetBytes(Int32.Parse(str, NumberStyles.AllowHexSpecifier));
      uint num = BitConverter.ToUInt32(bytes, 0);
      return num;
    }

    /// <summary>
    /// 16進数文字列をIntの数値に変換します
    /// </summary>
    /// <param name="str">16進数文字列</param>
    /// <returns>Intの数値</returns>
    public static int ToInt(string str)
    {
      byte[] bytes = BitConverter.GetBytes(Int32.Parse(str, NumberStyles.AllowHexSpecifier));
      int num = BitConverter.ToInt32(bytes, 0);
      return num;
    }
  }
}
