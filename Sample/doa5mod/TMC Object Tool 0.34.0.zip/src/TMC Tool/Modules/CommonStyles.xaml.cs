﻿using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;

namespace Common
{
  [ValueConversion(typeof(object), typeof(Visibility))]
  public class EqualsToVisibleConveter : IValueConverter
  {
    public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      if (value == null)
      {
        return parameter == null ? Visibility.Visible : Visibility.Collapsed;
      }
      return value.Equals(parameter) ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      throw new NotImplementedException();
    }
  }

  partial class Styles : ResourceDictionary
  {
    //
    // SINGLE CLICK EDITING
    //
    private void DataGridCell_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      DataGridCell cell = sender as DataGridCell;
      if (cell != null && !cell.IsEditing && !cell.IsReadOnly)
      {
        if (!cell.IsFocused)
        {
          cell.Focus();
        }
        DataGrid dataGrid = FindVisualParent<DataGrid>(cell);
        if (dataGrid != null)
        {
          if (dataGrid.SelectionUnit != DataGridSelectionUnit.FullRow)
          {
            if (!cell.IsSelected)
              cell.IsSelected = true;
          }
          else
          {
            DataGridRow row = FindVisualParent<DataGridRow>(cell);
            if (row != null && !row.IsSelected)
            {
              row.IsSelected = true;
            }
          }
        }
      }
    }

    private void DataGridCell_PreviewKeyDown(object sender, KeyEventArgs e)
    {
      if (e.Key == Key.Enter || e.Key == Key.Down || e.Key == Key.Up || e.Key == Key.Right || e.Key == Key.Left)
      {
        e.Handled = true;
        DataGridCell cell = sender as DataGridCell;
        DataGrid dataGrid = FindVisualParent<DataGrid>(cell);
        DataGridRow curRow = FindVisualParent<DataGridRow>(cell);

        DataGridCellInfo dataGridCellInfo;
        int selIndex;
        if (dataGrid.SelectionUnit == DataGridSelectionUnit.FullRow)
        {
          dataGridCellInfo = new DataGridCellInfo(dataGrid.Items[dataGrid.SelectedIndex], dataGrid.Columns[cell.Column.DisplayIndex]);
          selIndex = dataGrid.Items.IndexOf(curRow.Item);
        }
        else
        {
          dataGridCellInfo = dataGrid.CurrentCell;
          selIndex = dataGrid.Items.IndexOf(dataGrid.CurrentCell.Item);
        }


        TextBox tb = null;

        tb = e.OriginalSource as TextBox;

        FrameworkElement contentElement = dataGridCellInfo.Column.GetCellContent(dataGridCellInfo.Item);
        if (tb == null)
        {
          Type type = contentElement.GetType();
          if (type.Name == "TextBox")
          {
            tb = contentElement as TextBox;
          }
        }

        var dataGridCurCell = contentElement.Parent as DataGridCell;

        int columnOffset = 0;
        if (e.Key == Key.Up)
        {
          if (selIndex == 0)
          {
            dataGrid.CommitEdit();
            return;
          }
          selIndex -= 1;
        }
        else if (e.Key == Key.Right)
        {
          if (
            cell.Column.DisplayIndex == dataGrid.Columns.Count - 1 ||
            (tb != null && tb.Text != "" && (tb.SelectionStart != tb.Text.Length || tb.SelectionLength != 0))
            )
          {
            e.Handled = false;
            return;
          }
          columnOffset = 1;
        }
        else if (e.Key == Key.Left)
        {
          if (
            cell.Column.DisplayIndex == 0 ||
            (tb != null && (tb.SelectionStart != 0 || tb.SelectionLength != 0))
            )
          {
            e.Handled = false;
            return;
          }
          columnOffset = -1;
        }
        else
        {
          if (selIndex == dataGrid.Items.Count - 1)
          {
            if (e.Key == Key.Enter || e.Key == Key.Down)
            {
              dataGrid.CommitEdit();
            }
            return;
          }
          selIndex += 1;
        }

        if (dataGrid.Columns[cell.Column.DisplayIndex + columnOffset].IsReadOnly)
        {
          e.Handled = false;
          return;
        }

        dataGridCellInfo = new DataGridCellInfo(dataGrid.Items[selIndex], dataGrid.Columns[cell.Column.DisplayIndex + columnOffset]);
        dataGrid.CurrentCell = dataGridCellInfo;
        dataGrid.ScrollIntoView(dataGridCellInfo.Item);
        contentElement = dataGridCellInfo.Column.GetCellContent(dataGridCellInfo.Item);
        if (contentElement == null)
        {
          return;
        }
        var dataGridCell = contentElement.Parent as DataGridCell;
        if (dataGridCell == null)
        {
          return;
        }
        dataGridCell.Focus();

        if (dataGrid.SelectionUnit != DataGridSelectionUnit.FullRow)
        {
          dataGridCurCell.IsSelected = false;
          dataGridCell.IsSelected = true;
        }
        else
        {
          DataGridRow row = FindVisualParent<DataGridRow>(dataGridCell);
          if (row != null && !row.IsSelected)
          {
            dataGrid.SelectedIndex = -1;
            row.IsSelected = true;
          }
        }

        dataGrid.UpdateLayout();
        dataGrid.BeginEdit();
      }
    }

    private void DataGridCell_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
      if (e.LeftButton == MouseButtonState.Released) return;

      DataGridCell cell = sender as DataGridCell;
      TextBox tb = cell.Content as TextBox;

      if (tb == null) return;

      tb.SelectAll();
    }

    private void DataGridSelectAllButton_Click(object sender, RoutedEventArgs e)
    {
      Button button = sender as Button;
      DataGrid dataGrid = FindVisualParent<DataGrid>(button);

      DataGridCommitEdit(dataGrid);

      dataGrid.Focus();
      dataGrid.SelectAll();
    }

    public static T FindVisualParent<T>(UIElement element) where T : UIElement
    {
      UIElement parent = element;
      while (parent != null)
      {
        T correctlyTyped = parent as T;
        if (correctlyTyped != null)
        {
          return correctlyTyped;
        }

        parent = VisualTreeHelper.GetParent(parent) as UIElement;
      }
      return null;
    }

    public static void DataGridCommitEdit(DataGrid dataGrid)
    {
      IEditableCollectionView collectionView = (IEditableCollectionView)CollectionViewSource.GetDefaultView(dataGrid.Items);
      if (collectionView != null)
      {
        dataGrid.CommitEdit();
        if (collectionView.IsAddingNew)
        {
          collectionView.CommitNew();
          dataGrid.CanUserAddRows = false;
          dataGrid.CanUserAddRows = true;
        }
        if (collectionView.IsEditingItem) collectionView.CommitEdit();
      }
    }
  }

  public static class DependencyObjectExtensions
  {
    //--- 子要素を取得
    public static IEnumerable<DependencyObject> Children(this DependencyObject obj)
    {
      if (obj == null)
        throw new ArgumentNullException("obj");

      var count = VisualTreeHelper.GetChildrenCount(obj);
      if (count == 0)
        yield break;

      for (int i = 0; i < count; i++)
      {
        var child = VisualTreeHelper.GetChild(obj, i);
        if (child != null)
          yield return child;
      }
    }

    //--- 子孫要素を取得
    public static IEnumerable<DependencyObject> Descendants(this DependencyObject obj)
    {
      if (obj == null)
        throw new ArgumentNullException("obj");

      foreach (var child in obj.Children())
      {
        yield return child;
        foreach (var grandChild in child.Descendants())
          yield return grandChild;
      }
    }

    //--- 特定の型の子要素を取得
    public static IEnumerable<T> Children<T>(this DependencyObject obj)
        where T : DependencyObject
    {
      return obj.Children().OfType<T>();
    }

    //--- 特定の型の子孫要素を取得
    public static IEnumerable<T> Descendants<T>(this DependencyObject obj)
        where T : DependencyObject
    {
      return obj.Descendants().OfType<T>();
    }
  }
  //var button = window                    //--- Windowの
  //             .Descendants<Button>()    //--- ボタン型の子孫要素のうち
  //             .Where(x => x.IsEnabled)  //--- 有効なボタンの
  //             .FirstOrDefault();        //--- 最初に見つかったものを取得
}