﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;

namespace Language
{
  public class Lang
  {
    public Lang(TMC_Tool.MainWindow window)
    {
      Txt = new Text();

      Type = "Jpn";

      FilePath = AppDomain.CurrentDomain.BaseDirectory + @"\Language.dat";
      if (!File.Exists(FilePath))
      {
        return;
      }

      ChangeTxt(window);
    }


    public class Text
    {
      // Can not use 'Item'.

      public string btnOpen { get; set; } = "開く";
      public string OK { get; set; } = "OK";
      public string Cancel { get; set; } = "キャンセル";
      public string Yes { get; set; } = "はい";
      public string No { get; set; } = "いいえ";
      public string Auto { get; set; } = "自動";
      public string Info { get; set; } = "情報";
      public string Error { get; set; } = "エラー";
      public string Caution { get; set; } = "注意";
      public string Confirm { get; set; } = "確認";
      public string Message { get; set; } = "メッセージ";
      public string textStatus { get; set; } = "ファイルを開いて下さい";
      public string ExitWithoutSave { get; set; } = "変更後保存されていません。このまま終了しますか？";
      public string Exit { get; set; } = "終了する";
      public string UnsupportedArea { get; set; } = "";
      public string Overwrite { get; set; } = "ファイルを上書きしますか？";
      public string OverwriteYes { get; set; } = "上書きする";
      public string Saved { get; set; } = "保存しました";
      public string FailedToCreateBackup { get; set; } = "バックアップの作成に失敗したため保存出来ませんでした";
      public string UnsupportedFile { get; set; } = "対応しているファイルではありません";
      public string FailedToReopen { get; set; } = "再読込に失敗しました";
      public string ConfirmOpenFile { get; set; } = "このファイルを開きますか？";
      public string ConfirmFileUpdated { get; set; } = "下記ファイルが更新されました。開きなおしますか？";
      public string ConfirmOpenMany { get; set; } = "個のファイルを開こうとしています。このまま開きますか？";

      public string Add { get; set; } = "追加";
      public string Del { get; set; } = "削除";
      public string Delete { get; set; } = "削除";
      public string Get { get; set; } = "取得";
      public string Replace { get; set; } = "置換";

      public string Copy { get; set; } = "コピー";
      public string Paste { get; set; } = "貼り付け";

      public string ConfirmBlendIdxClear { get; set; } = "以下の*個のBlend Indexを削除しますか？";
      public string ConfirmObjDelete { get; set; } = "選択しているオブジェクトを削除しますか？\r\n（オブジェクトグループの選択は無視されます）";
      public string ConfirmAllDelete { get; set; } = "選択しているオブジェクトの頂点とIdxを全て削除しますか？\r\n（オブジェクトグループの選択は無視されます）";
      public string ConfirmAllDataDelete { get; set; } = "使用しているオブジェクトの頂点とIdxを全て削除しますか？";
      public string ConfirmAddVtxGrp { get; set; } = "頂点グループを追加しますか？\r\n（選択している頂点グループが元になります）";
      public string ConfirmDelVtxGrp { get; set; } = "選択している頂点グループを削除しますか？";
      public string ConfirmUnableTransparent { get; set; } = "以下のオブジェクトはフラグを有効にしても透明にはなりませんが、有効にしますか？";

      public string Visible { get; set; } = "表示";
      public string Hidden { get; set; } = "非表示";
      public string Glasses { get; set; } = "眼鏡";

      public string getMatTitle { get; set; } = "取得するマテリアル情報";
      public string getMatLabelTmcFile { get; set; } = "マテリアル情報を取得するTMCファイル";
      public string getMatLabelGetObj { get; set; } = "取得するオブジェクト";
      public string getMatLabelMatData { get; set; } = "取得するマテリアル情報";
      public string getMatTextAlert { get; set; } = "追加時には選択しているオブジェクトのインデックスが変更されます";

      public string editMtrColTitle { get; set; } = "MtrColを編集";
      public string editMatecpTitle { get; set; } = "matecpを編集";
      public string TextureParameters { get; set; } = "テクスチャパラメータ";
      public string inputObjNameTitle { get; set; } = "名前を入力";
      public string selectObjGrpTitle { get; set; } = "オブジェクトグループを選択";
      public string deleteObjGrpTitle { get; set; } = "オブジェクトグループを削除";
      public string extractMeshDataTitle { get; set; } = "メッシュデータを抽出";

      public string BaseParameters { get; set; } = "ベースパラメータ";
      public string NoteHex { get; set; } = "(16進数)";
      public string AnimationSlide { get; set; } = "アニメーション（スライド）";
      public string SpeedU { get; set; } = "U方向の速さ";
      public string SpeedV { get; set; } = "V方向の速さ";
      public string AnimationMultiple { get; set; } = "アニメーション（複数枚）";
      public string Count { get; set; } = "枚数";
      public string Skip { get; set; } = "スキップ";
      public string FramesPerTex { get; set; } = "フレーム/Tex";
      public string Repeat { get; set; } = "リピート";

      public string Parameter { get; set; } = "パラメータ";
      public string InfluenceObj { get; set; } = "影響を受けるオブジェクト";

      public string DelAndAdd { get; set; } = "削除して追加";
      public string ConfirmParamDelAndAdd { get; set; } = "選択しているものを追加する場合、以下のものが削除されますが、追加しますか？";

      public string ConfirmAdd { get; set; } = "追加しますか？";
      public string ConfirmReplace { get; set; } = "置換しますか？";
      public string SameMtrCol { get; set; } = "同じパラメーターのMtrColが存在します。";
      public string SameMateCp { get; set; } = "同じパラメーターのmatecpが存在します。";
      public string SameMCAMTRL { get; set; } = "同じパラメーターのMCAMTRLが存在します。";

      public string dgcObjGrpName { get; set; } = "オブジェクトグループ名";
      public string TmclNotFound { get; set; } = "対応するTMCLファイルが見つからないためインポートできません";
      public string ObjectNotAdded { get; set; } = "このオブジェクトはインポートできません";

      public string tbDeleteTogether { get; set; } = "オブジェクトグループで使用しているものを削除";
      public string tbDeleteTogetherNote { get; set; } = "（削除できない場合もあります）";
      public string DeleteAll { get; set; } = "全て削除";
      public string Textures { get; set; } = "テクスチャ";
      public string Physics { get; set; } = "物理シミュレーション";
      public string Bones { get; set; } = "ボーン";
      public string cbNotDeleteBaseBones { get; set; } = "基本ボーンは削除しない";
      public string cbDeleteUnused { get; set; } = "既に未使用のデータも削除";
      public string tbDeleteUnusedNote { get; set; } = "ボーンと物理シミュレーションのみ";

      public string tbFileName { get; set; } = "ファイル名";
      public string rbWithFileName { get; set; } = "TMC名-オブジェクト名";
      public string rbObjectNameOnly { get; set; } = "オブジェクト名";
      public string ExceptUnusedBlendIndex { get; set; } = "未使用BlendIndexを除く";
      public string cbCreateDir { get; set; } = "フォルダを作成";
      public string cbOverwrite { get; set; } = "既存ファイルを上書き";
      public string btnExtract { get; set; } = "抽出";

      public string Extracted { get; set; } = "メッシュデータを書き出しました";
      public string NotExtracted { get; set; } = "メッシュデータは書き出されませんでした";
      public string CanNotExtract { get; set; } = "は抽出できません。";
      public string AlreadyExists { get; set; } = "同じ名前のファイルが既にあります。別名で保存しますか？";
      public string SaveAs { get; set; } = "別名で保存する";

      public string IdxOutOfRange { get; set; } = "個の範囲外のIdxが存在していました";
      public string ExtractedBut { get; set; } = "抽出は完了しましたが上記の問題があります";


      //public string this[string propertyName]
      //{
      //  get
      //  {
      //    return typeof(Text).GetProperty(propertyName).GetValue(this).ToString();
      //  }
      //  set
      //  {
      //    typeof(Text).GetProperty(propertyName).SetValue(this, value);
      //  }
      //}
    }

    private void ChangeTxt(TMC_Tool.MainWindow window)
    {
      Dictionary<string, string> altTxt = SetAltTxt();
      if (altTxt.Count == 0) return;
      string t;


      if ((t = Alt("btnOpen")) != null)
      {
        window.btnOpen.Content = t;
        window.cmdOpen.Header = t;
      }
      if ((t = Alt("cmdRevert")) != null) window.cmdRevert.Header = t;
      if ((t = Alt("btnSave")) != null)
      {
        window.btnSave.Content = t;
        window.cmdSave.Header = t;
      }
      if ((t = Alt("SaveWithBackup")) != null) window.cmdSaveWithBackup.Header = t;
      if ((t = Alt("btnSaveAs")) != null) window.btnSaveAs.Content = t;
      if ((t = Alt("Import")) != null) window.btnImport.Content = t;
      if ((t = Alt("TextureParameters")) != null) window.menuEditTexParam.Header = t;
      if ((t = Alt("Edit")) != null) window.btnEdit.Content = t;
      if ((t = Alt("cbKeepData")) != null) window.cbKeepData.Content = t;

      if ((t = Alt("dgcName")) != null) window.dgcName.Header = t;
      if ((t = Alt("dgcToggle")) != null) window.dgcToggle.Header = t;
      if ((t = Alt("dgcVtxCount")) != null)
      {
        window.dgcVtxCount.Header = t;
        window.dgcGrpVtxCount.Header = t;
      }
      if ((t = Alt("dgcIdxCount")) != null)
      {
        window.dgcIdxCount.Header = t;
        window.dgcGrpIdxCount.Header = t;
      }
      if ((t = Alt("dgcEnvironmentMap")) != null) window.dgcEnvironmentMap.Header = t;
      if ((t = Alt("dgcTransparent")) != null) window.dgcTransparent.Header = t;
      if ((t = Alt("dgcDoubleSided")) != null) window.dgcDoubleSided.Header = t;
      if ((t = Alt("dgcCastShadow")) != null) window.dgcCastShadow.Header = t;
      if ((t = Alt("dgcReceiveShadow")) != null) window.dgcReceiveShadow.Header = t;
      if ((t = Alt("dgcCulling")) != null) window.dgcCulling.Header = t;

      if ((t = Alt("dgcObj")) != null) window.dgcObj.Header = t;
      if ((t = Alt("dgcUVCount")) != null) window.dgcUVCount.Header = t;

      if ((t = Alt("AddObjGrp")) != null) window.menuAddObjGrp.Header = t;
      if ((t = Alt("RenameObjGrp")) != null) window.menuRenameObjGrp.Header = t;
      if ((t = Alt("DeleteObjGrp")) != null) window.menuDeleteObjGrp.Header = t;
      if ((t = Alt("ClearBlendIdx")) != null) window.menuClearBlendIdx.Header = t;
      if ((t = Alt("ClearBlendIdxCancel")) != null) window.menuCancelClearBlendIdx.Header = t;

      if ((t = Alt("AddObj")) != null) window.menuAddObj.Header = t;
      if ((t = Alt("DeleteObj")) != null) window.menuDeleteObj.Header = t;
      if ((t = Alt("DeleteAllVtxIdx")) != null)
      {
        window.menuDeleteData.Header = t;
        window.menuDeleteDataGrp.Header = t;
      }
      if ((t = Alt("DeleteAllVtxIdxCancel")) != null) window.menuCancelDeleteData.Header = t;
      if ((t = Alt("GetMaterial")) != null) window.menuGetMaterials.Header = t;
      if ((t = Alt("ExtractMeshData")) != null) window.menuExtractMeshes.Header = t;

      if ((t = Alt("VtxIdxGrpAdd")) != null) window.menuAddVtxIdxGrp.Header = t;
      if ((t = Alt("VtxIdxGrpDel")) != null) window.menuDeleteVtxIdxGrp.Header = t;
      if ((t = Alt("VtxIdxGrpChangeCancel")) != null) window.menuCancelChangeVtxIdxGrp.Header = t;


      string Alt(string str)
      {
        if (altTxt.ContainsKey(str))
          return altTxt[str];
        else
          return null;
      }
    }

    private Dictionary<string, string> SetAltTxt()
    {
      Dictionary<string, string> altTxt = new Dictionary<string, string>();

      using (var sr = new StreamReader(FilePath))
      {
        while (!sr.EndOfStream)
        {
          string[] inLine = sr.ReadLine().Split('\t');
          if (inLine.Length == 0)
          {
            continue;
          }
          else if (inLine[0] == "Type")
          {
            Type = inLine[2].Trim();
          }
          else if (inLine[0] == Type)
          {
            altTxt[inLine[1].Trim()] = inLine[2].Trim();
          }
        }

        PropertyInfo[] infoArray = Txt.GetType().GetProperties();
        foreach (PropertyInfo info in infoArray)
        {
          if (info.Name == "Item" || !altTxt.ContainsKey(info.Name)) continue;

          string property = info.GetValue(Txt, null).ToString();

          info.SetValue(Txt, Regex.Unescape(altTxt[info.Name]), null);
        }
      }

      return altTxt;
    }


    public Text Txt { get; set; }

    public string Type { get; set; }

    public string FilePath { get; set; }
  }
}
