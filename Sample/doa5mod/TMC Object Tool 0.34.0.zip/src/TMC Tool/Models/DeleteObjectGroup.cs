﻿using System;
using System.Collections.Generic;
using System.Linq;
using Tmc;
using TMC_Tool.ViewModels;

namespace TMC_Tool.Models
{
  public class DeleteObjectGroup
  {
    /// <summary>
    /// 実行します
    /// </summary>
    /// <param name="data">MainWindowViewModel</param>
    public static void Do(MainWindowViewModel data)
    {
      Window = data.Window;
      TmcData = data.TmcData;
      Tables = data.Tables;
      IsTmclLoaded = data.IsTmclLoaded;

      DeleteOptions = DeleteObjGrpWindow.Show(Window, TmcData, IsTmclLoaded);
      if (DeleteOptions == null) return;

      DeleteTextureSet = new SortedSet<int>();
      DeleteMtrcolSet = new SortedSet<int>();
      DeleteMatecpSet = new SortedSet<int>();
      DeleteMcamtrlSet = new SortedSet<int>();
      DeletePhysicsSet = new SortedSet<int>();
      DeleteCandidateNodeSet = new SortedSet<int>();
      DeleteNodeSet = new SortedSet<int>();
      UndeletableNodeSet = new SortedSet<string>();

      if (DeleteOptions.NotDeleteBaseBones) UndeletableNodeSet.UnionWith(ConstData.UndeletableBones);


      // 選択しているオブジェクトグループとそれに含まれるオブジェクトを削除
      while (Window.dgObject.SelectedItems.Count > 0)
      {
        DeleteObjGrp();
      }


      // 残りのオブジェクトグループのノードとBlendsのノードを削除対象外に
      foreach (var grpData in Tables.ObjData)
      {
        if (grpData.Grp != -1) continue;

        var node = Tables.Nodes[grpData.Node];

        UndeletableNodeSet.Add(node.Name);
        UndeletableNodeSet.UnionWith(node.Blends);
      }


      if (DeleteOptions.DeleteUnuse)
      {
        if (DeleteOptions.Bone)
          DeleteUnusedBones();

        if (DeleteOptions.Physics)
          DeleteUnusedPhysics();
      }

      if (DeleteOptions.Texture) DeleteTexture();

      if (DeleteOptions.MtrCol) DeleteMtrCol();

      if (DeleteOptions.Matecp) DeleteMatecp();

      if (DeleteOptions.Mcamtrl) DeleteMcamtrl();

      if (DeleteOptions.Physics) DeletePhysics();


      // 残りのPhysicsで使用されているノードを削除対象外に
      if (TmcData.H.Offsets[16] != 0)
      {
        foreach (var physics in Tables.PhysicsList)
        {
          UndeletableNodeSet.Add(physics.Name);
        }

        for (int i = 0; i < Tables.PhysicsIndicesSet.Count; i++)
        {
          foreach (var physicsIndex in Tables.PhysicsIndicesSet[i])
          {
            UndeletableNodeSet.Add(physicsIndex.Name);
          }
        }
      }


      // 削除するノードをセットに追加
      foreach (int nodeIndex in DeleteCandidateNodeSet)
      {
        AddToDeleteNodeSet(nodeIndex);
      }


      if (DeleteNodeSet.Count > 0) DeleteNode();


      // オブジェクトグループのIDとTables.ObjCountsを再設定
      int id = -1;
      foreach (var obj in Tables.ObjData)
      {
        if (obj.Grp == -1)
        {
          id++;
          obj.ID = id;
          Tables.ObjCounts[obj.ID] = 0;
        }
        else
        {
          obj.Grp = id;
          Tables.ObjCounts[id]++;
        }
      }

      // オブジェクトグループのノードを再設定
      Tables.ResetObjDataNode();

      // ノードのObjIndexを再設定
      Tables.ResetNodesObjIndex();

      // 頂点グループのObjIDを再設定
      for (int i = 0; i < Tables.VIData.Count; i++)
      {
        int idx = Array.FindIndex(Tables.ObjData.ToArray(), elem => elem.Name == Tables.VIData[i].ObjName);
        if (idx == -1)
          Tables.VIData[i].ObjID = -1;
        else
          Tables.VIData[i].ObjID = Tables.ObjData[idx].ID;
      }

      // オブジェクトのVtxIdxGruopsを再設定
      Tables.ResetVtxIdxGruops();

      // 頂点グループのIdxGrpを再設定
      Tables.ResetVIDataIdxGrp();

      // LastGrpIndexを再設定
      foreach (var obj in Tables.ObjData)
      {
        if (obj.Grp == -1) obj.LastGrpIndex = obj.ID;
      }

      data.ObjGrpRebuild = true;
      data.TextureRebuild = TextureRebuild;
    }


    #region メソッド

    /// <summary>
    /// 削除するノードをセットに追加
    /// </summary>
    private static void AddToDeleteNodeSet(int nodeIndex)
    {
      bool delete = true;
      var nodeData = Tables.Nodes[nodeIndex];
      string nodeName = nodeData.Name;

      if (UndeletableNodeSet.Contains(nodeName)) return;


      if (DeleteOptions.Bone)
      {
        if (!DeleteCandidateChildNode(nodeData))
        {
          delete = false;
        }

        if (delete)
        {
          HashSet<string> parentNodeNames = new HashSet<string>();

          foreach (var node in Tables.Nodes)
          {
            if (node.Children.Contains(nodeName))
            {
              parentNodeNames.Add(node.Name);
              break;
            }
          }

          while (parentNodeNames.Count > 0)
          {
            bool deleteParent = true;
            string parentParentNodeName = "";
            string parentNodeName = parentNodeNames.ToList()[0];

            if (UndeletableNodeSet.Contains(parentNodeName))
            {
              parentNodeNames.Remove(parentNodeName);
              continue;
            }

            int parentNodeIndex = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == parentNodeName);
            if (!DeleteNodeSet.Contains(parentNodeIndex))
            {
              var parentNodeData = Tables.Nodes[parentNodeIndex];

              foreach (var node in Tables.Nodes)
              {
                if (node.Children.Contains(parentNodeName))
                {
                  parentParentNodeName = node.Name;
                }
                if (node.Blends.Contains(parentNodeName))
                {
                  deleteParent = false;
                }
              }

              if (deleteParent)
              {
                if (!DeleteCandidateChildNode(parentNodeData))
                {
                  deleteParent = false;
                }
              }

              if (deleteParent)
              {
                DeleteNodeSet.Add(parentNodeIndex);
                if (parentParentNodeName != "") parentNodeNames.Add(parentParentNodeName);
              }
              else
              {
                UndeletableNodeSet.Add(parentNodeName);
              }
            }

            parentNodeNames.Remove(parentNodeName);
          }
        }
      }


      if (delete)
      {
        int index = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == nodeName);
        DeleteNodeSet.Add(index);
      }
      else
      {
        UndeletableNodeSet.Add(nodeName);
      }
    }

    /// <summary>
    /// オブジェクトグループを削除
    /// </summary>
    private static void DeleteObjGrp()
    {
      ObjectData grpData = Window.dgObject.SelectedItems[0] as ObjectData;
      if (grpData.Grp != -1) return;

      int nodeIdx = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == grpData.Name);
      var node = Tables.Nodes[nodeIdx];

      //頂点・インデックスグループを削除
      int count = 0;
      while (Tables.VIData.Count > count)
      {
        if (Tables.VIData[count].ObjID == grpData.ID)
        {
          Tables.VIData.RemoveAt(count);
        }
        else
        {
          foreach (var objData in Tables.ObjData)
          {
            if (objData.VtxGrp == Tables.VIData[count].Index)
            {
              objData.VtxGrp = count;
            }
          }
          Tables.VIData[count].Index = count;
          count++;
        }
      }

      if (DeleteOptions.Physics)
      {
        PickupDeletePhysics(node);
      }

      // ノードを削除候補に追加
      node.ObjIndex = -1;
      if (!UndeletableNodeSet.Contains(node.Name))
      {
        DeleteCandidateNodeSet.Add(nodeIdx);
      }

      // Blendsのノードを削除候補に追加
      if (DeleteOptions.Bone)
      {
        foreach (var nodeName in node.Blends)
        {
          int index = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == nodeName);
          DeleteCandidateNodeSet.Add(index);
        }
      }

      // Blendsをクリア
      if (node.Blends.Count > 0) node.Blends.Clear();


      DeleteObj(grpData);
    }

    /// <summary>
    /// オブジェクトを削除
    /// </summary>
    /// <param name="grpData">オブジェクトグループデータ</param>
    private static void DeleteObj(ObjectData grpData)
    {
      int count = 0;
      while (Tables.ObjData.Count > count)
      {
        var objData = Tables.ObjData[count];

        if (Tables.ObjData[count].Grp == grpData.ID)
        {
          if (DeleteOptions.Texture)
          {
            // 使用しているテクスチャを削除候補に追加
            if (objData.Tex1 != null) DeleteTextureSet.Add((int)objData.Tex1);
            if (objData.Tex2 != null) DeleteTextureSet.Add((int)objData.Tex2);
            if (objData.Tex3 != null) DeleteTextureSet.Add((int)objData.Tex3);
            if (objData.Tex4 != null) DeleteTextureSet.Add((int)objData.Tex4);
            if (objData.Tex5 != null) DeleteTextureSet.Add((int)objData.Tex5);
          }

          if (DeleteOptions.MtrCol)
          {
            // 使用しているMtrColを削除候補に追加
            if (objData.MtrCol != null) DeleteMtrcolSet.Add((int)objData.MtrCol);
          }

          if (DeleteOptions.Matecp)
          {
            // 使用しているmatecpを削除候補に追加
            if (objData.Matecp != null && objData.Matecp != TmcData.MateCp.Count) DeleteMatecpSet.Add((int)objData.Matecp);
          }

          if (DeleteOptions.Mcamtrl)
          {
            // 使用しているMCAMTRLを削除候補に追加
            if (objData.Mcamtrl != null && objData.Mcamtrl != -1) DeleteMcamtrlSet.Add((int)objData.Mcamtrl);
          }

          Tables.ObjData.RemoveAt(count);
        }
        else
        {
          count++;
        }
      }
      Tables.ObjData.Remove(grpData);
    }

    /// <summary>
    /// 使用していないボーンを削除
    /// </summary>
    private static void DeleteUnusedBones()
    {
      for (int i = 0; i < Tables.Nodes.Count; i++)
      {
        var node = Tables.Nodes[i];

        if (UndeletableNodeSet.Contains(node.Name) || DeleteCandidateNodeSet.Contains(i))
        {
          continue;
        }

        DeleteCandidateNodeSet.Add(i);
      }
    }

    /// <summary>
    /// 使用していないPhysicsを削除
    /// </summary>
    private static void DeleteUnusedPhysics()
    {
      foreach (var physics in Tables.PhysicsList)
      {
        bool deletePhysics = true;

        if (UndeletableNodeSet.Contains(physics.Name))
        {
          continue;
        }

        if (physics.Data.Type != 2)
        {
          foreach (var part in physics.Data.Block1)
          {
            int index = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.OriginalIndex == part.NodeIndex && elem.DataIndex == physics.DataIndex);
            if (UndeletableNodeSet.Contains(Tables.Nodes[index].Name))
            {
              deletePhysics = false;
              break;
            }
          }
        }
        else
        {
          foreach (var type2s in physics.Data.Type2)
          {
            foreach (var part in type2s)
            {
              int index = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.OriginalIndex == part.NodeIndex && elem.DataIndex == physics.DataIndex);
              if (UndeletableNodeSet.Contains(Tables.Nodes[index].Name))
              {
                deletePhysics = false;
                break;
              }
            }
            if (!deletePhysics) break;
          }
        }

        if (deletePhysics) DeletePhysicsSet.Add(Tables.PhysicsList.IndexOf(physics));
      }
    }

    /// <summary>
    /// テクスチャを削除
    /// </summary>
    private static void DeleteTexture()
    {
      List<int> indices = new List<int>();
      for (int i = 0; i < TmcData.Tex.Count; i++) indices.Add(i);
      bool doDelete = false;

      // 削除
      foreach (int deleteIndex in DeleteTextureSet.Reverse())
      {
        bool delete = true;

        // 使用状況を確認
        foreach (var objData in Tables.ObjData)
        {
          if (objData.Grp == -1) continue;

          if (objData.Tex1 == deleteIndex)
            delete = false;
          else if (objData.Tex2 == deleteIndex)
            delete = false;
          else if (objData.Tex3 == deleteIndex)
            delete = false;
          else if (objData.Tex4 == deleteIndex)
            delete = false;
          else if (objData.Tex5 == deleteIndex)
            delete = false;

          if (!delete) break;
        }

        if (delete)
        {
          TmcData.Tex.RemoveAt(deleteIndex);
          indices.Remove(deleteIndex);
          doDelete = true;
        }
      }

      if (doDelete)
      {
        // 再設定
        foreach (var objData in Tables.ObjData)
        {
          if (objData.Grp == -1) continue;

          if (objData.Tex1 != null)
            objData.Tex1 = indices.IndexOf((int)objData.Tex1);

          if (objData.Tex2 != null)
            objData.Tex2 = indices.IndexOf((int)objData.Tex2);

          if (objData.Tex3 != null)
            objData.Tex3 = indices.IndexOf((int)objData.Tex3);

          if (objData.Tex4 != null)
            objData.Tex4 = indices.IndexOf((int)objData.Tex4);

          if (objData.Tex5 != null)
            objData.Tex5 = indices.IndexOf((int)objData.Tex5);
        }

        for (int i = 0; i < TmcData.Tex.Count; i++)
        {
          TmcData.Tex[i].ID = i;
        }

        TextureRebuild = true;
      }
    }

    /// <summary>
    /// MtrColを削除
    /// </summary>
    private static void DeleteMtrCol()
    {
      List<int> indices = new List<int>();
      for (int i = 0; i < TmcData.ColGrp.Count; i++) indices.Add(i);
      bool doDelete = false;

      foreach (int deleteIndex in DeleteMtrcolSet.Reverse())
      {
        bool delete = true;

        // 使用状況を確認
        foreach (var objData in Tables.ObjData)
        {
          if (objData.Grp == -1) continue;

          if (objData.MtrCol == deleteIndex)
          {
            delete = false;
            break;
          }
        }

        if (delete)
        {
          TmcData.ColGrp.RemoveAt(deleteIndex);
          indices.Remove(deleteIndex);
          doDelete = true;
        }
      }

      if (doDelete)
      {
        // 再設定
        foreach (var objData in Tables.ObjData)
        {
          if (objData.Grp == -1) continue;

          int newIndex = indices.IndexOf((int)objData.MtrCol);
          objData.MtrCol = newIndex;
        }

        for (int i = 0; i < TmcData.ColGrp.Count; i++)
        {
          TmcData.ColGrp[i].ID = i;
        }
      }
    }

    /// <summary>
    /// matecpを削除
    /// </summary>
    private static void DeleteMatecp()
    {
      List<int> indices = new List<int>();
      for (int i = 0; i < TmcData.MateCp.Count; i++) indices.Add(i);
      bool doDelete = false;

      foreach (int deleteIndex in DeleteMatecpSet.Reverse())
      {
        bool delete = true;

        // 使用状況を確認
        foreach (var objData in Tables.ObjData)
        {
          if (objData.Grp == -1) continue;

          if (objData.Matecp == deleteIndex)
          {
            delete = false;
            break;
          }
        }

        if (delete)
        {
          TmcData.MateCp.RemoveAt(deleteIndex);
          indices.Remove(deleteIndex);
          doDelete = true;
        }
      }

      if (doDelete)
      {
        // 再設定
        foreach (var objData in Tables.ObjData)
        {
          if (objData.Grp == -1) continue;

          int newIndex = indices.IndexOf((int)objData.Matecp);
          if (newIndex == -1) newIndex = indices.Count;
          objData.Matecp = newIndex;
        }

        for (int i = 0; i < TmcData.MateCp.Count; i++)
        {
          TmcData.MateCp[i].Index = i;
        }
      }
    }

    /// <summary>
    /// MCAMTRLを削除
    /// </summary>
    private static void DeleteMcamtrl()
    {
      List<int> indices = new List<int>();
      for (int i = 0; i < TmcData.Mat.Count; i++) indices.Add(i);
      bool doDelete = false;

      foreach (int deleteIndex in DeleteMcamtrlSet.Reverse())
      {
        bool delete = true;

        // 使用状況を確認
        foreach (var objData in Tables.ObjData)
        {
          if (objData.Grp == -1) continue;

          if (objData.Mcamtrl == deleteIndex)
          {
            delete = false;
            break;
          }
        }

        if (delete)
        {
          TmcData.Mat.RemoveAt(deleteIndex);
          indices.Remove(deleteIndex);
          doDelete = true;
        }
      }

      if (doDelete)
      {
        // 再設定
        foreach (var objData in Tables.ObjData)
        {
          if (objData.Grp == -1) continue;

          int newIndex = indices.IndexOf((int)objData.Mcamtrl);
          objData.Mcamtrl = newIndex;
        }

        for (int i = 0; i < TmcData.Mat.Count; i++)
        {
          TmcData.Mat[i].ID = i;
        }
      }
    }

    /// <summary>
    /// Physicsを削除
    /// </summary>
    private static void DeletePhysics()
    {
      List<int> indices = new List<int>();

      foreach (int deleteIndex in DeletePhysicsSet.Reverse())
      {
        bool delete = true;

        var physics = Tables.PhysicsList[deleteIndex];

        if (UndeletableNodeSet.Contains(physics.Name))
        {
          delete = false;
        }

        if (physics.Data.Type != 2)
        {
          foreach (var part in physics.Data.Block1)
          {
            int index = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.OriginalIndex == part.NodeIndex && elem.DataIndex == physics.DataIndex);
            if (UndeletableNodeSet.Contains(Tables.Nodes[index].Name))
            {
              delete = false;
              break;
            }
          }
        }
        else
        {
          foreach (var type2s in physics.Data.Type2)
          {
            foreach (var part in type2s)
            {
              int index = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.OriginalIndex == part.NodeIndex && elem.DataIndex == physics.DataIndex);
              if (UndeletableNodeSet.Contains(Tables.Nodes[index].Name))
              {
                delete = false;
                break;
              }
            }
            if (!delete) break;
          }
        }

        if (delete)
        {
          Tables.PhysicsList.RemoveAt(deleteIndex);
          for (int i = 0; i < Tables.PhysicsIndicesSet.Count; i++)
          {
            int index = Array.FindIndex(Tables.PhysicsIndicesSet[i].ToArray(), elem => elem.Name == physics.Name);
            if (index == -1) continue;

            Tables.PhysicsIndicesSet[i].RemoveAt(index);
          }

          int nodeIndex = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == physics.Name);
          if (DeleteOptions.Bone) DeleteNodeSet.Add(nodeIndex);

          if (physics.Data.Type != 2)
          {
            foreach (var part in physics.Data.Block1)
            {
              DeleteFromPhysics(physics, part, DeleteOptions.Bone);
            }
          }
          else
          {
            foreach (var type2s in physics.Data.Type2)
            {
              foreach (var part in type2s)
              {
                DeleteFromPhysics(physics, part, DeleteOptions.Bone);
              }
            }
          }
        }
      }
    }

    /// <summary>
    /// ノードを削除
    /// </summary>
    private static void DeleteNode()
    {
      List<string> deletedNodeNames = new List<string>();
      List<string> deleteHairAttachedNodes = new List<string>();
      foreach (var nodeIndex in DeleteNodeSet.Reverse())
      {
        string nodeName = Tables.Nodes[nodeIndex].Name;

        if (UndeletableNodeSet.Contains(nodeName))
        {
          continue;
        }
        else if (ConstData.HairAttachedNodes.Contains(nodeName))
        {
          deleteHairAttachedNodes.Add(nodeName);
          continue;
        }

        deletedNodeNames.Add(nodeName);
        Tables.Nodes.RemoveAt(nodeIndex);
      }

      foreach (string nodeName in deleteHairAttachedNodes)
      {
        int nodeIndex = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == nodeName);

        if (
          nodeIndex == -1 ||
          UndeletableNodeSet.Contains(nodeName) ||
          Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == "WGT_hair") != -1
        )
        {
          continue;
        }

        deletedNodeNames.Add(nodeName);
        Tables.Nodes.RemoveAt(nodeIndex);
      }


      foreach (string nodeName in deletedNodeNames)
      {
        foreach (var node in Tables.Nodes)
        {
          if (node.Children.Contains(nodeName))
            node.Children.Remove(nodeName);
          if (node.Blends.Contains(nodeName))
            node.Blends.Remove(nodeName);
        }

        if (TmcData.Collisions !=null)
        {
          // コリジョン削除
          int index = 0;
          while (TmcData.Collisions.Count > index)
          {
            if (deletedNodeNames.Contains(TmcData.Node[TmcData.Collisions[index].Node].Name))
            {
              TmcData.Collisions.RemoveAt(index);
            }
            else
            {
              TmcData.Collisions[index].Index = index;
              index++;
            }
          }
        }
      }

      Tables.ResetObjDataNode();
    }

    /// <summary>
    /// 削除するPhysicsをピックアップ
    /// </summary>
    /// <param name="nodeData">ノードデータ</param>
    private static void PickupDeletePhysics(NodeData nodeData)
    {
      // Physicsの削除リストに追加
      foreach (var physics in Tables.PhysicsList)
      {
        bool deletePhysics = false;

        if (nodeData.Children.IndexOf(physics.Name) != -1 || nodeData.Blends.IndexOf(physics.Name) != -1)
        {
          deletePhysics = true;
        }

        if (!deletePhysics)
        {
          if (physics.Data.Type != 2)
          {
            foreach (var part in physics.Data.Block1)
            {
              int index = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.OriginalIndex == part.NodeIndex && elem.DataIndex == physics.DataIndex);
              if (nodeData.Children.IndexOf(Tables.Nodes[index].Name) != -1 || nodeData.Blends.IndexOf(Tables.Nodes[index].Name) != -1)
              {
                deletePhysics = true;
                break;
              }
            }
          }
          else
          {
            foreach (var type2s in physics.Data.Type2)
            {
              foreach (var part in type2s)
              {
                int index = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.OriginalIndex == part.NodeIndex && elem.DataIndex == physics.DataIndex);
                if (nodeData.Children.IndexOf(Tables.Nodes[index].Name) != -1 || nodeData.Blends.IndexOf(Tables.Nodes[index].Name) != -1)
                {
                  deletePhysics = true;
                  break;
                }
              }
              if (deletePhysics) break;
            }
          }
        }

        if (deletePhysics) DeletePhysicsSet.Add(Tables.PhysicsList.IndexOf(physics));
      }
    }

    /// <summary>
    /// Physicsからボーンを削除
    /// </summary>
    /// <param name="physics">physicsデータ</param>
    /// <param name="part">physicsパートデータ</param>
    /// <param name="deleteBone">ボーンを削除するかどうか</param>
    private static void DeleteFromPhysics(Physics physics, dynamic part, bool deleteBone)
    {
      int nodeIndex = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.OriginalIndex == part.NodeIndex && elem.DataIndex == physics.DataIndex);
      if (deleteBone) DeleteNodeSet.Add(nodeIndex);
      string nodeName = Tables.Nodes[nodeIndex].Name;

      for (int i = 0; i < Tables.PhysicsIndicesSet.Count; i++)
      {
        int index = Array.FindIndex(Tables.PhysicsIndicesSet[i].ToArray(), elem => elem.Name == nodeName);
        if (index == -1) continue;

        Tables.PhysicsIndicesSet[i].RemoveAt(index);
      }
    }

    /// <summary>
    /// 削除候補子ノードを構築
    /// </summary>
    /// <param name="nodeData">ノードデータ</param>
    /// <returns>削除するノードがあるかどうか</returns>
    private static bool DeleteCandidateChildNode(NodeData nodeData)
    {
      bool delete = true;

      foreach (string childName in nodeData.Children)
      {
        int childIndex = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == childName);

        if (UndeletableNodeSet.Contains(childName))
        {
          delete = false;
        }
        else if (!DeleteNodeSet.Contains(childIndex))
        {
          bool deleteChild = true;
          var childData = Tables.Nodes[childIndex];

          if (TmcData.H.Offsets[16] != 0)
          {
            foreach (var physics in Tables.PhysicsList)
            {
              if (physics.Name == childName)
              {
                deleteChild = false;
                break;
              }
            }

            if (deleteChild)
            {
              for (int i = 0; i < Tables.PhysicsIndicesSet.Count; i++)
              {
                int index = Array.FindIndex(Tables.PhysicsIndicesSet[i].ToArray(), elem => elem.Name == childName);
                if (index != -1)
                {
                  deleteChild = false;
                  break;
                }
              }
            }
          }

          if (deleteChild && !DeleteCandidateChildNode(childData))
          {
            deleteChild = false;
          }

          if (deleteChild)
          {
            DeleteNodeSet.Add(childIndex);
          }
          else
          {
            UndeletableNodeSet.Add(childName);
            delete = false;
          }
        }
      }

      if (delete)
        return true;
      else
        return false;
    }

    #endregion



    #region プロパティ

    /// <summary>
    /// MainWindow
    /// </summary>
    private static MainWindow Window { get; set; }

    /// <summary>
    /// TMCデータ
    /// </summary>
    private static TmcData TmcData { get; set; }

    /// <summary>
    /// 表のデータ
    /// </summary>
    private static DataTables Tables { get; set; }

    /// <summary>
    /// TMCLファイルがロードされているかどうか
    /// </summary>
    private static bool IsTmclLoaded { get; set; }

    /// <summary>
    /// テクスチャを再構築するかどうか
    /// </summary>
    private static bool TextureRebuild { get; set; }


    /// <summary>
    /// 削除オプション
    /// </summary>
    private static DeleteObjGrpWindowViewModel DeleteOptions { get; set; }

    /// <summary>
    /// 削除するテクスチャセット
    /// </summary>
    private static SortedSet<int> DeleteTextureSet { get; set; }

    /// <summary>
    /// 削除するMtrColセット
    /// </summary>
    private static SortedSet<int> DeleteMtrcolSet { get; set; }

    /// <summary>
    /// 削除するmatecpセット
    /// </summary>
    private static SortedSet<int> DeleteMatecpSet { get; set; }

    /// <summary>
    /// 削除するMCAMTRLセット
    /// </summary>
    private static SortedSet<int> DeleteMcamtrlSet { get; set; }

    /// <summary>
    /// 削除するPhysicsセット
    /// </summary>
    private static SortedSet<int> DeletePhysicsSet { get; set; }

    /// <summary>
    /// 削除候補ノードセット
    /// </summary>
    private static SortedSet<int> DeleteCandidateNodeSet { get; set; }

    /// <summary>
    /// 削除するノードセット
    /// </summary>
    private static SortedSet<int> DeleteNodeSet { get; set; }

    /// <summary>
    /// 削除できないノードセット
    /// </summary>
    private static SortedSet<string> UndeletableNodeSet { get; set; }

    #endregion
  }
}
