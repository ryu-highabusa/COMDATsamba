﻿using Common;

namespace TMC_Tool.Models
{
  public class ObjectComboBoxItem : BindableBase
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    public ObjectComboBoxItem(string objectName, int grpID, int objID)
    {
      Name = objectName;
      Grp = grpID;
      Obj = objID;
    }

    public string Name { get; set; }
    public int Grp { get; set; }
    public int Obj { get; set; }
  }
}
