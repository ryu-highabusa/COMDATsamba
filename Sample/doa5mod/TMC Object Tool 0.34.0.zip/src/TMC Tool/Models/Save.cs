﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using TMC_Tool.ViewModels;
using Common;
using Language;
using Tmc;

namespace TMC_Tool.Models
{
  public class Save
  {
    public Save(MainWindowViewModel data)
    {
      Txt = MainWindow.Txt;
      Window = data.Window;
      BinLHeader = data.BinLHeader;
      TmcData = data.TmcData;
      OtherTmcDataList = data.OtherTmcDataList;
      Tables = data.Tables;
      ObjGrpRebuild = data.ObjGrpRebuild;
      TextureRebuild = data.TextureRebuild;
    }


    /// <summary>
    /// TMCを保存します
    /// </summary>
    /// <param name="path">ファイルパス</param>
    public void Do()
    {
      Init();


      if (ObjGrpRebuild)
      {
        // インデックスを再設定
        Tables.ResetObjectIndex();

        // 頂点グループのObjIDを再設定
        var grpNames = Tables.ObjData.Where(obj => obj.Grp == -1).Select(obj => obj.Name).ToList();
        foreach (var vidata in Tables.VIData)
        {
          vidata.ObjID = grpNames.IndexOf(vidata.ObjName);
        }

        foreach (var obj in Tables.ObjData)
        {
          if (obj.Grp != -1) continue;

          int idx = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == obj.Name);

          if (Tables.Nodes[idx].ObjIndex == -1) continue;

          Tables.Nodes[idx].ObjIndex = obj.ID;
        }
      }


      // 基本部分再構築
      PartBins[0] = BuildMdlGeo.Do(this, 0); // Tex、両面、透過1、透過2、MtrColを反映
      BuildVtxLay(2); // 頂点削除を反映
      BuildIdxLay(3); // Idx削除を反映
      BuildMtrCol(4); // MtrColを再構築
      BuildMdlInfo(5); // MdlInfoを再構築
      //if (TmcData.H.Offsets[11] != 0 || TmcData.MateCp.Count > 0) BuildCpf(11); // nodecp増減、itable、切替、matecpの編集を反映
      BuildCpf(11); // nodecp増減、itable、切替、matecpの編集を反映
      if (TmcData.H.Offsets[12] != 0) BuildMcaPack(12); // MCAPACKを再構築


      // テクスチャ再構築
      if (TextureRebuild)
      {
        BuildTtdm(1);

        int texPartCount = ExBinL.Count;

        // TMCLの先頭から0x80を持ってくる
        ExBinL.InsertRange(0, BinLHeader);

        // 0x0100より小さければ0x0100になるように
        if (ExBinL.Count < 0x100) ExBinL.AddRange(new byte[0x100 - ExBinL.Count]);

        // ExBinLのサイズ変更
        ByteListUtils.Replace(ExBinL, BitConverter.GetBytes(ExBinL.Count), 4);

        // LHeader変更
        ByteListUtils.Replace(PartBins[7], BitConverter.GetBytes(ExBinL.Count), 0x44);
        ByteListUtils.Replace(PartBins[7], BitConverter.GetBytes(texPartCount), 0x90);
      }


      // オブジェクトグループ再構築
      if (ObjGrpRebuild)
      {
        ResetBoneLevel();
        BuildHieLay(6); // HieLayを再構築
        BuildNodeLay(8); // NodeLayを再構築
        BuildMtx(9, "GlblMtx"); // GlblMtxを再構築
        BuildMtx(10, "BnOfsMtx"); // BnOfsMtxを再構築
        BuildRenPack(13); // RenPackを再構築
        if (TmcData.H.Offsets[16] != 0) BuildAcscls(16); // MCAPACKを再構築
      }
      else if (BlendCleared)
      {
        BuildNodeLay(8); // NodeLayを再構築
      }


      // バイナリ構築
      BuildBin();

      return;
    }

    /// <summary>
    /// プロパティ初期化
    /// </summary>
    private void Init()
    {
      // 各部バイナリ
      //  0 MdlGeo
      //  1 TTX
      //  2 VtxLay
      //  3 IdxLay
      //  4 MtrCol
      //  5 MdlInfo
      //  6 HieLay
      //  7 LHeader
      //  8 NodeLay
      //  9 GlblMtx
      // 10 BnOfsMtx
      // 11 cpf
      // 12 MCAPACK
      // 13 RENPACK
      // 14 GEOXTRAS
      // 15 
      // 16 ACSCLS

      int lastOffset = TmcData.H.Size;
      for (int i = TmcData.H.Count1 - 1; i >= 0; i--)
      {
        var partBin = new List<byte>();

        if (TmcData.H.Offsets[i] != 0)
        {
          partBin.AddRange(TmcData.Bin.Skip(TmcData.H.Offsets[i]).Take(lastOffset - TmcData.H.Offsets[i]));
          lastOffset = TmcData.H.Offsets[i];
        }

        PartBins.Insert(0, partBin);
      }


      // for broken TMC
      if (TmcData.H.Count1 > 14 && TmcData.H.Offsets[14] != 0 && BitConverter.ToUInt32(TmcData.Bin, TmcData.H.Offsets[14] + 8) != 0x01010000 && PartBins[14].Count > 0x40)
      {
        PartBins[14] = new List<byte>(new byte[0x40]);
      }


      foreach (var grp in TmcData.ObjGrp)
      {
        if (grp.ChildCount == 0)
        {
          ObjGrpRebuild = true;
          break;
        }
      }

      BlendCleared = false;
      foreach (var obj in Tables.ObjData)
      {
        if (obj.Grp != -1) continue;

        if (obj.IsBlendCleared)
        {
          BlendCleared = true;
          break;
        }
      }

      foreach (var data in OtherTmcDataList)
      {
        OtherBinList.Add(data.Bin.ToArray());
      }
    }

    /// <summary>
    /// ボーンレベルを再設定
    /// </summary>
    private void ResetBoneLevel()
    {
      HashSet<string> nodeNames = new HashSet<string>();

      foreach (var node in Tables.Nodes)
      {
        foreach (var child in node.Children)
        {
          nodeNames.Add(child);
        }
      }

      foreach (var node in Tables.Nodes)
      {
        if (nodeNames.ToList().IndexOf(node.Name) != -1) continue;

        int boneLevel = 0;
        node.BoneLevel = boneLevel;

        SetBoneLevel(node.Children, boneLevel);
      }
    }

    /// <summary>
    /// ボーンレベルを設定
    /// </summary>
    /// <param name="children">子要素群</param>
    /// <param name="boneLevel">ボーンレベル</param>
    private void SetBoneLevel(List<string> children, int boneLevel)
    {
      boneLevel++;
      foreach (var child in children)
      {
        int index = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == child);
        if (index == -1) continue;
        Tables.Nodes[index].BoneLevel = boneLevel;

        SetBoneLevel(Tables.Nodes[index].Children, boneLevel);
      }
    }

    /// <summary>
    /// TMCバイナリ構築
    /// </summary>
    private void BuildBin()
    {
      ExBin.AddRange(TmcData.Bin.Take(TmcData.H.Offset1));

      TmcUtils.BuildBin(ExBin, PartBins, null, false, true);
    }



    /// <summary>
    /// TTDMを構築
    /// </summary>
    /// <param name="partIndex">パートインデックス</param>
    private void BuildTtdm(int partIndex)
    {
      List<Textures> texList = new List<Textures>();
      List<Textures> texListL = new List<Textures>();

      foreach (var tex in TmcData.Tex)
      {
        if (tex.InL)
          texListL.Add(tex);
        else
          texList.Add(tex);
      }


      // TTDL
      var ttdlBn = BuildTtdl(texListL);


      var ttdmH = new HeaderData(TmcData.Bin, TmcData.H.Offsets[1]);
      var ttdlH = new HeaderData(TmcData.Bin, TmcData.H.Offsets[1] + ttdmH.Offset3);
      uint fileID = BitConverter.ToUInt32(TmcData.Bin, ttdlH.Start + 0x48);

      ByteListUtils.Replace(ttdlBn, BitConverter.GetBytes(texListL.Count), 0x40);
      ByteListUtils.Replace(ExBinL, BitConverter.GetBytes(texListL.Count), 0);
      ByteListUtils.Replace(ttdlBn, BitConverter.GetBytes(ExBinL.Count), 0x44);
      ByteListUtils.Replace(ExBinL, BitConverter.GetBytes(ExBinL.Count), 4);
      ByteListUtils.Replace(ttdlBn, BitConverter.GetBytes(fileID), 0x48);
      ByteListUtils.Replace(ExBinL, BitConverter.GetBytes(fileID), 8);

      ByteListUtils.Replace(ttdlBn, BitConverter.GetBytes(ttdlBn.Count), 0x10);


      // TTDH
      var ttdhBn = BuildTtdh(texList.Count + texListL.Count);


      // TTDM
      var ttdmBn = TmcUtils.BuildHeaderBaseBin("TTDM");
      ttdmBn.AddRange(ttdhBn);
      if (texList.Count > 0)
      {
        ByteListUtils.Replace(ttdmBn, BitConverter.GetBytes(texList.Count), 0x14);
        ByteListUtils.Replace(ttdmBn, BitConverter.GetBytes(texList.Count), 0x18);
        ByteListUtils.Replace(ttdmBn, BitConverter.GetBytes(ttdmBn.Count), 0x20);
        int offsetOffsets = ttdmBn.Count;
        ttdmBn.AddRange(new byte[4 * ((texList.Count + 3) / 4 * 4)]);
        ByteListUtils.Replace(ttdmBn, BitConverter.GetBytes(ttdmBn.Count), 0x24);
        int offsetSizes = ttdmBn.Count;
        ttdmBn.AddRange(new byte[4 * ((texList.Count + 3) / 4 * 4)]);

        ByteListUtils.Replace(ttdmBn, BitConverter.GetBytes(ttdmBn.Count), 0x28);
        ttdmBn.AddRange(ttdlBn);

        for (int i = 0; i < texList.Count; i++)
        {
          ByteListUtils.Replace(ttdmBn, BitConverter.GetBytes(ttdmBn.Count), offsetOffsets + (4 * i));
          ByteListUtils.Replace(ttdmBn, BitConverter.GetBytes(texList[i].Data.Length), offsetSizes + (4 * i));
          ttdmBn.AddRange(texList[i].Data);
          ttdmBn.AddRange(new byte[(16 - (ttdmBn.Count % 16)) % 16]);
          if (ExBinL.Count % 0x40 != 0) ExBinL.AddRange(new byte[0x40 - ExBinL.Count % 0x40]);
        }
      }
      else
      {
        ByteListUtils.Replace(ttdmBn, BitConverter.GetBytes(ttdmBn.Count), 0x28);
        ttdmBn.AddRange(ttdlBn);
      }

      ByteListUtils.Replace(ttdmBn, BitConverter.GetBytes(ttdmBn.Count), 0x10);


      PartBins[partIndex] = ttdmBn;
    }

    /// <summary>
    /// TTDLを構築
    /// </summary>
    /// <param name="texListL">Lに含むテクスチャリスト</param>
    /// <returns>TTDLのバイナリデータ</returns>
    private List<byte> BuildTtdl(List<Textures> texListL)
    {
      var ttdlBn = TmcUtils.BuildHeaderBaseBin("TTDL");
      ttdlBn.AddRange(new byte[0x20]);
      ttdlBn[0xC] = 0x50;

      if (texListL.Count > 0)
      {
        ByteListUtils.Replace(ttdlBn, BitConverter.GetBytes(texListL.Count), 0x14);
        ByteListUtils.Replace(ttdlBn, BitConverter.GetBytes(texListL.Count), 0x18);
        ByteListUtils.Replace(ttdlBn, BitConverter.GetBytes(ttdlBn.Count), 0x20);
        int offsetOffsets = ttdlBn.Count;
        ttdlBn.AddRange(new byte[4 * ((texListL.Count + 3) / 4 * 4)]);
        ByteListUtils.Replace(ttdlBn, BitConverter.GetBytes(ttdlBn.Count), 0x24);
        int offsetSizes = ttdlBn.Count;
        ttdlBn.AddRange(new byte[4 * ((texListL.Count + 3) / 4 * 4)]);
        ExBinL.AddRange(new byte[0x40]);
        for (int i = 0; i < texListL.Count; i++)
        {
          ByteListUtils.Replace(ttdlBn, BitConverter.GetBytes(ExBinL.Count), offsetOffsets + (4 * i));
          ByteListUtils.Replace(ttdlBn, BitConverter.GetBytes(texListL[i].Data.Length), offsetSizes + (4 * i));
          ExBinL.AddRange(texListL[i].Data);
          ExBinL.AddRange(new byte[(16 - (ExBinL.Count % 16)) % 16]);
          if (ExBinL.Count % 0x40 != 0) ExBinL.AddRange(new byte[0x40 - ExBinL.Count % 0x40]);
        }
      }
      else
      {
        ExBinL.AddRange(new byte[0x10]);
      }

      if (ExBinL.Count % 0x80 != 0) ExBinL.AddRange(new byte[0x80 - ExBinL.Count % 0x80]);


      return ttdlBn;
    }

    /// <summary>
    /// TTDHを構築
    /// </summary>
    /// <param name="texCount">テクスチャ数</param>
    /// <returns>TTDHのバイナリデータ</returns>
    private List<byte> BuildTtdh(int texCount)
    {
      var ttdhBn = TmcUtils.BuildHeaderBaseBin("TTDH");
      ttdhBn.AddRange(BitConverter.GetBytes(1));
      ttdhBn.AddRange(new byte[0xC]);

      if (texCount > 0)
      {
        ByteListUtils.Replace(ttdhBn, BitConverter.GetBytes(texCount), 0x14);
        ByteListUtils.Replace(ttdhBn, BitConverter.GetBytes(texCount), 0x18);
        ttdhBn[0x20] = 0x40;
        ttdhBn.AddRange(new byte[4 * ((texCount + 3) / 4 * 4)]);

        int count = 0;
        int countL = 0;
        foreach (var tex in TmcData.Tex)
        {
          ByteListUtils.Replace(ttdhBn, BitConverter.GetBytes(ttdhBn.Count), 0x40 + (4 * (count + countL)));

          if (tex.InL)
          {
            ttdhBn.AddRange(BitConverter.GetBytes(1));
            ttdhBn.AddRange(BitConverter.GetBytes(countL));
            countL++;
          }
          else
          {
            ttdhBn.AddRange(BitConverter.GetBytes(0));
            ttdhBn.AddRange(BitConverter.GetBytes(count));
            count++;
          }
          ttdhBn.AddRange(new byte[8]);
        }
      }
      ByteListUtils.Replace(ttdhBn, BitConverter.GetBytes(ttdhBn.Count), 0x10);


      return ttdhBn;
    }



    /// <summary>
    /// VtxLayを構築
    /// </summary>
    /// <param name="partIndex">パートインデックス</param>
    private void BuildVtxLay(int partIndex)
    {
      // 削除したものを0で初期化
      foreach (var obj in Tables.ObjData)
      {
        if (obj.IsDeleted)
        {
          if (obj.DataIndex == -1)
          {
            ObjectPart objPart = TmcData.ObjGrp[obj.OriginalGrpIndex].Obj[obj.OriginalObjIndex];

            int datasize = TmcData.ObjGrp[obj.OriginalGrpIndex].Decl[objPart.DeclIndex].DataSize;

            int offset = TmcData.VtxGrp[objPart.VtxGrpIndex].Offset + objPart.VtxStartIndex * datasize;

            ByteListUtils.Replace(PartBins[partIndex], new byte[objPart.VtxCount * datasize], offset);
          }
          else
          {
            TmcData data = OtherTmcDataList[obj.DataIndex];

            ObjectPart objPart = data.ObjGrp[obj.OriginalGrpIndex].Obj[obj.OriginalObjIndex];

            int datasize = data.ObjGrp[obj.OriginalGrpIndex].Decl[objPart.DeclIndex].DataSize;

            int offset = data.H.Offsets[partIndex] + data.VtxGrp[objPart.VtxGrpIndex].Offset + objPart.VtxStartIndex * datasize;

            OtherBinList[obj.DataIndex] = ByteListUtils.Replace(OtherBinList[obj.DataIndex].ToList(), new byte[objPart.VtxCount * datasize], offset).ToArray();
          }
        }
      }

      // VtxLay再構築
      List<byte> vtxLayBin = TmcUtils.BuildHeaderBaseBin("VtxLay");
      ByteListUtils.Replace(vtxLayBin, BitConverter.GetBytes(Tables.VIData.Count), 0x14);
      ByteListUtils.Replace(vtxLayBin, BitConverter.GetBytes(Tables.VIData.Count), 0x18);
      vtxLayBin[0x20] = 0x30;

      List<List<byte>> vtxBins = new List<List<byte>>();
      foreach (var viData in Tables.VIData)
      {
        List<byte> newBin = new List<byte>();

        TmcData data;
        if (viData.DataIndex == -1)
          data = TmcData;
        else
          data = OtherTmcDataList[viData.DataIndex];

        if (viData.DataIndex != -1 && !viData.IsAdded)
        {
          int offset = data.H.Offsets[partIndex] + data.VtxGrp[viData.OriginalIndex].Offset;

          newBin.AddRange(OtherBinList[viData.DataIndex].Skip(offset).Take(data.VtxGrp[viData.OriginalIndex].Size));
        }
        else if (!viData.IsAdded)
        {
          newBin.AddRange(PartBins[partIndex].Skip(data.VtxGrp[viData.OriginalIndex].Offset).Take(data.VtxGrp[viData.OriginalIndex].Size));
        }

        if (newBin.Count == 0)
        {
          int addSize = (data.VtxGrp[viData.OriginalIndex].DataSize + 15) / 16 * 16;
          newBin.AddRange(new byte[addSize]);
        }

        vtxBins.Add(newBin);
      }
      TmcUtils.BuildBin(vtxLayBin, vtxBins, null, true, false);


      PartBins[partIndex] = vtxLayBin;
    }



    /// <summary>
    /// IdxLayを構築
    /// </summary>
    /// <param name="partIndex">パートインデックス</param>
    private void BuildIdxLay(int partIndex)
    {
      // 削除したものを0で初期化
      foreach (var obj in Tables.ObjData)
      {
        if (obj.IsDeleted)
        {
          if (obj.DataIndex == -1)
          {
            ObjectPart objPart = TmcData.ObjGrp[obj.OriginalGrpIndex].Obj[obj.OriginalObjIndex];

            int offset = TmcData.IdxGrp[objPart.IdxGrpIndex].Offset + objPart.IdxStartIndex * 2;

            ByteListUtils.Replace(PartBins[partIndex], new byte[objPart.IdxCount * 2], offset);
          }
          else
          {
            TmcData data = OtherTmcDataList[obj.DataIndex];

            ObjectPart objPart = data.ObjGrp[obj.OriginalGrpIndex].Obj[obj.OriginalObjIndex];

            int offset = data.H.Offsets[partIndex] + data.IdxGrp[objPart.IdxGrpIndex].Offset + objPart.IdxStartIndex * 2;

            OtherBinList[obj.DataIndex] = ByteListUtils.Replace(OtherBinList[obj.DataIndex].ToList(), new byte[objPart.IdxCount * 2], offset).ToArray();
          }
        }
      }

      // IdxLay再構築
      List<byte> idxLayBin = TmcUtils.BuildHeaderBaseBin("IdxLay");
      idxLayBin[0x20] = 0x30;

      byte count = 0;
      List<List<byte>> idxBins = new List<List<byte>>();
      foreach (var viData in Tables.VIData)
      {
        if (viData.Use == 0) continue;

        List<byte> newBin = new List<byte>();

        TmcData data;
        if (viData.DataIndex == -1)
          data = TmcData;
        else
          data = OtherTmcDataList[viData.DataIndex];

        if (!viData.IsAdded && viData.OriginalIdxGrp != -1 && data.IdxGrp[viData.OriginalIdxGrp].Size > 0)
        {
          if (viData.DataIndex == -1)
          {
            newBin.AddRange(PartBins[partIndex].Skip(data.IdxGrp[viData.OriginalIdxGrp].Offset).Take(data.IdxGrp[viData.OriginalIdxGrp].Size));
          }
          else
          {
            int offset = data.H.Offsets[partIndex] + data.IdxGrp[viData.OriginalIdxGrp].Offset;

            newBin.AddRange(OtherBinList[viData.DataIndex].Skip(offset).Take(data.IdxGrp[viData.OriginalIdxGrp].Size));
          }
        }

        if (newBin.Count == 0) newBin.AddRange(new byte[0x10]);

        idxBins.Add(newBin);
        count++;
      }
      ByteListUtils.Replace(idxLayBin, BitConverter.GetBytes(count), 0x14);
      ByteListUtils.Replace(idxLayBin, BitConverter.GetBytes(count), 0x18);
      TmcUtils.BuildBin(idxLayBin, idxBins, null, true, false);


      PartBins[partIndex] = idxLayBin;
    }



    /// <summary>
    /// MtrColを構築
    /// </summary>
    /// <param name="partIndex">パートインデックス</param>
    private void BuildMtrCol(int partIndex)
    {
      List<byte> mtrColBin = TmcUtils.BuildHeaderBaseBin("MtrCol");
      ByteListUtils.Replace(mtrColBin, BitConverter.GetBytes(TmcData.ColGrp.Count), 0x14);
      ByteListUtils.Replace(mtrColBin, BitConverter.GetBytes(TmcData.ColGrp.Count), 0x18);
      mtrColBin[0x20] = 0x30;
      mtrColBin.AddRange(new byte[4 * ((TmcData.ColGrp.Count + 3) / 4 * 4)]);

      int colCount = 0;
      foreach (var col in TmcData.ColGrp)
      {
        List<byte> newCol = BuildColors(col, true);

        ByteListUtils.Replace(mtrColBin, BitConverter.GetBytes(mtrColBin.Count), 0x30 + (4 * colCount));
        mtrColBin.AddRange(newCol);
        colCount++;
      }

      // サイズ変更
      ByteListUtils.Replace(mtrColBin, BitConverter.GetBytes(mtrColBin.Count), 0x10);

      PartBins[partIndex] = mtrColBin;
    }

    /// <summary>
    /// Colorsを構築
    /// </summary>
    /// <param name="col">カラーグループ</param>
    /// <param name="setID">IDをセットするかどうか</param>
    /// <returns>カラーのバイナリデータ</returns>
    private List<byte> BuildColors(MtrColorGroup col, bool setID)
    {
      List<byte> newCol = new List<byte>();

      foreach (var color in col.Color)
      {
        foreach (var c in color)
        {
          newCol.AddRange(BitConverter.GetBytes(c));
        }
      }

      if (setID)
        newCol.AddRange(BitConverter.GetBytes(col.ID));
      else
        newCol.AddRange(BitConverter.GetBytes(0));

      Dictionary<int, int> counts = new Dictionary<int, int>();
      foreach (var obj in Tables.ObjData)
      {
        if (obj.Grp == -1)
        {
          counts[obj.ID] = 0;
        }
        else
        {
          if (obj.MtrCol == col.ID) counts[obj.Grp]++;
        }
      }

      int useCount = 0;
      foreach (KeyValuePair<int, int> count in counts)
      {
        if (count.Value != 0)
        {
          useCount++;
        }
      }
      newCol.AddRange(BitConverter.GetBytes(useCount));

      foreach (KeyValuePair<int, int> count in counts)
      {
        if (count.Value != 0)
        {
          newCol.AddRange(BitConverter.GetBytes(count.Key));
          newCol.AddRange(BitConverter.GetBytes(count.Value));
        }
      }

      newCol.AddRange(new byte[(16 - (newCol.Count % 16)) % 16]);

      return newCol;
    }



    /// <summary>
    /// MdlInfoを構築
    /// </summary>
    /// <param name="partIndex">パートインデックス</param>
    private void BuildMdlInfo(int partIndex)
    {
      List<byte> mtdlInfoBin = TmcUtils.BuildHeaderBaseBin("MdlInfo");

      List<List<byte>> objInfoBins = new List<List<byte>>();
      int objInfoIndex = 0;

      List<byte> objInfoBin = new List<byte>();
      List<byte> parentInfoBin = new List<byte>();
      List<List<byte>> infoBins = new List<List<byte>>();
      int infoIndex = 0;
      SortedSet<int> ZIndexSet = new SortedSet<int>();
      SortedSet<int> CastShadowSet = new SortedSet<int>();
      SortedSet<int> ReceiveShadowSet = new SortedSet<int>();

      ObjInfo objInfo = null;
      Info info;
      foreach (var obj in Tables.ObjData)
      {
        if (obj.Grp == -1)
        {
          if (infoBins.Count > 0 || objInfoBin.Count > 0)
          {
            ByteListUtils.Replace(objInfoBin, BitConverter.GetBytes(ZIndexSet.Sum()), 0x44);
            ByteListUtils.Replace(objInfoBin, BitConverter.GetBytes(CastShadowSet.Sum()), 0x68);
            ByteListUtils.Replace(objInfoBin, BitConverter.GetBytes(ReceiveShadowSet.Sum()), 0x6C);

            TmcUtils.BuildBin(objInfoBin, infoBins, null, false, false);
            objInfoBins.Add(objInfoBin);

            objInfoBin = new List<byte>();
            parentInfoBin = new List<byte>();
            infoBins = new List<List<byte>>();
            infoIndex = 0;
            ZIndexSet = new SortedSet<int>();
            CastShadowSet = new SortedSet<int>();
            ReceiveShadowSet = new SortedSet<int>();
          }

          objInfoBin = TmcUtils.BuildHeaderBaseBin("ObjInfo");

          if (obj.DataIndex == -1)
          {
            objInfo = TmcData.ObjInfo[obj.OriginalGrpIndex];
            parentInfoBin = PartBins[partIndex].Skip(objInfo.Offset + 0x30).Take(0x120).ToList();
          }
          else
          {
            objInfo = OtherTmcDataList[obj.DataIndex].ObjInfo[obj.OriginalGrpIndex];
            parentInfoBin = OtherTmcDataList[obj.DataIndex].Bin.Skip(objInfo.Start + 0x30).Take(0x120).ToList();
          }

          ByteListUtils.Replace(parentInfoBin, BitConverter.GetBytes(objInfoIndex), 4);
          ByteListUtils.Replace(parentInfoBin, BitConverter.GetBytes(obj.Z2), 0x28);
          ByteListUtils.Replace(parentInfoBin, BitConverter.GetBytes((float)obj.Culling), 0x100);
          objInfoBin.AddRange(parentInfoBin);
          ByteListUtils.Replace(objInfoBin, BitConverter.GetBytes(objInfoBin.Count), 0x20);

          objInfoIndex++;
        }
        else
        {

          List<byte> infoBin = new List<byte>();

          if (obj.DataIndex == -1)
          {
            info = TmcData.ObjInfo[obj.OriginalGrpIndex].Info[obj.OriginalObjIndex];
            infoBin = PartBins[partIndex].Skip(objInfo.Offset + info.Offset).Take(0xB0).ToList();
          }
          else
          {
            info = OtherTmcDataList[obj.DataIndex].ObjInfo[obj.OriginalGrpIndex].Info[obj.OriginalObjIndex];
            infoBin = OtherTmcDataList[obj.DataIndex].Bin.Skip(objInfo.Start + info.Offset).Take(0xB0).ToList();
          }

          ByteListUtils.Replace(infoBin, BitConverter.GetBytes(infoIndex), 0);
          int z1 = int.Parse(obj.Z1, NumberStyles.AllowHexSpecifier);
          ByteListUtils.Replace(infoBin, BitConverter.GetBytes(z1), 0x04);
          ByteListUtils.Replace(infoBin, BitConverter.GetBytes(obj.Z2), 0x18);
          ByteListUtils.Replace(infoBin, BitConverter.GetBytes(obj.CastShadow), 0x28);
          ByteListUtils.Replace(infoBin, BitConverter.GetBytes(obj.ReceiveShadow), 0x2C);
          ByteListUtils.Replace(infoBin, BitConverter.GetBytes((float)obj.Culling), 0x90);
          infoBins.Add(infoBin);

          ZIndexSet.Add(z1);
          CastShadowSet.Add(obj.CastShadow);
          ReceiveShadowSet.Add(obj.ReceiveShadow);

          infoIndex++;
        }
      }
      ByteListUtils.Replace(objInfoBin, BitConverter.GetBytes(ZIndexSet.Sum()), 0x44);
      ByteListUtils.Replace(objInfoBin, BitConverter.GetBytes(CastShadowSet.Sum()), 0x68);
      ByteListUtils.Replace(objInfoBin, BitConverter.GetBytes(ReceiveShadowSet.Sum()), 0x6C);

      TmcUtils.BuildBin(objInfoBin, infoBins, null, false, false);
      objInfoBins.Add(objInfoBin);

      mtdlInfoBin[0x20] = 0x30;
      TmcUtils.BuildBin(mtdlInfoBin, objInfoBins, null, false, false);

      PartBins[partIndex] = mtdlInfoBin;
    }



    /// <summary>
    /// HieLayを構築
    /// </summary>
    /// <param name="partIndex">パートインデックス</param>
    private void BuildHieLay(int partIndex)
    {
      List<byte> partBin = TmcUtils.BuildHeaderBaseBin("HieLay");

      List<byte> optionBin = new List<byte>();
      optionBin.AddRange(new byte[0x10]);

      List<List<byte>> childBins = new List<List<byte>>();
      for (int i = 0; i < Tables.Nodes.Count; i++)
      {
        Hies hie = TmcData.Hie[Tables.Nodes[i].AddedIndex];

        List<byte> newBin = new List<byte>();

        List<float> m = MatrixUtils.Matrix3DToList(hie.Matrix);
        foreach (float f in m)
        {
          newBin.AddRange(BitConverter.GetBytes(f));
        }

        int parent = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Children.IndexOf(Tables.Nodes[i].Name) != -1);
        if (parent == -1)
        {
          Console.WriteLine("HieLay / Parent Not Found : " + Tables.Nodes[i].Name);
        }
        else if (parent == i)
        {
          Console.WriteLine("HieLay / Parent is Own : " + Tables.Nodes[i].Name);
        }
        newBin.AddRange(BitConverter.GetBytes(parent));

        newBin.AddRange(BitConverter.GetBytes(Tables.Nodes[i].Children.Count));

        newBin.AddRange(BitConverter.GetBytes(Tables.Nodes[i].BoneLevel));

        newBin.AddRange(new byte[4]);

        // Childrenをソート
        Tables.Nodes[i].Children = Tables.Nodes[i].Children.OrderBy(elem => elem.ToLower(), StringComparer.Ordinal).ToList();

        foreach (var child in Tables.Nodes[i].Children)
        {
          int childIdx = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == child);
          if (childIdx != -1) newBin.AddRange(BitConverter.GetBytes(childIdx));
        }
        if (newBin.Count % 16 != 0) newBin.AddRange(new byte[16 - newBin.Count % 16]);

        if (hie.BoneLevel == 0)
        {
          optionBin.AddRange(BitConverter.GetBytes(i));
        }

        childBins.Add(newBin);
      }

      ByteListUtils.Replace(optionBin, BitConverter.GetBytes((optionBin.Count - 0x10) / 4), 0);

      if (optionBin.Count % 16 != 0) optionBin.AddRange(new byte[16 - (optionBin.Count % 16)]);

      TmcUtils.BuildBin(partBin, childBins, optionBin, false, false);


      PartBins[partIndex] = partBin;
    }



    /// <summary>
    /// NodeLayを構築
    /// </summary>
    /// <param name="partIndex">パートインデックス</param>
    private void BuildNodeLay(int partIndex)
    {
      List<byte> nodeLayBin = TmcUtils.BuildHeaderBaseBin("NodeLay");
      nodeLayBin.AddRange(new byte[0x10]);
      nodeLayBin[0x30] = 1;
      nodeLayBin[0x32] = 2;

      List<List<byte>> nodeObjBins = new List<List<byte>>();

      int count = 0;
      foreach (var node in Tables.Nodes)
      {
        Nodes originalNode = TmcData.Node[node.AddedIndex];

        List<byte> nodeObjBin = TmcUtils.BuildHeaderBaseBin("NodeObj");
        nodeObjBin.AddRange(BitConverter.GetBytes(0));

        int master = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == node.Master);
        nodeObjBin.AddRange(BitConverter.GetBytes(master));

        nodeObjBin.AddRange(BitConverter.GetBytes(count));
        nodeObjBin.AddRange(BitConverter.GetBytes(0));
        nodeObjBin.AddRange(Encoding.ASCII.GetBytes(node.Name));
        nodeObjBin.AddRange(new byte[16 - (nodeObjBin.Count % 16)]);

        if (node.ObjIndex != -1)
        {
          ByteListUtils.Replace(nodeObjBin, BitConverter.GetBytes(nodeObjBin.Count), 0x20);
          nodeObjBin[0x14] = 1;
          nodeObjBin[0x18] = 1;
          nodeObjBin.AddRange(BitConverter.GetBytes(nodeObjBin.Count + 0x10));
          nodeObjBin.AddRange(new byte[12]);

          nodeObjBin.AddRange(BitConverter.GetBytes(node.ObjIndex));

          if (node.IsBlendCleared)
            nodeObjBin.AddRange(BitConverter.GetBytes(0));
          else
            nodeObjBin.AddRange(BitConverter.GetBytes(node.Blends.Count));

          nodeObjBin.AddRange(BitConverter.GetBytes(count));
          nodeObjBin.AddRange(BitConverter.GetBytes(0));

          List<float> m = MatrixUtils.Matrix3DToList(originalNode.Matrix);
          foreach (float f in m)
          {
            nodeObjBin.AddRange(BitConverter.GetBytes(f));
          }

          if (!node.IsBlendCleared)
          {
            foreach (var blend in node.Blends)
            {
              int idx = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == blend);
              if (idx == -1)
              {
                Console.WriteLine("Missing BlendIdx : " + blend);
              }
              nodeObjBin.AddRange(BitConverter.GetBytes(idx));
            }
          }

          if (nodeObjBin.Count % 16 > 0) nodeObjBin.AddRange(new byte[16 - (nodeObjBin.Count % 16)]);
        }

        ByteListUtils.Replace(nodeObjBin, BitConverter.GetBytes(nodeObjBin.Count), 0x10);

        nodeObjBins.Add(nodeObjBin);

        count++;
      }
      TmcUtils.BuildBin(nodeLayBin, nodeObjBins, null, false, false);


      PartBins[partIndex] = nodeLayBin;
    }



    /// <summary>
    /// GlblMtx/BnOfsMtxを構築
    /// </summary>
    /// <param name="partIndex">パートインデックス</param>
    /// <param name="type">パートタイプ</param>
    private void BuildMtx(int partIndex, string type)
    {
      List<byte> partBin = TmcUtils.BuildHeaderBaseBin(type);

      var mtxGrp = TmcData.MtxGrp;
      if (type == "BnOfsMtx") mtxGrp = TmcData.BnOfsMtxGrp;

      List<List<byte>> childBins = new List<List<byte>>();

      foreach (var node in Tables.Nodes)
      {
        List<byte> newBin = new List<byte>();

        if (node.IsResetMatrix)
        {
          List<float> m = MatrixUtils.Matrix3DToList(mtxGrp[node.AddedIndex].Matrix);
          foreach (float f in m)
          {
            newBin.AddRange(BitConverter.GetBytes(f));
          }
        }
        else if (node.DataIndex == -1)
        {
          newBin.AddRange(PartBins[partIndex].Skip(mtxGrp[node.AddedIndex].Offset).Take(0x40).ToArray());
        }
        else
        {
          newBin.AddRange(OtherTmcDataList[node.DataIndex].Bin.Skip(mtxGrp[node.AddedIndex].Start).Take(0x40).ToArray());
        }

        childBins.Add(newBin);
      }

      TmcUtils.BuildBin(partBin, childBins, null, false, false);


      PartBins[partIndex] = partBin;
    }



    /// <summary>
    /// cpfを構築
    /// </summary>
    /// <param name="partIndex">パートインデックス</param>
    private void BuildCpf(int partIndex)
    {
      List<byte> cpfBin = TmcUtils.BuildHeaderBaseBin("cpf");

      List<List<byte>> cpfBins = new List<List<byte>>();

      // nodecpの変更をチェック
      Dictionary<int, int> cpChanges = CheckNodecpChanges();

      List<byte> nodecpBin = new List<byte>();
      List<byte> matecpBin = new List<byte>();


      if (TmcData.cpfOffsets != null)
      {
        int headerCount = TmcData.cpfOffsets[0];
        if (headerCount == 0)
        {
          if (TmcData.cpfOffsets.Length > 1 && TmcData.cpfOffsets[1] != 0)
            headerCount = TmcData.cpfOffsets[1];
          else
            headerCount = PartBins[partIndex].Count;
        }

        if (cpChanges.Count > 0 || ObjGrpRebuild)
        {
          nodecpBin.AddRange(TmcUtils.BuildHeaderBaseBin("nodecp"));
          List<List<byte>> nodecpBins = new List<List<byte>>();

          for (int i = 0; i < Tables.Nodes.Count; i++)
          {
            var node = Tables.Nodes[i];

            var cpBin = new List<byte>();

            int nodecp = Array.FindIndex(TmcData.NodeCp.ToArray(), elem => elem.Index == node.AddedIndex);

            if (nodecp != -1)
            {
              if (Tables.Nodes[i].DataIndex == -1)
              {
                int offset = headerCount + TmcData.NodeCp[nodecp].Offset;
                cpBin.AddRange(PartBins[partIndex].Skip(offset).Take(TmcData.NodeCp[nodecp].Size));
                // 同じオフセットのものも別のものとして取得
              }
              else
              {
                int offset = OtherTmcDataList[node.DataIndex].H.Offsets[partIndex] + headerCount + TmcData.NodeCp[nodecp].Offset;
                cpBin.AddRange(OtherTmcDataList[node.DataIndex].Bin.Skip(offset).Take(TmcData.NodeCp[nodecp].Size));
              }
            }
            nodecpBins.Add(cpBin);
          }

          // nodecpを変更
          if (cpChanges.Count > 0) ReflectNodecpChanges(nodecpBins, cpChanges);


          TmcUtils.BuildBin(nodecpBin, nodecpBins, null, false, true);
        }
        else
        {
          if (TmcData.cpfOffsets.Length > 1 && TmcData.cpfOffsets[1] != 0)
            nodecpBin.AddRange(PartBins[partIndex].Skip(headerCount).Take(TmcData.cpfOffsets[1] - headerCount));
          else
            nodecpBin.AddRange(PartBins[partIndex].Skip(headerCount));
        }
      }

      cpfBins.Add(nodecpBin);

      #region matecp

      if (TmcData.MateCp.Count > 0) matecpBin.AddRange(BuildMatecp());
      #endregion

      cpfBins.Add(matecpBin);

      if (nodecpBin.Count == 0 && matecpBin.Count == 0)
      {
        PartBins[partIndex] = new List<byte>();
        return;
      }

      TmcUtils.BuildBin(cpfBin, cpfBins, null, false, true);

      PartBins[partIndex] = cpfBin;
    }

    /// <summary>
    /// nodecpの変更をチェック
    /// </summary>
    /// <returns>nodecpが変更されたノードのディクショナリ</returns>
    private Dictionary<int, int> CheckNodecpChanges()
    {
      Dictionary<int, int> cpChanges = new Dictionary<int, int>();


      foreach (var obj in Tables.ObjData)
      {
        if (obj.Toggle == -1) continue;

        int toggleValue = 0;

        TmcData data = TmcData;
        if (obj.DataIndex != -1) data = OtherTmcDataList[obj.DataIndex];

        if (data.ObjGrp[obj.OriginalGrpIndex].NodeCp != -1)
        {
          foreach (var cp in data.NodeCp[data.ObjGrp[obj.OriginalGrpIndex].NodeCp].Cp)
          {
            if (cp.Data1 == 0xBB474F4B && cp.Param == 0)
            {
              toggleValue = 1;
            }
            else if (cp.Data1 == 0xBB474F4B && cp.Param == 1)
            {
              toggleValue = 2;
            }
            else if (cp.Data1 == 0xA50A10E2 && cp.Param == 0)
            {
              toggleValue = 3;
            }
            else if (cp.Data1 == 0xA50A10E2 && cp.Param == 1)
            {
              toggleValue = 4;
            }
          }
        }

        if (toggleValue != obj.Toggle)
        {
          cpChanges[obj.Index] = obj.Toggle;
        }
      }


      return cpChanges;
    }

    /// <summary>
    /// nodecpの変更を反映
    /// </summary>
    /// <param name="nodecpBins">nodecpのバイナリ群</param>
    /// <param name="cpChanges">nodecpが変更されたノードのディクショナリ</param>
    private void ReflectNodecpChanges(List<List<byte>> nodecpBins, Dictionary<int, int> cpChanges)
    {
      foreach (var param in cpChanges)
      {
        int node = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == Tables.ObjData[param.Key].Name);
        int originalObjID = Tables.ObjData[param.Key].OriginalGrpIndex;

        Customp nodecp = null;
        if (TmcData.ObjGrp[originalObjID].NodeCp != -1) nodecp = TmcData.NodeCp[TmcData.ObjGrp[originalObjID].NodeCp];

        uint toggleParam = 0;
        int toggleFlag = 1;
        var exclusions = new List<uint>();

        if (param.Value == 1 || param.Value == 2)
        {
          toggleParam = 0xBB474F4B;
          toggleFlag = param.Value;
          exclusions.Add(0xA50A10E2);
        }
        else if (param.Value == 3 || param.Value == 4)
        {
          toggleParam = 0xA50A10E2;
          toggleFlag = param.Value - 2;
          exclusions.Add(0xBB474F4B);
        }

        if (toggleParam != 0)
        {
          // 既にcustompがあるか
          if (TmcData.ObjGrp[originalObjID].NodeCp == -1)
          {
            // custompを追加
            nodecpBins[node] = CreateCustomp(toggleParam, toggleFlag);
          }
          else
          {
            // custompにパラメーターを追加
            nodecpBins[node] = EditCustomp(nodecp, toggleParam, toggleFlag, exclusions);
          }
        }
        else
        {
          // custompに他の値があるか
          if (nodecp.Cp.Count == 1)
          {
            // custompを削除
            nodecpBins[node].Clear();
          }
          else
          {
            // custompのパラメーターを削除
            nodecpBins[node] = EditCustomp(nodecp, 0, 0, null);
          }
        }
      }
    }

    /// <summary>
    /// custompを編集
    /// </summary>
    /// <returns>custompのバイナリデータ</returns>
    private List<byte> EditCustomp(Customp nodecp, uint toggleParam, int toggleFlag, List<uint> exclusions)
    {
      List<byte> cpBin = TmcUtils.BuildHeaderBaseBin("customp");

      List<byte> offsetsBin = new List<byte>();
      List<byte> Data1Bin = new List<byte>();
      List<byte> Data2Bin = new List<byte>();

      byte paramCount = 0;


      if (exclusions != null)
      {
        // custompにパラメーターを追加

        int cpCount = nodecp.Cp.Count;
        if (Array.FindIndex(nodecp.Cp.ToArray(), cp => cp.Data1 == toggleParam) == -1) cpCount++;

        int count = 0;
        bool added = false;
        int baseSize = 0x30 + ((4 * cpCount) + 15) / 16 * 16 + ((8 * cpCount) + 15) / 16 * 16;

        for (int i = 0; i <= nodecp.Cp.Count; i++)
        {
          // offsets    4 bytes
          // Data1      8 bytes
          // Data2   0x10 bytes

          if (!added && (count == nodecp.Cp.Count || nodecp.Cp[count].Data1 >= toggleParam))
          {
            offsetsBin.AddRange(BitConverter.GetBytes(baseSize + Data2Bin.Count));
            Data1Bin.AddRange(BitConverter.GetBytes(toggleParam));
            Data1Bin.AddRange(BitConverter.GetBytes(i));
            Data2Bin.AddRange(BitConverter.GetBytes(1));
            if (toggleFlag == 1)
              Data2Bin.AddRange(BitConverter.GetBytes(0));
            else if (toggleFlag == 2)
              Data2Bin.AddRange(BitConverter.GetBytes(1));
            Data2Bin.AddRange(new byte[8]);
            added = true;
            paramCount++;
            if (count < nodecp.Cp.Count && nodecp.Cp[count].Data1 == toggleParam)
            {
              count++;
            }
          }
          else if (count < nodecp.Cp.Count && !exclusions.Contains(nodecp.Cp[count].Data1))
          {
            offsetsBin.AddRange(BitConverter.GetBytes(baseSize + Data2Bin.Count));
            Data1Bin.AddRange(BitConverter.GetBytes(nodecp.Cp[count].Data1));
            Data1Bin.AddRange(BitConverter.GetBytes(i));
            Data2Bin.AddRange(BitConverter.GetBytes(nodecp.Cp[count].Data2));
            Data2Bin.AddRange(BitConverter.GetBytes(nodecp.Cp[count].Param));
            Data2Bin.AddRange(new byte[(16 - (Data2Bin.Count % 16)) % 16]);
            paramCount++;
            count++;
          }
        }
      }
      else
      {
        // custompのパラメーターを削除

        int baseSize = 0x30 + (((nodecp.Cp.Count - 1) * 4) + 15) / 16 * 16 + (((nodecp.Cp.Count - 1) * 8) + 15) / 16 * 16;

        for (int i = 0; i < nodecp.Cp.Count; i++)
        {
          if (nodecp.Cp[i].Data1 != 0xBB474F4B && nodecp.Cp[i].Data1 != 0xA50A10E2)
          {
            offsetsBin.AddRange(BitConverter.GetBytes(baseSize + Data2Bin.Count));
            Data1Bin.AddRange(BitConverter.GetBytes(nodecp.Cp[i].Data1));
            Data1Bin.AddRange(BitConverter.GetBytes(i));
            Data2Bin.AddRange(BitConverter.GetBytes(nodecp.Cp[i].Data2));
            Data2Bin.AddRange(BitConverter.GetBytes(nodecp.Cp[i].Param));
            Data2Bin.AddRange(new byte[(16 - (Data2Bin.Count % 16)) % 16]);
            paramCount++;
          }
        }
      }


      offsetsBin.AddRange(new byte[(16 - (offsetsBin.Count % 16)) % 16]);
      Data1Bin.AddRange(new byte[(16 - (Data1Bin.Count % 16)) % 16]);

      ByteListUtils.Replace(cpBin, BitConverter.GetBytes(paramCount), 0x14);
      ByteListUtils.Replace(cpBin, BitConverter.GetBytes(paramCount), 0x18);
      cpBin[0x20] = 0x30;

      cpBin.AddRange(offsetsBin);
      ByteListUtils.Replace(cpBin, BitConverter.GetBytes(cpBin.Count), 0x28);

      cpBin.AddRange(Data1Bin);
      cpBin.AddRange(Data2Bin);
      ByteListUtils.Replace(cpBin, BitConverter.GetBytes(cpBin.Count), 0x10);


      return cpBin;
    }

    /// <summary>
    /// custompを新規作成
    /// </summary>
    /// <returns>custompのバイナリデータ</returns>
    private List<byte> CreateCustomp(uint toggleParam, int toggleFlag)
    {
      List<byte> cpBin = TmcUtils.BuildHeaderBaseBin("customp");

      ByteListUtils.Replace(cpBin, BitConverter.GetBytes(1), 0x14);
      ByteListUtils.Replace(cpBin, BitConverter.GetBytes(1), 0x18);
      cpBin[0x20] = 0x30;

      cpBin.AddRange(new byte[0x10]);

      cpBin[0x28] = (byte)cpBin.Count;

      cpBin.AddRange(BitConverter.GetBytes(toggleParam));
      cpBin.AddRange(new byte[0xC]);

      cpBin[0x30] = (byte)cpBin.Count;

      cpBin.AddRange(BitConverter.GetBytes(1));
      cpBin.AddRange(BitConverter.GetBytes(toggleFlag - 1));
      cpBin.AddRange(new byte[8]);

      ByteListUtils.Replace(cpBin, BitConverter.GetBytes(cpBin.Count), 0x10);


      return cpBin;
    }

    /// <summary>
    /// matecpを構築
    /// </summary>
    /// <param name="partIndex">パートインデックス</param>
    /// <returns>matecpのバイナリデータ</returns>
    private List<byte> BuildMatecp()
    {
      List<byte> matecpBin = TmcUtils.BuildHeaderBaseBin("matecp");
      matecpBin[0x20] = 0x30;


      // itable構築
      List<byte> itableBin = BuildItable();


      // customp構築
      List<List<byte>> cpBins = new List<List<byte>>();
      foreach (var customp in TmcData.MateCp)
      {
        cpBins.Add(BuildCustomp(customp));
      }

      TmcUtils.BuildBin(matecpBin, cpBins, itableBin, false, false);


      return matecpBin;
    }

    /// <summary>
    /// itableを構築
    /// </summary>
    /// <returns>itableのバイナリデータ</returns>
    private List<byte> BuildItable()
    {
      int objGeoCount = Tables.ObjData.Where(obj => obj.Grp == -1).Count();

      List<byte> itableBin = TmcUtils.BuildHeaderBaseBin("itable");
      List<int> itableOffsets = new List<int>();
      ByteListUtils.Replace(itableBin, BitConverter.GetBytes(objGeoCount), 0x14);
      ByteListUtils.Replace(itableBin, BitConverter.GetBytes(objGeoCount), 0x18);
      itableBin[0x20] = 0x30;
      itableBin.AddRange(new byte[4 * ((objGeoCount + 3) / 4 * 4)]);

      List<byte> objCounts = new List<byte>();
      foreach (var obj in Tables.ObjData)
      {
        if (obj.Grp == -1)
        {
          if (itableBin.Count % 16 != 0)
          {
            itableBin.AddRange(new byte[16 - (itableBin.Count % 16)]);
          }
          itableOffsets.Add(itableBin.Count);
          ByteListUtils.Replace(itableBin, BitConverter.GetBytes(itableBin.Count), 0x30 + (4 * obj.ID));
          itableBin.AddRange(BitConverter.GetBytes(0));

          objCounts.Add(0);
        }
        else
        {
          itableBin.AddRange(BitConverter.GetBytes((int)obj.Matecp));

          objCounts[obj.Grp]++;
        }
      }
      if (itableBin.Count % 16 != 0)
      {
        itableBin.AddRange(new byte[16 - (itableBin.Count % 16)]);
      }
      for (int i = 0; i < objCounts.Count; i++)
      {
        itableBin[itableOffsets[i]] = objCounts[i];
      }
      ByteListUtils.Replace(itableBin, BitConverter.GetBytes(itableBin.Count), 0x10);


      return itableBin;
    }

    /// <summary>
    /// custompを構築
    /// </summary>
    /// <returns>custompのバイナリデータ</returns>
    private List<byte> BuildCustomp(Customp customp)
    {
      List<byte> cpBin = TmcUtils.BuildHeaderBaseBin("customp");

      ByteListUtils.Replace(cpBin, BitConverter.GetBytes(customp.Cp.Count), 0x14);
      ByteListUtils.Replace(cpBin, BitConverter.GetBytes(customp.Cp.Count), 0x18);
      cpBin[0x20] = 0x30;

      cpBin.AddRange(new byte[4 * ((customp.Cp.Count + 3) / 4 * 4)]);
      cpBin[0x28] = (byte)cpBin.Count;
      cpBin.AddRange(new byte[8 * ((customp.Cp.Count + 1) / 2 * 2)]);

      for (int i = 0; i < customp.Cp.Count; i++)
      {
        ByteListUtils.Replace(cpBin, BitConverter.GetBytes(cpBin.Count), 0x30 + (4 * i));
        ByteListUtils.Replace(cpBin, BitConverter.GetBytes(customp.Cp[i].Data1), cpBin[0x28] + (8 * i));
        ByteListUtils.Replace(cpBin, BitConverter.GetBytes(i), cpBin[0x28] + 4 + (8 * i));
        cpBin.AddRange(BitConverter.GetBytes(customp.Cp[i].Data2));
        cpBin.AddRange(BitConverter.GetBytes(customp.Cp[i].Param));

        if (cpBin.Count % 16 != 0) cpBin.AddRange(new byte[16 - (cpBin.Count % 16)]);
      }
      ByteListUtils.Replace(cpBin, BitConverter.GetBytes(cpBin.Count), 0x10);


      return cpBin;
    }



    /// <summary>
    /// McaPackを構築
    /// </summary>
    /// <param name="partIndex">パートインデックス</param>
    private void BuildMcaPack(int partIndex)
    {
      List<byte> mcapackBin = TmcUtils.BuildHeaderBaseBin("MCAPACK");
      ByteListUtils.Replace(mcapackBin, BitConverter.GetBytes(TmcData.Mat.Count), 0x14);
      ByteListUtils.Replace(mcapackBin, BitConverter.GetBytes(TmcData.Mat.Count), 0x18);
      mcapackBin[0x20] = 0x40;
      mcapackBin.AddRange(BitConverter.GetBytes(1));
      mcapackBin.AddRange(BitConverter.GetBytes(-1));
      mcapackBin.AddRange(BitConverter.GetBytes(-1));
      mcapackBin.AddRange(BitConverter.GetBytes(-1));
      mcapackBin.AddRange(new byte[4 * ((TmcData.Mat.Count + 3) / 4 * 4)]);
      ByteListUtils.Replace(mcapackBin, BitConverter.GetBytes(mcapackBin.Count), 0x28);


      List<byte> mcaindexBin = TmcUtils.BuildHeaderBaseBin("MCAINDEX");
      mcaindexBin[0x20] = 0x30;

      List<List<byte>> newIndices = new List<List<byte>>();
      List<byte> newIndex = new List<byte>();
      foreach (var obj in Tables.ObjData)
      {
        if (obj.Grp == -1)
        {
          if (obj.ID > 0)
          {
            newIndex.AddRange(new byte[(16 - (newIndex.Count % 16)) % 16]);
            newIndices.Add(newIndex);
          }
          newIndex = new List<byte>();
        }
        else
        {
          if (obj.Mcamtrl == null) obj.Mcamtrl = -1;
          newIndex.AddRange(BitConverter.GetBytes((int)obj.Mcamtrl));
        }
      }
      newIndex.AddRange(new byte[(16 - (newIndex.Count % 16)) % 16]);
      newIndices.Add(newIndex);

      // mcaindexBin構築
      TmcUtils.BuildBin(mcaindexBin, newIndices, null, false, true);
      mcapackBin.AddRange(mcaindexBin);

      foreach (var mat in TmcData.Mat)
      {
        List<byte> newMat = TmcUtils.BuildHeaderBaseBin("MCAMTRL");
        newMat[0x14] = 0x21;
        newMat[0x18] = (byte)mat.Param.Count;
        newMat[0x20] = 0x30;
        newMat.AddRange(new byte[0x90]);

        foreach (var param in mat.Param)
        {
          if (param == null) continue;

          List<byte> newParam = TmcUtils.BuildHeaderBaseBin("MCAPARAM");
          if (param.Params != null && param.Params.Count > 0)
          {
            ByteListUtils.Replace(newParam, BitConverter.GetBytes(param.Params.Count), 0x14);
            ByteListUtils.Replace(newParam, BitConverter.GetBytes(param.Params.Count), 0x18);
            newParam[0x20] = 0x60;
            newParam[0x28] = 0x40;
          }
          newParam.AddRange(BitConverter.GetBytes(param.Data1));
          newParam.Add(param.Data2);
          newParam.AddRange(Enumerable.Repeat<byte>(0xFF, 11).ToArray());

          if (param.Data3 != null)
          {
            foreach (var data in param.Data3)
            {
              newParam.AddRange(BitConverter.GetBytes(data));
            }
            newParam.AddRange(new byte[(16 - (newParam.Count % 16)) % 16]);
          }

          if (param.Params != null)
          {
            foreach (var ps in param.Params)
            {
              foreach (var p in ps)
              {
                newParam.AddRange(BitConverter.GetBytes(p));
              }
            }
          }

          // サイズ変更
          ByteListUtils.Replace(newParam, BitConverter.GetBytes(newParam.Count), 0x10);

          // オフセット変更と追加
          ByteListUtils.Replace(newMat, BitConverter.GetBytes(newMat.Count), 0x30 + (4 * param.ID));
          newMat.AddRange(newParam);
        }

        // サイズ変更
        ByteListUtils.Replace(newMat, BitConverter.GetBytes(newMat.Count), 0x10);

        // オフセット変更と追加
        ByteListUtils.Replace(mcapackBin, BitConverter.GetBytes(mcapackBin.Count), 0x40 + (4 * mat.ID));
        mcapackBin.AddRange(newMat);
      }

      // サイズ変更
      ByteListUtils.Replace(mcapackBin, BitConverter.GetBytes(mcapackBin.Count), 0x10);


      PartBins[partIndex] = mcapackBin;
    }



    /// <summary>
    /// RenPackを構築
    /// </summary>
    /// <param name="partIndex">パートインデックス</param>
    private void BuildRenPack(int partIndex)
    {
      ByteListUtils.Replace(PartBins[partIndex], BitConverter.GetBytes(Tables.ObjCounts.Count), 0x14);
    }



    /// <summary>
    /// Acsclsを構築
    /// </summary>
    /// <param name="partIndex">パートインデックス</param>
    private void BuildAcscls(int partIndex)
    {
      List<List<byte>> childBins = new List<List<byte>>();
      HeaderData h = null;
      if (PartBins[partIndex].Count != 0)
      {
        h = new HeaderData(PartBins[partIndex].ToArray(), 0);
        int lastOffset = h.Size;
        for (int i = (int)h.Count1 - 1; i >= 0; i--)
        {
          List<byte> childBin = new List<byte>();
          if (h.Offsets[i] != 0)
          {
            childBin.AddRange(PartBins[partIndex].Skip(h.Offsets[i]).Take(lastOffset - h.Offsets[i]));
            lastOffset = h.Offsets[i];
          }
          childBins.Insert(0, childBin);
        }
      }
      else
      {
        for (int i = 0; i < 4; i++)
        {
          List<byte> childBin = new List<byte>();
          childBins.Add(childBin);
        }
      }


      if (Tables.PhysicsList.Count > 0)
      {
        childBins[0] = BuildPhysicsBin(childBins[0], h);
      }
      else if (childBins[0].Count > 0)
      {
        childBins[0].Clear();
      }


      childBins[1] = BuildCollisionBin();


      for (int i = 0; i < 2; i++)
      {
        if (Tables.PhysicsIndicesSet[i].Count == 0)
        {
          if (childBins[2 + i].Count > 0) childBins[2 + i].Clear();
          continue;
        }

        List<byte> childBin = TmcUtils.BuildHeaderBaseBin("");

        ByteListUtils.Replace(childBin, BitConverter.GetBytes(Tables.PhysicsIndicesSet[i].Count), 0x14);
        ByteListUtils.Replace(childBin, BitConverter.GetBytes(Tables.PhysicsIndicesSet[i].Count), 0x18);
        ByteListUtils.Replace(childBin, BitConverter.GetBytes(0x30), 0x20);

        foreach (var indices in Tables.PhysicsIndicesSet[i])
        {
          int nodeIndex = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == indices.Name);
          childBin.AddRange(BitConverter.GetBytes(nodeIndex));
        }

        if (childBin.Count % 16 > 0) childBin.AddRange(new byte[16 - (childBin.Count % 16)]);

        ByteListUtils.Replace(childBin, BitConverter.GetBytes(childBin.Count), 0x10);

        childBins[2 + i] = childBin;
      }


      List<byte> partBin = TmcUtils.BuildHeaderBaseBin("ACSCLS");
      partBin.AddRange(new byte[0x10]);
      partBin[0x30] = 0x0C;

      TmcUtils.BuildBin(partBin, childBins, null, false, true);

      // Headerの全体サイズを変更
      ByteListUtils.Replace(partBin, BitConverter.GetBytes(partBin.Count), 0x10);


      PartBins[partIndex] = partBin;
    }

    /// <summary>
    /// Physicsを構築
    /// </summary>
    /// <param name="bin">Physicsバイナリ</param>
    /// <param name="h">Acsclsヘッダーデータ</param>
    /// <returns>Physicsのバイナリデータ</returns>
    private List<byte> BuildPhysicsBin(List<byte> bin, HeaderData h)
    {
      List<List<byte>> physicsBins = new List<List<byte>>();
      HeaderData childBinH = null;
      if (h.Offsets[0] != 0)
      {
        childBinH = new HeaderData(bin.ToArray(), 0);
      }

      List<byte> childBin = TmcUtils.BuildHeaderBaseBin("");

      List<byte> childHeaderBin = TmcUtils.BuildHeaderBaseBin("");
      int inUseCount = 0;
      for (int i = 0; i < Tables.PhysicsList.Count; i++)
      {
        if (Tables.PhysicsList[i].Data.InUse)
        {
          childHeaderBin.AddRange(BitConverter.GetBytes(i));
          inUseCount++;
        }
      }
      childHeaderBin.InsertRange(0x30, BitConverter.GetBytes(inUseCount));

      if (childHeaderBin.Count % 16 > 0) childHeaderBin.AddRange(new byte[16 - (childHeaderBin.Count % 16)]);
      ByteListUtils.Replace(childHeaderBin, BitConverter.GetBytes(childHeaderBin.Count), 0x20);


      Tables.PhysicsList = Tables.PhysicsList.OrderBy(elem => elem.Name.ToLower(), StringComparer.Ordinal).ToList();

      foreach (var physics in Tables.PhysicsList)
      {
        if (physics.DataIndex == -1)
          physicsBins.Add(BuildPhysicsPartBin(bin, childHeaderBin, physics, childBinH.Offsets[physics.Data.Index]));
        else
          physicsBins.Add(BuildPhysicsPartBin(null, childHeaderBin, physics, -1));
      }

      // childHeaderBin
      if (childHeaderBin.Count % 16 > 0) childHeaderBin.AddRange(new byte[16 - (childHeaderBin.Count % 16)]);
      ByteListUtils.Replace(childHeaderBin, BitConverter.GetBytes(childHeaderBin.Count), 0x10);
      ByteListUtils.Replace(childHeaderBin, BitConverter.GetBytes(Tables.PhysicsList.Count), 0x14);
      ByteListUtils.Replace(childHeaderBin, BitConverter.GetBytes(Tables.PhysicsList.Count), 0x18);

      childBin.AddRange(childHeaderBin);

      TmcUtils.BuildBin(childBin, physicsBins, null, false, false);


      return childBin;
    }

    /// <summary>
    /// Physicsを構築
    /// </summary>
    /// <param name="bin">Physicsバイナリ</param>
    /// <param name="physics">Physicsデータ</param>
    /// <param name="offset">Physicsパートへのオフセット</param>
    /// <param name="node">ノードインデックス</param>
    /// <returns>Physicsパートのバイナリデータ</returns>
    private List<byte> BuildPhysicsPartBin(List<byte> bin, List<byte> childHeaderBin, Physics physics, int offset)
    {
      List<byte> physicsBin = new List<byte>();
      HeaderData physicsH;

      var data = TmcData;
      if (physics.DataIndex == -1)
      {
        physicsH = new HeaderData(bin.ToArray(), offset);
        physicsBin.AddRange(bin.Skip(physicsH.Start).Take(physicsH.Size));
      }
      else
      {
        data = OtherTmcDataList[physics.DataIndex];
        var otherH = new HeaderData(data.Bin.ToArray(), data.H.Offsets[16]);
        var otherChildBinH = new HeaderData(data.Bin.ToArray(), otherH.Start + otherH.Offsets[0]);
        physicsH = new HeaderData(data.Bin.ToArray(), otherChildBinH.Start + otherChildBinH.Offsets[physics.Data.Index]);
        physicsBin.AddRange(data.Bin.Skip(physicsH.Start).Take(physicsH.Size));
      }

      physicsH = new HeaderData(physicsBin.ToArray(), 0);

      int node = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == physics.Name);

      if (node == -1)
      {
        Console.WriteLine(physics.Name);
      }

      int oriBaseNode = data.AcsclsIndices[0][physics.Data.BaseNode];
      int baseNode = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.OriginalIndex == oriBaseNode && elem.DataIndex == physics.DataIndex);

      if (baseNode == -1)
      {
        Console.WriteLine(physics.Name);
      }

      int nodeInIndices = Array.FindIndex(Tables.PhysicsIndicesSet[0].ToArray(), elem => elem.Name == Tables.Nodes[baseNode].Name);

      if (nodeInIndices == -1)
      {
        Console.WriteLine(physics.Name);
      }

      if (physics.Data.Type != 2)
      {
        ByteListUtils.Replace(physicsBin, BitConverter.GetBytes(node), 0x90);
        ByteListUtils.Replace(physicsBin, BitConverter.GetBytes(nodeInIndices), 0x98);

        var block1H1 = new HeaderData(physicsBin.ToArray(), physicsH.Offsets[0]);

        for (int i = 0; i < physics.Data.Block1.Count; i++)
        {
          int block1Start = (int)(block1H1.Start + block1H1.Offset1 + (0xA0 * i));
          var part = physics.Data.Block1[i];

          int nodeIndex = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.OriginalIndex == part.NodeIndex && elem.DataIndex == physics.DataIndex);
          int localIndex = Array.FindIndex(Tables.PhysicsIndicesSet[1].ToArray(), elem => elem.Name == Tables.Nodes[nodeIndex].Name);

          ByteListUtils.Replace(physicsBin, BitConverter.GetBytes(nodeIndex), block1Start + 0x88);
          ByteListUtils.Replace(physicsBin, BitConverter.GetBytes(localIndex), block1Start + 0x90);
        }

        int blockEndIndex = 5;
        if (physics.Data.Type != 0)
        {
          blockEndIndex = 4;
        }
        for (int i = 0; i < physics.Data.BlockEndIndices.Count; i++)
        {
          string nodeName = data.Node[physics.Data.BlockEndIndices[i]].Name;
          int nodeIndex = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == nodeName);

          ByteListUtils.Replace(physicsBin, BitConverter.GetBytes(nodeIndex), (int)(physicsH.Offsets[blockEndIndex] + 0x80 + (4 * i)));
        }
      }
      else
      {
        ByteListUtils.Replace(physicsBin, BitConverter.GetBytes(node), 0xA0);
        ByteListUtils.Replace(physicsBin, BitConverter.GetBytes(nodeInIndices), 0xA4);

        for (int i = 0; i < physicsH.Count1; i++)
        {
          for (int j = 0; j < physics.Data.Type2[i].Count; j++)
          {
            var part = physics.Data.Type2[i][j];

            int nodeIndex = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.OriginalIndex == part.NodeIndex && elem.DataIndex == physics.DataIndex);
            int localIndex = Array.FindIndex(Tables.PhysicsIndicesSet[1].ToArray(), elem => elem.Name == Tables.Nodes[nodeIndex].Name);

            ByteListUtils.Replace(physicsBin, BitConverter.GetBytes(nodeIndex), (int)(physicsH.Offsets[i] + 0x30 + 0x40 * j + 0x30));
            ByteListUtils.Replace(physicsBin, BitConverter.GetBytes(localIndex), (int)(physicsH.Offsets[i] + 0x30 + 0x40 * j + 0x34));
          }
        }
      }

      // childHeaderBin
      childHeaderBin.AddRange(BitConverter.GetBytes(physics.Data.Type));
      childHeaderBin.AddRange(BitConverter.GetBytes(node));
      childHeaderBin.AddRange(BitConverter.GetBytes(physics.Data.Param));


      return physicsBin;
    }

    /// <summary>
    /// コリジョンを構築
    /// </summary>
    /// <returns>コリジョンのバイナリデータ</returns>
    private List<byte> BuildCollisionBin()
    {
      List<byte> collisionBin = new List<byte>();
      if (TmcData.Collisions.Count != 0)
      {
        collisionBin = TmcUtils.BuildHeaderBaseBin("");
        ByteListUtils.Replace(collisionBin, BitConverter.GetBytes(TmcData.Collisions.Count), 0x14);
        ByteListUtils.Replace(collisionBin, BitConverter.GetBytes(TmcData.Collisions.Count), 0x18);

        List<byte> headerOptBin = TmcUtils.BuildHeaderBaseBin("");
        headerOptBin[0x20] = 0x30;
        ByteListUtils.Replace(headerOptBin, BitConverter.GetBytes(TmcData.Collisions.Count), 0x14);
        ByteListUtils.Replace(headerOptBin, BitConverter.GetBytes(TmcData.Collisions.Count), 0x18);

        List<List<byte>> dataBins = new List<List<byte>>();

        foreach (var collision in TmcData.Collisions)
        {
          string nodeName = TmcData.Node[collision.Node].Name;
          int newNodeIndex = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == nodeName);

          headerOptBin.AddRange(BitConverter.GetBytes(collision.Type));
          headerOptBin.AddRange(BitConverter.GetBytes(newNodeIndex));
          headerOptBin.AddRange(BitConverter.GetBytes(collision.Code));

          List<byte> dataBin = new List<byte>();
          foreach (var f in collision.Rotation)
          {
            dataBin.AddRange(BitConverter.GetBytes(f));
          }
          foreach (var f in collision.Size)
          {
            dataBin.AddRange(BitConverter.GetBytes(f));
          }
          foreach (var f in collision.Position)
          {
            dataBin.AddRange(BitConverter.GetBytes(f));
          }
          dataBin.AddRange(BitConverter.GetBytes(newNodeIndex));
          dataBin.AddRange(BitConverter.GetBytes(collision.Code2));
          if (dataBin.Count % 16 != 0) dataBin.AddRange(new byte[16 - dataBin.Count % 16]);

          dataBins.Add(dataBin);
        }
        if (headerOptBin.Count % 16 != 0) headerOptBin.AddRange(new byte[16 - headerOptBin.Count % 16]);
        ByteListUtils.Replace(headerOptBin, BitConverter.GetBytes(headerOptBin.Count), 0x10);
        collisionBin.AddRange(headerOptBin);

        TmcUtils.BuildBin(collisionBin, dataBins, null, false, false);
      }


      return collisionBin;
    }



    #region プロパティ

    /// <summary>
    /// メインウィンドウオブジェクト
    /// </summary>
    public MainWindow Window { get; set; }

    /// <summary>
    /// 言語テキストデータ
    /// </summary>
    private Lang.Text Txt;

    /// <summary>
    /// TMCLのヘッダ部分のバイナリ
    /// </summary>
    public byte[] BinLHeader { get; set; }

    /// <summary>
    /// TMCの出力バイナリ
    /// </summary>
    public List<byte> ExBin { get; set; } = new List<byte>();

    /// <summary>
    /// TMCLの出力バイナリ
    /// </summary>
    public List<byte> ExBinL { get; set; } = new List<byte>();


    /// <summary>
    /// TMCデータ
    /// </summary>
    public TmcData TmcData { get; set; }

    /// <summary>
    /// インポートしたTMCデータのリスト
    /// </summary>
    public List<TmcData> OtherTmcDataList;

    /// <summary>
    /// 表のデータ
    /// </summary>
    public DataTables Tables { get; set; }


    /// <summary>
    /// 各パートのバイナリリスト
    /// </summary>
    public List<List<byte>> PartBins { get; set; } = new List<List<byte>>();

    /// <summary>
    /// インポートしたTMCファイルバイナリのリスト
    /// </summary>
    public List<byte[]> OtherBinList { get; set; } = new List<byte[]>();

    /// <summary>
    /// オブジェクトグループを再構築するかどうか
    /// </summary>
    private bool ObjGrpRebuild { get; set; }

    /// <summary>
    /// テクスチャを再構築するかどうか
    /// </summary>
    private bool TextureRebuild { get; set; }

    /// <summary>
    /// Blendがクリアされているかどうか
    /// </summary>
    private bool BlendCleared { get; set; }

    #endregion
  }
}
