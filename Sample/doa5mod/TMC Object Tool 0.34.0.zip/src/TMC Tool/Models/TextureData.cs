﻿using System.Windows.Media.Imaging;

namespace TMC_Tool.Models
{
  public class TextureData
  {
    public TextureData()
    {
    }

    public BitmapImage Source { get; set; }
    public int Index { get; set; }
    public int Width { get; set; }
    public int Height { get; set; }
  }
}
