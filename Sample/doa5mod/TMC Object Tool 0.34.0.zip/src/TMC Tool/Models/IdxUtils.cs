﻿using System;
using System.Collections.Generic;
using System.Linq;
using Tmc;

namespace TMC_Tool.Models
{
  public class IdxUtils
  {
    /// <summary>
    /// ポリゴンパーツを取得します（TriangleStrip）
    /// </summary>
    /// <param name="tmcData">TMCデータ</param>
    /// <param name="obj">オブジェクトデータ</param>
    /// <param name="idxGrpIndex">Idxグループインデックス</param>
    /// <returns>ポリゴンパーツのリスト</returns>
    public static List<PolygonPart> GetPolygonPartsTriangleStrip(TmcData tmcData, ObjectPart obj, int idxGrpIndex)
    {
      var indices = tmcData.IdxGrp[idxGrpIndex].Idx;


      // ポリゴンパーツへ分解

      var polygonParts = new List<PolygonPart>();

      PolygonPart polygonPart = new PolygonPart();
      polygonPart.ObjectIndex = obj.ID;
      polygonPart.StartIndex = obj.IdxStartIndex;
      polygonPart.Indices.Add(indices[obj.IdxStartIndex]);

      bool partEndFlag = false;

      for (int i = obj.IdxStartIndex + 1; i < obj.IdxStartIndex + obj.IdxCount; i++)
      {
        int index = polygonPart.Indices.Count - 1;

        if (partEndFlag)
        {
          polygonParts.Add(polygonPart);

          partEndFlag = false;
          polygonPart = new PolygonPart();
          polygonPart.ObjectIndex = obj.ID;
          polygonPart.StartIndex = i;

          polygonPart.Indices.Add(indices[i]);

          if (i < indices.Length - 1)
          {
            polygonPart.Indices.Add(indices[i + 1]);
            i++;
          }

          continue;
        }
        else if (indices[i] == polygonPart.Indices[index])
        {
          // 余分なデータを除去
          if (index > 2 && indices[i] == polygonPart.Indices[index - 1] && indices[i] == polygonPart.Indices[index - 2])
          {
            polygonPart.Indices.RemoveAt(index);
            polygonPart.Indices.RemoveAt(index - 1);
          }

          // パートの終了判定
          if (i < obj.IdxStartIndex + obj.IdxCount - 2 && indices[i] != indices[i + 1] && indices[i + 1] == indices[i + 2])
          {
            partEndFlag = true;
          }
        }

        polygonPart.Indices.Add(indices[i]);
      }

      // 最後を追加
      polygonParts.Add(polygonPart);


      return polygonParts;
    }

    /// <summary>
    /// 出力する接続面のIdxのリストを取得します
    /// </summary>
    /// <param name="obj">オブジェクトデータ</param>
    /// <param name="polygonParts">ポリゴンパーツ</param>
    /// <param name="extract">抽出かどうか</param>
    /// <returns>出力する接続面のIdxのリスト</returns>
    public static List<ushort> GetIndicesConnected(ObjectPart obj, List<PolygonPart> polygonParts, bool extract)
    {
      List<ushort> indices = new List<ushort>();

      foreach (var part in polygonParts.Where(e => e.ObjectIndex == obj.ID && e.Selected == extract))
      {
        if (part.StartIndex == obj.IdxStartIndex)
        {
          indices.AddRange(part.Indices);
        }
        else if ((part.StartIndex - obj.IdxStartIndex) % 2 == indices.Count % 2)
        {
          if (
            indices.Count == 0 && part.Indices.Count > 3 &&
            part.Indices[0] == part.Indices[1] && part.Indices[0] == part.Indices[2]
          )
          {
            indices.AddRange(part.Indices.GetRange(2, part.Indices.Count - 2));
          }
          else if (
            indices.Count > 3 && part.Indices.Count > 3 &&
            indices.Last() == indices[indices.Count - 2] && indices.Last() == indices[indices.Count - 3] &&
            part.Indices[0] == part.Indices[1] && part.Indices[0] == part.Indices[2]
          )
          {
            indices.RemoveAt(indices.Count - 1);
            indices.AddRange(part.Indices.GetRange(1, part.Indices.Count - 1));
          }
          else
          {
            indices.AddRange(part.Indices);
          }
        }
        else
        {
          if (indices.Count == 0 && part.Indices.Count > 2 && part.Indices[0] == part.Indices[1])
          {
            indices.AddRange(part.Indices.GetRange(1, part.Indices.Count - 1));
          }
          else if (
            indices.Count > 3 &&
            indices.Last() == indices[indices.Count - 2] && indices.Last() == indices[indices.Count - 3]
          )
          {
            indices.RemoveAt(indices.Count - 1);
            indices.AddRange(part.Indices);
          }
          else if (
            part.Indices.Count > 3 &&
            part.Indices[0] == part.Indices[1] && part.Indices[0] == part.Indices[2]
          )
          {
            indices.AddRange(part.Indices.GetRange(1, part.Indices.Count - 1));
          }
          else
          {
            indices.Add(part.Indices[0]);
            indices.AddRange(part.Indices);
          }
        }
      }


      if (indices.Count > 3 && indices[0] == indices[1] && indices[0] == indices[2])
      {
        indices.RemoveAt(1);
        indices.RemoveAt(0);
      }

      while (indices.Count > 2 && indices.Last() == indices[indices.Count - 2])
      {
        indices.RemoveAt(indices.Count - 1);
      }


      return indices;
    }

    /// <summary>
    /// 出力する選択面のIdxのリストを取得します
    /// </summary>
    /// <param name="obj">オブジェクトデータ</param>
    /// <param name="indices">DeclのIdxデータ</param>
    /// <param name="convertVtxIndex">頂点インデックス置換辞書</param>
    /// <returns>出力する選択面のIdxのリスト</returns>
    public static List<ushort> GetIndicesSelected(ObjectPart obj, ushort[] indices, Dictionary<int, ushort> convertVtxIndex)
    {
      List<ushort> addIndices = new List<ushort>();
      bool deletedFlag = false;

      for (int i = obj.IdxStartIndex; i < obj.IdxStartIndex + obj.IdxCount; i++)
      {
        if (convertVtxIndex.ContainsKey(indices[i])) // 置換辞書オブジェクトに含まれているなら
        {
          if (deletedFlag) // デリートフラグが真なら
          {
            addIndices.Add(indices[i]);

            // 今のインデックスと元のインデックスの偶数奇数が異なるなら
            if (addIndices.Count % 2 != (i - obj.IdxStartIndex) % 2)
            {
              addIndices.Add(indices[i]);
            }

            deletedFlag = false;
          }

          addIndices.Add(indices[i]);
        }
        else if (!deletedFlag) // デリートフラグが真なら
        {
          // 先頭でないなら一つ前のIdxを追加
          if (addIndices.Count > 0)
          {
            addIndices.Add(indices[i - 1]);
          }

          // デリートフラグを真に
          deletedFlag = true;
        }
      }


      return addIndices;
    }
  }
}
