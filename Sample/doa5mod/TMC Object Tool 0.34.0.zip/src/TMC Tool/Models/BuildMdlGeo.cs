﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TMC_Tool.ViewModels;
using Common;
using Language;
using Tmc;

namespace TMC_Tool.Models
{
  public class BuildMdlGeo
  {
    /// <summary>
    /// ObjGeoを構築
    /// </summary>
    /// <param name="partIndex">パートインデックス</param>
    /// <returns>MdlGeoのバイナリデータ</returns>
    public static List<byte> Do(Save save, int partIndex)
    {
      Init(save, partIndex);

      List<List<byte>> objGeoBins = new List<List<byte>>();


      List<byte> mdlGeoBin = TmcUtils.BuildHeaderBaseBin("MdlGeo");
      mdlGeoBin[0x20] = 0x30;


      for (int i = 0; i < ObjectGroups.Count; i++)
      {
        ObjectData grp = ObjectGroups[i];

        TmcData tmcData;
        if (grp.DataIndex == -1)
          tmcData = TmcData;
        else
          tmcData = OtherTmcDataList[grp.DataIndex];

        ObjectGroup originGrp = tmcData.ObjGrp[grp.OriginalGrpIndex];


        // ObjGeoのバイナリ構築を開始
        List<byte> objGeoBin = TmcUtils.BuildHeaderBaseBin("ObjGeo");

        if (grp.DataIndex == -1)
          objGeoBin.AddRange(PartBin.Skip(originGrp.Offset + 0x30).Take(0x20).ToArray());
        else
          objGeoBin.AddRange(tmcData.Bin.Skip(originGrp.Start + 0x30).Take(0x20).ToArray());

        objGeoBin[0x20] = 0x60;
        ByteListUtils.Replace(objGeoBin, BitConverter.GetBytes(grp.ID), 0x34);

        // 名前部分追加
        // 15文字より大きい場合は*と後ろから14文字に
        // 0埋め
        string name = "";
        if (grp.Name.Length > 15)
          name = "*" + grp.Name.Substring(grp.Name.Length - 14);
        else
          name = grp.Name;

        objGeoBin.AddRange(Encoding.ASCII.GetBytes(name));
        objGeoBin.AddRange(new byte[(16 - (objGeoBin.Count % 16)) % 16]);


        // Declのバイナリを構築
        List<byte> declBin = BuildDeclBin(tmcData, originGrp, ObjectGroups[i]);


        // オブジェクトのバイナリ群を構築
        List<List<byte>> objBins = new List<List<byte>>();
        foreach (var objData in Objects[i])
        {
          objBins.Add(BuildObjBin(originGrp, objData));
        }

        // objGeoのバイナリを構築
        TmcUtils.BuildBin(objGeoBin, objBins, declBin, false, false);
        objGeoBins.Add(objGeoBin);

      }


      // MdlGeoのバイナリを構築
      TmcUtils.BuildBin(mdlGeoBin, objGeoBins, null, false, false);


      return mdlGeoBin;
    }

    /// <summary>
    /// プロパティ初期化
    /// </summary>
    /// <param name="save">Saveデータ</param>
    private static void Init(Save save, int partIndex)
    {
      Txt = MainWindow.Txt;
      Window = save.Window;
      PartBin = save.PartBins[partIndex].ToArray();
      TmcData = save.TmcData;
      OtherTmcDataList = save.OtherTmcDataList;
      Tables = save.Tables;

      VtxStartIndices = new Dictionary<int, int>();
      IdxStartIndices = new Dictionary<int, int>();
      DeclIndices = new Dictionary<int, byte>();

      IdxGrpCount = 0;


      ObjectGroups = new List<ObjectData>();
      Objects = new List<List<ObjectData>>();

      foreach (var obj in Tables.ObjData)
      {
        if (obj.Grp == -1)
        {
          ObjectGroups.Add(obj);
          Objects.Add(new List<ObjectData>());
        }
        else
        {
          Objects.Last().Add(obj);
        }
      }
    }



    /// <summary>
    /// Declを構築
    /// </summary>
    /// <param name="tmcData">TMCデータ</param>
    /// <param name="originGrp">元のオブジェクトグループデータ</param>
    /// <param name="grp">オブジェクトグループデータ</param>
    /// <returns>Declのバイナリデータ</returns>
    private static List<byte> BuildDeclBin(TmcData tmcData, ObjectGroup originGrp, ObjectData grp)
    {
      List<byte> declBin = TmcUtils.BuildHeaderBaseBin("GeoDecl");
      declBin[0x20] = 0x30;

      byte declCount = 0;

      List<List<byte>> newBins = new List<List<byte>>();
      foreach (var viData in Tables.VIData)
      {
        if (viData.Use == 0) continue;

        if (viData.ObjID == grp.ID)
        {
          List<byte> newBin;
          if (grp.DataIndex == -1)
            newBin = PartBin.Skip(originGrp.Offset + originGrp.DeclOffset + originGrp.Decl[(int)viData.OriginalDecl].Offset).Take(0x40).ToList();
          else
            newBin = tmcData.Bin.Skip(originGrp.Start + originGrp.DeclOffset + originGrp.Decl[(int)viData.OriginalDecl].Offset).Take(0x40).ToList();

          DeclIndices[viData.Index] = declCount;
          declCount++;

          ByteListUtils.Replace(newBin, BitConverter.GetBytes(IdxGrpCount), 0x0C);
          IdxGrpCount++;

          ByteListUtils.Replace(newBin, BitConverter.GetBytes(viData.Index), 0x30);

          if (viData.IsAdded)
          {
            ByteListUtils.Replace(newBin, BitConverter.GetBytes(1), 0x10);
            ByteListUtils.Replace(newBin, BitConverter.GetBytes(1), 0x14);
          }
          else
          {
            ByteListUtils.Replace(newBin, BitConverter.GetBytes(originGrp.Decl[(int)viData.OriginalDecl].IdxCount), 0x10);
            ByteListUtils.Replace(newBin, BitConverter.GetBytes(originGrp.Decl[(int)viData.OriginalDecl].VtxCount), 0x14);
          }


          int texCount = 0;
          bool texCountChange = false;
          foreach (var objData in Tables.ObjData)
          {
            if (objData.VtxGrp != viData.Index) continue;

            if (objData.TexCount != null && texCount < objData.TexCount)
            {
              texCount = (int)objData.TexCount;
            }

            if (objData.TexCount != objData.OriginalTexCount)
            {
              texCountChange = true;
            }
          }

          if (texCountChange) ByteListUtils.Replace(newBin, BitConverter.GetBytes(texCount), 0x18);


          ByteListUtils.Replace(newBin, BitConverter.GetBytes(Convert.ToInt32(viData.Datasize, 16)), 0x34);


          // FVFDataを追加
          newBin.AddRange(BuildFvfDataBin(tmcData, originGrp, viData));

          ByteListUtils.Replace(newBin, BitConverter.GetBytes(VdataLayersCount), 0x38);


          newBins.Add(newBin);
        }
      }


      // declBin構築
      TmcUtils.BuildBin(declBin, newBins, null, false, false);


      return declBin;
    }

    /// <summary>
    /// FVFDataを構築
    /// </summary>
    /// <param name="tmcData">TMCデータ</param>
    /// <param name="originGrp">元のオブジェクトグループデータ</param>
    /// <param name="obj">オブジェクトデータ</param>
    /// <returns>FVFDataのバイナリデータ</returns>
    private static List<byte> BuildFvfDataBin(TmcData tmcData, ObjectGroup originGrp, VtxIdxGrpData viData)
    {
      List<byte> bin = new List<byte>();


      VdataLayersCount = 0;
      byte offset = 0;

      // Position
      if (viData.Position)
      {
        if (viData.PositionType == "Float3")
        {
          AddDataBin(bin, offset, 2, 0, 0);
          offset += 0x0C;
        }
        else
        {
          AddDataBin(bin, offset, 3, 0, 0);
          offset += 0x10;
        }
      }

      // Normal
      if (viData.Normal)
      {
        if (viData.PositionType == "Float3")
        {
          AddDataBin(bin, offset, 2, 3, 0);
          offset += 0x0C;
        }
        else
        {
          AddDataBin(bin, offset, 3, 3, 0);
          offset += 0x10;
        }
      }

      // BLENDWEIGHTとBLENDINDICES
      var vtxGrp = tmcData.VtxGrp[originGrp.Decl[(int)viData.OriginalDecl].VtxGrpIndex];

      byte[] usages;
      if (vtxGrp.BlendIndicesOffsets.Count > 0 && vtxGrp.BlendWeightOffsets.Count >0 && vtxGrp.BlendIndicesOffsets[0] < vtxGrp.BlendWeightOffsets[0])
        usages = new byte[] { 2, 1 };
      else
        usages = new byte[] { 1, 2 };

      foreach (byte usage in usages)
      {
        if (viData.BWeights && usage == 1)
        {
          if (viData.BWeightsType == "Float4")
          {
            AddDataBin(bin, offset, 3, usage, 0);
            offset += 0x10;
          }
          else
          {
            AddDataBin(bin, offset, 13, usage, 0);
            offset += 4;
          }
        }
        if (viData.BIndices && usage == 2)
        {
          AddDataBin(bin, offset, 5, usage, 0);
          offset += 4;
        }
      }

      // 頂点カラー
      if (viData.Color)
      {
        AddDataBin(bin, offset, 0x0D, 0x0A, 0);
        offset += 4;
      }

      // Tangent
      if (viData.Tangent)
      {
        if (viData.BWeightsType == "Float4")
          offset += 0x0C;

        AddDataBin(bin, offset, 3, 6, 0);
        offset += 0x10;
      }

      // UV
      if (viData.UVCount > 1)
      {
        AddDataBin(bin, offset, 0x0B, 5, 0);
        offset += 8;
      }

      if (viData.UVCount == 1)
      {
        AddDataBin(bin, offset, 0x0A, 5, 0);
      }
      else if (viData.UVCount == 3)
      {
        AddDataBin(bin, offset, 0x0A, 5, 1);
      }
      else if (viData.UVCount > 3)
      {
        AddDataBin(bin, offset, 0x0B, 5, 1);
        offset += 8;
      }

      if (viData.UVCount == 5)
      {
        AddDataBin(bin, offset, 0x0A, 5, 2);
      }


      if (VdataLayersCount % 2 == 1) bin.AddRange(new byte[8]);


      return bin;
    }

    /// <summary>
    /// FVFDataの個別データを構築
    /// </summary>
    /// <param name="bin">FVFDataのバイナリデータ</param>
    /// <param name="offset">オフセット</param>
    /// <param name="type">D3DDECLTYPE</param>
    /// <param name="usage">D3DDECLUSAGE</param>
    /// <param name="layer">レイヤー</param>
    private static void AddDataBin(List<byte> bin, byte offset, byte type, byte usage, byte layer)
    {
      byte[] dataBin = new byte[8];
      dataBin[2] = offset;
      dataBin[4] = type;
      dataBin[6] = usage;
      dataBin[7] = layer;

      bin.AddRange(dataBin);
      VdataLayersCount++;
    }

    /// <summary>
    /// ObjGeoを構築
    /// </summary>
    /// <param name="originGrp">元のオブジェクトグループデータ</param>
    /// <param name="obj">オブジェクトデータ</param>
    /// <returns>オブジェクトのバイナリデータ</returns>
    private static List<byte> BuildObjBin(ObjectGroup originGrp, ObjectData obj)
    {
      ObjectPart originObj = originGrp.Obj[obj.OriginalObjIndex];
      List<byte> objBin = new List<byte>();

      if (obj.DataIndex == -1)
        objBin.AddRange(PartBin.Skip(originGrp.Offset + originObj.Offset).Take(0xD0));
      else
        objBin.AddRange(OtherTmcDataList[obj.DataIndex].Bin.Skip(originGrp.Start + originObj.Offset).Take(0xD0));


      // オブジェクトの基本データをセット
      SetObjBaseData(objBin, originObj, obj);


      // オブジェクトのテクスチャデータをセット
      if (obj.TexCount > 0)
      {
        SetObjTextureData(objBin, originObj, obj);
      }
      else
      {
        SetObjTextureData(objBin);
      }


      return objBin;
    }

    /// <summary>
    /// オブジェクトの基本情報をセット
    /// </summary>
    /// <param name="objBin">オブジェクトのバイナリデータ</param>
    /// <param name="originObj">元のオブジェクトデータ</param>
    /// <param name="obj">オブジェクトデータ</param>
    private static void SetObjBaseData(List<byte> objBin, ObjectPart originObj, ObjectData obj)
    {
      // ID
      objBin[0] = (byte)obj.ID;

      // MtrCol
      objBin[4] = (byte)obj.MtrCol;

      // TexCount
      objBin[0xC] = (byte)obj.TexCount;

      // Tex Offset 初期化
      for (int i = 0; i < 5; i++)
      {
        ByteListUtils.Replace(objBin, BitConverter.GetBytes(0), 0x10 + (4 * i));
      }

      // Decl
      objBin[0x38] = DeclIndices[(int)obj.VtxGrp];

      // Transparent
      switch (obj.Transparent)
      {
        case 1:
          objBin[0x40] = 1;
          objBin[0x48] = 0;
          break;
        case 2:
          objBin[0x40] = 0;
          objBin[0x48] = 0xC0;
          break;
        default:
          objBin[0x40] = 0;
          objBin[0x48] = 0;
          break;
      }

      // DoubleSided
      objBin[0x6C] = ((bool)obj.DoubleSided) ? (byte)1 : (byte)0;

      // Idx Start Index
      int idxGrp = Tables.VIData[(int)obj.VtxGrp].IdxGrp;
      if (obj.IsVgrpChanged)
      {
        if (IdxStartIndices.ContainsKey(idxGrp))
          ByteListUtils.Replace(objBin, BitConverter.GetBytes(IdxStartIndices[idxGrp]), 0x70);
        else
          ByteListUtils.Replace(objBin, BitConverter.GetBytes(0), 0x70);
        ByteListUtils.Replace(objBin, BitConverter.GetBytes(0), 0x74);
      }
      else if (obj.IsDeleted)
      {
        ByteListUtils.Replace(objBin, BitConverter.GetBytes(0), 0x74);
      }
      else
      {
        IdxStartIndices[idxGrp] = (int)(originObj.IdxStartIndex + obj.IdxCount);
      }

      // Vtx Start Index
      if (obj.IsVgrpChanged)
      {
        if (VtxStartIndices.ContainsKey((int)obj.VtxGrp))
          ByteListUtils.Replace(objBin, BitConverter.GetBytes(VtxStartIndices[(int)obj.VtxGrp]), 0x78);
        else
          ByteListUtils.Replace(objBin, BitConverter.GetBytes(0), 0x78);
        ByteListUtils.Replace(objBin, BitConverter.GetBytes(0), 0x7C);
      }
      else if (obj.IsDeleted)
      {
        ByteListUtils.Replace(objBin, BitConverter.GetBytes(0), 0x7C);
      }
      else
      {
        VtxStartIndices[(int)obj.VtxGrp] = (int)(originObj.VtxStartIndex + obj.VtxCount);
      }
    }

    /// <summary>
    /// オブジェクトのテクスチャデータをセット
    /// </summary>
    /// <param name="objBin">オブジェクトのバイナリデータ</param>
    /// <param name="originObj">元のオブジェクトデータ</param>
    /// <param name="obj">オブジェクトデータ</param>
    private static void SetObjTextureData(List<byte> objBin, ObjectPart originObj, ObjectData obj)
    {
      if (obj.TexType != -1 && obj.TexTypes[obj.TexType] != "Error")
      {
        // TexParam
        string texTypes = "0";
        if (obj.TexCount > 1)
          texTypes = obj.TexTypes[obj.TexType];

        objBin[0xCC] = (byte)HexTextUtils.ToUInt(obj.TexParam.BaseParams[0]);

        obj.TexParam.BaseParams[1] = (HexTextUtils.ToUInt(obj.TexParam.BaseParams[1]) / 0x10 * 0x10).ToString("X2");
        if (texTypes.IndexOf("2") != -1)
          objBin[0xCD] = (byte)(HexTextUtils.ToUInt(obj.TexParam.BaseParams[1]) + 8);
        else
          objBin[0xCD] = (byte)HexTextUtils.ToUInt(obj.TexParam.BaseParams[1]);

        obj.TexParam.BaseParams[2] = (HexTextUtils.ToUInt(obj.TexParam.BaseParams[2]) / 8 * 8).ToString("X2");
        objBin[0xCE] = (byte)(HexTextUtils.ToUInt(obj.TexParam.BaseParams[2]));
        if (obj.ChangeableEnvMap)
          objBin[0xCE] += (byte)obj.EnvironmentMap;

        objBin[0xCF] = (byte)((0x10 * texTypes.Count(c => c == '0')) + (4 * texTypes.Count(c => c == '1')));
      }

      // TexTypeから各テクスチャのTypeを設定
      int[] texType = new int[(int)obj.TexCount];
      if (obj.TexTypes[obj.TexType] == "Error")
      {
        for (int i = 0; i < (int)obj.TexCount; i++)
        {
          if (i < originObj.TexCount)
          {
            texType[i] = originObj.Tex[i].Type;
          }
          else
          {
            texType[i] = 0;
          }
        }
      }
      else
      {
        for (int i = 0; i < (int)obj.TexCount; i++)
        {
          texType[i] = Int32.Parse(obj.TexTypes[obj.TexType].Replace(" ", "")[i].ToString());
        }
      }

      int?[] texs = new int?[] { obj.Tex1, obj.Tex2, obj.Tex3, obj.Tex4, obj.Tex5 };

      // テクスチャデータ追加
      for (int i = 0; i < obj.TexCount; i++)
      {
        List<byte> objTexBin = new List<byte>();

        objTexBin.AddRange(BitConverter.GetBytes(i));
        objTexBin.AddRange(BitConverter.GetBytes(texType[i]));
        objTexBin.AddRange(BitConverter.GetBytes((int)texs[i]));
        if (i >= obj.TexDataList.Count)
        {
          List<byte> newDataBin = new List<byte>();
          newDataBin.AddRange(new byte[28 * 4]);
          newDataBin[0x10] = 5;
          newDataBin[0x14] = 1;
          newDataBin[0x40] = 1;
          newDataBin[0x44] = 1;
          newDataBin[0x48] = 1;
          ByteListUtils.Replace(newDataBin, BitConverter.GetBytes((float)12.0), 0x54);
          ByteListUtils.Replace(newDataBin, BitConverter.GetBytes((float)-1.0), 0x58);
          newDataBin[0x6C] = 2;

          SetTexParams(newDataBin, obj.TexParam.ParamSets[i]);

          objTexBin.AddRange(newDataBin.Skip(12));
        }
        else
        {
          List<byte> newDataBin = new List<byte>(new byte[4 * 3]);

          for (int j = 0; j < 27; j++) newDataBin.AddRange(BitConverter.GetBytes(obj.TexDataList[i][j]));

          SetTexParams(newDataBin, obj.TexParam.ParamSets[i]);

          objTexBin.AddRange(newDataBin.Skip(12));
        }


        // オフセット変更
        ByteListUtils.Replace(objBin, BitConverter.GetBytes(0xD0 + (0x70 * i)), 0x10 + (4 * i));

        objBin.AddRange(objTexBin);
      }
    }

    /// <summary>
    /// オブジェクトのテクスチャデータをセット（ダミー）
    /// </summary>
    /// <param name="objBin">オブジェクトのバイナリデータ</param>
    private static void SetObjTextureData(List<byte> objBin)
    {
      objBin[0xCC] = 0;
      objBin[0xCD] = 0;
      objBin[0xCE] = 0x80;
      objBin[0xCF] = 0;

      List<byte> objTexBin = new List<byte>();
      objTexBin.AddRange(new byte[0x70]);
      objTexBin[0x04] = 2;
      ByteListUtils.Replace(objTexBin, BitConverter.GetBytes(-1), 0x08);
      objTexBin[0x10] = 5;
      objTexBin[0x14] = 1;
      objTexBin[0x40] = 1;
      objTexBin[0x44] = 1;
      objTexBin[0x48] = 1;
      ByteListUtils.Replace(objTexBin, BitConverter.GetBytes((float)12.0), 0x54);
      ByteListUtils.Replace(objTexBin, BitConverter.GetBytes((float)-1.0), 0x58);
      objTexBin[0x6C] = 2;

      objBin.AddRange(objTexBin);
    }

    /// <summary>
    /// テクスチャパラメータをセット
    /// </summary>
    /// <param name="bin">テクスチャパラメータバイナリ</param>
    /// <param name="texParams">テクスチャパラメータデータ</param>
    private static void SetTexParams(List<byte> bin, TexParameters texParams)
    {
      ByteListUtils.Replace(bin, BitConverter.GetBytes(texParams.USpeed), 0x20);
      ByteListUtils.Replace(bin, BitConverter.GetBytes(texParams.VSpeed), 0x24);

      if (texParams.USpeed != 0 || texParams.VSpeed != 0)
        ByteListUtils.Replace(bin, BitConverter.GetBytes(-1), 0x28);
      else
        ByteListUtils.Replace(bin, BitConverter.GetBytes(0), 0x28);

      ByteListUtils.Replace(bin, BitConverter.GetBytes(texParams.Count), 0x30);
      ByteListUtils.Replace(bin, BitConverter.GetBytes(texParams.Skip), 0x34);

      if (texParams.Repeat)
        ByteListUtils.Replace(bin, BitConverter.GetBytes((short)1), 0x36);
      else
        ByteListUtils.Replace(bin, BitConverter.GetBytes((short)0), 0x36);

      if (texParams.Count > 0 && texParams.FramesPerTex == 0)
      {
        ByteListUtils.Replace(bin, BitConverter.GetBytes((short)1), 0x38);
        texParams.FramesPerTex = 1;
      }
      else
        ByteListUtils.Replace(bin, BitConverter.GetBytes(texParams.FramesPerTex), 0x38);
    }



    /// <summary>
    /// メインウィンドウオブジェクト
    /// </summary>
    private static MainWindow Window { get; set; }

    /// <summary>
    /// 言語テキストデータ
    /// </summary>
    private static Lang.Text Txt;

    /// <summary>
    /// TMCのバイナリ
    /// </summary>
    private static byte[] PartBin { get; set; }


    /// <summary>
    /// TMCデータ
    /// </summary>
    private static TmcData TmcData { get; set; }

    /// <summary>
    /// インポートしたTMCデータのリスト
    /// </summary>
    private static List<TmcData> OtherTmcDataList;

    /// <summary>
    /// 表のデータ
    /// </summary>
    private static DataTables Tables { get; set; }


    /// <summary>
    /// 
    /// </summary>
    private static Dictionary<int, int> VtxStartIndices { get; set; }

    /// <summary>
    /// 
    /// </summary>
    private static Dictionary<int, int> IdxStartIndices { get; set; }

    /// <summary>
    /// 
    /// </summary>
    private static Dictionary<int, byte> DeclIndices { get; set; }

    /// <summary>
    /// 
    /// </summary>
    private static int IdxGrpCount { get; set; }

    /// <summary>
    /// 
    /// </summary>
    private static int VdataLayersCount { get; set; }


    /// <summary>
    /// 
    /// </summary>
    private static List<ObjectData> ObjectGroups { get; set; }

    /// <summary>
    /// 
    /// </summary>
    private static List<List<ObjectData>> Objects { get; set; }

  }
}
