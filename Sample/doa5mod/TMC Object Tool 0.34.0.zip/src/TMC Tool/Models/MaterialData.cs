﻿using System;
using System.Collections.Generic;
using Tmc;

namespace TMC_Tool.Models
{
  public class MaterialData
  {
    public MaterialData()
    {
      ColTarget = -1;
      MatTarget = -1;
    }

    public void SetColData(int start, int offset, byte[] bin, int target)
    {
      Col = new MtrColorGroup(bin, start, offset);

      if (target == -1)
        ColAdd = true;
      else
        ColTarget = target;
    }

    public void SetMateCpData(int start, int offset, byte[] bin, int target)
    {
      MateCp = new Customp(bin, start, offset);

      if (target == -1)
        MateCpAdd = true;
      else
        MateCpTarget = target;
    }

    public void SetMatData(int start, int offset, byte[] bin, int target)
    {
      Mat = new Material(bin, start, offset);

      if (target == -1)
        MatAdd = true;
      else
        MatTarget = target;
    }

    public void SetObjTexData(ObjectPart obj, byte[] bin)
    {
      TexParams = new byte[4];
      for (byte i = 0; i < 4; i++)
      {
        TexParams[i] = obj.TexParams[i];
      }

      Tex = new List<ObjectTextureData>();
      for (byte i = 0; i < obj.TexCount; i++)
      {
        var newTex = new ObjectTextureData();
        newTex.Offset = BitConverter.ToInt32(bin, obj.Start + 0x10 + (i * 4));
        newTex.ID = BitConverter.ToInt32(bin, obj.Start + newTex.Offset);
        newTex.Type = BitConverter.ToInt32(bin, obj.Start + newTex.Offset + 4);
        newTex.Num = BitConverter.ToInt32(bin, obj.Start + newTex.Offset + 8);

        int count = 0;
        for (int j = 0; j < 27; j++)
        {
          if (j == 3 || j == 5 || j == 6 || j == 20 || j == 21)
          {
            newTex.Data[j] = BitConverter.ToSingle(bin, obj.Start + newTex.Offset + 0x0C + count);
            count += 4;
          }
          else if (j == 7)
          {
            newTex.Data[j] = BitConverter.ToInt32(bin, obj.Start + newTex.Offset + 0x0C + count);
            count += 4;
          }
          else if (j >= 10 && j <= 13)
          {
            newTex.Data[j] = BitConverter.ToUInt16(bin, obj.Start + newTex.Offset + 0x0C + count);
            count += 2;
          }
          else
          {
            newTex.Data[j] = BitConverter.ToUInt32(bin, obj.Start + newTex.Offset + 0x0C + count);
            count += 4;
          }
        }

        Tex.Add(newTex);
      }
    }


    public bool ColAdd { get; set; }
    public bool MateCpAdd { get; set; }
    public bool MatAdd { get; set; }
    public int ColTarget { get; set; }
    public int MateCpTarget { get; set; }
    public int MatTarget { get; set; }
    public byte[] TexParams { get; set; }

    public MtrColorGroup Col { get; private set; }
    public Customp MateCp { get; private set; }
    public Material Mat { get; private set; }
    public List<ObjectTextureData> Tex { get; private set; }
  }
}
