﻿using System;

namespace TMC_Tool.Models
{
  public class PhysicsIndex
  {
    public PhysicsIndex()
    {
    }

    public int Index { get; set; }
    public string Name { get; set; }
    public int DataIndex { get; set; }
  }
}
