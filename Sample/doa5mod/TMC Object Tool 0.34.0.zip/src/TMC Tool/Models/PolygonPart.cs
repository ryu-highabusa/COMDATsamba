﻿using System.Collections.Generic;

namespace TMC_Tool.Models
{
  public class PolygonPart
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    public PolygonPart()
    {
      Indices = new List<ushort>();
      ObjectIndex = -1;
      StartIndex = -1;
    }

    /// <summary>
    /// 面インデックスリスト
    /// </summary>
    public List<ushort> Indices { get; set; }

    /// <summary>
    /// 選択されているか
    /// </summary>
    public bool Selected { get; set; }

    /// <summary>
    /// オブジェクトインデックス
    /// </summary>
    public int ObjectIndex { get; set; }

    /// <summary>
    /// 開始インデックス
    /// </summary>
    public int StartIndex { get; set; }
  }
}
