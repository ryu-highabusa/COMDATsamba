﻿using System;
using System.Collections.Generic;
using Tmc;
using TMC_Tool.ViewModels;
using Language;
using Message;

namespace TMC_Tool.Models
{
  public class GetMaterials
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    /// <param name="data">MainWindowViewModel</param>
    public GetMaterials(MainWindowViewModel data)
    {
      Txt = MainWindow.Txt;
      Data = data;
      Window = data.Window;
      TmcData = data.TmcData;
      Tables = data.Tables;
    }

    /// <summary>
    /// インポート時用のコンストラクタ
    /// </summary>
    /// <param name="import">Importデータ</param>
    public GetMaterials(Import import)
    {
      Txt = MainWindow.Txt;
      Data = import.Data;
      Window = import.Window;
      TmcData = import.Data.TmcData;
      Tables = import.Data.Tables;
      Material = new MaterialData();
    }


    #region メソッド

    /// <summary>
    /// 取得
    /// </summary>
    public void Get()
    {
      GetData(-1);

      if (Material == null) return;

      if (Material.Col != null) GetCol();

      if (Material.MateCp != null) GetMateCp();

      if (Material.Mat != null) GetMat();

      if (Material.TexParams != null) GetTexParams();
    }

    /// <summary>
    /// 取得ウィンドウを表示してマテリアルデータを取得
    /// </summary>
    public void GetData(int index)
    {
      Material = Data.GetMatWindow.Show(Window, TmcData, Tables, GetSelectedObjects(), index);
    }

    /// <summary>
    /// 取得ウィンドウを表示してMtrColデータを取得
    /// </summary>
    public void GetData(List<MtrColData> mtrCols, int index)
    {
      Material = Data.GetMatWindow.Show(Window, TmcData, Tables, GetSelectedObjects(), mtrCols, index);
    }

    /// <summary>
    /// 取得ウィンドウを表示してMtrColデータを取得
    /// </summary>
    public void GetData(List<CustomParameters> customps, int index)
    {
      Material = Data.GetMatWindow.Show(Window, TmcData, Tables, GetSelectedObjects(), customps, index);
    }

    /// <summary>
    /// 選択しているオブジェクトを取得
    /// </summary>
    /// <returns>選択しているオブジェクトのリスト</returns>
    public List<ObjectData> GetSelectedObjects()
    {
      List<ObjectData> objLists = new List<ObjectData>();

      foreach (ObjectData obj in Window.dgObject.SelectedItems)
      {
        if (obj.Grp == -1) continue;

        objLists.Add(obj);
      }

      return objLists;
    }

    /// <summary>
    /// MtrColを取得
    /// </summary>
    private void GetCol()
    {
      if (CheckGettingCol(null))
      {
        SetGettingCol();

        if (Material.ColAdd)
        {
          foreach (ObjectData obj in Window.dgObject.SelectedItems)
          {
            if (obj.Grp == -1) continue;
            obj.MtrCol = Material.Col.ID;
          }
        }
      }
    }

    /// <summary>
    /// matecpを取得
    /// </summary>
    private void GetMateCp()
    {
      if (CheckGettingMateCp(null))
      {
        SetGettingMateCp();

        if (Material.MateCpAdd)
        {
          foreach (ObjectData obj in Window.dgObject.SelectedItems)
          {
            if (obj.Grp == -1) continue;
            obj.Matecp = Material.MateCp.Index;
          }
        }
      }

      foreach (ObjectData obj in Window.dgObject.SelectedItems)
      {
        if (obj.Grp == -1) continue;
        Tables.CheckObjectType(obj);
      }
    }

    /// <summary>
    /// MCAMTRLを取得
    /// </summary>
    private void GetMat()
    {
      if (CheckGettingMat(null))
      {
        SetGettingMat();

        if (Material.MatAdd)
        {
          foreach (ObjectData obj in Window.dgObject.SelectedItems)
          {
            if (obj.Grp == -1) continue;
            obj.Mcamtrl = Material.Mat.ID;
          }
        }
      }
    }

    /// <summary>
    /// テクスチャパラメータを取得
    /// </summary>
    private void GetTexParams()
    {
      foreach (ObjectData obj in Window.dgObject.SelectedItems)
      {
        if (obj.Grp == -1) continue;

        string checkTexType = "";
        string curTexType = "";
        if (obj.TexTypes.Count != 0) curTexType = obj.TexTypes[obj.TexType].Replace(" ", "");
        if (curTexType == "Error") curTexType = "0123";
        obj.TexParam.BaseParams[0] = Material.TexParams[0].ToString("X2");
        obj.TexParam.BaseParams[1] = (Material.TexParams[1] / 0x10 * 0x10).ToString("X2");
        obj.TexParam.BaseParams[2] = (Material.TexParams[2] / 8 * 8).ToString("X2");

        for (byte i = 0; i < Material.Tex.Count; i++)
        {
          if (obj.TexDataList.Count <= i)
          {
            obj.TexDataList.Add(Material.Tex[i].Data);

            var param = new TexParameters();
            param.SetParams(Material.Tex[i]);
            param.Name = "Tex" + (obj.TexParam.ParamSets.Count + 1);
            obj.TexParam.ParamSets.Add(param);
          }
          else
          {
            obj.TexDataList[i] = (dynamic[])Material.Tex[i].Data.Clone();

            obj.TexParam.ParamSets[i].SetParams(Material.Tex[i]);
          }

          obj.RecentTexTypes[i] = Material.Tex[i].Type.ToString()[0];
          if (Material.Tex.Count >= obj.TexCount) checkTexType += Material.Tex[i].Type;
        }

        int envCount = (int)(obj.TexCount - obj.UVCount);
        if (checkTexType.Length > obj.UVCount)
        {
          checkTexType = checkTexType.Substring(0, (int)obj.UVCount);
          for (int i = 0; i < envCount; i++)
          {
            checkTexType += "3";
          }
        }
        else
        {
          for (int i = checkTexType.Length; i < obj.TexCount; i++)
          {
            checkTexType += curTexType[i];
          }
        }

        obj.SetTexType(obj.UVCount, checkTexType);

        if (checkTexType.Contains("3"))
          obj.ChangeableEnvMap = true;
        else
          obj.ChangeableEnvMap = false;
      }

      Data.Modified();
    }



    /// <summary>
    /// 取得したMtrColを確認
    /// </summary>
    /// <returns>取得したMtrColを追加するかどうか</returns>
    public bool CheckGettingCol(ObjectData objData)
    {
      // 既に同じものがあるかチェック（置換の場合は置換先は除く）
      List<int> equalCol = new List<int>();
      foreach (var col in TmcData.ColGrp)
      {
        if (!Material.ColAdd && col.ID == Material.ColTarget) continue;

        for (int i = 0; i < col.Color.Count; i++)
        {
          for (int j = 0; j < col.Color[i].Length; j++)
          {
            if (col.Color[i][j] != Material.Col.Color[i][j])
            {
              goto SkipAdd;
            }
          }
        }
        equalCol.Add(col.ID);

        SkipAdd:;
      }

      // 同じものがあれば追加するか確認
      if (equalCol.Count > 0)
      {
        string str = Txt.ConfirmReplace;
        if (Material.ColAdd) str = Txt.ConfirmAdd;

        string equalColText = "   MtrCol :";
        foreach (var col in equalCol)
        {
          equalColText += " " + col;
        }

        if (objData != null)
        {
          objData.MtrCol = equalCol[0];
          return false;
        }

        var result = MessageWindow.Show(Window, Txt.SameMtrCol + equalColText + "\r\n" + str, Txt.Confirm, Txt.Yes, Txt.No, Txt.Auto);

        if (result == MessageWindow.Result.Cancel)
        {
          return false;
        }
        else if (result == MessageWindow.Result.Other)
        {
          foreach (ObjectData obj in Window.dgObject.SelectedItems)
          {
            if (obj.Grp == -1 || equalCol.Contains((int)obj.MtrCol)) continue;

            obj.MtrCol = equalCol[0];
          }
          Data.Modified();
          return false;
        }
      }

      return true;
    }

    /// <summary>
    /// 取得したMtrColをセット
    /// </summary>
    public void SetGettingCol()
    {
      Material.Col.Offset = 0;
      Material.Col.Start = 0;
      if (Material.ColAdd)
      {
        // tmcDataに追加
        Material.Col.ID = TmcData.ColGrp.Count;
        Tables.MtlCols.Add(Material.Col.ID);
        TmcData.ColGrp.Add(Material.Col);
      }
      else
      {
        // tmcDataのデータを置換
        Material.Col.ID = Material.ColTarget;
        TmcData.ColGrp.RemoveAt(Material.ColTarget);
        TmcData.ColGrp.Insert(Material.ColTarget, Material.Col);
      }

      Data.Modified();
    }

    /// <summary>
    /// 取得したmatecpを確認
    /// </summary>
    /// <returns>取得したmatecpを追加するかどうか</returns>
    public bool CheckGettingMateCp(ObjectData objData)
    {
      // 既に同じものがあるかチェック（置換の場合は置換先は除く）
      List<int> equalMateCp = new List<int>();
      foreach (var matecp in TmcData.MateCp)
      {
        if (!Material.MateCpAdd && matecp.Index == Material.MateCpTarget) continue;

        if (matecp.Cp.Count != Material.MateCp.Cp.Count) continue;

        for (int i = 0; i < matecp.Cp.Count; i++)
        {
          if (
            matecp.Cp[i].Data1 != Material.MateCp.Cp[i].Data1 ||
            matecp.Cp[i].Data2 != Material.MateCp.Cp[i].Data2 ||
            matecp.Cp[i].Param != Material.MateCp.Cp[i].Param
            )
          {
            goto SkipAdd;
          }
        }
        equalMateCp.Add(matecp.Index);

        SkipAdd:;
      }

      // 同じものがあれば追加するか確認
      if (equalMateCp.Count > 0)
      {
        string str = Txt.ConfirmReplace;
        if (Material.MateCpAdd) str = Txt.ConfirmAdd;

        string equalMateCpText = "   MateCp :";
        foreach (var mat in equalMateCp)
        {
          equalMateCpText += " " + mat;
        }

        if (objData != null)
        {
          objData.Matecp = equalMateCp[0];
          return false;
        }

        var result = MessageWindow.Show(Window, Txt.SameMateCp + equalMateCpText + "\r\n" + str, Txt.Confirm, Txt.Yes, Txt.No, Txt.Auto);

        if (result == MessageWindow.Result.Cancel)
        {
          return false;
        }
        else if (result == MessageWindow.Result.Other)
        {
          foreach (ObjectData obj in Window.dgObject.SelectedItems)
          {
            if (obj.Grp == -1 || equalMateCp.Contains((int)obj.Matecp)) continue;

            obj.Matecp = equalMateCp[0];
          }
          Data.Modified();
          return false;
        }
      }

      return true;
    }

    /// <summary>
    /// 取得したmatecpをセット
    /// </summary>
    public void SetGettingMateCp()
    {
      Material.MateCp.Offset = 0;
      Material.MateCp.Start = 0;
      if (Material.MateCpAdd)
      {
        foreach (var obj in Tables.ObjData)
        {
          if (obj.Matecp == TmcData.MateCp.Count)
          {
            obj.Matecp++;
          }
        }
        // tmcDataに追加
        Material.MateCp.Index = TmcData.MateCp.Count;
        Tables.Matecps.Add(Material.MateCp.Index + 1);
        TmcData.MateCp.Add(Material.MateCp);
      }
      else
      {
        // tmcDataのデータを置換
        Material.MateCp.Index = Material.MateCpTarget;
        TmcData.MateCp.RemoveAt(Material.MateCpTarget);
        TmcData.MateCp.Insert(Material.MateCpTarget, Material.MateCp);
      }

      Data.Modified();
    }

    /// <summary>
    /// 取得したMCAMTRLを確認
    /// </summary>
    /// <returns>取得したMCAMTRLを追加するかどうか</returns>
    public bool CheckGettingMat(ObjectData objData)
    {
      // 既に同じものがあるかチェック（置換の場合は置換先は除く）
      List<int> equalMat = new List<int>();
      foreach (var mat in TmcData.Mat)
      {
        if (!Material.MatAdd && mat.ID == Material.MatTarget) continue;

        if (mat.Param.Count != Material.Mat.Param.Count) continue;

        for (int i = 0; i < mat.Param.Count; i++)
        {
          if (mat.Param[i] == null && Material.Mat.Param[i] == null) continue;

          if (
            mat.Param[i] == null ||
            Material.Mat.Param[i] == null ||
            mat.Param[i].ID != Material.Mat.Param[i].ID ||
            mat.Param[i].Count != Material.Mat.Param[i].Count ||
            mat.Param[i].Data1 != Material.Mat.Param[i].Data1 ||
            mat.Param[i].Data2 != Material.Mat.Param[i].Data2
          )
          {
            goto SkipAdd;
          }

          if (mat.Param[i].Data3 == null && Material.Mat.Param[i].Data3 == null) continue;

          if (mat.Param[i].Data3 != null && Material.Mat.Param[i].Data3 != null)
          {
            for (int j = 0; j < mat.Param[i].Data3.Length; j++)
            {
              if (mat.Param[i].Data3[j] != Material.Mat.Param[i].Data3[j])
              {
                goto SkipAdd;
              }
            }
          }

          if (mat.Param[i].Params == null && Material.Mat.Param[i].Params == null) continue;

          if (mat.Param[i].Params != null && Material.Mat.Param[i].Params != null)
          {
            for (int j = 0; j < mat.Param[i].Params.Count; j++)
            {
              for (int k = 0; k < mat.Param[i].Params[j].Length; k++)
              {
                if (mat.Param[i].Params[j][k] != Material.Mat.Param[i].Params[j][k])
                {
                  goto SkipAdd;
                }
              }
            }
          }
        }
        equalMat.Add(mat.ID);

        SkipAdd:;
      }

      // 同じものがあれば追加するか確認
      if (equalMat.Count > 0)
      {
        string str = Txt.ConfirmReplace;
        if (Material.MatAdd) str = Txt.ConfirmAdd;

        string equalMatText = "   MCAMTRL :";
        foreach (var mat in equalMat)
        {
          equalMatText += " " + mat;
        }

        if (objData != null)
        {
          objData.Mcamtrl = equalMat[0];
          return false;
        }

        var result = MessageWindow.Show(Window, Txt.SameMCAMTRL + equalMatText + "\r\n" + str, Txt.Confirm, Txt.Yes, Txt.No, Txt.Auto);

        if (result == MessageWindow.Result.Cancel)
        {
          return false;
        }
        else if (result == MessageWindow.Result.Other)
        {
          foreach (ObjectData obj in Window.dgObject.SelectedItems)
          {
            if (obj.Grp == -1 || equalMat.Contains((int)obj.Mcamtrl)) continue;

            obj.Mcamtrl = equalMat[0];
          }
          Data.Modified();
          return false;
        }
      }

      return true;
    }

    /// <summary>
    /// 取得したMCAMTRLをセット
    /// </summary>
    public void SetGettingMat()
    {
      Material.Mat.Offset = 0;
      Material.Mat.Start = 0;

      if (Material.MatAdd)
      {
        // tmcDataに追加
        Material.Mat.ID = TmcData.Mat.Count;
        Tables.Mcamtrls.Add(Material.Mat.ID);
        TmcData.Mat.Add(Material.Mat);
      }
      else
      {
        // tmcDataのデータを置換
        Material.Mat.ID = Material.MatTarget;
        TmcData.Mat.RemoveAt(Material.MatTarget);
        TmcData.Mat.Insert(Material.MatTarget, Material.Mat);
      }

      Data.Modified();
    }

    #endregion



    #region プロパティ

    /// <summary>
    /// MainWindowViewModel
    /// </summary>
    public MainWindowViewModel Data { get; set; }

    /// <summary>
    /// 言語テキスト
    /// </summary>
    private static Lang.Text Txt { get; set; }

    /// <summary>
    /// MainWindow
    /// </summary>
    private static MainWindow Window { get; set; }

    /// <summary>
    /// TMCデータ
    /// </summary>
    public static TmcData TmcData { get; set; }

    /// <summary>
    /// 表のデータ
    /// </summary>
    private static DataTables Tables { get; set; }


    /// <summary>
    /// 取得しているマテリアル
    /// </summary>
    public MaterialData Material { get; set; }

    #endregion
  }
}
