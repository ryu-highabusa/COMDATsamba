﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Common;
using TMC_Tool.ViewModels;
using Language;
using Message;
using Tmc;

namespace TMC_Tool.Models
{
  public class ExtractMeshes
  {
    public ExtractMeshes(MainWindowViewModel data, ExtractMeshWindowViewModel options, List<ObjectData> objects)
    {
      Txt = MainWindow.Txt;

      Data = data;
      Objects = objects;

      ExceptUnusedBlendIndex = options.ExceptUnusedBlendIndex;
      CreateDirectory = options.CreateDirectory;
      Overwrite = options.Overwrite;
      ObjectNameOnly = options.ObjectNameOnly;

      Count = 0;
    }


    /// <summary>
    /// メッシュデータの抽出を実行します（TMCから抽出）
    /// </summary>
    /// <returns>メッシュデータを抽出した数</returns>
    public int Do()
    {
      // 保存するディレクトリをセット
      SetDirectoryPath();


      foreach (var objData in Objects)
      {
        if (objData.Grp == -1) continue;


        if (objData.DataIndex == -1)
          TmcData = Data.TmcData;
        else
          TmcData = Data.OtherTmcDataList[objData.DataIndex];


        var objGrp = TmcData.ObjGrp[objData.OriginalGrpIndex];


        if (TmcData.Node[objGrp.Node].ObjIndex == -1 || objData.VtxCount <= 1 || objData.IdxCount <= 2)
        {
          CanNotExtractedObjects.Add(objData.Name);
          continue;
        }


        var obj = objGrp.Obj[objData.OriginalObjIndex];

        var decl = objGrp.Decl[(int)Data.Tables.VIData[(int)objData.VtxGrp].OriginalDecl];

        var indices = TmcData.IdxGrp[decl.IdxGrpIndex].Idx;
        var dataSize = decl.DataSize;
        var declBin = BuildDeclBin(decl);


        if (TmcData.VtxGrp[obj.VtxGrpIndex].Vtx.Count == 0) TmcData.ParseVertexData(TmcData.Bin, TmcData.H.Offsets[2]);


        ExtractVertices = new List<int>();

        for (int i = obj.VtxStartIndex; i < obj.VtxStartIndex + obj.VtxCount; i++)
        {
          ExtractVertices.Add(i);
        }

        if (ExtractVertices.Count == 0)
        {
          CanNotExtractedObjects.Add(objData.Name);
          continue;
        }


        bool? result = ExtractMesh(objGrp, decl, obj, declBin);

        if (result == null)
          return Count;
        else if (result == false)
          CanNotExtractedObjects.Add(objData.Name);
      }

      // 初期化
      BlendIdx = new Dictionary<byte, string>();


      if (CanNotExtractedObjects.Count > 0)
      {
        string names = "";

        foreach (string objName in CanNotExtractedObjects)
        {
          names += objName + "\r\n";
        }

        MessageWindow.Show(Data.Window, names + "\r\n" + Txt.CanNotExtract, Txt.Error);
      }

      return Count;
    }

    /// <summary>
    /// 保存するディレクトリをセットします
    /// </summary>
    private void SetDirectoryPath()
    {
      DirectoryPath = Path.GetDirectoryName(Data.TmcData.Path) + @"\";
      if (CreateDirectory)
      {
        DirectoryPath += Path.GetFileNameWithoutExtension(Data.TmcData.Path) + @"_MESHES\";
      }
    }

    /// <summary>
    /// 指定オブジェクトのメッシュデータを抽出します
    /// </summary>
    /// <param name="objGrp">オブジェクトグループデータ</param>
    /// <param name="decl">Declデータ</param>
    /// <param name="obj">オブジェクトデータ</param>
    /// <param name="declBin">Declバイナリデータ</param>
    /// <returns>メッシュデータを抽出できたかどうか</returns>
    private bool? ExtractMesh(ObjectGroup objGrp, DeclPart decl, ObjectPart obj, List<byte> declBin)
    {
      // 既存ファイルチェック
      bool? result = CheckExistFile(objGrp, obj);

      if (result == null)
        return null;
      else if (result == false)
        return false;


      PrepareExtractVertices(obj, decl.IdxGrpIndex);


      ConvertVtxIndex = new Dictionary<int, ushort>();
      BlendIdxList = new SortedSet<byte>();

      PartBins = new List<List<byte>>();
      for (int i = 0; i < 17; i++)
      {
        PartBins.Add(new List<byte>());
      }

      PartBins[2] = BuildVtxBin(obj);

      PartBins[3] = BuildIdxBin(obj);

      PartBins[0] = BuildGeoBin(obj, declBin);

      PartBins[4] = BuildColorBin(obj);

      PartBins[9] = BuildMatrixBin(obj, objGrp.Node);

      var blends = TmcData.Node[objGrp.Node].Blends;
      for (byte i = 0; i < blends.Count; i++)
      {
        BlendIdx[i] = TmcData.Node[blends[i]].Name;
      }
      PartBins[15] = BuildBlendIdxBin(obj);


      // バイナリ構築
      BuildBin();


      if (ExBin.Count == 0) return false;


      // メッシュデータ保存
      Save();


      return true;
    }

    /// <summary>
    /// 削除する頂点リストを準備します
    /// </summary>
    /// <param name="obj">オブジェクトデータ</param>
    /// <param name="idxGrpIndex">Idxグループインデックス</param>
    private void PrepareExtractVertices(ObjectPart obj, int idxGrpIndex)
    {
      if (!ExtractAddedOnly)
      {
        // 表のものからポリゴンパーツを取得
        PolygonParts = IdxUtils.GetPolygonPartsTriangleStrip(TmcData, obj, idxGrpIndex);

        // 三角形にならないポリゴンパーツを除去
        RemoveDegenerateParts();

        // 接続面へ対象を拡大して抽出頂点リストに追加
        ExtractVertices = SetConnectedParts();
      }
    }


    /// <summary>
    /// 三角形にならないポリゴンパーツを除去します
    /// </summary>
    private void RemoveDegenerateParts()
    {
      foreach (var part in PolygonParts.ToList())
      {
        if (part.Indices.Distinct().Count() < 3)
        {
          PolygonParts.Remove(part);
        }
      }
    }

    /// <summary>
    /// 抽出する接続面の頂点を取得します
    /// </summary>
    /// <returns>抽出する接続面の頂点インデックスリスト</returns>
    private List<int> SetConnectedParts()
    {
      HashSet<int> vertices = new HashSet<int>(ExtractVertices);
      int extractCount;
      do
      {
        extractCount = vertices.Count;

        foreach (var part in PolygonParts)
        {
          if (part.Selected) continue;

          foreach (var idx in part.Indices)
          {
            if (!vertices.Contains(idx)) continue;

            for (int i = 0; i < part.Indices.Count; i++)
            {
              vertices.Add(part.Indices[i]);
            }
            part.Selected = true;
            break;
          }
        }
      } while (PolygonParts.Count(e => e.Selected == false) > 0 && extractCount < vertices.Count);


      return vertices.ToList();
    }


    /// <summary>
    /// Geoのバイナリを構築します
    /// </summary>
    /// <param name="obj">オブジェクトデータ</param>
    /// <param name="declBin">Declバイナリデータ</param>
    /// <returns>バイナリデータ</returns>
    private List<byte> BuildGeoBin(ObjectPart obj, List<byte> declBin)
    {
      List<byte> bin = TmcUtils.BuildHeaderBaseBin("Geo");

      List<List<byte>> bins = new List<List<byte>>();

      bins.Add(declBin);


      int offset = 0x60;


      List<byte> objBin = new List<byte>();
      objBin.AddRange(TmcData.Bin.Skip(obj.Start).Take(0xD0));
      ByteListUtils.Replace(objBin, BitConverter.GetBytes(0), 0x00);
      ByteListUtils.Replace(objBin, BitConverter.GetBytes(0), 0x04);
      ByteListUtils.Replace(objBin, BitConverter.GetBytes(0), 0x38);
      ByteListUtils.Replace(objBin, BitConverter.GetBytes(0), offset + 0x10);
      ByteListUtils.Replace(objBin, BitConverter.GetBytes(IdxCount), offset + 0x14);
      ByteListUtils.Replace(objBin, BitConverter.GetBytes(0), offset + 0x18);
      ByteListUtils.Replace(objBin, BitConverter.GetBytes(VtxCount), offset + 0x1C);

      bins.Add(objBin);


      TmcUtils.BuildBin(bin, bins, null, false, true);

      return bin;
    }

    /// <summary>
    /// Declのバイナリを構築します
    /// </summary>
    /// <param name="decl">Declデータ</param>
    /// <returns>バイナリデータ</returns>
    private List<byte> BuildDeclBin(DeclPart decl)
    {
      List<byte> bin = new List<byte>();

      bin.AddRange(BitConverter.GetBytes(0));
      bin.AddRange(BitConverter.GetBytes(decl.DataSize));
      bin.AddRange(BitConverter.GetBytes(TmcData.VtxGrp[decl.VtxGrpIndex].DataLayers.Count));
      bin.AddRange(BitConverter.GetBytes(0));

      foreach (var layer in TmcData.VtxGrp[decl.VtxGrpIndex].DataLayers)
      {
        bin.AddRange(layer);
      }

      if (bin.Count % 0x10 > 0) bin.AddRange(new byte[0x10 - bin.Count % 0x10]);

      return bin;
    }

    /// <summary>
    /// Vtxのバイナリを構築します
    /// </summary>
    /// <param name="obj">オブジェクトデータ</param>
    /// <returns>バイナリデータ</returns>
    private List<byte> BuildVtxBin(ObjectPart obj)
    {
      List<byte> bin = new List<byte>();

      VtxCount = 0;

      var vtxGrp = TmcData.VtxGrp[obj.VtxGrpIndex];
      int offset = TmcData.H.Offsets[2] + vtxGrp.Offset;
      int dataSize = vtxGrp.DataSize;


      for (int i = obj.VtxStartIndex; i < obj.VtxStartIndex + obj.VtxCount; i++)
      {
        if (ExtractVertices.Contains(i))
        {
          Vertex v = vtxGrp.Vtx[i];

          // 頂点のバイナリを取得
          byte[] vBin = new byte[dataSize];
          Array.Copy(TmcData.Bin, v.Address, vBin, 0, dataSize);


          for (int j = 0; j < v.BlendIdx.Count; j++)
          {
            if ((v.Weights.Count > 0 && v.Weights[j] == 0) || (v.WeightsF.Count > 0 && v.WeightsF[j] == 0))
            {
              if (v.BlendIdx[j] == 0)
              {
                continue;
              }
              else if (ExceptUnusedBlendIndex)
              {
                vBin[vtxGrp.BlendIndicesOffsets[j / 4] + j] = 0;
                continue;
              }
            }

            BlendIdxList.Add(v.BlendIdx[j]);
          }


          // 頂点のバイナリを新規バイナリに追加
          bin.AddRange(vBin);

          // 置換辞書オブジェクトをセット
          ConvertVtxIndex[i] = VtxCount;

          VtxCount++;
        }
      }


      if (VtxCount > 0 && BlendIdxList.Count == 0)
      {
        BlendIdxList.Add(0);
      }


      if (bin.Count % 0x10 > 0) bin.AddRange(new byte[0x10 - bin.Count % 0x10]);

      return bin;
    }

    /// <summary>
    /// Idxのバイナリを構築します
    /// </summary>
    /// <param name="obj">オブジェクトデータ</param>
    /// <returns>バイナリデータ</returns>
    private List<byte> BuildIdxBin(ObjectPart obj)
    {
      List<ushort> addIndices = new List<ushort>();

      if (ExtractAddedOnly)
      {
        addIndices.AddRange(IdxUtils.GetIndicesSelected(obj, TmcData.IdxGrp[obj.IdxGrpIndex].Idx, ConvertVtxIndex));
      }
      else
      {
        addIndices.AddRange(IdxUtils.GetIndicesConnected(obj, PolygonParts, true));
      }


      IdxCount = addIndices.Count;


      List<byte> bin = new List<byte>();

      // インデックスを変換しつつバイナリデータへ追加
      foreach (ushort idx in addIndices)
      {
        if (!ConvertVtxIndex.ContainsKey(idx))
        {
          bin.AddRange(BitConverter.GetBytes((ushort)0));
        }
        else
        {
          bin.AddRange(BitConverter.GetBytes(ConvertVtxIndex[idx]));
        }
      }

      if (bin.Count % 0x10 > 0) bin.AddRange(new byte[0x10 - bin.Count % 0x10]);

      return bin;
    }

    /// <summary>
    /// Colorのバイナリを構築します
    /// </summary>
    /// <param name="obj">オブジェクトデータ</param>
    /// <returns>バイナリデータ</returns>
    private List<byte> BuildColorBin(ObjectPart obj)
    {
      List<byte> bin = new List<byte>();

      MtrColorGroup colGrp = TmcData.ColGrp[obj.MtrColor];
      foreach (var color in colGrp.Color)
      {
        foreach (var c in color)
        {
          bin.AddRange(BitConverter.GetBytes(c));
        }
      }
      bin.AddRange(BitConverter.GetBytes(0));
      bin.AddRange(BitConverter.GetBytes(colGrp.Link.Count));

      foreach (KeyValuePair<int, int> pair in colGrp.Link)
      {
        bin.AddRange(BitConverter.GetBytes(pair.Key));
        bin.AddRange(BitConverter.GetBytes(pair.Value));
      }

      bin.AddRange(new byte[(16 - (bin.Count % 16)) % 16]);

      return bin;
    }

    /// <summary>
    /// Matrixのバイナリを構築します
    /// </summary>
    /// <param name="obj">オブジェクトデータ</param>
    /// <param name="nodeIndex">ノードインデックス</param>
    /// <returns>バイナリデータ</returns>
    private List<byte> BuildMatrixBin(ObjectPart obj, int nodeIndex)
    {
      List<byte> bin = new List<byte>();

      if (TmcData.MtxGrp[TmcData.Node[nodeIndex].Index].Matrix.IsIdentity)
      {
        for (int i = 0; i < 16; i++)
        {
          if (i == 0 || i == 5 || i == 10 || i == 15)
            bin.AddRange(BitConverter.GetBytes((float)1));
          else
            bin.AddRange(BitConverter.GetBytes((float)0));
        }
      }
      else
      {
        List<float> matrix = MatrixUtils.Matrix3DToList(TmcData.MtxGrp[TmcData.Node[nodeIndex].Index].Matrix);
        foreach (float f in matrix)
        {
          bin.AddRange(BitConverter.GetBytes(f));
        }
      }

      return bin;
    }

    /// <summary>
    /// BlendIdxのバイナリを構築します
    /// </summary>
    /// <param name="obj">オブジェクトデータ</param>
    /// <returns>バイナリデータ</returns>
    private List<byte> BuildBlendIdxBin(ObjectPart obj)
    {
      List<byte> bin = TmcUtils.BuildHeaderBaseBin("BlendIdx");

      List<List<byte>> bins = new List<List<byte>>();
      if (BlendIdx.Count > 0)
      {
        foreach (byte idx in BlendIdxList)
        {
          List<byte> newBin = new List<byte>();

          string name = BlendIdx[idx];

          newBin.AddRange(BitConverter.GetBytes((int)idx));
          newBin.AddRange(BitConverter.GetBytes(name.Length));
          newBin.AddRange(BitConverter.GetBytes(0));
          newBin.AddRange(BitConverter.GetBytes(0));

          newBin.AddRange(Encoding.ASCII.GetBytes(name));

          newBin.AddRange(new byte[(16 - (newBin.Count % 16)) % 16]);

          bins.Add(newBin);
        }
      }

      TmcUtils.BuildBin(bin, bins, null, false, false);

      return bin;
    }


    /// <summary>
    /// 既存ファイルを確認し存在している場合はダイアログを表示します
    /// </summary>
    /// <param name="objGrp">オブジェクトグループデータ</param>
    /// <param name="obj">オブジェクトデータ</param>
    /// <returns>ダイアログの結果</returns>
    private bool? CheckExistFile(ObjectGroup objGrp, ObjectPart obj)
    {
      string filePath;

      string objName = objGrp.Name + "_" + obj.ID.ToString("x");

      if (ObjectNameOnly)
      {
        filePath = DirectoryPath + objName + ".tmcmesh";
      }
      else
      {
        filePath = DirectoryPath + Path.GetFileNameWithoutExtension(Data.TmcData.Path) + "-" + objName + ".tmcmesh";
      }


      SavePath = "";

      if (!Overwrite && File.Exists(filePath))
      {
        var result = MessageWindow.Show(Data.Window, filePath + "\r\n" + Txt.AlreadyExists, Txt.Confirm, Txt.SaveAs, Txt.Cancel, Txt.OverwriteYes, Txt.Skip);
        if (result == MessageWindow.Result.OK)
        {
          Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
          dlg.InitialDirectory = Path.GetDirectoryName(filePath);
          dlg.FileName = Path.GetFileName(filePath);
          dlg.DefaultExt = ".tmcmesh";
          dlg.Filter = "tmcmesh Files (.tmcmesh)|*.tmcmesh";
          bool? resultDlg = dlg.ShowDialog();
          if (resultDlg == true)
          {
            SavePath = dlg.FileName;
          }
        }
        else if (result == MessageWindow.Result.Other)
        {
          SavePath = filePath;
        }
        else if (result == MessageWindow.Result.Other2)
        {
          return false;
        }
        else if (result == MessageWindow.Result.Cancel)
        {
          return null;
        }
      }
      else
      {
        if (!Directory.Exists(DirectoryPath))
        {
          Directory.CreateDirectory(DirectoryPath);
        }

        SavePath = filePath;
      }

      if (String.IsNullOrEmpty(SavePath)) return false;


      return true;
    }

    /// <summary>
    /// tmcmeshのバイナリを構築します
    /// </summary>
    private void BuildBin()
    {
      ExBin = TmcUtils.BuildHeaderBaseBin("tmcmesh");


      TmcUtils.BuildBin(ExBin, PartBins, null, true, true);
    }

    /// <summary>
    /// メッシュデータを保存します
    /// </summary>
    private void Save()
    {
      File.WriteAllBytes(SavePath, ExBin.ToArray());

      Count++;
    }



    #region プロパティ

    /// <summary>
    /// 抽出したメッシュファイル数
    /// </summary>
    public int Count { get; set; }

    /// <summary>
    /// 抽出出来なかったオブジェクトのリスト
    /// </summary>
    public List<string> CanNotExtractedObjects { get; set; } = new List<string>();


    /// <summary>
    /// MainWindowViewModel
    /// </summary>
    private MainWindowViewModel Data { get; set; }

    /// <summary>
    /// 言語テキストデータ
    /// </summary>
    private Lang.Text Txt;

    /// <summary>
    /// TMCの出力バイナリ
    /// </summary>
    private List<byte> ExBin { get; set; }


    /// <summary>
    /// TMCデータ
    /// </summary>
    private TmcData TmcData { get; set; }

    /// <summary>
    /// 抽出するオブジェクトデータ
    /// </summary>
    private List<ObjectData> Objects { get; set; }

    /// <summary>
    /// ポリゴンパーツ
    /// </summary>
    private List<PolygonPart> PolygonParts { get; set; }

    /// <summary>
    /// 各パートのバイナリリスト
    /// </summary>
    private List<List<byte>> PartBins { get; set; }

    /// <summary>
    /// VtxLayのバイナリ
    /// </summary>
    private List<byte> VtxBin { get; set; }

    /// <summary>
    /// IdxLayのバイナリ
    /// </summary>
    private List<byte> IdxBin { get; set; }

    /// <summary>
    /// Vtx数
    /// </summary>
    private ushort VtxCount { get; set; }

    /// <summary>
    /// Idx数
    /// </summary>
    private int IdxCount { get; set; }

    /// <summary>
    /// 保存するディレクトリパス
    /// </summary>
    private string DirectoryPath { get; set; }

    /// <summary>
    /// 保存するパス
    /// </summary>
    private string SavePath { get; set; }


    /// <summary>
    /// 抽出する頂点リスト
    /// </summary>
    private List<int> ExtractVertices { get; set; }

    /// <summary>
    /// 頂点のインデックスの変換ディクショナリ
    /// </summary>
    private Dictionary<int, ushort> ConvertVtxIndex { get; set; }

    /// <summary>
    /// BlendIdxのリスト
    /// </summary>
    private SortedSet<byte> BlendIdxList { get; set; }


    /// <summary>
    /// tmcmeshのBlendIdx
    /// </summary>
    private Dictionary<byte, string> BlendIdx { get; set; } = new Dictionary<byte, string>();


    /// <summary>
    /// 対象のみの面のみメッシュを抽出
    /// </summary>
    private bool ExtractAddedOnly { get; set; }

    /// <summary>
    /// メッシュ抽出時に未使用BlendIndexを除く
    /// </summary>
    private bool ExceptUnusedBlendIndex { get; set; }

    /// <summary>
    /// メッシュ抽出時にフォルダを作成
    /// </summary>
    private bool CreateDirectory { get; set; }

    /// <summary>
    /// メッシュ抽出時に既存ファイルを上書き
    /// </summary>
    private bool Overwrite { get; set; }

    /// <summary>
    /// 抽出するメッシュファイル名 : オブジェクト名
    /// </summary>
    private bool ObjectNameOnly { get; set; }

    #endregion
  }
}
