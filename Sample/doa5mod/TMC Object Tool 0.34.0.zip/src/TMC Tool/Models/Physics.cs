﻿using Tmc;

namespace TMC_Tool.Models
{
  public class Physics
  {
    public Physics()
    {
    }

    public string Name { get; set; }
    public PhysicsData Data { get; set; }
    public int DataIndex { get; set; }
  }
}
