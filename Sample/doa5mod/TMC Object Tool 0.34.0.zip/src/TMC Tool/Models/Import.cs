﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media.Media3D;
using System.Data;
using TMC_Tool.ViewModels;
using Tmc;
using Language;
using Message;

namespace TMC_Tool.Models
{
  public class Import
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    public Import(MainWindowViewModel data)
    {
      Txt = MainWindow.Txt;
      Window = data.Window;
      Data = data;
      TmcData = data.TmcData;
      Tables = data.Tables;
    }


    /// <summary>
    /// 実行します
    /// </summary>
    /// <param name="path">ファイルパス</param>
    public void Do(string path)
    {
      try
      {
        if (!Open(path)) return;


        Init();

        int matecpCount = TmcData.MateCp.Count;

        // Tablesにデータを追加
        foreach (var grpData in ImportedTables.ObjData)
        {
          if (grpData.Grp != -1 || !ObjGrpIndices.Contains(grpData.ID)) continue;

          SetObjGrpData(grpData);
        }

        // AdditionalOtherNodesのノードとその親ノードを追加候補に追加
        AddNodesFromOtherNodes();

        // Physicsのノードを追加候補に追加
        AddNodesFromPhysics();

        // 親ノードを追加
        foreach (var index in AdditionalNodes)
        {
          AddParent(index);
        }

        // 追加候補からノードを追加
        AddNodes();

        // Physicsを追加
        if (TmcData.H.Offsets[16] != 0) AddPhysics();

        // ノードをソート
        Tables.SortNodes();

        // オブジェクトグループのノードを再設定
        Tables.ResetObjDataNode();

        // Blendsの名前を変換
        ConvertNameInBlends();

        // Neckの位置が違う場合に再計算リストに追加
        CheckNeckBonePosition();

        // GlblMtxとBnOfsMtxを再計算
        RecalcMatrix();

        // 追加したノードの親に子として追加
        AddAsChild();

        // PhysicsIndicesをソート
        if (TmcData.H.Offsets[16] != 0) SortPhysicsIndices();

        // テクスチャバイナリデータ追加
        AddTextures();

        // 元にmatecpが無かった場合は再設定
        if (matecpCount == 0 && TmcData.MateCp.Count > 0) setMateCp();


        Data.TextureRebuild = true;
        Data.Status = TmcData.Path + "* <TMCL*>";

        Data.IsModified = true;
      }
      catch (Exception e)
      {
        MessageWindow.Show(Window, e.Message + "\r\n\r\n" + e.StackTrace, Txt.Error);
      }
    }

    /// <summary>
    /// インポートするファイルを開く
    /// </summary>
    /// <param name="path">ファイルパス</param>
    /// <returns>ファイルを開けたかどうか</returns>
    public bool Open(string path)
    {
      Bin = File.ReadAllBytes(path);
      char[] charsToTrim = { '\0' };
      string Name = Encoding.ASCII.GetString(Bin, 0, 8).TrimEnd(charsToTrim);
      if (Name != "TMC")
      {
        MessageWindow.Show(Window, Txt.UnsupportedFile + "\r\n" + path, Txt.Error);
        return false;
      }
      if (BitConverter.ToUInt32(Bin, 8) != 0x01010000)
      {
        MessageWindow.Show(Window, Txt.UnsupportedFile + "\r\n" + path, Txt.Error);
        return false;
      }

      string pathL = Path.ChangeExtension(path, ".TMCL");
      if (!File.Exists(pathL))
      {
        string[] separators = { " - " };
        pathL = Path.ChangeExtension(path.Split(separators, StringSplitOptions.RemoveEmptyEntries)[0], ".TMCL");

        if (!File.Exists(pathL))
        {
          MessageWindow.Show(Window, Txt.TmclNotFound, Txt.Error);
          return false;
        }
      }

      ImportedTmcData = Data.ParseTmc(Bin);

      var lHeaderH = new HeaderData(Bin, ImportedTmcData.H.Offsets[7]);
      LOffset = BitConverter.ToInt32(Bin, lHeaderH.Start + lHeaderH.Offset1);

      BinL = File.ReadAllBytes(pathL);


      Window.Activate();

      ObjGrpIndices = SelectObjGrpWindow.Show(Window, ImportedTmcData, TmcData);

      if (ObjGrpIndices == null) return false;

      ImportedTables = new DataTables();
      ImportedTables.SetData(ImportedTmcData);
      CurTexCount = TmcData.Tex.Count;

      Data.OtherTmcDataList.Add(ImportedTmcData);


      return true;
    }

    /// <summary>
    /// プロパティを初期化
    /// </summary>
    private void Init()
    {
      AdditionalTexSet = new HashSet<int>();
      AddedNodes = new Dictionary<string, string>();
      AdditionalBoneGrpList = new HashSet<PhysicsData>();
      AdditionalChar = new Dictionary<int, int>();
      AdditionalOtherNodes = new SortedSet<int>();
      AdditionalNodes = new SortedSet<int>();
      ResettedMatrixNodes = new SortedSet<string>();
      DataIndex = Data.OtherTmcDataList.Count - 1;
    }


    #region オブジェクトグループデータ

    /// <summary>
    /// オブジェクトグループデータをセット
    /// </summary>
    /// <param name="grpData">オブジェクトグループデータ</param>
    private void SetObjGrpData(ObjectData grpData)
    {
      CurNode = grpData.Node;

      NewName = grpData.Name;
      IsAddNode = false;
      if (!ConstData.BasicBones.Contains(grpData.Name))
      {
        NewName = CheckNodeNameExist(grpData.Name, -1);
        IsAddNode = true;
      }
      else if (Array.FindIndex(Tables.Nodes.ToArray(), node => node.Name == NewName) == -1)
      {
        IsAddNode = true;
      }


      foreach (var objData in ImportedTables.ObjData)
      {
        if (objData.Grp == -1 || objData.Grp != grpData.ID) continue;


        var obj = ImportedTmcData.ObjGrp[objData.Grp].Obj[objData.ID];

        // テクスチャを追加準備して再設定
        ResetTextures(obj, objData);

        // マテリアル取得
        GetMaterials(obj, objData);
      }

      AddedNodes[grpData.Name] = NewName;

      grpData.DataIndex = DataIndex;

      AddedIndex = TmcData.Node.Count;

      IsResetMatrix = false;

      // 各種データを追加
      if (IsAddNode) AddData(grpData);

      // オブジェクトグループを追加
      var edit = new Edit(this);
      int newNodeIndex = edit.AddObjGrp(NewName, grpData, ImportedTables);

      if (IsAddNode)
      {
        Tables.Nodes[newNodeIndex].AddedIndex = AddedIndex;
      }

      if (IsResetMatrix)
      {
        Tables.Nodes[newNodeIndex].IsResetMatrix = true;
        ResettedMatrixNodes.Add(NewName);
      }

      // Tables.Nodesに無いノードをオブジェクトグループの親から追加
      AddNodesFromParent(grpData);

      // Tables.Nodesに無いノードをChildrenから追加
      AddChildren(grpData.Node);

      // Tables.Nodesに無いノードをBlendsから追加
      // ACSCLSから追加する必要があるノードを判断
      AddNodesFromBlends(grpData);

      // nodecpを追加
      if (ImportedTmcData.NodeCp != null && IsAddNode) AddNodeCp();
    }

    /// <summary>
    /// 各種データを追加
    /// </summary>
    /// <param name="grpData">オブジェクトグループデータ</param>
    private void AddData(ObjectData grpData)
    {
      ImportedTmcData.Node[grpData.Node].Start = 0;
      TmcData.Node.Add(ImportedTmcData.Node[grpData.Node]);
      TmcData.Hie.Add(ImportedTmcData.Hie[grpData.Node]);
      TmcData.MtxGrp.Add(ImportedTmcData.MtxGrp[grpData.Node]);
      TmcData.BnOfsMtxGrp.Add(ImportedTmcData.BnOfsMtxGrp[grpData.Node]);

      // for Hair Object
      if (grpData.Name == "WGT_hair" && ImportedTmcData.Hie[CurNode].Parent == -1)
      {
        //int index = Array.FindIndex(tmcTables.Nodes.ToArray(), node => node.Name == "WGT_hair");
        //if (index == -1) index = Array.FindIndex(tmcTables.Nodes.ToArray(), node => node.Name == "MOT01_Head");
        int index = Array.FindIndex(Tables.Nodes.ToArray(), node => node.Name == "MOT01_Head");

        if (index != -1)
        {
          Tables.Nodes[index].Children.Add(NewName);

          TmcData.Hie[AddedIndex].Matrix = Matrix3D.Identity;
          TmcData.MtxGrp[AddedIndex] = TmcData.MtxGrp[index];
          TmcData.BnOfsMtxGrp[AddedIndex] = TmcData.BnOfsMtxGrp[index];

          IsResetMatrix = true;
        }
      }
    }

    /// <summary>
    /// Tables.Nodesに無いノードをオブジェクトグループの親から追加
    /// </summary>
    /// <param name="grpData">オブジェクトグループデータ</param>
    private void AddNodesFromParent(ObjectData grpData)
    {
      int parent = ImportedTmcData.Hie[grpData.Node].Parent;
      while (parent != -1)
      {
        int index = Array.FindIndex(Tables.Nodes.ToArray(), node => node.Name == ImportedTmcData.Node[parent].Name);
        if (index != -1 || AddedNodes.ContainsKey(ImportedTmcData.Node[parent].Name)) break;

        AdditionalOtherNodes.Add(parent);

        foreach (var child in ImportedTmcData.Hie[parent].Children)
        {
          AdditionalOtherNodes.Add(child);
        }

        parent = ImportedTmcData.Hie[parent].Parent;
      }
    }

    /// <summary>
    /// Tables.Nodesに無いノードをChildrenから追加
    /// </summary>
    /// <param name="index">ノードインデックス</param>
    private void AddChildren(int index)
    {
      foreach (int child in ImportedTmcData.Hie[index].Children)
      {
        AdditionalOtherNodes.Add(child);
        AddChildren(child);
      }
    }

    /// <summary>
    /// Tables.Nodesに無いノードをBlendsから追加
    /// ACSCLSから追加する必要があるノードを判断
    /// </summary>
    /// <param name="grpData">オブジェクトグループデータ</param>
    private void AddNodesFromBlends(ObjectData grpData)
    {
      foreach (int index in ImportedTmcData.Node[grpData.Node].Blends)
      {
        bool added = false;

        if (ImportedTmcData.Physics != null)
        {
          foreach (var physics in ImportedTmcData.Physics)
          {
            if (physics.RootNode == index)
            {
              AdditionalBoneGrpList.Add(physics);
              added = true;
              continue;
            }

            foreach (var block1 in physics.Block1)
            {
              if (block1.NodeIndex == index)
              {
                AdditionalBoneGrpList.Add(physics);
                added = true;
                break;
              }
            }

            foreach (var type2 in physics.Type2)
            {
              foreach (var type2data in type2)
              {
                if (type2data.NodeIndex == index)
                {
                  AdditionalBoneGrpList.Add(physics);
                  added = true;
                  break;
                }
              }
            }
          }
        }

        if (added) continue;

        AdditionalOtherNodes.Add(index);
      }
    }

    /// <summary>
    /// nodecpを追加
    /// </summary>
    private void AddNodeCp()
    {
      int nodeCpIndex = Array.FindIndex(ImportedTmcData.NodeCp.ToArray(), nodecp => nodecp.Index == CurNode);
      if (nodeCpIndex != -1)
      {
        Customp newNodeCp = ImportedTmcData.NodeCp[nodeCpIndex].Clone();
        newNodeCp.Index = AddedIndex;
        TmcData.NodeCp.Add(newNodeCp);
      }
    }

    #endregion


    #region オブジェクトデータ

    /// <summary>
    /// オブジェクトのテクスチャを追加準備して再設定
    /// </summary>
    /// <param name="obj">オブジェクトパートデータ</param>
    /// <param name="objData">オブジェクトデータ</param>
    private void ResetTextures(ObjectPart obj, ObjectData objData)
    {
      List<int?> texs = new List<int?>();
      for (byte i = 0; i < 5; i++)
      {
        if (obj.TexCount > i)
        {
          AdditionalTexSet.Add(obj.Tex[i].Num);
          texs.Add(CurTexCount + AdditionalTexSet.ToList().IndexOf(obj.Tex[i].Num));
        }
        else
          texs.Add(null);
      }
      objData.Tex1 = texs[0];
      objData.Tex2 = texs[1];
      objData.Tex3 = texs[2];
      objData.Tex4 = texs[3];
      objData.Tex5 = texs[4];
    }

    /// <summary>
    /// オブジェクトのマテリアルを追加
    /// </summary>
    /// <param name="obj">オブジェクトパートデータ</param>
    /// <param name="objData">オブジェクトデータ</param>
    private void GetMaterials(ObjectPart obj, ObjectData objData)
    {
      var gettingMat = new GetMaterials(this);

      // MtrCol追加・再設定
      if (ImportedTmcData.ColGrp.Count > 0)
      {
        MtrColorGroup col = ImportedTmcData.ColGrp[obj.MtrColor];
        gettingMat.Material.SetColData(col.Start - col.Offset, col.Offset, Bin, -1);

        if (gettingMat.CheckGettingCol(objData))
        {
          gettingMat.SetGettingCol();
          objData.MtrCol = gettingMat.Material.Col.ID;
        }
      }

      // matecp追加・再設定
      if (ImportedTmcData.MateCp.Count > 0)
      {
        if (ImportedTmcData.Itable[objData.Grp].Indices[objData.ID] == ImportedTmcData.MateCp.Count)
        {
          objData.Matecp = TmcData.MateCp.Count;
        }
        else
        {
          Customp cp = ImportedTmcData.MateCp[ImportedTmcData.Itable[objData.Grp].Indices[objData.ID]];
          gettingMat.Material.SetMateCpData(cp.Start - cp.Offset, cp.Offset, Bin, -1);

          if (gettingMat.CheckGettingMateCp(objData))
          {
            gettingMat.SetGettingMateCp();
            objData.Matecp = gettingMat.Material.MateCp.Index;
          }
        }
      }
      else if (ImportedTmcData.MateCp.Count == 0)
      {
        objData.Matecp = TmcData.MateCp.Count;
      }

      // MCAMTRL追加・再設定
      if (TmcData.Mat == null)
      {
        objData.Mcamtrl = null;
      }
      else if (ImportedTmcData.Mat != null)
      {
        if (ImportedTmcData.McaIdx[objData.Grp].MatID[objData.ID] == -1)
        {
          objData.Mcamtrl = -1;
        }
        else
        {
          Tmc.Material mat = ImportedTmcData.Mat[ImportedTmcData.McaIdx[objData.Grp].MatID[objData.ID]];
          gettingMat.Material.SetMatData(mat.Start - mat.Offset, mat.Offset, Bin, -1);

          if (gettingMat.CheckGettingMat(objData))
          {
            gettingMat.SetGettingMat();
            objData.Mcamtrl = gettingMat.Material.Mat.ID;
          }
        }
      }
      else if (ImportedTmcData.Mat == null)
      {
        objData.Mcamtrl = -1;
      }
    }

    #endregion


    /// <summary>
    /// AddOtherNodesのノードとその親ノードを追加候補に追加
    /// </summary>
    private void AddNodesFromOtherNodes()
    {
      foreach (var nodeIndex in AdditionalOtherNodes)
      {
        AdditionalNodes.Add(nodeIndex);

        // Tables.Nodesに無いノードを追加するノードの親から追加
        int parent = ImportedTmcData.Hie[nodeIndex].Parent;
        while (parent != -1)
        {
          string parentName = ImportedTmcData.Node[parent].Name;
          int index = Array.FindIndex(Tables.Nodes.ToArray(), node => node.Name == parentName);
          if (index != -1 || AdditionalNodes.Contains(parent)) break;

          AdditionalNodes.Add(parent);

          foreach (var child in ImportedTmcData.Hie[parent].Children)
          {
            string childName = ImportedTmcData.Node[parent].Name;
            AdditionalNodes.Add(child);
          }

          parent = ImportedTmcData.Hie[parent].Parent;
        }
      }
    }

    /// <summary>
    /// Physicsのノードを追加候補に追加
    /// </summary>
    private void AddNodesFromPhysics()
    {
      foreach (var physics in AdditionalBoneGrpList)
      {
        bool exist = false;

        AdditionalNodes.Add(physics.RootNode);
        if (Array.FindIndex(TmcData.Node.ToArray(), elem => elem.Name == ImportedTmcData.Node[physics.RootNode].Name) != -1)
        {
          exist = true;
        }

        foreach (var block1 in physics.Block1)
        {
          AdditionalNodes.Add(block1.NodeIndex);
          if (Array.FindIndex(TmcData.Node.ToArray(), elem => elem.Name == ImportedTmcData.Node[block1.NodeIndex].Name) != -1)
          {
            exist = true;
          }
        }

        foreach (var type2 in physics.Type2)
        {
          foreach (var type2data in type2)
          {
            AdditionalNodes.Add(type2data.NodeIndex);
            if (Array.FindIndex(TmcData.Node.ToArray(), elem => elem.Name == ImportedTmcData.Node[type2data.NodeIndex].Name) != -1)
            {
              exist = true;
            }
          }
        }

        int charCode = 0x61;
        while (exist)
        {
          exist = PreCheckNodeNameExist(ImportedTmcData.Node[physics.RootNode].Name, charCode);
          AdditionalChar[physics.RootNode] = charCode;

          foreach (var block1 in physics.Block1)
          {
            exist = PreCheckNodeNameExist(ImportedTmcData.Node[block1.NodeIndex].Name, charCode);
            AdditionalChar[block1.NodeIndex] = charCode;
          }

          foreach (var type2 in physics.Type2)
          {
            foreach (var type2data in type2)
            {
              exist = PreCheckNodeNameExist(ImportedTmcData.Node[type2data.NodeIndex].Name, charCode);
              AdditionalChar[type2data.NodeIndex] = charCode;
            }
          }

          charCode++;
        }
      }
    }

    /// <summary>
    /// 親ノードを追加候補に追加
    /// </summary>
    /// <param name="index">ノードインデックス</param>
    private void AddParent(int index)
    {
      if (
        AdditionalNodes.Contains(index) ||
        Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == ImportedTmcData.Node[index].Name) != -1
      ) return;

      AdditionalNodes.Add(index);
      AddParent(ImportedTmcData.Hie[index].Parent);
    }

    /// <summary>
    /// 追加候補からノードを追加
    /// </summary>
    private void AddNodes()
    {
      foreach (var index in AdditionalNodes)
      {
        string curName = ImportedTmcData.Node[index].Name;

        if (AddedNodes.ContainsKey(curName) || (Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == curName) != -1 && ConstData.BasicBones.Contains(curName))) continue;

        int charCode = -1;
        if (AdditionalChar.ContainsKey(index))
        {
          charCode = AdditionalChar[index];
        }
        string name = CheckNodeNameExist(curName, charCode);

        AddNode(curName, name, index);
        AddedNodes[curName] = name;
      }
    }

    /// <summary>
    /// ノードを追加
    /// </summary>
    /// <param name="originalName">元のノード名</param>
    /// <param name="newName">新しいノード名</param>
    /// <param name="node">ノードインデックス</param>
    private void AddNode(string originalName, string newName, int node)
    {
      if (Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == newName) != -1) return;


      int addedIndex = TmcData.Node.Count;

      ImportedTmcData.Node[node].Start = 0;
      TmcData.Node.Add(ImportedTmcData.Node[node]);
      TmcData.Hie.Add(ImportedTmcData.Hie[node]);
      TmcData.MtxGrp.Add(ImportedTmcData.MtxGrp[node]);
      TmcData.BnOfsMtxGrp.Add(ImportedTmcData.BnOfsMtxGrp[node]);

      Nodes originalNode = ImportedTmcData.Node[ImportedTables.Nodes[node].OriginalIndex];

      // ノードを追加
      var newNode = new NodeData(originalNode);
      newNode.DataIndex = DataIndex;
      newNode.Name = newName;
      newNode.AddedIndex = addedIndex;
      newNode.ObjIndex = -1;
      newNode.IsAdded = true;
      Tables.Nodes.Add(newNode);

      // nodecpの追加
      if (ImportedTmcData.NodeCp != null)
      {
        int nodeCpIndex = Array.FindIndex(ImportedTmcData.NodeCp.ToArray(), nodecp => nodecp.Index == node);
        if (nodeCpIndex != -1)
        {
          Customp newNodeCp = ImportedTmcData.NodeCp[nodeCpIndex].Clone();
          newNodeCp.Index = addedIndex;
          TmcData.NodeCp.Add(newNodeCp);
        }
      }

      if (TmcData.H.Offsets[16] != 0)
      {
        // PhysicsIndicesSetへの追加
        for (int i = 0; i < ImportedTables.PhysicsIndicesSet.Count; i++)
        {
          if (Array.FindIndex(ImportedTables.PhysicsIndicesSet[i].ToArray(), elem => elem.Name == originalName) == -1) continue;

          var physicsIndex = new PhysicsIndex();
          physicsIndex.Name = newName;
          physicsIndex.DataIndex = DataIndex;

          Tables.PhysicsIndicesSet[i].Add(physicsIndex);
        }
      }
    }

    /// <summary>
    /// Physicsを追加
    /// </summary>
    private void AddPhysics()
    {
      foreach (var physics in AdditionalBoneGrpList)
      {
        int nodeIndex = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.OriginalIndex == physics.RootNode && elem.DataIndex == DataIndex);

        var newPhysics = new Physics();
        newPhysics.Name = Tables.Nodes[nodeIndex].Name;
        newPhysics.Data = physics;
        newPhysics.DataIndex = DataIndex;
        Tables.PhysicsList.Add(newPhysics);
      }
    }

    /// <summary>
    /// Blendsの名前を変換
    /// </summary>
    private void ConvertNameInBlends()
    {
      foreach (var node in Tables.Nodes)
      {
        if (node.DataIndex != DataIndex) continue;

        if (ImportedTmcData.Hie[node.OriginalIndex].Parent != -1)
        {
          int parent = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.OriginalIndex == ImportedTmcData.Hie[node.OriginalIndex].Parent && elem.DataIndex == node.DataIndex);
          if (parent == -1)
          {
            parent = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == ImportedTmcData.Node[ImportedTmcData.Hie[node.OriginalIndex].Parent].Name);
          }
          if (parent != -1 && !Tables.Nodes[parent].Children.Contains(node.Name))
            Tables.Nodes[parent].Children.Add(node.Name);
        }

        for (int i = 0; i < node.Blends.Count; i++)
        {
          if (!AddedNodes.ContainsKey(node.Blends[i])) continue;

          node.Blends[i] = AddedNodes[node.Blends[i]];
        }
      }
    }

    /// <summary>
    /// Neckの位置が違う場合に再計算リストに追加
    /// </summary>
    private void CheckNeckBonePosition()
    {
      int faceRootIndex = Array.FindIndex(ImportedTmcData.Node.ToArray(), node => node.Name == "OPT_Face_Root");
      if (faceRootIndex != -1)
      {
        int neckIndex = Array.FindIndex(TmcData.Node.ToArray(), node => node.Name == "MOT15_Neck");
        int dataNeckIndex = Array.FindIndex(ImportedTmcData.Node.ToArray(), node => node.Name == "MOT15_Neck");

        double allowable = 0.001;
        double[] offset = new double[]
        {
            Math.Abs(ImportedTmcData.MtxGrp[dataNeckIndex].Matrix.OffsetX - TmcData.MtxGrp[neckIndex].Matrix.OffsetX),
            Math.Abs(ImportedTmcData.MtxGrp[dataNeckIndex].Matrix.OffsetY - TmcData.MtxGrp[neckIndex].Matrix.OffsetY),
            Math.Abs(ImportedTmcData.MtxGrp[dataNeckIndex].Matrix.OffsetZ - TmcData.MtxGrp[neckIndex].Matrix.OffsetZ)
        };
        if (offset[0] > allowable || offset[1] > allowable || offset[2] > allowable
        )
        {
          ResettedMatrixNodes.Add(ImportedTmcData.Node[dataNeckIndex].Name);
        }
      }
    }

    /// <summary>
    ///  GlblMtxとBnOfsMtxを再計算
    /// </summary>
    private void RecalcMatrix()
    {
      foreach (var nodeName in ResettedMatrixNodes)
      {
        int index = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == nodeName);
        if (index == -1) continue;

        var node = Tables.Nodes[index];
        int nodeIndex = node.AddedIndex;

        RecalcMatrix(Tables.Nodes[index]);
      }
    }

    /// <summary>
    /// Matrixを再計算
    /// </summary>
    /// <param name="parent">親のノードデータ</param>
    private void RecalcMatrix(NodeData parent)
    {
      foreach (var nodeName in parent.Children)
      {
        int index = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == nodeName);
        if (index == -1) continue;

        var node = Tables.Nodes[index];
        int nodeIndex = node.AddedIndex;
        TmcData.MtxGrp[nodeIndex].Matrix = TmcData.Hie[nodeIndex].Matrix * TmcData.MtxGrp[parent.AddedIndex].Matrix;
        var matrix = new Matrix3D();
        matrix.Append(TmcData.MtxGrp[nodeIndex].Matrix);
        matrix.Invert();
        TmcData.BnOfsMtxGrp[nodeIndex].Matrix = matrix;
        node.IsResetMatrix = true;

        RecalcMatrix(node);
      }
    }

    /// <summary>
    /// 追加したノードの親に子として追加
    /// </summary>
    private void AddAsChild()
    {
      foreach (var pair in AddedNodes)
      {
        int originalNodeIndex = Array.FindIndex(ImportedTmcData.Node.ToArray(), elem => elem.Name == pair.Key);

        if (ImportedTmcData.Hie[originalNodeIndex].Parent != -1)
        {
          int parent = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.OriginalIndex == ImportedTmcData.Hie[originalNodeIndex].Parent && elem.DataIndex == DataIndex);
          if (parent == -1)
          {
            parent = Array.FindIndex(Tables.Nodes.ToArray(), elem => elem.Name == ImportedTmcData.Node[ImportedTmcData.Hie[originalNodeIndex].Parent].Name);
            if (parent != -1 && !Tables.Nodes[parent].Children.Contains(pair.Value))
              Tables.Nodes[parent].Children.Add(pair.Value);
          }
        }
      }
    }

    /// <summary>
    /// PhysicsIndicesをソート
    /// </summary>
    private void SortPhysicsIndices()
    {
      for (int i = 0; i < Tables.PhysicsIndicesSet.Count; i++)
      {
        Tables.PhysicsIndicesSet[i] = Tables.PhysicsIndicesSet[i].OrderBy(elem => elem.Name.ToLower(), StringComparer.Ordinal).ToList();
      }
    }

    /// <summary>
    /// テクスチャバイナリデータ追加
    /// </summary>
    private void AddTextures()
    {
      foreach (int id in AdditionalTexSet)
      {
        var newTex = new Textures();

        newTex.ID = CurTexCount + AdditionalTexSet.ToList().IndexOf(id);
        newTex.InL = true;

        var tex = ImportedTmcData.Tex[id];
        if (tex.InL)
          newTex.Data = BinL.Skip(LOffset + tex.Offset).Take(tex.Size).ToArray();
        else
          newTex.Data = Bin.Skip(ImportedTmcData.H.Offsets[1] + tex.Offset).Take(tex.Size).ToArray();

        TmcData.Tex.Add(newTex);
        Data.SelectTextureWindow.Data.Add(newTex);
        Tables.Textures.Add(newTex.ID);
      }
    }

    /// <summary>
    /// 元にmatecpが無かった場合は再設定
    /// </summary>
    private void setMateCp()
    {
      foreach (var objData in Tables.ObjData)
      {
        if (objData.Grp != -1 && objData.Matecp == null)
        {
          objData.Matecp = TmcData.MateCp.Count;
        }
      }
    }


    /// <summary>
    /// ノード名をチェックしてBool値を返す
    /// </summary>
    /// <param name="curName">既存のノード名</param>
    /// <param name="charCode">文字コード</param>
    /// <returns>ノード名が既にあるかどうか</returns>
    private bool PreCheckNodeNameExist(string curName, int charCode)
    {
      bool parsableNum = true;
      int num = 0;
      int numLength = 0;
      do
      {
        numLength++;
        parsableNum = Int32.TryParse(curName.Substring(curName.Length - numLength), out num);
      } while (parsableNum);
      numLength--;

      int countUp = 1;
      if (numLength > 0)
      {
        num = Int32.Parse(curName.Substring(curName.Length - numLength));
      }
      else
      {
        countUp++;
      }

      string name;
      if (numLength == 0)
      {
        name = curName + "_" + Convert.ToChar(charCode);
      }
      else
      {
        name = curName.Substring(0, curName.Length - numLength) + "_" + Convert.ToChar(charCode) + num.ToString("D");
      }
      int idx = Array.FindIndex(Tables.Nodes.ToArray(), node => node.Name == name);

      return idx != -1;
    }

    /// <summary>
    /// ノード名をチェックして重複しないノード名を返す
    /// </summary>
    /// <param name="curName">既存のノード名</param>
    /// <param name="charCode">文字コード</param>
    /// <returns>重複しないノード名</returns>
    private string CheckNodeNameExist(string curName, int charCode)
    {
      if (Array.FindIndex(Tables.Nodes.ToArray(), node => node.Name == curName) == -1)
      {
        return curName;
      }

      bool parsableNum = true;
      int num = 0;
      int numLength = 0;
      do
      {
        numLength++;
        parsableNum = Int32.TryParse(curName.Substring(curName.Length - numLength), out num);
      } while (parsableNum);
      numLength--;

      int countUp = 1;
      if (numLength > 0)
      {
        num = Int32.Parse(curName.Substring(curName.Length - numLength));
      }
      else
      {
        countUp++;
      }

      string name = "";

      if (charCode != -1)
      {
        if (numLength == 0)
        {
          name = curName + "_" + Convert.ToChar(charCode);
        }
        else
        {
          name = curName.Substring(0, curName.Length - numLength) + "_" + Convert.ToChar(charCode) + num.ToString("D");
        }
      }
      else
      {
        int idx = -1;
        do
        {
          name = curName.Substring(0, curName.Length - numLength) + (num + countUp).ToString("D" + numLength);
          idx = Array.FindIndex(Tables.Nodes.ToArray(), node => node.Name == name);
          countUp++;
        } while (idx != -1);
      }

      return name;
    }



    #region プロパティ

    /// <summary>
    /// メインウィンドウオブジェクト
    /// </summary>
    public MainWindow Window { get; set; }

    /// <summary>
    /// 言語テキストデータ
    /// </summary>
    private Lang.Text Txt;

    /// <summary>
    /// MainWindowViewModel
    /// </summary>
    public MainWindowViewModel Data { get; set; }

    /// <summary>
    /// TMCデータ
    /// </summary>
    private TmcData TmcData { get; set; }

    /// <summary>
    /// インポートしたTMCデータ
    /// </summary>
    public TmcData ImportedTmcData { get; set; }

    /// <summary>
    /// 表のデータ
    /// </summary>
    private DataTables Tables;

    /// <summary>
    /// インポートした表のデータ
    /// </summary>
    public DataTables ImportedTables;

    /// <summary>
    /// インポートしたTMCのバイナリ
    /// </summary>
    private byte[] Bin;

    /// <summary>
    /// インポートしたTMCLのバイナリ
    /// </summary>
    private byte[] BinL;



    /// <summary>
    /// 
    /// </summary>
    private List<int> ObjGrpIndices;

    /// <summary>
    /// 
    /// </summary>
    private HashSet<int> AdditionalTexSet;

    /// <summary>
    /// 
    /// </summary>
    private Dictionary<string, string> AddedNodes;

    /// <summary>
    /// 
    /// </summary>
    private HashSet<PhysicsData> AdditionalBoneGrpList;

    /// <summary>
    /// 
    /// </summary>
    private Dictionary<int, int> AdditionalChar;

    /// <summary>
    /// 
    /// </summary>
    private SortedSet<int> AdditionalOtherNodes;

    /// <summary>
    /// 
    /// </summary>
    private SortedSet<int> AdditionalNodes;

    /// <summary>
    /// 
    /// </summary>
    private SortedSet<string> ResettedMatrixNodes;

    /// <summary>
    /// 
    /// </summary>
    private int DataIndex;

    /// <summary>
    /// 
    /// </summary>
    private int CurTexCount;



    /// <summary>
    /// 
    /// </summary>
    private int LOffset;

    /// <summary>
    /// 
    /// </summary>
    private int CurNode;

    /// <summary>
    /// 
    /// </summary>
    private string NewName;

    /// <summary>
    /// 
    /// </summary>
    private bool IsAddNode;

    /// <summary>
    /// 
    /// </summary>
    private int AddedIndex;

    /// <summary>
    /// 
    /// </summary>
    private bool IsResetMatrix;

    #endregion
  }
}
