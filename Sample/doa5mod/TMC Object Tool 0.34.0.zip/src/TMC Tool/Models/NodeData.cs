﻿using System;
using System.Collections.Generic;
using Tmc;

namespace TMC_Tool.Models
{
  public class NodeData
  {
    public NodeData(Nodes node)
    {
      Children = new List<string>();
      Blends = new List<string>();

      OriginalIndex = node.Index;
      AddedIndex = node.Index;
      Name = node.Name;
      Master = "";
      ObjIndex = node.ObjIndex;
      IsAdded = false;
      DataIndex = -1;
    }

    public int OriginalIndex { get; set; }
    public int AddedIndex { get; set; }
    public string Name { get; set; }
    public string Master { get; set; }
    public int ObjIndex { get; set; }
    public int BoneLevel { get; set; }
    public List<string> Children { get; set; }
    public List<string> Blends { get; set; }
    public int DataIndex { get; set; }
    public bool IsAdded { get; set; }
    public bool IsBlendCleared { get; set; }
    public bool IsResetMatrix { get; set; }
  }
}
