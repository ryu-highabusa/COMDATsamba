﻿using System;
using System.Collections.Generic;
using System.Linq;
using SystemHalf;
using Tmc;
using TMC_Tool.ViewModels;
using Language;

namespace TMC_Tool.Models
{
  public class TransformUVs
  {
    public TransformUVs(MainWindowViewModel data)
    {
      txt = MainWindow.txt;
      mainWindow = data.mainWindow;
      Bin = data.Bin;
      TmcData = data.TmcData;
      Vertices = data.Vertices.Distinct().Where(e => e.IsChecked == true).ToList();

      TargetUVs = new List<int>();
      if (data.TargetUV1 && data.IsEnableTargetUV1) TargetUVs.Add(0);
      if (data.TargetUV2 && data.IsEnableTargetUV2) TargetUVs.Add(1);
      if (data.TargetUV3 && data.IsEnableTargetUV3) TargetUVs.Add(2);
      if (data.TargetUV4 && data.IsEnableTargetUV4) TargetUVs.Add(3);

      if (data.UV1 == 0 && data.UV2 == 1 && data.UV3 == 2 && data.UV4 == 3)
        UVs = null;
      else
        UVs = new int[] { data.UV1, data.UV2, data.UV3, data.UV4 };

      SelectionExpand = data.SelectionExpand;
      ScaleU = (Half)data.ScaleU;
      ScaleV = (Half)data.ScaleV;
      MoveU = (Half)data.MoveU;
      MoveV = (Half)data.MoveV;

      Invert = data.Invert;
      InvertAxis = (Half)data.InvertAxis;
      CenterFudge = Math.Abs(data.CenterFudge);
      InvertTangent = data.InvertTangent;
      X0AroundCenter = data.X0AroundCenter;

      ErrorMessage = "";
    }


    #region プロパティ

    /// <summary>
    /// エラーメッセージ
    /// </summary>
    public string ErrorMessage { get; set; }

    /// <summary>
    /// TMCの出力バイナリ
    /// </summary>
    public List<byte> ExBin { get; set; }


    /// <summary>
    /// メインウィンドウオブジェクト
    /// </summary>
    private MainWindow mainWindow { get; set; }

    /// <summary>
    /// 言語テキストデータ
    /// </summary>
    private Lang.Text txt;

    /// <summary>
    /// TMCのバイナリ
    /// </summary>
    private byte[] Bin { get; set; }


    /// <summary>
    /// TMCデータ
    /// </summary>
    private TmcData TmcData { get; set; }

    /// <summary>
    /// 表のメッシュデータ
    /// </summary>
    private List<VertexItem> Vertices { get; set; }

    /// <summary>
    /// ポリゴンパーツ
    /// </summary>
    private List<PolygonPart> PolygonParts { get; set; }

    /// <summary>
    /// 各パートのバイナリリスト
    /// </summary>
    private List<List<byte>> PartBins { get; set; }

    /// <summary>
    /// VtxLayのバイナリリスト
    /// </summary>
    private List<List<byte>> VtxBins { get; set; }

    /// <summary>
    /// IdxLayのバイナリリスト
    /// </summary>
    private List<List<byte>> IdxBins { get; set; }


    /// <summary>
    /// UV座標変更対象の頂点リスト
    /// </summary>
    private List<int> TargetVertices { get; set; }


    /// <summary>
    /// 選択範囲を接続面に拡張
    /// </summary>
    private bool SelectionExpand { get; set; }

    /// <summary>
    /// 変更対象のUVマップ配列
    /// </summary>
    private List<int> TargetUVs { get; set; }

    /// <summary>
    /// UVマップ割り当て配列
    /// </summary>
    private int[] UVs { get; set; }

    /// <summary>
    /// 拡大U方向
    /// </summary>
    private Half ScaleU { get; set; }

    /// <summary>
    /// 拡大V方向
    /// </summary>
    private Half ScaleV { get; set; }

    /// <summary>
    /// 移動U方向
    /// </summary>
    private Half MoveU { get; set; }

    /// <summary>
    /// 移動V方向
    /// </summary>
    private Half MoveV { get; set; }

    /// <summary>
    /// 右半分の頂点のUVを左右反転する
    /// </summary>
    private bool Invert { get; set; }

    /// <summary>
    /// 反転軸座標
    /// </summary>
    private Half InvertAxis { get; set; }

    /// <summary>
    /// 中心頂点誤差
    /// </summary>
    private float CenterFudge { get; set; }

    /// <summary>
    /// ノーマルマップの効果を反転する
    /// </summary>
    private bool InvertTangent { get; set; }

    /// <summary>
    /// X=0の頂点のUVを反転軸座標に揃える
    /// </summary>
    private bool X0AroundCenter { get; set; }


    /// <summary>
    /// 頂点グループのバイナリデータ配列
    /// </summary>
    private byte[] VtxBinArray { get; set; }

    /// <summary>
    /// 頂点のTangentデータオフセット
    /// </summary>
    private int OffsetTangent { get; set; }

    /// <summary>
    /// 頂点のUVデータオフセット
    /// </summary>
    private int OffsetUV { get; set; }

    /// <summary>
    /// 頂点のデータサイズ
    /// </summary>
    private int DataSize { get; set; }

    #endregion



    /// <summary>
    /// 削除を実行します（TMC）
    /// </summary>
    public void Do()
    {
      Init();


      if (Vertices.Count == 0)
      {
        ErrorMessage = "NoTarget";
        return;
      }


      foreach (var objGrp in TmcData.ObjGrp)
      {

        for (int i = 0; i < objGrp.Decl.Count; i++)
        {
          var decl = objGrp.Decl[i];


          if (TmcData.VtxGrp[decl.VtxGrpIndex].UVCount == 0) continue;


          var declVertices = Vertices.Where(e => e.VtxGrp == decl.VtxGrpIndex && e.Grp == objGrp.ID).OrderBy(e => e.Obj).ThenBy(e => e.Index).ToList();

          if (declVertices.Count == 0) continue;


          VtxBinArray = VtxBins[decl.VtxGrpIndex].ToArray();

          OffsetTangent = TmcData.VtxGrp[decl.VtxGrpIndex].TangentOffset;
          OffsetUV = TmcData.VtxGrp[decl.VtxGrpIndex].TexCoordOffsets.Min();
          DataSize = TmcData.VtxGrp[decl.VtxGrpIndex].DataSize;

          foreach (var obj in objGrp.Obj)
          {
            var vertices = declVertices.Where(e => e.Obj == obj.ID).Select(e => e.Index).ToList();

            if (vertices.Count == 0) continue;


            // 削除頂点アイテム群からDeclベースのインデックスに変換したリストを作成
            TargetVertices = new List<int>();

            foreach (var index in vertices)
            {
              TargetVertices.Add(obj.VtxStartIndex + index);
            }


            // 対象頂点を追加
            PrepareTargetVertices(obj, decl.IdxGrpIndex);


            // UV座標を変形
            Transform(obj);
          }


          VtxBins[decl.VtxGrpIndex] = VtxBinArray.ToList();
        }
      }


      // バイナリ構築
      BuildTmcBin();
    }

    /// <summary>
    /// 削除を実行します（tmcmesh）
    /// </summary>
    public void DoTmcmesh()
    {
      Init();


      TargetVertices = Vertices.Where(e => e.VtxGrp == 0 && e.Grp == 0 && e.Obj == 0).OrderBy(e => e.Index).Select(e => e.Index).ToList();

      if (TargetVertices.Count == 0)
      {
        ErrorMessage = "NoTarget";
        return;
      }


      VtxBinArray = VtxBins[0].ToArray();

      OffsetTangent = TmcData.VtxGrp[0].TangentOffset;
      OffsetUV = TmcData.VtxGrp[0].TexCoordOffsets.Min();
      DataSize = TmcData.VtxGrp[0].DataSize;

      var obj = TmcData.ObjGrp[0].Obj[0];


      // 対象頂点を追加
      PrepareTargetVertices(obj, 0);


      // UV座標を変形
      Transform(obj);


      PartBins[2] = VtxBinArray.ToList();


      // バイナリ構築
      BuildTmcmeshBin();
    }


    /// <summary>
    /// プロパティを初期化します
    /// </summary>
    private void Init()
    {
      // 各部バイナリ
      //  0 MdlGeo
      //  1 TTX
      //  2 VtxLay
      //  3 IdxLay
      //  4 MtrCol
      //  5 MdlInfo
      //  6 HieLay
      //  7 LHeader
      //  8 NodeLay
      //  9 GlblMtx
      // 10 BnOfsMtx
      // 11 cpf
      // 12 MCAPACK
      // 13 RENPACK
      // 14 GEOXTRAS
      // 15 
      // 16 ACSCLS

      PartBins = new List<List<byte>>();

      int lastOffset = TmcData.H.Size;
      for (int i = TmcData.H.Count1 - 1; i >= 0; i--)
      {
        var partBin = new List<byte>();

        if (TmcData.H.Offsets[i] != 0)
        {
          partBin.AddRange(Bin.Skip(TmcData.H.Offsets[i]).Take(lastOffset - TmcData.H.Offsets[i]));
          lastOffset = TmcData.H.Offsets[i];
        }

        PartBins.Insert(0, partBin);
      }


      // for broken TMC
      if (TmcData.H.Count1 > 14 && TmcData.H.Offsets[14] != 0 && BitConverter.ToUInt32(Bin, TmcData.H.Offsets[14] + 8) != 0x01010000 && PartBins[14].Count > 0x40)
      {
        PartBins[14] = new List<byte>(new byte[0x40]);
      }


      // VtxとIdxのバイナリパートデータをセット
      List<byte> VtxPartBin = PartBins[2];


      // Vtxバイナリ
      VtxBins = new List<List<byte>>();
      foreach (var grp in TmcData.VtxGrp)
      {
        List<byte> bin = new List<byte>();
        bin = VtxPartBin.Skip(grp.Offset).Take(grp.Size).ToList();
        VtxBins.Add(bin);
      }


      ExBin = new List<byte>();
    }

    /// <summary>
    /// 削除する頂点リストを準備します
    /// </summary>
    /// <param name="obj">オブジェクトデータ</param>
    /// <param name="idxGrpIndex">Idxグループインデックス</param>
    private void PrepareTargetVertices(ObjectPart obj, int idxGrpIndex)
    {
      if (SelectionExpand) // 接続面の頂点へ対象を拡大
      {
        // ポリゴンパーツを取得
        PolygonParts = IdxUtils.GetPolygonPartsTriangleStrip(TmcData, obj, idxGrpIndex);

        // 接続面の頂点へ対象を拡大して対象頂点リストに追加
        TargetVertices = GetTargetVertices(new HashSet<int>(TargetVertices));
      }
    }

    /// <summary>
    /// 接続面の頂点を取得します
    /// </summary>
    /// <param name="targetVertices">対象頂点ハッシュリスト</param>
    private List<int> GetTargetVertices(HashSet<int> targetVertices)
    {
      // 接続面の頂点を削除頂点リストへ追加
      int count;
      List<PolygonPart> tempPolygonParts = new List<PolygonPart>(PolygonParts);
      do
      {
        count = targetVertices.Count;

        foreach (var part in tempPolygonParts.ToList())
        {
          if (part.Selected) continue;

          foreach (var idx in part.Indices)
          {
            if (!targetVertices.Contains(idx)) continue;

            for (int i = 0; i < part.Indices.Count; i++)
            {
              targetVertices.Add(part.Indices[i]);
            }
            part.Selected = true;
            tempPolygonParts.Remove(part);
            break;
          }
        }
      } while (tempPolygonParts.Count > 0 && count < targetVertices.Count);


      return targetVertices.ToList();
    }


    /// <summary>
    /// UV座標を変形します
    /// </summary>
    /// <param name="obj">オブジェクトデータ</param>
    private void Transform(ObjectPart obj)
    {
      // 範囲外のインデックスの頂点を無視するためにオブジェクトの頂点インデックス範囲を処理
      for (int i = obj.VtxStartIndex; i < obj.VtxStartIndex + obj.VtxCount; i++)
      {
        if (!TargetVertices.Contains(i)) continue;

        TransformInVtx(obj, i);
      }
    }

    /// <summary>
    /// 頂点のUV座標を変形します
    /// </summary>
    /// <param name="obj">オブジェクトデータ</param>
    /// <param name="vtxIndex">頂点インデックス</param>
    private void TransformInVtx(ObjectPart obj, int vtxIndex)
    {
      var v = TmcData.VtxGrp[obj.VtxGrpIndex].Vtx[vtxIndex];

      int offset = DataSize * vtxIndex;

      List<byte[]> UBins = new List<byte[]>();
      List<byte[]> VBins = new List<byte[]>();
      foreach (var uv in TargetUVs)
      {
        UBins.Add(new byte[2]);
        VBins.Add(new byte[2]);
      }

      if (Invert && (v.X < -CenterFudge || Math.Abs(v.X) <= CenterFudge))
      {
        for (int i = 0; i < TargetUVs.Count; i++)
        {
          if (TargetUVs[i] == v.UV.Count) break;

          if (X0AroundCenter && Math.Abs(v.X) <= CenterFudge)
          {
            UBins[i] = Half.GetBytes(InvertAxis);
          }
          else if (!(Math.Abs(v.X) <= CenterFudge && CheckRightSided(obj, vtxIndex, CenterFudge)))
          {
            UBins[i] = Half.GetBytes((InvertAxis * 2) - ((Half.ToHalf(v.UV[TargetUVs[i]].U, 0) * ScaleU) + MoveU));
          }
          else
          {
            UBins[i] = Half.GetBytes((Half.ToHalf(v.UV[TargetUVs[i]].U, 0) * ScaleU) + MoveU);
          }
        }

        if (InvertTangent && OffsetTangent != 0 && v.T4 == -1)
        {
          Array.Copy(BitConverter.GetBytes(v.T1 * -1), 0, VtxBinArray, offset + OffsetTangent, 4);
          Array.Copy(BitConverter.GetBytes(v.T2 * -1), 0, VtxBinArray, offset + OffsetTangent + 0x04, 4);
          Array.Copy(BitConverter.GetBytes(v.T3 * -1), 0, VtxBinArray, offset + OffsetTangent + 0x08, 4);
          Array.Copy(BitConverter.GetBytes((float)1), 0, VtxBinArray, offset + OffsetTangent + 0x0C, 4);
        }
      }
      else
      {
        for (int i = 0; i < TargetUVs.Count; i++)
        {
          if (TargetUVs[i] == v.UV.Count) break;

          UBins[i] = Half.GetBytes((Half.ToHalf(v.UV[TargetUVs[i]].U, 0) * ScaleU) + MoveU);
        }
      }

      for (int i = 0; i < TargetUVs.Count; i++)
      {
        if (TargetUVs[i] == v.UV.Count) break;

        VBins[i] = Half.GetBytes((Half.ToHalf(v.UV[TargetUVs[i]].V, 0) * ScaleV) + MoveV);
      }

      for (int i = 0; i < TargetUVs.Count; i++)
      {
        if (TargetUVs[i] == v.UV.Count) break;

        Array.Copy(UBins[i], 0, VtxBinArray, offset + OffsetUV + (4 * TargetUVs[i]), 2);
        Array.Copy(VBins[i], 0, VtxBinArray, offset + OffsetUV + 2 + (4 * TargetUVs[i]), 2);
      }

      if (UVs != null) TransferUV(v, offset);
    }

    /// <summary>
    /// 右側の対称頂点が存在するかを確認します
    /// </summary>
    /// <param name="obj">オブジェクトデータ</param>
    /// <param name="vtxIndex">頂点インデックス</param>
    /// <param name="fudge">誤差</param>
    private bool CheckRightSided(ObjectPart obj, int vtxIndex, float fudge)
    {
      var vtx = TmcData.VtxGrp[obj.VtxGrpIndex].Vtx;
      var idx = TmcData.IdxGrp[obj.IdxGrpIndex].Idx;

      for (int i = obj.IdxStartIndex; i < obj.IdxStartIndex + obj.IdxCount; i++)
      {
        if (idx[i] == vtxIndex)
        {
          for (int j = 0; j < idx.Length - 1 - i; j++)
          {
            if ((i > 0 && i < idx.Length - 2 && idx[i] == idx[i - 1] && idx[i + 1] == idx[i + 2]) ||
              (idx[i + j] == idx[i + j + 1] && !(j == 0 && i > 2 && idx[i - 1] == idx[i - 2])))
            {
              break;
            }
            else if (vtx[idx[i + j + 1]].X > fudge)
            {
              return true;
            }
          }

          for (int j = 0; j < i; j++)
          {
            if (i - j > 2 && idx[i - j - 1] == idx[i - j - 2])
            {
              break;
            }
            else if (vtx[idx[i - j - 1]].X > fudge)
            {
              return true;
            }
          }
        }
      }
      return false;
    }

    /// <summary>
    /// UV座標を転写します
    /// </summary>
    /// <param name="v">頂点データ</param>
    /// <param name="offset">頂点へのオフセット</param>
    private void TransferUV(Vertex v, int offset)
    {
      var curUVs = new List<byte[]>();

      for (int i = 0; i < v.UV.Count; i++)
      {
        byte[] curUV = new byte[4];
        Array.Copy(VtxBinArray, offset + OffsetUV + (4 * i), curUV, 0, 4);
        curUVs.Add(curUV);
      }

      for (int i = 0; i < v.UV.Count; i++)
      {
        if (UVs[i] == i || UVs[i] >= v.UV.Count) continue;

        Array.Copy(curUVs[UVs[i]], 0, VtxBinArray, offset + OffsetUV + (4 * i), 4);
      }
    }


    /// <summary>
    /// TMCのバイナリを構築します
    /// </summary>
    private void BuildTmcBin()
    {
      // VtxLayバイナリパート再構築
      PartBins[2] = TmcUtils.BuildHeaderBaseBin("VtxLay");
      TmcUtils.BuildBin(PartBins[2], VtxBins, null, true, false);


      ExBin.AddRange(Bin.Take(TmcData.H.Offset1));

      TmcUtils.BuildBin(ExBin, PartBins, null, false, true);
    }

    /// <summary>
    /// tmcmeshのバイナリを構築します
    /// </summary>
    private void BuildTmcmeshBin()
    {
      ExBin.AddRange(Bin.Take(TmcData.H.Offset1));

      TmcUtils.BuildBin(ExBin, PartBins, null, true, true);
    }

  }
}
