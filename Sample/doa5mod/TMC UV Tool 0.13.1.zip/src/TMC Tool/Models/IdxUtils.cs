﻿using System;
using System.Collections.Generic;
using System.Linq;
using Tmc;

namespace TMC_Tool.Models
{
  public class IdxUtils
  {
    /// <summary>
    /// ポリゴンパーツを取得します（TriangleStrip）
    /// </summary>
    /// <param name="tmcData">TMCデータ</param>
    /// <param name="obj">オブジェクトデータ</param>
    /// <param name="idxGrpIndex">Idxグループインデックス</param>
    public static List<PolygonPart> GetPolygonPartsTriangleStrip(TmcData tmcData, ObjectPart obj, int idxGrpIndex)
    {
      var indices = tmcData.IdxGrp[idxGrpIndex].Idx;


      // ポリゴンパーツへ分解

      var polygonParts = new List<PolygonPart>();

      PolygonPart polygonPart = new PolygonPart();
      polygonPart.ObjectIndex = obj.ID;
      polygonPart.StartIndex = obj.IdxStartIndex;
      polygonPart.Indices.Add(indices[obj.IdxStartIndex]);

      bool partEndFlag = false;

      for (int i = obj.IdxStartIndex + 1; i < obj.IdxStartIndex + obj.IdxCount; i++)
      {
        int index = polygonPart.Indices.Count - 1;

        if (partEndFlag)
        {
          polygonParts.Add(polygonPart);

          partEndFlag = false;
          polygonPart = new PolygonPart();
          polygonPart.ObjectIndex = obj.ID;
          polygonPart.StartIndex = i;

          polygonPart.Indices.Add(indices[i]);

          if (i < indices.Length - 1)
          {
            polygonPart.Indices.Add(indices[i + 1]);
            i++;
          }

          continue;
        }
        else if (indices[i] == polygonPart.Indices[index])
        {
          // 余分なデータを除去
          if (index > 2 && indices[i] == polygonPart.Indices[index - 1] && indices[i] == polygonPart.Indices[index - 2])
          {
            polygonPart.Indices.RemoveAt(index);
            polygonPart.Indices.RemoveAt(index - 1);
          }

          // パートの終了判定
          if (i < obj.IdxStartIndex + obj.IdxCount - 2 && indices[i] != indices[i + 1] && indices[i + 1] == indices[i + 2])
          {
            partEndFlag = true;
          }
        }

        polygonPart.Indices.Add(indices[i]);
      }

      // 最後を追加
      polygonParts.Add(polygonPart);


      return polygonParts;
    }
  }
}
