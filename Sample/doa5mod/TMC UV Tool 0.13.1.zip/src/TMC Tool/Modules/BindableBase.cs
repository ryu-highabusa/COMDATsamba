﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Common
{
  /// <summary>
  /// ViewModelの基本クラス。INotifyPropertyChangedの実装を提供します。
  /// </summary>
  public abstract class BindableBase : INotifyPropertyChanged
  {
    /// <summary>
    /// プロパティの変更があったときに発行されます。
    /// </summary>
    public event PropertyChangedEventHandler PropertyChanged;

    /// <summary>
    /// PropertyChangedイベントを発行します。
    /// </summary>
    /// <param name="propertyName">プロパティ名</param>
    protected void OnPropertyChanged(string propertyName)
      => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));

    protected void SetProperty<T>(ref T storage, T value, [CallerMemberName] string propertyName = null)
    {
      if (object.Equals(storage, value))
        return;
      storage = value;
      OnPropertyChanged(propertyName);
    }
  }
}
