﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;

namespace Language
{
  public class Lang
  {
    public Lang(TMC_Tool.MainWindow window)
    {
      Txt = new Text();

      Type = "Jpn";

      FilePath = AppDomain.CurrentDomain.BaseDirectory + @"\Language.dat";
      if (!File.Exists(FilePath))
      {
        return;
      }

      ChangeTxt(window);
    }


    public class Text
    {
      // Can not use 'Item'.

      public string btnOpen { get; set; } = "開く";
      public string OK { get; set; } = "OK";
      public string Cancel { get; set; } = "キャンセル";
      public string Yes { get; set; } = "はい";
      public string No { get; set; } = "いいえ";
      public string Info { get; set; } = "情報";
      public string Error { get; set; } = "エラー";
      public string Caution { get; set; } = "注意";
      public string Confirm { get; set; } = "確認";
      public string Message { get; set; } = "メッセージ";
      public string textStatus { get; set; } = "ファイルを開いて下さい";
      public string ExitWithoutSave { get; set; } = "変更後保存されていません。このまま終了しますか？";
      public string Exit { get; set; } = "終了する";
      public string Overwrite { get; set; } = "ファイルを上書きしますか？";
      public string OverwriteYes { get; set; } = "上書きする";
      public string Saved { get; set; } = "保存しました";
      public string FailedToCreateBackup { get; set; } = "バックアップの作成に失敗したため保存出来ませんでした";
      public string UnsupportedFile { get; set; } = "対応しているファイルではありません";
      public string FailedToReopen { get; set; } = "再読込に失敗しました";
      public string ConfirmOpenFile { get; set; } = "このファイルを開きますか？";
      public string ConfirmFileUpdated { get; set; } = "下記ファイルが更新されました。開きなおしますか？";

      public string ErrorNotChecked { get; set; } = "チェックが入ったデータがありません。リストのデータにチェックを入れて下さい。";
      public string ErrorNotSavedBecauseNotChanged { get; set; } = "変更するデータが無いため保存されませんでした。";

      public string VertexAdded { get; set; } = "個の頂点を追加しました。";
      public string NothingAdded { get; set; } = "該当頂点はありませんでした。";

      public string objSelDescription { get; set; } = "チェックしたオブジェクトの現在入力されている\r\n座標範囲にある頂点を追加します";
      public string dgcObjName { get; set; } = "オブジェクト名";

      public string WaveDash { get; set; } = "～";
      public string Objects { get; set; } = "オブジェクト";
      public string Vertices { get; set; } = "頂点";
      public string Address { get; set; } = "アドレス";
      public string Group { get; set; } = "グループ";
      public string AddressHalf { get; set; } = "ｱﾄﾞﾚｽ";
      public string IndexHalf { get; set; } = "ｲﾝﾃﾞｯｸｽ";
      public string GroupHalf { get; set; } = "ｸﾞﾙｰﾌﾟ";
      public string UVCount { get; set; } = "UV数";
      public string VertexDataSize { get; set; } = "頂点データサイズ";
      public string Count { get; set; } = "個数";
      public string VertexGroups { get; set; } = "頂点グループ";
      public string IdxGroups { get; set; } = "Idxグループ";

      public string InfoFisrtData { get; set; } = "最初の{0}個のデータ";
      public string InfoTotalVertexCount { get; set; } = "合計{0}個の頂点があります";
      public string InfoDifferentVertexCount { get; set; } = "オブジェクト情報の頂点数と頂点情報から算出した頂点数に違いがあります ( オブジェクト情報 : {0} / 頂点情報 : {1} )";
    }

    private void ChangeTxt(TMC_Tool.MainWindow window)
    {
      Dictionary<string, string> altTxt = SetAltTxt();

      if (altTxt.Count == 0) return;


      if (altTxt.ContainsKey("btnOpen")) window.btnOpen.Content = altTxt["btnOpen"];
      if (altTxt.ContainsKey("btnSave"))
      {
        window.btnSave.Content = altTxt["btnSave"];
        window.cmdSave.Header = altTxt["btnSave"];
      }
      if (altTxt.ContainsKey("SaveWithBackup")) window.cmdSaveWithBackup.Header = altTxt["SaveWithBackup"];
      if (altTxt.ContainsKey("btnSaveAs")) window.btnSaveAs.Content = altTxt["btnSaveAs"];
      if (altTxt.ContainsKey("btnReload")) window.btnReload.Content = altTxt["btnReload"];
      if (altTxt.ContainsKey("cbKeepData")) window.cbKeepData.Content = altTxt["cbKeepData"];
      if (altTxt.ContainsKey("dgcName")) window.dgcName.Header = altTxt["dgcName"];
      if (altTxt.ContainsKey("dgcTarget")) window.dgcTarget.Header = altTxt["dgcTarget"];
      if (altTxt.ContainsKey("btnAdd")) window.btnAddRow.Content = altTxt["btnAdd"];
      if (altTxt.ContainsKey("btnAdd")) window.menuAdd.Header = altTxt["btnAdd"];
      if (altTxt.ContainsKey("menuAddMulti")) window.menuAddMulti.Header = altTxt["menuAddMulti"];
      if (altTxt.ContainsKey("rbAddIndex")) window.rbAddIndex.Content = altTxt["rbAddIndex"];
      if (altTxt.ContainsKey("rbAddRange")) window.rbAddRange.Content = altTxt["rbAddRange"];
      if (altTxt.ContainsKey("rbAddRangeUV")) window.rbAddRangeUV.Content = altTxt["rbAddRangeUV"];
      if (altTxt.ContainsKey("btnResetRange"))
      {
        window.btnResetRange.Content = altTxt["btnResetRange"];
        window.btnResetRangeUV.Content = altTxt["btnResetRange"];
      }
      if (altTxt.ContainsKey("cbSlantY")) window.cbSlantY.Content = altTxt["cbSlantY"];
      if (altTxt.ContainsKey("cbXMirror")) window.cbXMirror.Content = altTxt["cbXMirror"];
      if (altTxt.ContainsKey("labelRangeUVTarget")) window.labelRangeUVTarget.Content = altTxt["labelRangeUVTarget"];
      if (altTxt.ContainsKey("btnSaveRows")) window.btnSaveRows.Content = altTxt["btnSaveRows"];
      if (altTxt.ContainsKey("btnOpenRows")) window.btnOpenRows.Content = altTxt["btnOpenRows"];
      if (altTxt.ContainsKey("btnDeleteRow")) window.btnDeleteRow.Content = altTxt["btnDeleteRow"];
      if (altTxt.ContainsKey("btnClearRow")) window.btnClearRow.Content = altTxt["btnClearRow"];
      if (altTxt.ContainsKey("cbSelectionExpand")) window.cbSelectionExpand.Content = altTxt["cbSelectionExpand"];
      if (altTxt.ContainsKey("labelScale")) window.labelScale.Content = altTxt["labelScale"];
      if (altTxt.ContainsKey("labelMove")) window.labelMove.Content = altTxt["labelMove"];
      if (altTxt.ContainsKey("cbInvert")) window.cbInvert.Content = altTxt["cbInvert"];
      if (altTxt.ContainsKey("labelInvertAxis")) window.labelInvertAxis.Content = altTxt["labelInvertAxis"];
      if (altTxt.ContainsKey("labelCenterFudge")) window.labelCenterFudge.Content = altTxt["labelCenterFudge"];
      if (altTxt.ContainsKey("cbInvertTangent")) window.cbInvertTangent.Content = altTxt["cbInvertTangent"];
      if (altTxt.ContainsKey("cbX0AroundCenter")) window.cbX0AroundCenter.Content = altTxt["cbX0AroundCenter"];
    }

    private Dictionary<string, string> SetAltTxt()
    {
      Dictionary<string, string> altTxt = new Dictionary<string, string>();

      using (var sr = new StreamReader(FilePath))
      {
        while (!sr.EndOfStream)
        {
          string[] inLine = sr.ReadLine().Split('\t');
          if (inLine.Length == 0)
          {
            continue;
          }
          else if (inLine[0] == "Type")
          {
            Type = inLine[2].Trim();
          }
          else if (inLine[0] == Type)
          {
            altTxt[inLine[1].Trim()] = inLine[2].Trim();
          }
        }

        PropertyInfo[] infoArray = Txt.GetType().GetProperties();
        foreach (PropertyInfo info in infoArray)
        {
          if (info.Name == "Item" || !altTxt.ContainsKey(info.Name)) continue;

          string property = info.GetValue(Txt, null).ToString();

          info.SetValue(Txt, Regex.Unescape(altTxt[info.Name]), null);
        }
      }

      return altTxt;
    }


    public Text Txt { get; set; }

    public string Type { get; set; }

    public string FilePath { get; set; }
  }
}
