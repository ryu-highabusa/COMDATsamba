﻿using Common;

namespace TMC_Tool.ViewModels
{
  public class ObjectItem : BindableBase
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    //public ObjectItem()
    //{
    //}
    public ObjectItem(bool isChecked, string objectName, int grpID, int objID)
    {
      IsChecked = isChecked;
      ObjectName = objectName;
      Grp = grpID;
      Obj = objID;
    }


    #region IsChecked
    /// <summary>
    /// チェックの有無
    /// </summary>
    private bool _IsChecked;
    public bool IsChecked
    {
      get => _IsChecked;
      set => SetProperty(ref _IsChecked, value);
    }
    #endregion

    #region ObjectName
    /// <summary>
    /// オブジェクト名
    /// </summary>
    private string _ObjectName;
    public string ObjectName
    {
      get => _ObjectName;
      set => SetProperty(ref _ObjectName, value);
    }
    #endregion

    #region Grp
    /// <summary>
    /// グループID
    /// </summary>
    public int Grp { get; set; }
    #endregion

    #region Obj
    /// <summary>
    /// オブジェクトID
    /// </summary>
    public int Obj { get; set; }
    #endregion
  }

}
