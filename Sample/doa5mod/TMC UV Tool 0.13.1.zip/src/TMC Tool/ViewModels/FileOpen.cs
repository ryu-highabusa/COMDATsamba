﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Common;
using Tmc;
using Message;

namespace TMC_Tool.ViewModels
{
  public partial class MainWindowViewModel : BindableBase
  {
    /// <summary>
    /// ドロップされたファイルを開きます
    /// </summary>
    /// <param name="paths">ファイルパスリスト</param>
    public void OpenDorpFile(List<string> paths)
    {
      if (paths.Count < 1) return;

      try
      {
        string dataPath = "";
        string lstPath = "";
        List<string> lnkPaths = new List<string>();
        foreach (string path in paths)
        {
          if (dataPath == "" && (Path.GetExtension(path).ToUpper() == ".TMC" || Path.GetExtension(path).ToLower() == ".tmcmesh"))
          {
            dataPath = path;
          }
          else if (lstPath == "" && Path.GetExtension(path).ToLower() == ".lst")
          {
            lstPath = path;
          }
          else if (Path.GetExtension(path).ToLower() == ".lnk")
          {
            lnkPaths.Add(path);
          }
        }

        if (lnkPaths.Count > 0)
        {
          Type t = Type.GetTypeFromCLSID(new Guid("72C24DD5-D70A-438B-8A42-98424B88AFB8"));
          dynamic shell = Activator.CreateInstance(t);
          List<string> shortcutPaths = new List<string>();
          foreach (string path in lnkPaths)
          {
            var shortcut = shell.CreateShortcut(path);
            shortcutPaths.Add(shortcut.TargetPath);
            System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shortcut);
          }
          System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shell);

          foreach (string path in shortcutPaths)
          {
            if (dataPath == "" && (Path.GetExtension(path).ToUpper() == ".TMC" || Path.GetExtension(path).ToLower() == ".tmcmesh"))
            {
              dataPath = path;
            }
            else if (lstPath == "" && Path.GetExtension(path).ToLower() == ".lst")
            {
              lstPath = path;
            }
            if (dataPath != "" && lstPath != "") break;
          }
        }

        if (dataPath != "")
        {
          Open(dataPath);
        }

        if (TmcData != null && lstPath != "")
        {
          OpenListFile(lstPath);
        }
      }
      catch (Exception e)
      {
        MessageWindow.Show(mainWindow, e.Message + "\r\n\r\n" + e.StackTrace, txt.Error);
      }
    }

    /// <summary>
    /// クリップボードのパステキストからファイルを開きます
    /// </summary>
    public void OpenFromClipboard()
    {
      var pathText = Clipboard.GetText();
      if (Clipboard.ContainsFileDropList())
      {
        //データを取得する（取得できなかった時はnull）
        System.Collections.Specialized.StringCollection files = Clipboard.GetFileDropList();
        if (files != null) pathText = files[0];
      }
      if (!string.IsNullOrEmpty(pathText) && File.Exists(pathText) && (Path.GetExtension(pathText).ToUpper() == ".TMC" || Path.GetExtension(pathText).ToLower() == ".tmcmesh"))
      {
        var result = MessageWindow.Show(mainWindow, pathText + "\r\n\r\n" + txt.ConfirmOpenFile, txt.Info, txt.btnOpen, txt.Cancel);
        if (result == MessageWindow.Result.OK)
        {
          Open(pathText);
        }
        Keyboard.Focus(mainWindow);
      }
    }

    /// <summary>
    /// TMCファイルを開きます
    /// </summary>
    /// <param name="path">ファイルパス</param>
    public async void Open(string path)
    {
      mainWindow.IsEnabled = false;
      MainWindow.DoEvents();

      try
      {
        Info.Text = "";
        IsEnableMain = false;
        IsModified = false;

        if (Vertices.Count > 0) Vertices.Clear();
        if (VerticesHashSet.Count > 0) VerticesHashSet.Clear();

        SetTmcData(path);

        if (TmcData == null) return;

        await Task.Run(() => Info.BuildText(TmcData));

        IsEnableMain = true;

        BuildObjectList();

        Status = path;

        CheckModified();

        if (Objects.Count > 1) ObjSelWindow.Init(TmcData);
      }
      catch (Exception e)
      {
        TmcData = null;
        MessageWindow.Show(mainWindow, e.Message + "\r\n\r\n" + e.StackTrace, txt.Error);
      }
      finally
      {
        mainWindow.IsEnabled = true;
        mainWindow.Activate();
        mainWindow.Focus();

        CommandManager.InvalidateRequerySuggested();
      }
    }

    /// <summary>
    /// ファイルを開きTmcDataに設定します
    /// </summary>
    /// <param name="path">ファイルパス</param>
    private void SetTmcData(string path)
    {
      var bin = File.ReadAllBytes(path);
      char[] charsToTrim = { '\0' };
      string name = Encoding.ASCII.GetString(bin, 0, 8).TrimEnd(charsToTrim);
      if (name != "TMC" && name != "tmcmesh")
      {
        mainWindow.Activate();
        MessageWindow.Show(mainWindow, txt.UnsupportedFile + "\r\n" + path, txt.Error);
        return;
      }
      if (BitConverter.ToUInt32(bin, 8) != 0x01010000)
      {
        mainWindow.Activate();
        MessageWindow.Show(mainWindow, txt.UnsupportedFile + "\r\n" + path, txt.Error);
        return;
      }
      TmcData = new TmcData(bin);

      if (TmcData == null) return;

      DataType = name;


      Bin = bin;

      TmcData.Path = path;
      TmcData.WriteTime = File.GetLastWriteTime(path);

      // for broken TMC
      TmcData.H.Size = Bin.Length;
      if (TmcData.H.Count1 > 15 && TmcData.H.Offsets[15] != 0 && BitConverter.ToUInt32(Bin, TmcData.H.Offsets[15] + 8) != 16842752)
      {
        TmcData.H.Offsets[15] = 0;
      }

      if (DataType == "TMC")
      {
        TmcData.ParseObjBaseData(Bin);
        //TmcData.ParseTextureData(Bin);
        //TmcData.ParseMtrColor(Bin);
        //TmcData.ParseMdlInfo(Bin);
        //TmcData.ParseHieLayer(Bin);
        //TmcData.ParseBoneOffsetMatrices(Bin);
        TmcData.ParseVertexData(Bin, TmcData.H.Offsets[2]);
        //if (TmcData.H.Count1 > 12 && TmcData.H.Offsets[12] != 0) TmcData.ParseMCAPack(Bin);
        //if (TmcData.H.Count1 > 16 && TmcData.H.Offsets[16] != 0) TmcData.ParseACSCLS(Bin);

        TmcData.H.Size = Bin.Length;
      }
      else
      {
        ParseMeshData(Bin);
      }
    }

    /// <summary>
    /// tmcmeshファイルをパースします
    /// </summary>
    /// <param name="bin">バイナリデータ</param>
    private void ParseMeshData(byte[] bin)
    {
      // Init VertexGrp
      TmcData.VtxGrp = new List<VertexGroup>();
      var vtxGrp = new VertexGroup(0, TmcData.H.Sizes[2]);
      TmcData.VtxGrp.Add(vtxGrp);


      // Init IdxGrp
      TmcData.IdxGrp = new List<IndexGroup>();
      var idxGrp = new IndexGroup(bin, 0, TmcData.H.Sizes[3]);
      TmcData.IdxGrp.Add(idxGrp);


      // Parse ObjGrp
      var geoH = new HeaderData(bin, TmcData.H.Offsets[0]);
      TmcData.ObjGrp = new List<ObjectGroup>();
      var objGrp = new ObjectGroup(null, bin, 0, "");

      objGrp.Offset = 0;
      objGrp.Start = geoH.Start;
      objGrp.Name = "tmcmesh";
      objGrp.ChildCount = 1;
      objGrp.DeclOffset = geoH.Offsets[0] + 0x10;
      objGrp.ID = 0;

      int vtxDataLayersCount = BitConverter.ToInt32(bin, geoH.Start + geoH.Offsets[0] + 0x08);
      TmcData.ParseVertexDataLayers(bin, TmcData.VtxGrp[0], geoH.Start + geoH.Offsets[0] + 0x10, vtxDataLayersCount);

      TmcData.VtxGrp[0].DataSize = BitConverter.ToInt32(bin, geoH.Start + geoH.Offsets[0] + 0x04);

      var obj = new ObjectPart();
      obj.Offset = geoH.Offsets[1];
      obj.ID = 0;
      obj.VtxGrpIndex = 0;
      obj.IdxGrpIndex = 0;
      obj.IdxStartIndex = 0;
      obj.IdxCount = BitConverter.ToInt32(bin, geoH.Start + geoH.Offsets[1] + 0x74);
      obj.VtxStartIndex = 0;
      obj.VtxCount = BitConverter.ToUInt16(bin, geoH.Start + geoH.Offsets[1] + 0x7C);

      objGrp.Obj.Add(obj);
      TmcData.ObjGrp.Add(objGrp);


      // Set Data
      TmcData.ParseVertexGrp(bin, TmcData.H.Offsets[2], TmcData.VtxGrp[0], 0);
      TmcData.IdxGrp[0].AddIdx(bin, TmcData.H.Offsets[3], obj.IdxCount);


      // Parse Matrix
      var mtxGrp = new MatrixGroup(bin, TmcData.H.Offsets[9], 0);
      TmcData.MtxGrp.Add(mtxGrp);
    }

  }
}
