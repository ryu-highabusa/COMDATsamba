﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.IO;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Media3D;
using SystemHalf;
using Common;
using Tmc;
using Language;
using Message;

namespace TMC_Tool.ViewModels
{
  public partial class MainWindowViewModel : BindableBase
  {
    public MainWindowViewModel(MainWindow window)
    {
      mainWindow = window;

      txt = MainWindow.txt;

      SetMainWindowTitle();

      storyFadeTextMessage = (Storyboard)mainWindow.FindResource("fadeTextMessage");

      ObjSelWindow = new ObjectSelectWindow();

      Info = new InfoViewModel();

      
      // プロパティ初期化
      Status = txt.textStatus;

      Vertices = new ObservableCollection<VertexItem>();
      VerticesHashSet = new HashSet<string>();

      SelectedObjectIndex = -1;
      Objects = new List<int[]>();

      alertBg = new SolidColorBrush(Color.FromRgb(0xFF, 0x55, 0x55));
      delayTime = new TimeSpan(0, 0, 0, 2, 500);
      var timeline = storyFadeTextMessage.Children[0] as ParallelTimeline;
      animeFadeTextMessageClose = timeline.Children[1];
      curBegin = animeFadeTextMessageClose.BeginTime;

      Indices = "0, 1, 2";
      InitRange();
      InitRangeUV();
      SelectedUVMapIndex = 0;
      IsCheckedAddRange = true;
      MirrorX = true;
      LabelY = "Y";

      SelectionExpand = true;
      TargetUV1 = true;
      InitTransform();
      UV1 = 0;
      UV2 = 1;
      UV3 = 2;
      UV4 = 3;

      IsEnableTargetUV1 = true;
      IsEnableTargetUV2 = true;
      IsEnableTargetUV3 = true;
      IsEnableTargetUV4 = true;

      IsInitialized = true;

      IsEnableCreateBackup = true;
    }



    /// <summary>
    /// MainWindowのタイトルをセットします
    /// </summary>
    private void SetMainWindowTitle()
    {
      System.Reflection.Assembly thisAssem = System.Reflection.Assembly.GetExecutingAssembly();
      System.Version ver = thisAssem.GetName().Version;
      MainWindowTitle = thisAssem.GetName().Name + " " + ver.Major + "." + ver.Minor + "." + ver.Build;
    }


    /// <summary>
    /// 座標範囲を初期化
    /// </summary>
    private void InitRange()
    {
      XMin = -1;
      XMax = 1;
      YMin = -1;
      YMax = 1;
      YMin2 = -1;
      YMax2 = 1;
      ZMin = -1;
      ZMax = 1;
    }

    /// <summary>
    /// UV座標範囲を初期化
    /// </summary>
    private void InitRangeUV()
    {
      UMin = 0;
      UMax = 1;
      VMin = 0;
      VMax = 1;
    }

    /// <summary>
    /// オブジェクトリストを構築
    /// </summary>
    private void BuildObjectList()
    {
      if (Objects.Count > 0) Objects.Clear();
      if (mainWindow.cmbObject.Items.Count > 0) mainWindow.cmbObject.Items.Clear();


      for (int i = 0; i < TmcData.ObjGrp.Count; i++)
      {
        for (int j = 0; j < TmcData.ObjGrp[i].Obj.Count; j++)
        {
          if (TmcData.ObjGrp[i].Obj[j].IdxCount == 0 && TmcData.ObjGrp[i].Obj[j].VtxCount == 0) continue;

          string type = "";
          if (TmcData.ObjGrp[i].Obj[j].MaterialType == "Skin")
            type = " (Skin)";
          else if (TmcData.ObjGrp[i].Obj[j].MaterialType == "WetTex")
            type = " (Wet)";

          mainWindow.cmbObject.Items.Add(TmcData.ObjGrp[i].Name + "_" + TmcData.ObjGrp[i].Obj[j].ID.ToString("x") + type);

          Objects.Add(new int[] { i, j });
        }
      }


      if (Objects.Count > 0) SelectedObjectIndex = 0;
    }


    /// <summary>
    /// 追加した数を表示
    /// </summary>
    private void ShowAddedMessage()
    {
      if (addedCount > 0)
      {
        animeFadeTextMessageClose.BeginTime += delayTime;
        ShowTextBlockMessage(addedCount + " " + txt.VertexAdded);
        animeFadeTextMessageClose.BeginTime = curBegin;

        addedCount = 0;
      }
      else
      {
        ShowTextBlockMessage(txt.NothingAdded, alertBg);
      }
    }


    /// <summary>
    /// 頂点アイテムのチェックを変更
    /// </summary>
    /// <param name="state">チェック状態</param>
    public void IsCheckedChanged(bool state)
    {
      if (mainWindow.dgSelection.SelectedItems.Count > 1)
      {
        foreach (var item in mainWindow.dgSelection.SelectedItems)
        {
          var vertexItem = item as VertexItem;
          vertexItem.IsChecked = state;
        }
      }
    }

    /// <summary>
    /// 頂点アイテムを追加
    /// </summary>
    private void VerticesAddIndex()
    {
      int count = 0;

      int grpID = Objects[SelectedObjectIndex][0];
      int objID = Objects[SelectedObjectIndex][1];

      string[] indeces = Indices.Split(',');

      foreach (string idx in indeces)
      {
        if (idx == "") continue;
        try
        {
          if (!Int32.TryParse(idx, out int index)) continue;

          VertexItem newItem = new VertexItem(true, TmcData.ObjGrp[grpID].Name + "_" + TmcData.ObjGrp[grpID].Obj[objID].ID.ToString("x"), grpID, objID, index, TmcData.ObjGrp[grpID].Obj[objID].VtxGrpIndex);

          string ints = grpID + "," + objID + "," + index;
          if (!VerticesHashSet.Contains(ints))
          {
            Vertices.Add(newItem);
            VerticesHashSet.Add(ints);
            mainWindow.dgSelection.SelectedIndex = Vertices.Count - 1;
            count++;
          }
        }
        catch (FormatException)
        {
        }
      }

      if (count > 0)
      {
        IsModified = true;
        mainWindow.dgSelection.ScrollIntoView(mainWindow.dgSelection.Items[Vertices.Count - 1]);
      }

      addedCount += count;
    }

    /// <summary>
    /// 頂点アイテムを座標範囲から追加
    /// </summary>
    /// <param name="grpID">オブジェクトグループID</param>
    /// <param name="objID">オブジェクトID</param>
    private void VerticesAddRange(int grpID, int objID)
    {
      int count = 0;

      var grp = TmcData.ObjGrp[grpID];
      var obj = grp.Obj[objID];
      var vtxGrp = TmcData.VtxGrp[obj.VtxGrpIndex];
      int start = obj.VtxStartIndex;
      int end = obj.VtxStartIndex + obj.VtxCount;

      string objName = grp.Name + "_" + obj.ID.ToString("x");

      float coefficientYmin = 0;
      float coefficientYmax = 0;
      float baseYmin = 0;
      float baseYmax = 0;

      if (MirrorX)
      {
        if (XMax < 0) XMax = -XMax;
        XMin = -XMax;
      }

      if (SlantY)
      {
        if (XMax - XMin != 0)
        {
          coefficientYmin = (YMin2 - YMin) / (XMax - XMin);
          coefficientYmax = (YMax2 - YMax) / (XMax - XMin);
          baseYmin = (XMax * YMin - XMin * YMin2) / (XMax - XMin);
          baseYmax = (XMax * YMax - XMin * YMax2) / (XMax - XMin);
        }
      }

      MatrixTransform3D objTransform = new MatrixTransform3D(TmcData.MtxGrp[grp.Node].Matrix);

      for (int i = start; i < end; i++)
      {
        Point3D p = objTransform.Transform(new Point3D(vtxGrp.Vtx[i].X, vtxGrp.Vtx[i].Y, vtxGrp.Vtx[i].Z));

        float X = (float)p.X;
        float Y = (float)p.Y;
        float Z = (float)p.Z;

        bool add = false;
        if (SlantY)
        {
          if (
            X >= XMin &&
            X <= XMax &&
            Y >= X * coefficientYmin + baseYmin &&
            Y <= X * coefficientYmax + baseYmax &&
            Z >= ZMin &&
            Z <= ZMax
            )
          {
            add = true;
          }
        }
        else
        {
          if (
            X >= XMin &&
            X <= XMax &&
            Y >= YMin &&
            Y <= YMax &&
            Z >= ZMin &&
            Z <= ZMax
            )
          {
            add = true;
          }
        }

        if (add)
        {
          VertexItem newItem = new VertexItem(true, objName, grpID, objID, i - start, obj.VtxGrpIndex);

          string ints = grpID + "," + objID + "," + (i - start);
          if (!VerticesHashSet.Contains(ints))
          {
            Vertices.Add(newItem);
            VerticesHashSet.Add(ints);
            count++;
          }
        }
      }

      if (count > 0)
      {
        mainWindow.dgSelection.SelectedIndex = Vertices.Count - 1;
        IsModified = true;
        mainWindow.dgSelection.ScrollIntoView(mainWindow.dgSelection.Items[Vertices.Count - 1]);
      }

      addedCount += count;
    }

    /// <summary>
    /// 頂点アイテムをUV座標範囲から追加
    /// </summary>
    /// <param name="grpID">オブジェクトグループID</param>
    /// <param name="objID">オブジェクトID</param>
    private void VerticesAddRangeUV(int grpID, int objID)
    {
      int count = 0;

      if (SelectedUVMapIndex == -1) return;


      var grp = TmcData.ObjGrp[grpID];
      var obj = grp.Obj[objID];
      var vtxGrp = TmcData.VtxGrp[obj.VtxGrpIndex];

      if (vtxGrp.UVCount <= SelectedUVMapIndex) return;


      int start = obj.VtxStartIndex;
      int end = obj.VtxStartIndex + obj.VtxCount;

      string objName = grp.Name + "_" + obj.ID.ToString("x");

      for (int i = start; i < end; i++)
      {
        Half U = Half.ToHalf(vtxGrp.Vtx[i].UV[SelectedUVMapIndex].U, 0);
        Half V = Half.ToHalf(vtxGrp.Vtx[i].UV[SelectedUVMapIndex].V, 0);

        bool add = false;
        if (
          U >= UMin &&
          U <= UMax &&
          V >= VMin &&
          V <= VMax
          )
        {
          add = true;
        }

        if (add)
        {
          VertexItem newItem = new VertexItem(true, objName, grpID, objID, i - start, obj.VtxGrpIndex);

          string ints = grpID + "," + objID + "," + (i - start);
          if (!VerticesHashSet.Contains(ints))
          {
            Vertices.Add(newItem);
            VerticesHashSet.Add(ints);
            count++;
          }
        }
      }

      if (count > 0)
      {
        mainWindow.dgSelection.SelectedIndex = Vertices.Count - 1;
        IsModified = true;
        mainWindow.dgSelection.ScrollIntoView(mainWindow.dgSelection.Items[Vertices.Count - 1]);
      }

      addedCount += count;
    }

    /// <summary>
    /// 頂点アイテムをリストファイルから追加
    /// </summary>
    /// <param name="filePath">ファイルパス</param>
    private void OpenListFile(string filePath)
    {
      using (StreamReader sr = new StreamReader(filePath))
      {
        int count = 0;
        while (sr.Peek() >= 0)
        {
          string s = sr.ReadLine();
          if (s == "") continue;
          char[] charsToSplit = { ',' };
          var row = s.Split(charsToSplit);
          if (row.Length < 5)
          {
            MessageWindow.Show(mainWindow, txt.UnsupportedFile, txt.Error);
            break;
          }

          if (!Boolean.TryParse(row[0], out bool isChecked)) continue;
          if (!Int32.TryParse(row[2], out int grpID)) continue;
          if (!Int32.TryParse(row[3], out int objID)) continue;
          if (!Int32.TryParse(row[4], out int index)) continue;
          if (!Int32.TryParse(row[5], out int vtxGrpID)) continue;

          VertexItem newItem = new VertexItem(isChecked, row[1], grpID, objID, index, vtxGrpID);

          string ints = row[2] + "," + row[3] + "," + row[4];
          if (!VerticesHashSet.Contains(ints))
          {
            Vertices.Add(newItem);
            VerticesHashSet.Add(ints);
            count++;
          }
        }

        if (count > 0)
        {
          mainWindow.dgSelection.SelectedIndex = Vertices.Count - 1;
          IsModified = true;
          if (mainWindow.dgSelection.Items.Count == Vertices.Count)
            mainWindow.dgSelection.ScrollIntoView(mainWindow.dgSelection.Items[Vertices.Count - 1]);
        }
      }
    }

    /// <summary>
    /// 頂点アイテムをリストファイルに保存
    /// </summary>
    /// <param name="filePath">ファイルパス</param>
    private void SaveListFile(string filePath)
    {
      string text = "";

      foreach (var vtx in Vertices)
      {
        text += vtx.IsChecked;
        text += ",";
        text += vtx.ObjectName;
        text += ",";
        text += vtx.Grp;
        text += ",";
        text += vtx.Obj;
        text += ",";
        text += vtx.Index;
        text += ",";
        text += vtx.VtxGrp;
        text += "\r\n";
      }

      using (StreamWriter sw = new StreamWriter(filePath, false))
      {
        sw.Write(text);
        sw.Close();
      }
    }

    /// <summary>
    /// 頂点アイテムを削除
    /// </summary>
    private void VerticesRemove()
    {
      int itemsCount = mainWindow.dgSelection.SelectedItems.Count;
      int idx = -1;

      while (mainWindow.dgSelection.SelectedItems.Count > 0)
      {
        idx = mainWindow.dgSelection.Items.IndexOf(mainWindow.dgSelection.SelectedItems[0]);

        var vertexItem = mainWindow.dgSelection.SelectedItems[0] as VertexItem;

        string ints = vertexItem.Grp + "," + vertexItem.Obj + "," + vertexItem.Index;
        VerticesHashSet.Remove(ints);
        Vertices.Remove(vertexItem);
      }


      if (Vertices.Count == 0)
      {
        IsModified = false;
      }
      else if (itemsCount == 1 && idx == Vertices.Count)
      {
        mainWindow.dgSelection.Focus();
        mainWindow.dgSelection.SelectedIndex = idx - 1;
        mainWindow.dgSelection.ScrollIntoView(mainWindow.dgSelection.Items[idx - 1]);
      }
      else if (itemsCount == 1)
      {
        mainWindow.dgSelection.Focus();
        mainWindow.dgSelection.SelectedIndex = idx;
        mainWindow.dgSelection.ScrollIntoView(mainWindow.dgSelection.Items[idx]);
      }
    }

    /// <summary>
    /// 頂点アイテムをクリア
    /// </summary>
    private void VerticesClear()
    {
      try
      {
        if (Vertices.Count > 0)
        {
          Vertices.Clear();
          VerticesHashSet.Clear();

          IsModified = false;
        }
      }
      catch (DataException e)
      {
        MessageWindow.Show(mainWindow, e.Message, txt.Error);
      }
    }


    /// <summary>
    /// UV座標変形に使用する数値を初期化
    /// </summary>
    private void InitTransform()
    {
      ScaleU = 1;
      ScaleV = 1;
      MoveU = 0;
      MoveV = 0;
      InvertAxis = 0.5f;
      CenterFudge = 0.001f;
    }

    /// <summary>
    /// UVマップの割り当てを変更した場合の処理
    /// </summary>
    private void ChangedUV()
    {
      var uvs = new HashSet<int>() { UV1, UV2, UV3, UV4 };

      IsEnableTargetUV1 = uvs.Contains(0);
      IsEnableTargetUV2 = uvs.Contains(1);
      IsEnableTargetUV3 = uvs.Contains(2);
      IsEnableTargetUV4 = uvs.Contains(3);

      IsModified = true;
    }


    /// <summary>
    /// 変更されているかどうかを確認
    /// </summary>
    private void CheckModified()
    {
      if (
        ScaleU != 1 ||
        ScaleV != 1 ||
        MoveU != 0 ||
        MoveV != 0 ||
        UV1 != 0 ||
        UV2 != 1 ||
        UV3 != 2 ||
        UV4 != 3 ||
        Invert
      )
      {
        IsModified = true;
      }
    }


    /// <summary>
    /// ファイルが更新されているかを確認して読み込み直すかそのままにするかを選択します
    /// </summary>
    public void CheckUpdated()
    {
      try
      {
        if (TmcData == null || !File.Exists(TmcData.Path)) return;

        var lastWriteTimeTmc = File.GetLastWriteTime(TmcData.Path);
        if (TmcData.WriteTime.CompareTo(lastWriteTimeTmc) != 0)
        {
          if (MessageWindow.Show(mainWindow, txt.ConfirmFileUpdated + "\r\n\r\n" + TmcData.Path, txt.Confirm, txt.Yes, txt.No) == MessageWindow.Result.OK)
          {
            Open(TmcData.Path);
          }
          else
          {
            TmcData.WriteTime = lastWriteTimeTmc;
          }
        }
      }
      catch (Exception e)
      {
        MessageWindow.Show(mainWindow, e.Message + "\r\n\r\n" + e.StackTrace, txt.Error);
      }
    }





    public MainWindow mainWindow { get; set; }

    public static Lang.Text txt;

    private static int addedCount = 0;

    private static Brush alertBg;
    private static Timeline animeFadeTextMessageClose;
    private static TimeSpan delayTime;
    private static TimeSpan? curBegin;

    private static bool IsInitialized;

    /// <summary>
    /// データタイプ
    /// </summary>
    private string DataType { get; set; }

    /// <summary>
    /// TMCのバイナリ
    /// </summary>
    public byte[] Bin { get; set; }

    /// <summary>
    /// TMCデータ
    /// </summary>
    public TmcData TmcData { get; set; }

    /// <summary>
    /// ObjectSelectWindow
    /// </summary>
    public ObjectSelectWindow ObjSelWindow { get; set; }


    #region MainWindowTitle
    /// <summary>
    /// MainWindowタイトル
    /// </summary>
    private string _MainWindowTitle;
    public string MainWindowTitle
    {
      get => _MainWindowTitle;
      set => SetProperty(ref _MainWindowTitle, value);
    }
    #endregion

    #region Status
    /// <summary>
    /// ステータスバーのテキスト
    /// </summary>
    private string _Status;
    public string Status
    {
      get => _Status;
      set => SetProperty(ref _Status, value);
    }
    #endregion

    #region IsEnableMain
    /// <summary>
    /// メイン部分が有効かどうか
    /// </summary>
    private bool _IsEnableMain;
    public bool IsEnableMain
    {
      get => _IsEnableMain;
      set => SetProperty(ref _IsEnableMain, value);
    }
    #endregion

    #region IsModified
    /// <summary>
    /// 変更されたかどうか
    /// </summary>
    private bool _IsModified;
    public bool IsModified
    {
      get => _IsModified;
      set => SetProperty(ref _IsModified, value);
    }
    #endregion

    #region IsEnableCreateBackup
    /// <summary>
    /// 上書き保存（バックアップを作成）を有効にできるかどうか
    /// </summary>
    public bool IsEnableCreateBackup { get; set; }
    #endregion

    #region IsKeepData
    /// <summary>
    /// 保存しても元のデータの値を保持して再試行可能にするが有効かどうか
    /// </summary>
    private bool _IsKeepData;
    public bool IsKeepData
    {
      get => _IsKeepData;
      set => SetProperty(ref _IsKeepData, value);
    }
    #endregion

    #region Vertices
    /// <summary>
    /// 表の頂点アイテム
    /// </summary>
    public ObservableCollection<VertexItem> Vertices { get; set; }
    #endregion

    #region VerticesHashSet
    /// <summary>
    /// 頂点アイテムのユニーク判断用セット
    /// </summary>
    public HashSet<string> VerticesHashSet { get; set; }
    #endregion


    #region IsCheckedAddIndex
    /// <summary>
    /// 手動で追加
    /// </summary>
    private bool _IsCheckedAddIndex;
    public bool IsCheckedAddIndex
    {
      get => _IsCheckedAddIndex;
      set
      {
        SetProperty(ref _IsCheckedAddIndex, value);

        if (_IsCheckedAddIndex)
        {
          var story = (Storyboard)mainWindow.FindResource("selectAddIndex");
          story.Begin();
        }
      }
    }
    #endregion

    #region IsCheckedAddRange
    /// <summary>
    /// 座標範囲を指定して自動で追加
    /// </summary>
    private bool _IsCheckedAddRange;
    public bool IsCheckedAddRange
    {
      get => _IsCheckedAddRange;
      set
      {
        SetProperty(ref _IsCheckedAddRange, value);

        if (_IsCheckedAddRange)
        {
          var story = (Storyboard)mainWindow.FindResource("selectAddRange");
          story.Begin();
        }
      }
    }
    #endregion

    #region IsCheckedAddRangeUV
    /// <summary>
    /// UV座標範囲を指定して自動で追加
    /// </summary>
    private bool _IsCheckedAddRangeUV;
    public bool IsCheckedAddRangeUV
    {
      get => _IsCheckedAddRangeUV;
      set
      {
        SetProperty(ref _IsCheckedAddRangeUV, value);

        if (_IsCheckedAddRangeUV)
        {
          var story = (Storyboard)mainWindow.FindResource("selectAddRangeUV");
          story.Begin();
        }
      }
    }
    #endregion


    #region Indices
    /// <summary>
    /// インデックス群
    /// </summary>
    private string _Indices;
    public string Indices
    {
      get => _Indices;
      set => SetProperty(ref _Indices, value);
    }
    #endregion


    #region XMin
    /// <summary>
    /// XMin
    /// </summary>
    private float _XMin;
    public float XMin
    {
      get => _XMin;
      set => SetProperty(ref _XMin, value);
    }
    #endregion

    #region XMax
    /// <summary>
    /// XMax
    /// </summary>
    private float _XMax;
    public float XMax
    {
      get => _XMax;
      set => SetProperty(ref _XMax, value);
    }
    #endregion

    #region YMin
    /// <summary>
    /// YMin
    /// </summary>
    private float _YMin;
    public float YMin
    {
      get => _YMin;
      set => SetProperty(ref _YMin, value);
    }
    #endregion

    #region YMax
    /// <summary>
    /// YMax
    /// </summary>
    private float _YMax;
    public float YMax
    {
      get => _YMax;
      set => SetProperty(ref _YMax, value);
    }
    #endregion

    #region YMin2
    /// <summary>
    /// YMin2
    /// </summary>
    private float _YMin2;
    public float YMin2
    {
      get => _YMin2;
      set => SetProperty(ref _YMin2, value);
    }
    #endregion

    #region YMax2
    /// <summary>
    /// YMax2
    /// </summary>
    private float _YMax2;
    public float YMax2
    {
      get => _YMax2;
      set => SetProperty(ref _YMax2, value);
    }
    #endregion

    #region ZMin
    /// <summary>
    /// ZMin
    /// </summary>
    private float _ZMin;
    public float ZMin
    {
      get => _ZMin;
      set => SetProperty(ref _ZMin, value);
    }
    #endregion

    #region ZMax
    /// <summary>
    /// ZMax
    /// </summary>
    private float _ZMax;
    public float ZMax
    {
      get => _ZMax;
      set => SetProperty(ref _ZMax, value);
    }
    #endregion

    #region SlantY
    /// <summary>
    /// Y軸を斜めに指定できるようにする
    /// </summary>
    private bool _SlantY;
    public bool SlantY
    {
      get => _SlantY;
      set
      {
        SetProperty(ref _SlantY, value);

        if (_SlantY)
        {
          IsEnableY2 = true;
          LabelY = "Y(X=Min)";
        }
        else
        {
          IsEnableY2 = false;
          LabelY = "Y";
        }
      }
    }
    #endregion

    #region MirrorX
    /// <summary>
    /// X軸の範囲を左右対称にする
    /// </summary>
    private bool _MirrorX;
    public bool MirrorX
    {
      get => _MirrorX;
      set
      {
        SetProperty(ref _MirrorX, value);

        IsEnableXMin = !_MirrorX;
      }
    }
    #endregion


    #region IsEnableXMin
    /// <summary>
    /// X Minが有効かどうか
    /// </summary>
    private bool _IsEnableXMin;
    public bool IsEnableXMin
    {
      get => _IsEnableXMin;
      set => SetProperty(ref _IsEnableXMin, value);
    }
    #endregion

    #region IsEnableY2
    /// <summary>
    /// Y2が有効かどうか
    /// </summary>
    private bool _IsEnableY2;
    public bool IsEnableY2
    {
      get => _IsEnableY2;
      set => SetProperty(ref _IsEnableY2, value);
    }
    #endregion

    #region LabelY
    /// <summary>
    /// Yのラベルテキスト
    /// </summary>
    private string _LabelY;
    public string LabelY
    {
      get => _LabelY;
      set => SetProperty(ref _LabelY, value);
    }
    #endregion



    #region UMin
    /// <summary>
    /// UMin
    /// </summary>
    private float _UMin;
    public float UMin
    {
      get => _UMin;
      set => SetProperty(ref _UMin, value);
    }
    #endregion

    #region UMax
    /// <summary>
    /// UMax
    /// </summary>
    private float _UMax;
    public float UMax
    {
      get => _UMax;
      set => SetProperty(ref _UMax, value);
    }
    #endregion

    #region VMin
    /// <summary>
    /// VMin
    /// </summary>
    private float _VMin;
    public float VMin
    {
      get => _VMin;
      set => SetProperty(ref _VMin, value);
    }
    #endregion

    #region VMax
    /// <summary>
    /// VMax
    /// </summary>
    private float _VMax;
    public float VMax
    {
      get => _VMax;
      set => SetProperty(ref _VMax, value);
    }
    #endregion

    #region SelectedUVMapIndex
    /// <summary>
    /// 選択しているUVマップのインデックス
    /// </summary>
    private int _SelectedUVMapIndex;
    public int SelectedUVMapIndex
    {
      get => _SelectedUVMapIndex;
      set => SetProperty(ref _SelectedUVMapIndex, value);
    }
    #endregion


    #region Objects
    /// <summary>
    /// オブジェクトリスト
    /// </summary>
    private List<int[]> Objects { get; set; }
    #endregion

    #region SelectedObjectIndex
    /// <summary>
    /// 選択しているオブジェクトのインデックス
    /// </summary>
    private int _SelectedObjectIndex;
    public int SelectedObjectIndex
    {
      get => _SelectedObjectIndex;
      set => SetProperty(ref _SelectedObjectIndex, value);
    }
    #endregion


    #region SelectionExpand
    /// <summary>
    /// 選択範囲を接続面に拡張
    /// </summary>
    private bool _SelectionExpand;
    public bool SelectionExpand
    {
      get => _SelectionExpand;
      set => SetProperty(ref _SelectionExpand, value);
    }
    #endregion

    #region TargetUV1
    /// <summary>
    /// TargetUV1
    /// </summary>
    private bool _TargetUV1;
    public bool TargetUV1
    {
      get => _TargetUV1;
      set => SetProperty(ref _TargetUV1, value);
    }
    #endregion

    #region TargetUV2
    /// <summary>
    /// TargetUV2
    /// </summary>
    private bool _TargetUV2;
    public bool TargetUV2
    {
      get => _TargetUV2;
      set => SetProperty(ref _TargetUV2, value);
    }
    #endregion

    #region TargetUV3
    /// <summary>
    /// TargetUV3
    /// </summary>
    private bool _TargetUV3;
    public bool TargetUV3
    {
      get => _TargetUV3;
      set => SetProperty(ref _TargetUV3, value);
    }
    #endregion

    #region TargetUV4
    /// <summary>
    /// TargetUV4
    /// </summary>
    private bool _TargetUV4;
    public bool TargetUV4
    {
      get => _TargetUV4;
      set => SetProperty(ref _TargetUV4, value);
    }
    #endregion

    #region IsEnableTargetUV1
    /// <summary>
    /// IsEnableTargetUV1
    /// </summary>
    private bool _IsEnableTargetUV1;
    public bool IsEnableTargetUV1
    {
      get => _IsEnableTargetUV1;
      set => SetProperty(ref _IsEnableTargetUV1, value);
    }
    #endregion

    #region IsEnableTargetUV2
    /// <summary>
    /// IsEnableTargetUV2
    /// </summary>
    private bool _IsEnableTargetUV2;
    public bool IsEnableTargetUV2
    {
      get => _IsEnableTargetUV2;
      set => SetProperty(ref _IsEnableTargetUV2, value);
    }
    #endregion

    #region IsEnableTargetUV3
    /// <summary>
    /// IsEnableTargetUV3
    /// </summary>
    private bool _IsEnableTargetUV3;
    public bool IsEnableTargetUV3
    {
      get => _IsEnableTargetUV3;
      set => SetProperty(ref _IsEnableTargetUV3, value);
    }
    #endregion

    #region IsEnableTargetUV4
    /// <summary>
    /// IsEnableTargetUV4
    /// </summary>
    private bool _IsEnableTargetUV4;
    public bool IsEnableTargetUV4
    {
      get => _IsEnableTargetUV4;
      set => SetProperty(ref _IsEnableTargetUV4, value);
    }
    #endregion

    #region ScaleU
    /// <summary>
    /// 拡大U方向
    /// </summary>
    private float _ScaleU;
    public float ScaleU
    {
      get => _ScaleU;
      set
      {
        SetProperty(ref _ScaleU, value);
        if (IsInitialized) IsModified = true;
      }
    }
    #endregion

    #region ScaleV
    /// <summary>
    /// 拡大V方向
    /// </summary>
    private float _ScaleV;
    public float ScaleV
    {
      get => _ScaleV;
      set
      {
        SetProperty(ref _ScaleV, value);
        if (IsInitialized) IsModified = true;
      }
    }
    #endregion

    #region MoveU
    /// <summary>
    /// 移動U方向
    /// </summary>
    private float _MoveU;
    public float MoveU
    {
      get => _MoveU;
      set
      {
        SetProperty(ref _MoveU, value);
        if (IsInitialized) IsModified = true;
      }
    }
    #endregion

    #region MoveV
    /// <summary>
    /// 移動V方向
    /// </summary>
    private float _MoveV;
    public float MoveV
    {
      get => _MoveV;
      set
      {
        SetProperty(ref _MoveV, value);
        if (IsInitialized) IsModified = true;
      }
    }
    #endregion


    #region Invert
    /// <summary>
    /// 右半分の頂点のUVを左右反転する
    /// </summary>
    private bool _Invert;
    public bool Invert
    {
      get => _Invert;
      set
      {
        SetProperty(ref _Invert, value);
        if (IsInitialized) IsModified = true;
      }
    }
    #endregion

    #region InvertAxis
    /// <summary>
    /// 反転軸座標
    /// </summary>
    private float _InvertAxis;
    public float InvertAxis
    {
      get => _InvertAxis;
      set
      {
        SetProperty(ref _InvertAxis, value);
        if (IsInitialized) IsModified = true;
      }
    }
    #endregion

    #region CenterFudge
    /// <summary>
    /// 中心頂点誤差
    /// </summary>
    private float _CenterFudge;
    public float CenterFudge
    {
      get => _CenterFudge;
      set
      {
        SetProperty(ref _CenterFudge, value);
        if (IsInitialized) IsModified = true;
      }
    }
    #endregion

    #region InvertTangent
    /// <summary>
    /// ノーマルマップの効果を反転する
    /// </summary>
    private bool _InvertTangent;
    public bool InvertTangent
    {
      get => _InvertTangent;
      set
      {
        SetProperty(ref _InvertTangent, value);
        if (IsInitialized) IsModified = true;
      }
    }
    #endregion

    #region X0AroundCenter
    /// <summary>
    /// X=0の頂点のUVを反転軸座標に揃える
    /// </summary>
    private bool _X0AroundCenter;
    public bool X0AroundCenter
    {
      get => _X0AroundCenter;
      set
      {
        SetProperty(ref _X0AroundCenter, value);
        if (IsInitialized) IsModified = true;
      }
    }
    #endregion


    #region UV1
    /// <summary>
    /// UV1
    /// </summary>
    private int _UV1;
    public int UV1
    {
      get => _UV1;
      set
      {
        SetProperty(ref _UV1, value);
        if (IsInitialized) ChangedUV();
      }
    }
    #endregion

    #region UV2
    /// <summary>
    /// UV2
    /// </summary>
    private int _UV2;
    public int UV2
    {
      get => _UV2;
      set
      {
        SetProperty(ref _UV2, value);
        if (IsInitialized) ChangedUV();
      }
    }
    #endregion

    #region UV3
    /// <summary>
    /// UV3
    /// </summary>
    private int _UV3;
    public int UV3
    {
      get => _UV3;
      set
      {
        SetProperty(ref _UV3, value);
        if (IsInitialized) ChangedUV();
      }
    }
    #endregion

    #region UV4
    /// <summary>
    /// UV4
    /// </summary>
    private int _UV4;
    public int UV4
    {
      get => _UV4;
      set
      {
        SetProperty(ref _UV4, value);
        if (IsInitialized) ChangedUV();
      }
    }
    #endregion



    #region Info
    /// <summary>
    /// 情報テキスト
    /// </summary>
    private InfoViewModel _Info;
    public InfoViewModel Info
    {
      get => _Info;
      set => SetProperty(ref _Info, value);
    }
    #endregion



    #region コマンド：開く
    /// <summary>
    /// コマンド：開く
    /// </summary>
    private DelegateCommand _OpenCommand;
    public DelegateCommand OpenCommand
      => _OpenCommand ?? (_OpenCommand = new DelegateCommand(OpenExecute, () => true));

    /// <summary>
    /// コマンド：開く の実行を行います。
    /// </summary>
    private void OpenExecute()
    {
      Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
      dlg.Filter = "Supported Files|*.TMC;*.tmcmesh|TMC Files (.TMC)|*.TMC|tmcmesh Files (.tmcmesh)|*.tmcmesh";
      if (TmcData != null && String.IsNullOrEmpty(TmcData.Path))
      {
        dlg.InitialDirectory = Path.GetDirectoryName(TmcData.Path);
        dlg.FileName = Path.GetFileName(TmcData.Path);
      }
      if (dlg.ShowDialog() == true)
      {
        Open(dlg.FileName);
      }
    }
    #endregion

    #region コマンド：再読込
    /// <summary>
    /// コマンド：再読込
    /// </summary>
    private DelegateCommand _ReloadCommand;
    public DelegateCommand ReloadCommand
      => _ReloadCommand ?? (_ReloadCommand = new DelegateCommand(ReloadExecute, CanReloadExecute));

    /// <summary>
    /// コマンド：再読込 の実行を行います。
    /// </summary>
    private void ReloadExecute()
    {
      Open(TmcData.Path);
    }

    /// <summary>
    /// コマンド：再読込 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanReloadExecute()
    {
      if (TmcData != null && File.Exists(TmcData.Path))
        return true;
      else
        return false;
    }
    #endregion

    #region コマンド：上書き保存
    /// <summary>
    /// コマンド：上書き保存
    /// </summary>
    private DelegateCommand _SaveCommand;
    public DelegateCommand SaveCommand
      => _SaveCommand ?? (_SaveCommand = new DelegateCommand(SaveExecute, CanSaveExecute));

    /// <summary>
    /// コマンド：上書き保存 の実行を行います。
    /// </summary>
    private void SaveExecute()
    {
      if (!PreSaveCheck())
      {
        MessageWindow.Show(mainWindow, txt.ErrorNotChecked, txt.Error);
        return;
      }
      var result = MessageWindow.Show(mainWindow, txt.Overwrite, txt.Confirm, txt.OverwriteYes, txt.Cancel);
      if (result == MessageWindow.Result.OK)
      {
        Save(TmcData.Path);
      }
    }

    /// <summary>
    /// コマンド：上書き保存 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanSaveExecute()
    {
      if (IsModified)
        return true;
      else
        return false;
    }
    #endregion

    #region コマンド：上書き保存（バックアップを作成）
    /// <summary>
    /// コマンド：上書き保存（バックアップを作成）
    /// </summary>
    private DelegateCommand _SaveWithBackupCommand;
    public DelegateCommand SaveWithBackupCommand
      => _SaveWithBackupCommand ?? (_SaveWithBackupCommand = new DelegateCommand(SaveWithBackupExecute, CanSaveExecute));

    /// <summary>
    /// コマンド：上書き保存（バックアップを作成） の実行を行います。
    /// </summary>
    private void SaveWithBackupExecute()
    {
      if (!PreSaveCheck())
      {
        MessageWindow.Show(mainWindow, txt.ErrorNotChecked, txt.Error);
        return;
      }
      string newPath = CreateBackup();
      if (newPath != null)
      {
        if (!Save(TmcData.Path))
        {
          if (File.Exists(newPath)) File.Move(newPath, TmcData.Path);
        }
      }
      else
      {
        MessageWindow.Show(mainWindow, txt.FailedToCreateBackup, txt.Error);
      }
    }

    /// <summary>
    /// コマンド：上書き保存（バックアップを作成） が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanSaveWithBackupExecute()
    {
      if (IsModified && IsEnableCreateBackup)
        return true;
      else
        return false;
    }
    #endregion

    #region コマンド：別名で保存
    /// <summary>
    /// コマンド：別名で保存
    /// </summary>
    private DelegateCommand _SaveAsCommand;
    public DelegateCommand SaveAsCommand
      => _SaveAsCommand ?? (_SaveAsCommand = new DelegateCommand(SaveAsExecute, CanSaveAsExecute));

    /// <summary>
    /// コマンド：別名で保存 の実行を行います。
    /// </summary>
    private void SaveAsExecute()
    {
      if (!PreSaveCheck())
      {
        MessageWindow.Show(mainWindow, txt.ErrorNotChecked, txt.Error);
        return;
      }
      Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
      dlg.InitialDirectory = Path.GetDirectoryName(TmcData.Path);
      dlg.FileName = Path.GetFileName(TmcData.Path);

      if (Path.GetExtension(TmcData.Path).ToLower() == ".tmcmesh")
      {
        dlg.DefaultExt = ".tmcmesh";
        dlg.Filter = "tmcmesh Files (.tmcmesh)|*.tmcmesh";
      }
      else
      {
        dlg.DefaultExt = ".TMC";
        dlg.Filter = "TMC Files (.TMC)|*.TMC";
      }

      if (dlg.ShowDialog() == true)
      {
        Save(dlg.FileName);
      }
    }

    /// <summary>
    /// コマンド：別名で保存 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanSaveAsExecute()
    {
      if (IsModified)
        return true;
      else
        return false;
    }
    #endregion



    #region コマンド：リストを保存
    /// <summary>
    /// コマンド：リストを保存
    /// </summary>
    private DelegateCommand _SaveVertexItemsCommand;
    public DelegateCommand SaveVertexItemsCommand
      => _SaveVertexItemsCommand ?? (_SaveVertexItemsCommand = new DelegateCommand(SaveVertexItemsExecute, CanSaveVertexItemsExecute));

    /// <summary>
    /// コマンド：リストを保存 の実行を行います。
    /// </summary>
    private void SaveVertexItemsExecute()
    {
      Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
      dlg.FileName = "";
      dlg.DefaultExt = ".lst";
      dlg.Filter = "List Files (.lst)|*.lst";

      bool? result = dlg.ShowDialog();

      if (result == true)
      {
        SaveListFile(dlg.FileName);
      }
    }

    /// <summary>
    /// コマンド：リストを保存 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanSaveVertexItemsExecute()
    {
      if (Vertices.Count > 0)
        return true;
      else
        return false;
    }
    #endregion

    #region コマンド：リストを読込
    /// <summary>
    /// コマンド：リストを読込
    /// </summary>
    private DelegateCommand _OpenVertexItemsCommand;
    public DelegateCommand OpenVertexItemsCommand
      => _OpenVertexItemsCommand ?? (_OpenVertexItemsCommand = new DelegateCommand(OpenVertexItemsExecute, CanOpenVertexItemsExecute));

    /// <summary>
    /// コマンド：リストを読込 の実行を行います。
    /// </summary>
    private void OpenVertexItemsExecute()
    {
      Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
      dlg.FileName = "";
      dlg.DefaultExt = ".lst";
      dlg.Filter = "List Files (.lst)|*.lst";

      bool? result = dlg.ShowDialog();

      if (result == true)
      {
        OpenListFile(dlg.FileName);
      }
    }

    /// <summary>
    /// コマンド：リストを読込 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanOpenVertexItemsExecute()
    {
      if (TmcData !=null)
        return true;
      else
        return false;
    }
    #endregion

    #region コマンド：選択行をリストから除去
    /// <summary>
    /// コマンド：選択行をリストから除去
    /// </summary>
    private DelegateCommand _RemoveVertexItemsCommand;
    public DelegateCommand RemoveVertexItemsCommand
      => _RemoveVertexItemsCommand ?? (_RemoveVertexItemsCommand = new DelegateCommand(RemoveVertexItemsExecute, CanRemoveVertexItemsExecute));

    /// <summary>
    /// コマンド：選択行をリストから除去 の実行を行います。
    /// </summary>
    private void RemoveVertexItemsExecute()
    {
      VerticesRemove();
    }

    /// <summary>
    /// コマンド：選択行をリストから除去 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanRemoveVertexItemsExecute()
    {
      if (mainWindow.dgSelection.SelectedItems.Count > 0)
        return true;
      else
        return false;
    }
    #endregion

    #region コマンド：リストをクリア
    /// <summary>
    /// コマンド：リストをクリア
    /// </summary>
    private DelegateCommand _ClearVertexItemsCommand;
    public DelegateCommand ClearVertexItemsCommand
      => _ClearVertexItemsCommand ?? (_ClearVertexItemsCommand = new DelegateCommand(ClearVertexItemsExecute, CanClearVertexItemsExecute));

    /// <summary>
    /// コマンド：リストをクリア の実行を行います。
    /// </summary>
    private void ClearVertexItemsExecute()
    {
      VerticesClear();
    }

    /// <summary>
    /// コマンド：リストをクリア が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanClearVertexItemsExecute()
    {
      if (mainWindow.dgSelection.SelectedItems.Count > 0)
        return true;
      else
        return false;
    }
    #endregion



    #region コマンド：座標範囲を初期化
    /// <summary>
    /// コマンド：座標範囲を初期化
    /// </summary>
    private DelegateCommand _ResetRangeCommand;
    public DelegateCommand ResetRangeCommand
      => _ResetRangeCommand ?? (_ResetRangeCommand = new DelegateCommand(ResetRangeExecute, CanResetRangeExecute));

    /// <summary>
    /// コマンド：座標範囲を初期化 の実行を行います。
    /// </summary>
    private void ResetRangeExecute()
    {
      InitRange();
    }

    /// <summary>
    /// コマンド：座標範囲を初期化 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanResetRangeExecute()
    {
      if (IsCheckedAddRange &&
        (
          XMin != -1 || XMax != 1 ||
          YMin != -1 || YMax != 1 ||
          YMin2 != -1 || YMax2 != 1 ||
          ZMin != -1 || ZMax != 1
        )
      )
        return true;
      else
        return false;
    }
    #endregion

    #region コマンド：UV座標範囲を初期化
    /// <summary>
    /// コマンド：UV座標範囲を初期化
    /// </summary>
    private DelegateCommand _ResetRangeUVCommand;
    public DelegateCommand ResetRangeUVCommand
      => _ResetRangeUVCommand ?? (_ResetRangeUVCommand = new DelegateCommand(ResetRangeUVExecute, CanResetRangeUVExecute));

    /// <summary>
    /// コマンド：UV座標範囲を初期化 の実行を行います。
    /// </summary>
    private void ResetRangeUVExecute()
    {
      InitRangeUV();
    }

    /// <summary>
    /// コマンド：UV座標範囲を初期化 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanResetRangeUVExecute()
    {
      if (IsCheckedAddRangeUV &&
        (
          UMin != 0 || UMax != 1 ||
          VMin != 0 || VMax != 1
        )
      )
        return true;
      else
        return false;
    }
    #endregion

    #region コマンド：頂点を追加
    /// <summary>
    /// コマンド：頂点を追加
    /// </summary>
    private DelegateCommand _AddCommand;
    public DelegateCommand AddCommand
      => _AddCommand ?? (_AddCommand = new DelegateCommand(AddExecute, CanAddExecute));

    /// <summary>
    /// コマンド：頂点を追加 の実行を行います。
    /// </summary>
    private void AddExecute()
    {
      addedCount = 0;

      if (IsCheckedAddIndex)
      {
        VerticesAddIndex();
      }
      else if (IsCheckedAddRange)
      {
        VerticesAddRange(Objects[SelectedObjectIndex][0], Objects[SelectedObjectIndex][1]);
      }
      else
      {
        VerticesAddRangeUV(Objects[SelectedObjectIndex][0], Objects[SelectedObjectIndex][1]);
      }

      ShowAddedMessage();
    }

    /// <summary>
    /// コマンド：頂点を追加 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanAddExecute()
    {
      if (TmcData != null)
        return true;
      else
        return false;
    }
    #endregion

    #region コマンド：複数のオブジェクトの頂点を追加
    /// <summary>
    /// コマンド：複数のオブジェクトの頂点を追加
    /// </summary>
    private DelegateCommand _AddMultiCommand;
    public DelegateCommand AddMultiCommand
      => _AddMultiCommand ?? (_AddMultiCommand = new DelegateCommand(AddMultiExecute, CanAddMultiExecute));

    /// <summary>
    /// コマンド：複数のオブジェクトの頂点を追加 の実行を行います。
    /// </summary>
    private void AddMultiExecute()
    {
      mainWindow.IsEnabled = false;
      bool result = ObjSelWindow.Show(mainWindow);
      mainWindow.IsEnabled = true;
      mainWindow.btnAddRow.Focus();

      if (!result) return;


      addedCount = 0;

      if (IsCheckedAddRange)
      {
        foreach (var obj in ObjSelWindow.Data.Objects)
        {
          if (obj.IsChecked) VerticesAddRange(obj.Grp, obj.Obj);
        }
      }
      else if (IsCheckedAddRangeUV)
      {
        foreach (var obj in ObjSelWindow.Data.Objects)
        {
          if (obj.IsChecked) VerticesAddRangeUV(obj.Grp, obj.Obj);
        }
      }

      ShowAddedMessage();
    }

    /// <summary>
    /// コマンド：複数のオブジェクトの頂点を追加 が実行可能かどうかの判定を行います。
    /// </summary>
    /// <returns></returns>
    private bool CanAddMultiExecute()
    {
      if (TmcData != null && (IsCheckedAddRange || IsCheckedAddRangeUV) && Objects.Count > 1)
        return true;
      else
        return false;
    }
    #endregion



    #region コマンド：クリップボードのパステキストからファイルを開く
    /// <summary>
    /// コマンド：クリップボードのパステキストからファイルを開く
    /// </summary>
    private DelegateCommand _PathPasteCommand;
    public DelegateCommand PathPasteCommand
      => _PathPasteCommand ?? (_PathPasteCommand = new DelegateCommand(PathPasteCommandExecute, () => true));

    /// <summary>
    /// コマンド：クリップボードのパステキストからファイルを開く の実行を行います。
    /// </summary>
    private void PathPasteCommandExecute()
    {
      OpenFromClipboard();
    }
    #endregion

    #region コマンド：終了
    /// <summary>
    /// コマンド：終了
    /// </summary>
    private DelegateCommand _CloseCommand;
    public DelegateCommand CloseCommand
      => _CloseCommand ?? (_CloseCommand = new DelegateCommand(CloseCommandExecute, () => true));

    /// <summary>
    /// コマンド：終了 の実行を行います。
    /// </summary>
    private void CloseCommandExecute()
    {
      mainWindow.Close();
    }
    #endregion



    #region SlideMessageText
    /// <summary>
    /// スライド表示メッセージのテキスト
    /// </summary>
    private string _SlideMessageText;
    public string SlideMessageText
    {
      get => _SlideMessageText;
      set => SetProperty(ref _SlideMessageText, value);
    }
    #endregion

    #region SlideMessageBackground
    /// <summary>
    /// スライド表示メッセージの背景
    /// </summary>
    private Brush _SlideMessageBackground;
    public Brush SlideMessageBackground
    {
      get => _SlideMessageBackground;
      set => SetProperty(ref _SlideMessageBackground, value);
    }
    #endregion

    #region storyFadeTextMessage
    /// <summary>
    /// スライド表示メッセージのストーリーボード
    /// </summary>
    private Storyboard storyFadeTextMessage;
    #endregion

    #region メソッド：SlideMessage
    public void ShowTextBlockMessage(string text)
    {
      ShowTextBlockMessage(text, new SolidColorBrush(Color.FromRgb(0x00, 0x88, 0xDD)));
    }
    public void ShowTextBlockMessage(string text, Brush background)
    {
      SlideMessageBackground = background;
      SlideMessageText = text;
      storyFadeTextMessage.SeekAlignedToLastTick(new TimeSpan(0, 0, 0));
      storyFadeTextMessage.Stop();
      storyFadeTextMessage.Begin();
    }
    public void FadeTextMessageAnimation_Completed()
    {
      storyFadeTextMessage.Stop();
      SlideMessageText = "";
    }
    #endregion

  }

}
