
!!! Caution !!!

If you downloaded from direct url, this might be old version.
Check this url.
https://www.mediafire.com/folder/9zi2gt8dyllaj/doa5mod

You are not permitted to use this tool without your agreement of the following document.
https://www.mediafire.com/folder/rbhtrb7pjlrgr/License -> License.txt

You need to install .NET Framework 4.5.x or 4.6.x.
https://msdn.microsoft.com/library/5a4x27ek.aspx



How to enable Language.dat (Delete file extension.)

Language.dat.disable => Language.dat





Movie Data Tab

-> Groups
Index : Index

-> Parameters
Index    : Index
Type     : Parameter Type
Note     : Note
and more : Parameter Data

- Context Menu on Parameters
Delete
Insert


-> Table
         : Index
Cut Name : Cut Name

- Context Menu on Table
Copy  : Copy Cut Parameters
Paste : Paste Cut Parameters



Scene Data Tab

LIGHT Tab

-> Table
     : Index
Name : Light Group Name

- Context Menu on Table
Copy  : Copy Light Parameters
Paste : Paste Light Parameters


Elevation(deg) : Elevation angle (Degree)
Direction(deg) : Direction angle (Degree)


Hdr Tab

-> Table
     : Index
Name : Wind Group Name

- Context Menu on Table
Copy  : Copy Wind Parameters
Paste : Paste Wind Parameters


WIND Tab

-> Table
     : Index
Name : Wind Group Name

- Context Menu on Table
Copy  : Copy Wind Parameters
Paste : Paste Wind Parameters


Direction(deg) : Direction angle (Degree)



Bone Motion Tab

-> Motion Groups
         : Index
Count    : Motion Count
BaseBone : Base Bone Name

-> Motions
      : Index
Count : Frame Count
Type  : Key Frame Type

Checkbox
Ignore Frm : Ignore frame number when CSV importing
Add        : Add frames to current frames when CSV importing
Keep Pos   : Keep position when CSV importing (except MOT00_Hips and Face's Bone)

Face Bone Pos.
Adjust... : Adjust position of face bones between characters (Enabled by face motion)

-> Motion Data (When Key Frame Type is Curve, All Cells are Read Only.)
Frame : Frame Number (Read Only)
Pos X : Position X
Pos Y : Position Y
Pos Z : Position Z
Rot X : Rotation X
Rot Y : Rotation Y
Rot Z : Rotation Z
Sca X : Scale X
Sca Y : Scale Y
Sca Z : Scale Z

Shift Value : Shift value of selected cells by Text Box value

- Context Menu on Motion Data
Fill Down
Delete (Visible by Frame Select)



Camera Motion Tab

Checkbox
Ignore Frm : Ignore frame number when CSV importing
Add        : Add frames to current frames when CSV importing

-> Motion Data
Frame      : Frame Number (Read Only)
Position X : Position X of Camera
Position Y : Position Y of Camera
Position Z : Position Z of Camera
POR X      : Position X of Point of Regard
POR Y      : Position Y of Point of Regard
POR Z      : Position Z of Point of Regard
Tilt       : Tilt (Degree)
Angle      : Angle of Vertical View (Degree)

Shift Value : Shift value of selected cells by Text Box value

- Context Menu on Motion Data
Fill Down
Delete (Visible by Frame Select)





Sorry, more detailed information is not in English.

Please forgive me my lousy English.
(I was using Google a lot.)





Copyright 2015-now, dtk mnr

Released under the GPL v3.0 License.
http://www.gnu.org/licenses/gpl-3.0.txt
