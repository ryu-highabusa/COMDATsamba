﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Runtime.Serialization.Formatters.Binary;
using Message;

namespace Movie_Tool
{
  /// <summary>
  /// MainWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class MainWindow : Window
  {
    private static TdpData tdpData;
    private static MovData movData;
    private static ScnData scnData;
    private static MpmData mpmData;
    private static CamData camData;

    private static MovieTables movieTables;

    private static byte[] bn;

    ContextMenu menuDataGridMovieParams = new ContextMenu();
    MenuItem menuitemMovieParamDelete = new MenuItem();
    MenuItem menuitemMovieParamInsert = new MenuItem();

    ContextMenu CopyAndPasteContextMenu = new ContextMenu();

    ContextMenu menuDataGridFrames = new ContextMenu();
    MenuItem menuitemFramesFillDown = new MenuItem();
    MenuItem menuitemFramesDelete = new MenuItem();

    private readonly static string[] undeletableTypes = new string[] { "0x0000", "0x0001", "0x003A" };
    private readonly static string[] uninsertableTypes = new string[] { "0x0000", "0x003A" };

    private static string curFilePath = "";
    private static DateTime curFileWriteTime;
    private static string curCsvPath = "";
    private static float curValue = 0;
    private static int curNum = 0;
    private static int curNumIndex = 0;
    private static uint curCount = 0;
    private static string curText = "";
    private static string firstHeaderName = "";

    private static CutData clipboardCutData;
    private static LightData clipboardLightData;
    private static HdrData clipboardHdrData;
    private static WindData clipboardWindData;

    private static bool checkChanging = false;

    private static CultureInfo curCulture = null;

    Dictionary<int, SortedSet<int>> selCellIndices;

    private static bool modifiedMovie = false;
    private static bool modifiedScene = false;
    private static bool modifiedLight = false;
    private static bool modifiedHdr = false;
    private static bool modifiedWind = false;
    private static bool modifiedBone = false;
    private static bool modifiedCam = false;

    private static SortedSet<int> motSelectedColumns = new SortedSet<int>();
    private static SortedSet<int> camSelectedColumns = new SortedSet<int>();
    int motCurrentColumnIndex = -1;
    int camCurrentColumnIndex = -1;

    private static bool appStarted = false;
    private static bool updateChecking = true;
    private static bool modified = false;
    private static bool exitConfirm = true;
    public static Dictionary<string, string> txt = new Dictionary<string, string>();
    public static string langType = "Jpn";



    public MainWindow()
    {
      InitializeComponent();

      SetBoneNames();

      MainWindowTitle();
      changeLanguage();
      MessageWindow.lang(txt);

      BuildContextMenu();

      float checkFloat;
      float.TryParse("1.1", out checkFloat);
      if (checkFloat != 1.1f)
      {
        curCulture = CultureInfo.CurrentCulture;
      }

      Application.Current.ShutdownMode = ShutdownMode.OnMainWindowClose;
    }

    private void BuildContextMenu()
    {
      menuitemMovieParamDelete.Header = txt["Delete"];
      menuitemMovieParamInsert.Header = txt["Insert"];

      menuitemMovieParamDelete.InputGestureText = "Delete";

      RoutedCommand deleteParams = this.FindResource("DeleteParams") as RoutedCommand;
      menuitemMovieParamDelete.Command = deleteParams;

      menuitemMovieParamInsert.Click += new RoutedEventHandler(menuitemMovieParamInsert_Click);

      menuDataGridMovieParams.Items.Add(menuitemMovieParamDelete);
      menuDataGridMovieParams.Items.Add(menuitemMovieParamInsert);

      dgMovieParams.ContextMenu = menuDataGridMovieParams;

      SetCopyAndPasteContextMenu(CopyAndPasteContextMenu);

      dgCuts.ContextMenu = CopyAndPasteContextMenu;

      dgLightGrps.ContextMenu = CopyAndPasteContextMenu;
      dgHdrGrps.ContextMenu = CopyAndPasteContextMenu;
      dgWindGrps.ContextMenu = CopyAndPasteContextMenu;

      menuitemFramesFillDown.Header = txt["FillDown"];
      menuitemFramesDelete.Header = txt["Delete"];

      menuitemFramesFillDown.InputGestureText = "Ctrl+D";
      menuitemFramesDelete.InputGestureText = "Delete";

      RoutedCommand fillDown = this.FindResource("FillDown") as RoutedCommand;
      menuitemFramesFillDown.Command = fillDown;

      RoutedCommand deleteFrames = this.FindResource("DeleteFrames") as RoutedCommand;
      menuitemFramesDelete.Command = deleteFrames;

      menuDataGridFrames.Items.Add(menuitemFramesFillDown);
      menuDataGridFrames.Items.Add(menuitemFramesDelete);

      dgMotionFrames.ContextMenu = menuDataGridFrames;
      dgCameraFrames.ContextMenu = menuDataGridFrames;
    }
    private void SetCopyAndPasteContextMenu(ContextMenu menu)
    {
      MenuItem menuitemCopy = new MenuItem();
      MenuItem menuitemPaste = new MenuItem();

      menuitemCopy.Header = txt["Copy"];
      menuitemPaste.Header = txt["Paste"];

      menuitemCopy.InputGestureText = "Ctrl+C";
      menuitemPaste.InputGestureText = "Ctrl+V";

      menuitemCopy.Command = ApplicationCommands.Copy;
      menuitemPaste.Command = ApplicationCommands.Paste;

      menu.Items.Add(menuitemCopy);
      menu.Items.Add(menuitemPaste);
    }

    private void Modified()
    {
      modified = true;
      textStatus.Path = curFilePath + " *";
    }

    private void mainWindow_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      if (e.LeftButton == MouseButtonState.Pressed) this.DragMove();
    }

    private void mainWindow_Loaded(object sender, RoutedEventArgs e)
    {
      List<string> cmds = System.Environment.GetCommandLineArgs().ToList();
      cmds.RemoveAt(0);
      OpenDorpFile(cmds);
    }

    private void mainWindow_DragOver(object sender, DragEventArgs e)
    {
      e.Handled = true;
      if (e.Data.GetDataPresent(DataFormats.FileDrop))
        e.Effects = DragDropEffects.Move;
      else
        e.Effects = DragDropEffects.None;
    }

    private void mainWindow_DragDrop(object sender, DragEventArgs e)
    {
      List<string> filePaths = ((string[])e.Data.GetData(DataFormats.FileDrop, false)).ToList();
      OpenDorpFile(filePaths);
    }

    private void OpenDorpFile(List<string> filePaths)
    {
      if (filePaths.Count < 1) return;

      string openPath = "";
      string csvPath = "";
      List<string> lnkPaths = new List<string>();
      foreach (string path in filePaths)
      {
        if (System.IO.Path.GetExtension(path).ToLower() == ".lnk")
        {
          lnkPaths.Add(path);
        }
        else if (csvPath == "" && System.IO.Path.GetExtension(path).ToLower() == ".csv")
        {
          csvPath = path;
        }
        else if (openPath == "" && PreOpenCheck(path))
        {
          openPath = path;
        }
      }

      if (lnkPaths.Count > 0)
      {
        Type t = Type.GetTypeFromCLSID(new Guid("72C24DD5-D70A-438B-8A42-98424B88AFB8"));
        dynamic shell = Activator.CreateInstance(t);
        List<string> shortcutPaths = new List<string>();
        foreach (string path in lnkPaths)
        {
          var shortcut = shell.CreateShortcut(path);
          shortcutPaths.Add(shortcut.TargetPath);
          System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shortcut);
        }
        System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shell);

        foreach (string path in shortcutPaths)
        {
          if (csvPath == "" && System.IO.Path.GetExtension(path).ToUpper() == ".TMC")
          {
            csvPath = path;
          }
          else if (openPath == "" && PreOpenCheck(path))
          {
            openPath = path;
            break;
          }
        }
      }

      if (openPath != "")
      {
        OpenFile(openPath);
      }
      else if (csvPath != "" && movieTables != null)
      {
        var tab = tabControl.SelectedItem as TabItem;
        if (tab.Name == "tabBone")
        {
          var motion = mpmData.Grps[movieTables.BoneMotionGrps[dgMotionGrps.SelectedIndex].Index].Motions[dgMotions.SelectedIndex];
          if (motion.Type != 0)
          {
            var result = MessageWindow.Show(this, txt["ConfirmConvertToBaked"], txt["Confirm"], txt["Continue"], txt["Cancel"]);
            if (result != MessageWindow.Result.OK) return;
          }

          ImportCsvBone(csvPath);
        }
        else if (tab.Name == "tabCamera")
        {
          ImportCsvCam(csvPath);
        }
      }
    }

    private void OpenFromClipboard()
    {
      var pathText = Clipboard.GetText();
      if (Clipboard.ContainsFileDropList())
      {
        //データを取得する（取得できなかった時はnull）
        System.Collections.Specialized.StringCollection files = Clipboard.GetFileDropList();
        if (files != null) pathText = files[0];
      }
      if (!string.IsNullOrEmpty(pathText) && File.Exists(pathText) && PreOpenCheck(pathText))
      {
        var result = MessageWindow.Show(this, pathText + "\r\n\r\n" + txt["ConfirmOpenFile"], txt["Info"], txt["btnOpen"], txt["Cancel"]);
        if (result == MessageWindow.Result.OK)
        {
          OpenFile(pathText);
        }
        Keyboard.Focus(mainWindow);
      }
    }

    private void openCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      e.CanExecute = true;
    }
    private void openCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
      dlg.Filter = "All Files|*|tdpack Files|*.tdpack|MPM Files|*.MPM|CAM Files|*.CAM|SCN Files|*.SCN";
      if (curFilePath != "")
      {
        dlg.InitialDirectory = Path.GetDirectoryName(curFilePath);
        dlg.FileName = Path.GetFileName(curFilePath);
      }
      if (dlg.ShowDialog() == true)
      {
        if (!PreOpenCheck(dlg.FileName))
        {
          MessageWindow.Show(this, txt["UnsupportedFile"], txt["Error"]);
          return;
        }

        OpenFile(dlg.FileName);
      }
    }

    private void saveCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (modified)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void saveCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      DataGrid_CommitEdit();

      var result = MessageWindow.Show(this, txt["Overwrite"], txt["Confirm"], txt["OverwriteYes"], txt["Cancel"]);
      if (result == MessageWindow.Result.OK)
      {
        SaveFile(curFilePath);
      }
    }

    private void saveWithBackupCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (modified)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void saveWithBackupCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      DataGrid_CommitEdit();

      string newPath = CreateBackup();
      if (newPath != null)
      {
        if (!SaveFile(curFilePath))
        {
          if (File.Exists(newPath)) File.Move(newPath, curFilePath);
        }
      }
      else
      {
        MessageWindow.Show(this, txt["FailedToCreateBackup"], txt["Error"]);
      }
    }

    private void saveAsCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (movData != null || scnData != null || mpmData != null || camData != null)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void saveAsCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      DataGrid_CommitEdit();

      this.IsEnabled = false;

      Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
      dlg.InitialDirectory = Path.GetDirectoryName(curFilePath);
      dlg.FileName = Path.GetFileName(curFilePath);
      if (tdpData != null)
      {
        if (Path.GetExtension(curFilePath).ToLower() == ".tdpack")
        {
          dlg.DefaultExt = ".tdpack";
          dlg.Filter = "tdpack Files|*.tdpack";
        }
        else
        {
          dlg.DefaultExt = "";
          dlg.Filter = "All Files|*";
        }
      }
      else if (mpmData != null)
      {
        dlg.DefaultExt = ".MPM";
        dlg.Filter = "MPM Files|*.MPM";
      }
      else if (camData != null)
      {
        dlg.DefaultExt = ".CAM";
        dlg.Filter = "CAM Files|*.CAM";
      }
      else
      {
        dlg.DefaultExt = ".SCN";
        dlg.Filter = "SCN Files|*.SCN";
      }

      if (dlg.ShowDialog() == true)
      {
        SaveFile(dlg.FileName);
      }

      this.IsEnabled = true;
      this.Focus();
    }

    private void fillDownCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      var dataGrid = e.Source as DataGrid;
      selCellIndices = PreCheckFillDown(dataGrid);
      if (dataGrid != null && dataGrid.SelectedCells.Count > 0 && selCellIndices != null && !(dataGrid.Name == "dgMotionFrames" && movieTables.BoneMotions[dgMotions.SelectedIndex].Type == "Curve"))
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void fillDownCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var dataGrid = e.Source as DataGrid;
      FillDown(dataGrid);
    }

    private void deleteFramesCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      var dataGrid = e.Source as DataGrid;
      if (dataGrid != null && dataGrid.SelectedItems.Count > 0 && dataGrid.Items.Count > 1 && !(dataGrid.Name == "dgMotionFrames" && movieTables.BoneMotions[dgMotions.SelectedIndex].Type == "Curve"))
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void deleteFramesCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var dataGrid = e.Source as DataGrid;
      DeleteFrames(dataGrid);
    }

    private bool PreOpenCheck(string filePath)
    {
      if (Path.GetExtension(filePath).ToUpper() == ".CAM")
      {
        return true;
      }

      using (FileStream fs = new FileStream(filePath, FileMode.Open))
      {
        byte[] b = new byte[16];
        fs.Read(b, 0, b.Length);
        if (BitConverter.ToUInt32(b, 8) != 0x01010000)
        {
          return false;
        }

        string headerName = Encoding.ASCII.GetString(b, 0, 8).TrimEnd('\0');
        if (headerName == "tdpack" || headerName == "char_dat" || headerName == "SCENE")
        {
          return true;
        }
      }
      return false;
    }

    private void DataGrid_PreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e)
    {
      var dataGrid = sender as DataGrid;
      dataGrid.Focus();
    }

    private void TextBoxParams_GotFocus(object sender, RoutedEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (target == null) return;

      target.SelectAll();

      curText = target.Text;
    }



    private void dgMovieParamGrps_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      SetMovieParams();
    }

    private void cmbVisiblePreset_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (!IsInitialized || cmbVisiblePreset.SelectedIndex == -1) return;

      SetMovieParams();
    }

    private void SetMovieParams()
    {
      gridMovieParams.IsEnabled = false;
      if (dgMovieParamGrps.SelectedIndex == -1)
      {
        if (movieTables.MovieParams.Count > 0) movieTables.MovieParams.Clear();
        return;
      }

      var grp = movData.Grps[dgMovieParamGrps.SelectedIndex];

      movieTables.SetMovieParams(grp, cmbVisiblePreset.SelectedIndex);

      while (dgMovieParams.Columns.Count > 3)
      {
        dgMovieParams.Columns.RemoveAt(3);
      }

      for (int i = 0; i < grp.MaxParamCount; i++)
      {
        var col = new DataGridTextColumn();
        col.Header = i;
        col.Width = 100;
        col.Binding = new Binding("Nums[" + i + "]");
        col.CellStyle = new Style(typeof(DataGridCell));
        col.CellStyle.BasedOn = mainWindow.Resources["DGCellMovieParam"] as Style;
        var trigger = new DataTrigger() { Value = null, Binding = new Binding("Nums[" + i + "]") };
        var setter = new Setter(DataGridCell.VisibilityProperty, Visibility.Hidden);
        trigger.Setters.Add(setter);
        col.CellStyle.Triggers.Add(trigger);
        col.EditingElementStyle = mainWindow.Resources["MovieDataCellEditingCheckElementStyle"] as Style;
        dgMovieParams.Columns.Insert(dgMovieParams.Columns.Count, col);
      }

      gridMovieParams.IsEnabled = true;
    }

    private void MovieParam_BeginningEdit(object sender, DataGridBeginningEditEventArgs e)
    {
      var dataGrid = sender as DataGrid;
      FrameworkElement contentElement = dataGrid.CurrentCell.Column.GetCellContent(dataGrid.CurrentCell.Item);
      var tb = contentElement as TextBlock;

      curNumIndex = dataGrid.CurrentCell.Column.DisplayIndex - 3;
      int val;
      if (Int32.TryParse(tb.Text, out val))
      {
        curNum = val;
      }
    }

    private void MovieParam_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
    {
      var dataGrid = sender as DataGrid;
      if (dataGrid.SelectedCells.Count < 1) return;

      var tb = e.EditingElement as TextBox;

      bool canParse = true;
      int val;
      if (!Int32.TryParse(tb.Text, out val)) canParse = false;

      if (!canParse)
      {
        tb.Text = curNum.ToString();
        return;
      }
      else if (val == curNum) return;

      var param = dataGrid.SelectedItem as MovieTables.MovieParamData;
      var grp = movData.Grps[dgMovieParamGrps.SelectedIndex];
      grp.Params[param.Index].Nums[curNumIndex] = val;
      modifiedMovie = true;
      Modified();
    }

    private void dgMovieParams_ContextMenuOpening(object sender, ContextMenuEventArgs e)
    {
      menuitemMovieParamInsert.IsEnabled = false;

      bool visibleInsert = false;

      if (dgMovieParams.SelectedItems.Count == 1)
      {
        var param = dgMovieParams.SelectedItem as MovieTables.MovieParamData;
        if (!uninsertableTypes.Contains(param.Type)) visibleInsert = true;
      }

      if (visibleInsert) menuitemMovieParamInsert.IsEnabled = true;
    }

    private void deleteParamsCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      bool visibleDelete = false;
      if (dgMovieParams.SelectedItems.Count > 0)
      {
        foreach (var item in dgMovieParams.SelectedItems)
        {
          var param = item as MovieTables.MovieParamData;
          if (!undeletableTypes.Contains(param.Type)) visibleDelete = true;
        }
      }

      if (visibleDelete)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void deleteParamsCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      if (MessageWindow.Show(this, txt["ConfirmDeleteParameters"], txt["Confirm"], txt["OK"], txt["Cancel"]) == MessageWindow.Result.Cancel) return;

      var deleteList = new List<int>();

      foreach (var item in dgMovieParams.SelectedItems)
      {
        var param = item as MovieTables.MovieParamData;
        if (undeletableTypes.Contains(param.Type)) continue;
        deleteList.Add(param.Index);
      }

      deleteList.Sort();
      deleteList.Reverse();

      var grp = movData.Grps[dgMovieParamGrps.SelectedIndex];

      foreach (var index in deleteList)
      {
        grp.Params.RemoveAt(index);
      }

      movData.ResetMaxParamCount(grp);

      SetMovieParams();
      modifiedMovie = true;
      Modified();
    }

    private void menuitemMovieParamInsert_Click(object sender, RoutedEventArgs e)
    {
      short[] valSet = InsertMovieParamWindow.Show(this);

      if (valSet == null) return;

      var grp = movData.Grps[dgMovieParamGrps.SelectedIndex];
      var selParam = dgMovieParams.SelectedItem as MovieTables.MovieParamData;

      var param = new MovieFrameParam();
      param.Type = valSet[0];
      for (int i = 0; i < valSet[1]; i++)
      {
        param.Nums.Add(0);
      }

      grp.Params.Insert(selParam.Index, param);

      movData.ResetMaxParamCount(grp);

      SetMovieParams();
      modifiedMovie = true;
      Modified();
    }


    private void dgCuts_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (!IsInitialized) return;

      SetCutParams();
    }

    private void ClearCutParams()
    {
      tbCutDofDepth.Text = "";
      tbCutDofBoundary.Text = "";
      tbCutDofAmount1.Text = "";
      tbCutDofAmount2.Text = "";
    }

    private void SetCutParams()
    {
      gridCutParams.IsEnabled = false;
      if (dgCuts.SelectedIndex == -1)
      {
        ClearCutParams();
        return;
      }

      var cut = movData.Cuts[dgCuts.SelectedIndex];

      tbCutDofDepth.Text = cut.Floats[3].ToString();
      tbCutDofBoundary.Text = cut.Floats[5].ToString();
      tbCutDofAmount1.Text = cut.Floats[7].ToString();
      tbCutDofAmount2.Text = cut.Floats[8].ToString();

      gridCutParams.IsEnabled = true;
    }

    private void tbCutParams_KeyUp(object sender, KeyEventArgs e)
    {
      modifiedMovie = true;
      Modified();
    }

    private void tbCutParams_LostFocus(object sender, RoutedEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (target == null || target.Text == curText) return;

      float val;
      if (!float.TryParse(target.Text, out val)) return;

      var cut = movData.Cuts[dgCuts.SelectedIndex];

      switch (target.Name)
      {
        case "tbCutDofDepth":
          cut.Floats[3] = val;
          break;
        case "tbCutDofBoundary":
          cut.Floats[5] = val;
          break;
        case "tbCutDofAmount1":
          cut.Floats[7] = val;
          break;
        case "tbCutDofAmount2":
          cut.Floats[8] = val;
          break;
      }
    }

    private void cutParamsCopyCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var cut = movData.Cuts[dgCuts.SelectedIndex];
      if (cut != null)
      {
        BinaryFormatter bf = new BinaryFormatter();
        MemoryStream ms = new MemoryStream();
        bf.Serialize(ms, cut);
        Clipboard.SetDataObject(ms);
      }
    }

    private void cutParamsPasteCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      clipboardCutData = null;
      var data = GetDataFromClipboard();
      if (data is CutData)
        clipboardCutData = data as CutData;

      if (clipboardCutData != null)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void cutParamsPasteCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      foreach (var item in dgCuts.SelectedItems)
      {
        var grp = item as MovieTables.MovieCutData;
        var cut = movData.Cuts[grp.Index];
        cut.ParamsCopy(clipboardCutData);
      }

      modifiedMovie = true;
      Modified();

      SetCutParams();
    }


    private void dgLightGrps_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (!IsInitialized) return;

      SetLightParams();
    }

    private void ClearLightParams()
    {
      checkChanging = true;

      cbAmbient.IsChecked = false;
      tbAmbientR1.Text = "";
      tbAmbientG1.Text = "";
      tbAmbientB1.Text = "";
      tbAmbientR2.Text = "";
      tbAmbientG2.Text = "";
      tbAmbientB2.Text = "";

      tbAmbientSub1R.Text = "";
      tbAmbientSub1G.Text = "";
      tbAmbientSub1B.Text = "";
      tbAmbientSub2R.Text = "";
      tbAmbientSub2G.Text = "";
      tbAmbientSub2B.Text = "";

      cbLightMain.IsChecked = false;
      tbLightMainR.Text = "";
      tbLightMainG.Text = "";
      tbLightMainB.Text = "";
      tbLightMainElevation.Text = "";
      tbLightMainDirection.Text = "";
      cbLightMainPoint.IsChecked = false;

      cbLightSub1.IsChecked = false;
      tbLightSub1R.Text = "";
      tbLightSub1G.Text = "";
      tbLightSub1B.Text = "";
      tbLightSub1Elevation.Text = "";
      tbLightSub1Direction.Text = "";
      cbLightSub1Point.IsChecked = false;

      cbLightSub2.IsChecked = false;
      tbLightSub2R.Text = "";
      tbLightSub2G.Text = "";
      tbLightSub2B.Text = "";
      tbLightSub2Elevation.Text = "";
      tbLightSub2Direction.Text = "";
      cbLightSub2Point.IsChecked = false;

      tbLightShadowR.Text = "";
      tbLightShadowG.Text = "";
      tbLightShadowB.Text = "";

      checkChanging = false;
    }

    private void SetLightParams()
    {
      gridLightParams.IsEnabled = false;
      if (dgLightGrps.SelectedIndex == -1)
      {
        ClearLightParams();
        return;
      }

      var light = scnData.Lights[dgLightGrps.SelectedIndex];

      checkChanging = true;

      if (light.AmbientFlag == 0)
        cbAmbient.IsChecked = true;
      else
        cbAmbient.IsChecked = false;
      tbAmbientR1.Text = light.AmbientColor[0].ToString();
      tbAmbientG1.Text = light.AmbientColor[1].ToString();
      tbAmbientB1.Text = light.AmbientColor[2].ToString();
      tbAmbientR2.Text = light.AmbientSpeColor[0].ToString();
      tbAmbientG2.Text = light.AmbientSpeColor[1].ToString();
      tbAmbientB2.Text = light.AmbientSpeColor[2].ToString();

      tbAmbientSub1R.Text = light.AmbientSub1Color[0].ToString();
      tbAmbientSub1G.Text = light.AmbientSub1Color[1].ToString();
      tbAmbientSub1B.Text = light.AmbientSub1Color[2].ToString();
      tbAmbientSub2R.Text = light.AmbientSub2Color[0].ToString();
      tbAmbientSub2G.Text = light.AmbientSub2Color[1].ToString();
      tbAmbientSub2B.Text = light.AmbientSub2Color[2].ToString();

      cbLightMain.IsChecked = light.MainEnable;
      tbLightMainR.Text = light.MainColor[0].ToString();
      tbLightMainG.Text = light.MainColor[1].ToString();
      tbLightMainB.Text = light.MainColor[2].ToString();
      tbLightMainElevation.Text = (light.MainAngleElevation * 180 / Math.PI).ToString("F6");
      tbLightMainDirection.Text = (light.MainAngleDirection * 180 / Math.PI).ToString("F6");
      cbLightMainPoint.IsChecked = light.MainPoint;

      cbLightSub1.IsChecked = light.Sub1Enable;
      tbLightSub1R.Text = light.Sub1Color[0].ToString();
      tbLightSub1G.Text = light.Sub1Color[1].ToString();
      tbLightSub1B.Text = light.Sub1Color[2].ToString();
      tbLightSub1Elevation.Text = (light.Sub1AngleElevation * 180 / Math.PI).ToString("F6");
      tbLightSub1Direction.Text = (light.Sub1AngleDirection * 180 / Math.PI).ToString("F6");
      cbLightSub1Point.IsChecked = light.Sub1Point;

      cbLightSub2.IsChecked = light.Sub2Enable;
      tbLightSub2R.Text = light.Sub2Color[0].ToString();
      tbLightSub2G.Text = light.Sub2Color[1].ToString();
      tbLightSub2B.Text = light.Sub2Color[2].ToString();
      tbLightSub2Elevation.Text = (light.Sub2AngleElevation * 180 / Math.PI).ToString("F6");
      tbLightSub2Direction.Text = (light.Sub2AngleDirection * 180 / Math.PI).ToString("F6");
      cbLightSub2Point.IsChecked = light.Sub2Point;

      tbLightShadowR.Text = light.SelfShadowColor[0].ToString();
      tbLightShadowG.Text = light.SelfShadowColor[1].ToString();
      tbLightShadowB.Text = light.SelfShadowColor[2].ToString();

      checkChanging = false;

      gridLightParams.IsEnabled = true;
    }

    private void cbLightParams_CheckeChanged(object sender, RoutedEventArgs e)
    {
      if (!IsInitialized) return;

      var cb = sender as CheckBox;

      switch (cb.Name)
      {
        case "cbAmbient":
          panelAmbient.IsEnabled = (bool)cb.IsChecked;
          break;
        case "cbLightMain":
          panelLightMain.IsEnabled = (bool)cb.IsChecked;
          break;
        case "cbLightSub1":
          panelLightSub1.IsEnabled = (bool)cb.IsChecked;
          break;
        case "cbLightSub2":
          panelLightSub2.IsEnabled = (bool)cb.IsChecked;
          break;
      }

      if (checkChanging) return;


      var light = scnData.Lights[dgLightGrps.SelectedIndex];

      switch (cb.Name)
      {
        case "cbAmbient":
          if ((bool)cb.IsChecked)
            light.AmbientFlag = 0;
          else
            light.AmbientFlag = 1;
          break;
        case "cbLightMain":
          light.MainEnable = (bool)cb.IsChecked;
          break;
        case "cbLightSub1":
          light.Sub1Enable = (bool)cb.IsChecked;
          break;
        case "cbLightSub2":
          light.Sub2Enable = (bool)cb.IsChecked;
          break;
        case "cbLightMainPoint":
          light.MainPoint = (bool)cb.IsChecked;
          break;
        case "cbLightSub1Point":
          light.Sub1Point = (bool)cb.IsChecked;
          break;
        case "cbLightSub2Point":
          light.Sub2Point = (bool)cb.IsChecked;
          break;
      }

      modifiedScene = true;
      modifiedLight = true;
      Modified();
    }

    private void tbLightParams_KeyUp(object sender, KeyEventArgs e)
    {
      modifiedScene = true;
      modifiedLight = true;
      Modified();
    }

    private void tbLightParams_LostFocus(object sender, RoutedEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (target == null || target.Text == curText) return;

      float val;
      if (!float.TryParse(target.Text, out val)) return;

      var light = scnData.Lights[dgLightGrps.SelectedIndex];

      switch (target.Name)
      {
        case "tbAmbientR1":
          light.AmbientColor[0] = val;
          break;
        case "tbAmbientG1":
          light.AmbientColor[1] = val;
          break;
        case "tbAmbientB1":
          light.AmbientColor[2] = val;
          break;
        case "tbAmbientR2":
          light.AmbientSpeColor[0] = val;
          break;
        case "tbAmbientG2":
          light.AmbientSpeColor[1] = val;
          break;
        case "tbAmbientB2":
          light.AmbientSpeColor[2] = val;
          break;
        case "tbAmbientSub1R":
          light.AmbientSub1Color[0] = val;
          break;
        case "tbAmbientSub1G":
          light.AmbientSub1Color[1] = val;
          break;
        case "tbAmbientSub1B":
          light.AmbientSub1Color[2] = val;
          break;
        case "tbAmbientSub2R":
          light.AmbientSub2Color[0] = val;
          break;
        case "tbAmbientSub2G":
          light.AmbientSub2Color[1] = val;
          break;
        case "tbAmbientSub2B":
          light.AmbientSub2Color[2] = val;
          break;
        case "tbLightMainR":
          light.MainColor[0] = val;
          break;
        case "tbLightMainG":
          light.MainColor[1] = val;
          break;
        case "tbLightMainB":
          light.MainColor[2] = val;
          break;
        case "tbLightMainElevation":
          light.MainAngleElevation = (float)(val / 180 * Math.PI);
          break;
        case "tbLightMainDirection":
          light.MainAngleDirection = (float)(val / 180 * Math.PI);
          break;
        case "tbLightSub1R":
          light.Sub1Color[0] = val;
          break;
        case "tbLightSub1G":
          light.Sub1Color[1] = val;
          break;
        case "tbLightSub1B":
          light.Sub1Color[2] = val;
          break;
        case "tbLightSub1Elevation":
          light.Sub1AngleElevation = (float)(val / 180 * Math.PI);
          break;
        case "tbLightSub1Direction":
          light.Sub1AngleDirection = (float)(val / 180 * Math.PI);
          break;
        case "tbLightSub2R":
          light.Sub2Color[0] = val;
          break;
        case "tbLightSub2G":
          light.Sub2Color[1] = val;
          break;
        case "tbLightSub2B":
          light.Sub2Color[2] = val;
          break;
        case "tbLightSub2Elevation":
          light.Sub2AngleElevation = (float)(val / 180 * Math.PI);
          break;
        case "tbLightSub2Direction":
          light.Sub2AngleDirection = (float)(val / 180 * Math.PI);
          break;
        case "tbLightShadowR":
          light.SelfShadowColor[0] = val;
          break;
        case "tbLightShadowG":
          light.SelfShadowColor[1] = val;
          break;
        case "tbLightShadowB":
          light.SelfShadowColor[2] = val;
          break;
      }
    }

    private void lightParamsCopyCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var light = scnData.Lights[dgLightGrps.SelectedIndex];
      if (light != null)
      {
        BinaryFormatter bf = new BinaryFormatter();
        MemoryStream ms = new MemoryStream();
        bf.Serialize(ms, light);
        Clipboard.SetDataObject(ms);
      }
    }

    private void lightParamsPasteCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      clipboardLightData = null;
      var data = GetDataFromClipboard();
      if (data is LightData)
        clipboardLightData = data as LightData;

      if (clipboardLightData != null)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void lightParamsPasteCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      foreach (var item in dgLightGrps.SelectedItems)
      {
        var grp = item as MovieTables.LightGrpData;
        var light = scnData.Lights[grp.Index];
        light.ParamsCopy(clipboardLightData);
      }

      modifiedScene = true;
      modifiedLight = true;
      Modified();

      SetLightParams();
    }


    private void dgHdrGrps_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (!IsInitialized) return;

      SetHdrParams();
    }

    private void ClearHdrParams()
    {
      tbHdrR.Text = "";
      tbHdrG.Text = "";
      tbHdrB.Text = "";
      tbHdrUnknown.Text = "";
      tbHdrParamR.Text = "";
      tbHdrParamG.Text = "";
      tbHdrParamB.Text = "";
    }

    private void SetHdrParams()
    {
      gridHdrParams.IsEnabled = false;
      if (dgHdrGrps.SelectedIndex == -1)
      {
        ClearHdrParams();
        return;
      }

      var hdr = scnData.Hdrs[dgHdrGrps.SelectedIndex];

      tbHdrR.Text = hdr.Params[4].ToString();
      tbHdrG.Text = hdr.Params[5].ToString();
      tbHdrB.Text = hdr.Params[6].ToString();
      tbHdrUnknown.Text = hdr.Params[7].ToString();

      tbHdrParamR.Text = hdr.Params[0].ToString();
      tbHdrParamG.Text = hdr.Params[1].ToString();
      tbHdrParamB.Text = hdr.Params[2].ToString();

      gridHdrParams.IsEnabled = true;
    }

    private void tbHdrParams_KeyUp(object sender, KeyEventArgs e)
    {
      modifiedScene = true;
      modifiedHdr = true;
      Modified();
    }

    private void tbHdrParams_LostFocus(object sender, RoutedEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (target == null || target.Text == curText) return;

      float val;
      if (!float.TryParse(target.Text, out val)) return;

      var hdr = scnData.Hdrs[dgHdrGrps.SelectedIndex];

      switch (target.Name)
      {
        case "tbHdrR":
          hdr.Params[4] = val;
          break;
        case "tbHdrG":
          hdr.Params[5] = val;
          break;
        case "tbHdrB":
          hdr.Params[6] = val;
          break;
        case "tbHdrUnknown":
          hdr.Params[7] = val;
          break;

        case "tbHdrParamR":
          hdr.Params[0] = val;
          break;
        case "tbHdrParamG":
          hdr.Params[1] = val;
          break;
        case "tbHdrParamB":
          hdr.Params[2] = val;
          break;
      }
    }

    private void hdrParamsCopyCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var hdr = scnData.Hdrs[dgHdrGrps.SelectedIndex];
      if (hdr != null)
      {
        BinaryFormatter bf = new BinaryFormatter();
        MemoryStream ms = new MemoryStream();
        bf.Serialize(ms, hdr);
        Clipboard.SetDataObject(ms);
      }
    }

    private void hdrParamsPasteCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      clipboardHdrData = null;
      var data = GetDataFromClipboard();
      if (data is HdrData)
        clipboardHdrData = data as HdrData;

      if (clipboardHdrData != null)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void hdrParamsPasteCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      foreach (var item in dgHdrGrps.SelectedItems)
      {
        var grp = item as MovieTables.HdrGrpData;
        var hdr = scnData.Hdrs[grp.Index];
        hdr.ParamsCopy(clipboardHdrData);
      }

      modifiedScene = true;
      modifiedHdr = true;
      Modified();

      SetHdrParams();
    }


    private void dgWindGrps_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (!IsInitialized) return;

      SetWindParams();
    }

    private void ClearWindParams()
    {
      tbWind1and2Flag1.Text = "";
      tbWind1and2Flag2.Text = "";
      tbWind1and2Flag3.Text = "";
      tbWind1and2Flag4.Text = "";
      tbWind1Force.Text = "";
      tbWind1Vertical.Text = "";
      tbWind1Direction.Text = "";
      tbWind2Force.Text = "";
      tbWind2Vertical.Text = "";
      tbWind2Direction.Text = "";
      tbWind1and2Force.Text = "";
      tbWind1and2Vertical.Text = "";
      tbWind1and2Direction.Text = "";

      tbWind3and4Flag1.Text = "";
      tbWind3and4Flag2.Text = "";
      tbWind3and4Flag3.Text = "";
      tbWind3and4Flag4.Text = "";
      tbWind3Force.Text = "";
      tbWind3Vertical.Text = "";
      tbWind3Direction.Text = "";
      tbWind4Force.Text = "";
      tbWind4Vertical.Text = "";
      tbWind4Direction.Text = "";
      tbWind3and4Force.Text = "";
      tbWind3and4Vertical.Text = "";
      tbWind3and4Direction.Text = "";

      tbWind5and6Flag1.Text = "";
      tbWind5and6Flag2.Text = "";
      tbWind5and6Flag3.Text = "";
      tbWind5and6Flag4.Text = "";
      tbWind5Force.Text = "";
      tbWind5Vertical.Text = "";
      tbWind5Direction.Text = "";
      tbWind6Force.Text = "";
      tbWind6Vertical.Text = "";
      tbWind6Direction.Text = "";
      tbWind5and6Force.Text = "";
      tbWind5and6Vertical.Text = "";
      tbWind5and6Direction.Text = "";
    }

    private void SetWindParams()
    {
      gridWindParams.IsEnabled = false;
      if (dgWindGrps.SelectedIndex == -1)
      {
        ClearWindParams();
        return;
      }

      var wind = scnData.Winds[dgWindGrps.SelectedIndex];

      tbWind1and2Flag1.Text = wind.Nums1[0].ToString();
      tbWind1and2Flag2.Text = wind.Nums1[1].ToString();
      tbWind1and2Flag3.Text = wind.Nums1[2].ToString();
      tbWind1and2Flag4.Text = wind.Nums1[3].ToString();
      tbWind1Force.Text = wind.Params[0].Param1.ToString();
      tbWind1Vertical.Text = wind.Params[1].Param1.ToString();
      tbWind1Direction.Text = wind.Params[2].Param1.ToString();
      tbWind2Force.Text = wind.Params[0].Param2.ToString();
      tbWind2Vertical.Text = wind.Params[1].Param2.ToString();
      tbWind2Direction.Text = wind.Params[2].Param2.ToString();
      tbWind1and2Force.Text = wind.Params[0].Param3.ToString();
      tbWind1and2Vertical.Text = wind.Params[1].Param3.ToString();
      tbWind1and2Direction.Text = wind.Params[2].Param3.ToString();

      tbWind3and4Flag1.Text = wind.Nums2[0].ToString();
      tbWind3and4Flag2.Text = wind.Nums2[1].ToString();
      tbWind3and4Flag3.Text = wind.Nums2[2].ToString();
      tbWind3and4Flag4.Text = wind.Nums2[3].ToString();
      tbWind3Force.Text = wind.Params[3].Param1.ToString();
      tbWind3Vertical.Text = wind.Params[4].Param1.ToString();
      tbWind3Direction.Text = wind.Params[5].Param1.ToString();
      tbWind4Force.Text = wind.Params[3].Param2.ToString();
      tbWind4Vertical.Text = wind.Params[4].Param2.ToString();
      tbWind4Direction.Text = wind.Params[5].Param2.ToString();
      tbWind3and4Force.Text = wind.Params[3].Param3.ToString();
      tbWind3and4Vertical.Text = wind.Params[4].Param3.ToString();
      tbWind3and4Direction.Text = wind.Params[5].Param3.ToString();

      tbWind5and6Flag1.Text = wind.Nums3[0].ToString();
      tbWind5and6Flag2.Text = wind.Nums3[1].ToString();
      tbWind5and6Flag3.Text = wind.Nums3[2].ToString();
      tbWind5and6Flag4.Text = wind.Nums3[3].ToString();
      tbWind5Force.Text = wind.Params[6].Param1.ToString();
      tbWind5Vertical.Text = wind.Params[7].Param1.ToString();
      tbWind5Direction.Text = wind.Params[8].Param1.ToString();
      tbWind6Force.Text = wind.Params[6].Param2.ToString();
      tbWind6Vertical.Text = wind.Params[7].Param2.ToString();
      tbWind6Direction.Text = wind.Params[8].Param2.ToString();
      tbWind5and6Force.Text = wind.Params[6].Param3.ToString();
      tbWind5and6Vertical.Text = wind.Params[7].Param3.ToString();
      tbWind5and6Direction.Text = wind.Params[8].Param3.ToString();

      gridWindParams.IsEnabled = true;
    }

    private void tbWindParams_KeyUp(object sender, KeyEventArgs e)
    {
      modifiedScene = true;
      modifiedWind = true;
      Modified();
    }

    private void tbWindParams_LostFocus(object sender, RoutedEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (target == null || target.Text == curText) return;

      float val;
      if (!float.TryParse(target.Text, out val)) return;

      var wind = scnData.Winds[dgWindGrps.SelectedIndex];

      switch (target.Name)
      {
        case "tbWind1Force":
          wind.Params[0].Param1 = val;
          break;
        case "tbWind1Vertical":
          wind.Params[1].Param1 = val;
          break;
        case "tbWind1Direction":
          wind.Params[2].Param1 = val;
          break;
        case "tbWind2Force":
          wind.Params[0].Param2 = val;
          break;
        case "tbWind2Vertical":
          wind.Params[1].Param2 = val;
          break;
        case "tbWind2Direction":
          wind.Params[2].Param2 = val;
          break;

        case "tbWind3Force":
          wind.Params[3].Param1 = val;
          break;
        case "tbWind3Vertical":
          wind.Params[4].Param1 = val;
          break;
        case "tbWind3Direction":
          wind.Params[5].Param1 = val;
          break;
        case "tbWind4Force":
          wind.Params[3].Param2 = val;
          break;
        case "tbWind4Vertical":
          wind.Params[4].Param2 = val;
          break;
        case "tbWind4Direction":
          wind.Params[5].Param2 = val;
          break;

        case "tbWind5Force":
          wind.Params[6].Param1 = val;
          break;
        case "tbWind5Vertical":
          wind.Params[7].Param1 = val;
          break;
        case "tbWind5Direction":
          wind.Params[8].Param1 = val;
          break;
        case "tbWind6Force":
          wind.Params[6].Param2 = val;
          break;
        case "tbWind6Vertical":
          wind.Params[7].Param2 = val;
          break;
        case "tbWind6Direction":
          wind.Params[8].Param2 = val;
          break;
      }
    }

    private void tbWindParamsInt_LostFocus(object sender, RoutedEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (target == null || target.Text == curText) return;

      int val;
      if (!int.TryParse(target.Text, out val)) return;

      var wind = scnData.Winds[dgWindGrps.SelectedIndex];

      switch (target.Name)
      {
        case "tbWind1and2Flag1":
          wind.Nums1[0] = val;
          break;
        case "tbWind1and2Flag2":
          wind.Nums1[1] = val;
          break;
        case "tbWind1and2Flag3":
          wind.Nums1[2] = val;
          break;
        case "tbWind1and2Flag4":
          wind.Nums1[3] = val;
          break;
        case "tbWind1and2Force":
          wind.Params[0].Param3 = val;
          break;
        case "tbWind1and2Vertical":
          wind.Params[1].Param3 = val;
          break;
        case "tbWind1and2Direction":
          wind.Params[2].Param3 = val;
          break;

        case "tbWind3and4Flag1":
          wind.Nums2[0] = val;
          break;
        case "tbWind3and4Flag2":
          wind.Nums2[1] = val;
          break;
        case "tbWind3and4Flag3":
          wind.Nums2[2] = val;
          break;
        case "tbWind3and4Flag4":
          wind.Nums2[3] = val;
          break;
        case "tbWind3and4Force":
          wind.Params[3].Param3 = val;
          break;
        case "tbWind3and4Vertical":
          wind.Params[4].Param3 = val;
          break;
        case "tbWind3and4Direction":
          wind.Params[5].Param3 = val;
          break;

        case "tbWind5and6Flag1":
          wind.Nums3[0] = val;
          break;
        case "tbWind5and6Flag2":
          wind.Nums3[1] = val;
          break;
        case "tbWind5and6Flag3":
          wind.Nums3[2] = val;
          break;
        case "tbWind5and6Flag4":
          wind.Nums3[3] = val;
          break;
        case "tbWind5and6Force":
          wind.Params[6].Param3 = val;
          break;
        case "tbWind5and6Vertical":
          wind.Params[7].Param3 = val;
          break;
        case "tbWind5and6Direction":
          wind.Params[8].Param3 = val;
          break;
      }
    }

    private void windParamsCopyCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var wind = scnData.Winds[dgWindGrps.SelectedIndex];
      if (wind != null)
      {
        BinaryFormatter bf = new BinaryFormatter();
        MemoryStream ms = new MemoryStream();
        bf.Serialize(ms, wind);
        Clipboard.SetDataObject(ms);
      }
    }

    private void windParamsPasteCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      clipboardWindData = null;
      var data = GetDataFromClipboard();
      if (data is WindData)
        clipboardWindData = data as WindData;

      if (clipboardWindData != null)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void windParamsPasteCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      foreach (var item in dgWindGrps.SelectedItems)
      {
        var grp = item as MovieTables.WindGrpData;
        var wind = scnData.Winds[grp.Index];
        wind.ParamsCopy(clipboardWindData);
      }

      modifiedScene = true;
      modifiedWind = true;
      Modified();

      SetWindParams();
    }


    private object GetDataFromClipboard()
    {
      try
      {
        IDataObject clipboardData = Clipboard.GetDataObject();
        if (clipboardData != null)
        {
          if (clipboardData.GetDataPresent(typeof(MemoryStream)))
          {
            using (MemoryStream stream = clipboardData.GetData(typeof(MemoryStream)) as MemoryStream)
            {
              BinaryFormatter bf = new BinaryFormatter();
              return bf.Deserialize(stream);
            }
          }
        }
        return null;
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
        return null;
      }
    }


    private void dgMotionGrps_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (!IsInitialized) return;

      var dataGrid = sender as DataGrid;

      if (dataGrid.SelectedIndex == -1)
      {
        if (movieTables.BoneMotions.Count > 0) movieTables.BoneMotions.Clear();
        gridMotions.IsEnabled = false;

        return;
      }

      var grp = mpmData.Grps[movieTables.BoneMotionGrps[dataGrid.SelectedIndex].Index];

      movieTables.SetBoneMotions(grp);

      if (movieTables.BoneMotions.Count > 0) dgMotions.SelectedIndex = 0;

      gridMotions.IsEnabled = true;
    }

    private void dgMotions_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (!IsInitialized) return;

      var dataGrid = sender as DataGrid;

      if (lbBones.Items.Count > 0) lbBones.Items.Clear();

      if (dataGrid.SelectedIndex == -1)
      {
        if (lbBones.Items.Count > 0) lbBones.SelectedIndex = -1;
        panelMotionBtn.IsEnabled = false;
        gridMotionFrames.IsEnabled = false;

        return;
      }

      var grp = mpmData.Grps[movieTables.BoneMotionGrps[dgMotionGrps.SelectedIndex].Index];
      var motion = movieTables.BoneMotions[dataGrid.SelectedIndex];

      SetBonesList(grp, motion);

      if (lbBones.Items.Count > 0)
      {
        if (lbBones.SelectedIndex == -1)
        {
          lbBones.SelectedIndex = 0;
        }
        else
        {
          int curSelectIndex = lbBones.SelectedIndex;
          lbBones.SelectedIndex = -1;
          lbBones.SelectedIndex = curSelectIndex;
        }
      }
      panelFacePosAdjust.IsEnabled = true;
      panelMotionBtn.IsEnabled = true;
      gridMotionFrames.IsEnabled = true;
      panelMotShiftVal.IsEnabled = true;
      cbAddMot.IsEnabled = true;

      if (grp.BaseBoneName != "OPT_Face_Root" || motion.Type == "Curve")
      {
        panelFacePosAdjust.IsEnabled = false;
      }

      if (motion.Type == "Curve")
      {
        panelMotShiftVal.IsEnabled = false;
        cbAddMot.IsEnabled = false;
      }
    }

    private void SetBonesList(MotionGroup grp, MovieTables.BoneMotionBaseData motion)
    {
      if (grp.Hies.Count > motion.BoneCount)
      {
        for (int i = 0; i < motion.BoneCount; i++)
        {
          lbBones.Items.Add(i.ToString());
        }
      }
      else if (bonenames.ContainsKey(grp.BaseBoneName))
      {
        foreach (var bone in bonenames[grp.BaseBoneName])
        {
          lbBones.Items.Add(bone);

          if (lbBones.Items.Count >= motion.BoneCount) break;
        }
      }
      else
      {
        foreach (var hie in grp.Hies)
        {
          lbBones.Items.Add(hie.Index.ToString());
        }
      }
    }

    private void btnImportCsvBone_Click(object sender, RoutedEventArgs e)
    {
      var motion = mpmData.Grps[movieTables.BoneMotionGrps[dgMotionGrps.SelectedIndex].Index].Motions[dgMotions.SelectedIndex];
      if (motion.Type != 0)
      {
        var result = MessageWindow.Show(this, txt["ConfirmConvertToBaked"], txt["Confirm"], txt["Continue"], txt["Cancel"]);
        if (result != MessageWindow.Result.OK) return;
      }

      Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
      dlg.Filter = "CSV Files (.csv)|*.csv";
      if (curCsvPath != "")
      {
        dlg.InitialDirectory = Path.GetDirectoryName(curCsvPath);
        dlg.FileName = Path.GetFileName(curCsvPath);
      }
      if (dlg.ShowDialog() == true)
      {
        ImportCsvBone(dlg.FileName);
      }
    }

    private void btnExportCsvBone_Click(object sender, RoutedEventArgs e)
    {
      Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
      if (curCsvPath == "")
      {
        dlg.InitialDirectory = Path.GetDirectoryName(curFilePath);
      }
      else
      {
        dlg.InitialDirectory = Path.GetDirectoryName(curCsvPath);
      }
      dlg.FileName = Path.GetFileNameWithoutExtension(curFilePath) + "_Bone_" + movieTables.BoneMotionGrps[dgMotionGrps.SelectedIndex].Index + "_" + dgMotions.SelectedIndex;
      dlg.Filter = "CSV Files (.csv)|*.csv";

      if (dlg.ShowDialog() == true)
      {
        ExportCsvBone(dlg.FileName);
      }
    }

    private void lbBones_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (!IsInitialized) return;

      var listBox = sender as ListBox;

      dgcBonePosX.IsReadOnly = true;
      dgcBonePosY.IsReadOnly = true;
      dgcBonePosZ.IsReadOnly = true;
      dgcBoneRotX.IsReadOnly = true;
      dgcBoneRotY.IsReadOnly = true;
      dgcBoneRotZ.IsReadOnly = true;
      dgcBoneScaX.IsReadOnly = true;
      dgcBoneScaY.IsReadOnly = true;
      dgcBoneScaZ.IsReadOnly = true;

      if (motSelectedColumns.Count > 0) motSelectedColumns.Clear();
      motCurrentColumnIndex = -1;

      if (listBox.SelectedIndex == -1)
      {
        if (movieTables.BoneMotFrames.Count > 0) movieTables.BoneMotFrames.Clear();
        dgMotionFrames.IsEnabled = false;
        return;
      }

      var motion = mpmData.Grps[movieTables.BoneMotionGrps[dgMotionGrps.SelectedIndex].Index].Motions[dgMotions.SelectedIndex];
      movieTables.SetBoneMotionFrame(motion, listBox.SelectedIndex);

      if (motion.Type == 0)
      {
        dgcBonePosX.IsReadOnly = false;
        dgcBonePosY.IsReadOnly = false;
        dgcBonePosZ.IsReadOnly = false;
        dgcBoneRotX.IsReadOnly = false;
        dgcBoneRotY.IsReadOnly = false;
        dgcBoneRotZ.IsReadOnly = false;
        dgcBoneScaX.IsReadOnly = false;
        dgcBoneScaY.IsReadOnly = false;
        dgcBoneScaZ.IsReadOnly = false;

        btnExportCsvBone.IsEnabled = true;
      }
      else
      {
        btnExportCsvBone.IsEnabled = false;
      }

      dgMotionFrames.IsEnabled = true;
    }


    private void dgCameraMotions_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (!IsInitialized) return;

      var dataGrid = sender as DataGrid;

      if (camSelectedColumns.Count > 0) camSelectedColumns.Clear();
      camCurrentColumnIndex = -1;

      if (dataGrid.SelectedIndex == -1)
      {
        if (movieTables.CamMotFrames.Count > 0) movieTables.CamMotFrames.Clear();
        gridCameraFrames.IsEnabled = false;

        return;
      }

      var motion = camData.Motions[dataGrid.SelectedIndex];

      movieTables.SetCameraMotionFrame(motion);

      //cbCamRepeat.IsEnabled = motion.Repeatable;
      cbCamRepeat.IsChecked = motion.Repeat;
      tbCamRepeatStart.Text = motion.RepeatStart.ToString();

      gridCameraFrames.IsEnabled = true;
    }

    private void cbCamRepeat_CheckChanged(object sender, RoutedEventArgs e)
    {
      if (!IsInitialized) return;

      tbCamRepeatStart.IsEnabled = (bool)cbCamRepeat.IsChecked;
      if (dgCameraMotions.SelectedIndex != -1)
        camData.Motions[dgCameraMotions.SelectedIndex].Repeat = (bool)cbCamRepeat.IsChecked;
    }

    private void tbCamRepeatStart_KeyUp(object sender, KeyEventArgs e)
    {
      Modified();
      modifiedCam = true;
    }

    private void tbCamRepeatStart_LostFocus(object sender, RoutedEventArgs e)
    {
      var tb = sender as TextBox;

      if (dgCameraMotions.SelectedIndex == -1) return;

      uint outInt;
      if (uint.TryParse(tb.Text, out outInt))
      {
        camData.Motions[dgCameraMotions.SelectedIndex].RepeatStart = outInt;
      }
      else
      {
        camData.Motions[dgCameraMotions.SelectedIndex].RepeatStart = null;
      }
    }

    private void btnCamFpsToHalf_Click(object sender, RoutedEventArgs e)
    {
      int selIndex = dgCameraMotions.SelectedIndex;
      var framesData = camData.Motions[selIndex].Frames;

      for (int i = framesData.Count - 1; i > 0; i--)
      {
        if (framesData[i].Frame % 2 == 0) continue;

        framesData.RemoveAt(i);
      }
      for (int i = 0; i < framesData.Count; i++)
      {
        framesData[i].Frame = i;
      }

      camData.Motions[selIndex].FrameCount = framesData.Count;
      movieTables.CameraMotions[selIndex].FrameCount = framesData.Count;

      movieTables.SetCameraMotionFrame(camData.Motions[selIndex]);

      Modified();
      modifiedCam = true;
    }

    private void btnImportCsvCam_Click(object sender, RoutedEventArgs e)
    {
      Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
      dlg.Filter = "CSV Files (.csv)|*.csv";
      if (curCsvPath != "")
      {
        dlg.InitialDirectory = Path.GetDirectoryName(curCsvPath);
        dlg.FileName = Path.GetFileName(curCsvPath);
      }
      if (dlg.ShowDialog() == true)
      {
        ImportCsvCam(dlg.FileName);
      }
    }

    private void btnExportCsvCam_Click(object sender, RoutedEventArgs e)
    {
      Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
      if (curCsvPath == "")
      {
        dlg.InitialDirectory = Path.GetDirectoryName(curFilePath);
      }
      else
      {
        dlg.InitialDirectory = Path.GetDirectoryName(curCsvPath);
      }
      dlg.FileName = Path.GetFileNameWithoutExtension(curFilePath) + "_Cam_" + dgCameraMotions.SelectedIndex;
      dlg.Filter = "CSV Files (.csv)|*.csv";

      if (dlg.ShowDialog() == true)
      {
        ExportCsvCam(dlg.FileName);
      }
    }


    private void btnAdjust_Click(object sender, RoutedEventArgs e)
    {
      var charaSet = CharacterChangeWindow.Show(this);

      if (charaSet == null) return;

      SetfaceLoc();

      var grp = mpmData.Grps[movieTables.BoneMotionGrps[dgMotionGrps.SelectedIndex].Index];
      var motion = grp.Motions[dgMotions.SelectedIndex];

      int boneIndex = 0;
      List<List<float>> offsetsSet = new List<List<float>>();
      for (int i = 387; i < 390; i++)
      {
        List<float> offsets = new List<float>();

        for (int j = 0; j < motion.Parts[i].Frames.Count; j++)
        {
          offsets.Add(motion.Parts[i].Frames[j].Param);
          motion.Parts[i].Frames[j].Param = 0;
        }

        offsetsSet.Add(offsets);
      }

      for (int i = 0; i < motion.Parts.Count - 9; i++)
      {
        if (boneIndex > 42)
          break;
        else if (i % 9 == 8)
        {
          boneIndex++;
          continue;
        }
        else if (i % 9 > 2)
          continue;

        if (faceLoc[charaSet[1]][boneIndex][i % 9] == 0 || faceLoc[charaSet[0]][boneIndex][i % 9] == 0)
          continue;

        float diff = faceLoc[charaSet[1]][boneIndex][i % 9] - faceLoc[charaSet[0]][boneIndex][i % 9];

        if (grp.Hies[boneIndex].Parent == 43)
        {
          for (int j = 0; j < motion.Parts[i].Frames.Count; j++)
          {
            motion.Parts[i].Frames[j].Param += diff + offsetsSet[i % 9][j];
          }
        }
        else
        {
          for (int j = 0; j < motion.Parts[i].Frames.Count; j++)
          {
            motion.Parts[i].Frames[j].Param += diff;
          }
        }
      }

      faceLoc.Clear();

      movieTables.SetBoneMotionFrame(motion, lbBones.SelectedIndex);

      modifiedBone = true;
      motion.Modified = true;
      Modified();
    }


    private void btnMotShiftVal_Click(object sender, RoutedEventArgs e)
    {
      decimal shiftVal;

      if (curCulture != null) Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");

      if (!decimal.TryParse(tbMotShiftVal.Text, out shiftVal)) return;

      if (curCulture != null) Thread.CurrentThread.CurrentCulture = curCulture;


      var motion = mpmData.Grps[movieTables.BoneMotionGrps[dgMotionGrps.SelectedIndex].Index].Motions[dgMotions.SelectedIndex];
      if (motion == null || motion.Type == 1) return;

      foreach (var cell in dgMotionFrames.SelectedCells)
      {
        var item = cell.Item as MovieTables.BoneMotionFrameData;
        var curVal = GetBoneFrameData(item, cell.Column.SortMemberPath);

        if (curVal == null) continue;

        decimal deci = (decimal)curVal + shiftVal;

        SetBoneFrameData(item, cell.Column.SortMemberPath, deci);

        var part = motion.Parts[lbBones.SelectedIndex * 9 + cell.Column.DisplayIndex];
        part.Frames[item.Frame].Param = (float)deci;
      }

      modifiedBone = true;
      motion.Modified = true;
      Modified();
    }

    private void btnCamShiftVal_Click(object sender, RoutedEventArgs e)
    {
      decimal shiftVal;

      if (curCulture != null) Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");

      if (!decimal.TryParse(tbCamShiftVal.Text, out shiftVal)) return;

      if (curCulture != null) Thread.CurrentThread.CurrentCulture = curCulture;


      var motion = camData.Motions[dgCameraMotions.SelectedIndex];
      if (motion == null) return;

      foreach (var cell in dgCameraFrames.SelectedCells)
      {
        var item = cell.Item as MovieTables.CameraMotionFrameData;
        var curVal = GetCameraFrameData(item, cell.Column.SortMemberPath);

        if (curVal == null) continue;

        decimal deci = (decimal)curVal + shiftVal;

        SetCameraFrameData(item, cell.Column.SortMemberPath, deci);

        var frameData = motion.Frames[item.Frame];
        SetCameraFrameData(frameData, cell.Column.SortMemberPath, (float)deci);
      }

      modifiedCam = true;
      Modified();
    }


    private void dgMotionFramesColumnHeader_Click(object sender, RoutedEventArgs e)
    {
      var header = sender as DataGridColumnHeader;
      if (header == null) return;

      dgMotionFrames.Focus();
      SelectColumnAllCells(dgMotionFrames, header.DisplayIndex);
    }

    private void dgCameraFramesColumnHeader_Click(object sender, RoutedEventArgs e)
    {
      var header = sender as DataGridColumnHeader;
      if (header == null) return;

      dgCameraFrames.Focus();
      SelectColumnAllCells(dgCameraFrames, header.DisplayIndex);
    }

    private void SelectColumnAllCells(DataGrid dataGrid, int column)
    {
      SortedSet<int> selected = new SortedSet<int>();

      Common.Styles.DataGridCommitEdit(dataGrid);

      int curColIndex = -1;
      SortedSet<int> selectedColumns = null;
      if (dataGrid.Name == "dgMotionFrames")
      {
        curColIndex = motCurrentColumnIndex;
        selectedColumns = motSelectedColumns;
      }
      else if (dataGrid.Name == "dgCameraFrames")
      {
        curColIndex = camCurrentColumnIndex;
        selectedColumns = motSelectedColumns;
      }

      if ((Keyboard.Modifiers & ModifierKeys.Shift) > 0 && curColIndex != -1)
      {
        if (curColIndex < column)
        {
          for (int i = curColIndex; i <= column; i++)
          {
            selected.Add(i);
          }
        }
        else
        {
          for (int i = column; i <= curColIndex; i++)
          {
            selected.Add(i);
          }
        }
      }
      else
      {
        selected.Add(column);
        curColIndex = column;
      }

      if (dataGrid.Name == "dgMotionFrames")
        motCurrentColumnIndex = curColIndex;
      else if (dataGrid.Name == "dgCameraFrames")
        camCurrentColumnIndex = curColIndex;

      if ((Keyboard.Modifiers & ModifierKeys.Control) > 0)
      {
        if (selectedColumns.Contains(column))
        {
          selectedColumns.Remove(column);
          foreach (var row in dataGrid.Items)
          {
            var dataGridCellInfo = new DataGridCellInfo(row, dataGrid.Columns[column]);
            if (dataGrid.SelectedCells.Contains(dataGridCellInfo)) dataGrid.SelectedCells.Remove(dataGridCellInfo);
          }

          return;
        }
      }
      else
      {
        if (dataGrid.SelectedCells.Count > 0) dataGrid.SelectedCells.Clear();
        if (selectedColumns.Count > 0) selectedColumns.Clear();
      }

      foreach (var col in selected)
      {
        foreach (var row in dataGrid.Items)
        {
          var dataGridCellInfo = new DataGridCellInfo(row, dataGrid.Columns[col]);
          if (!dataGrid.SelectedCells.Contains(dataGridCellInfo)) dataGrid.SelectedCells.Add(dataGridCellInfo);
        }
        selectedColumns.Add(col);
      }
    }


    private void FrameCount_BeginningEdit(object sender, DataGridBeginningEditEventArgs e)
    {
      var dataGrid = sender as DataGrid;
      FrameworkElement contentElement = dataGrid.CurrentCell.Column.GetCellContent(dataGrid.CurrentCell.Item);
      var tb = contentElement as TextBlock;

      uint val;
      if (UInt32.TryParse(tb.Text, out val))
      {
        curCount = val;
      }
    }

    private void FrameCount_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
    {
      var dataGrid = sender as DataGrid;
      if (dataGrid.SelectedCells.Count < 1) return;

      var tb = e.EditingElement as TextBox;

      bool canParse = true;
      uint val;
      if (!UInt32.TryParse(tb.Text, out val)) canParse = false;

      if (!canParse)
      {
        tb.Text = curCount.ToString();
        return;
      }
      else if (val == 0)
      {
        tb.Text = "1";
        val = 1;
      }

      if (val == curCount)
        return;
      else if (val > curCount)
      {
        // 追加
        var result = MessageWindow.Show(this, txt["ConfirmExtendFrames"], txt["Confirm"], txt["Continue"], txt["Cancel"]);
        if (result == MessageWindow.Result.Cancel)
        {
          tb.Text = curCount.ToString();
          return;
        }

        if (dataGrid.Name == "dgMotions")
        {
          var grp = mpmData.Grps[movieTables.BoneMotionGrps[dgMotionGrps.SelectedIndex].Index];
          var motion = grp.Motions[dataGrid.SelectedIndex];

          float?[] values = new float?[motion.Parts.Count];

          if (curCount > 0)
          {
            for (int i = 0; i < motion.Parts.Count; i++)
            {
              values[i] = motion.Parts[i].Frames[(int)curCount - 1].Param;
            }
          }
          else
          {
            for (int i = 0; i < motion.Parts.Count; i++)
            {
              if (i % 9 == 6 || i % 9 == 7 || i % 9 == 8)
                values[i] = 1;
              else
                values[i] = 0;
            }
          }

          for (int i = (int)curCount; i < val; i++)
          {
            SetCsvRowBone(motion, i, values, grp.BaseBoneName, false);
          }

          motion.FrameCount = (int)val;
          foreach (var part in motion.Parts)
          {
            part.FrameCount = (int)val;
          }

          movieTables.SetBoneMotionFrame(motion, lbBones.SelectedIndex);
          movieTables.BoneMotions[dgMotions.SelectedIndex].FrameCount = (int)val;

          modifiedBone = true;
          motion.Modified = true;
        }
        else if (dataGrid.Name == "dgCameraMotions")
        {
          var motion = camData.Motions[dataGrid.SelectedIndex];
          var framesData = motion.Frames;
          if (curCount > 0)
          {
            FrameData lastFrameData = motion.Frames[(int)curCount - 1];
            for (int i = (int)curCount; i < val; i++)
            {
              var data = new FrameData(i);
              data.PositionX = lastFrameData.PositionX;
              data.PositionY = lastFrameData.PositionY;
              data.PositionZ = lastFrameData.PositionZ;
              data.PorX = lastFrameData.PorX;
              data.PorY = lastFrameData.PorY;
              data.PorZ = lastFrameData.PorZ;
              data.Tilt = lastFrameData.Tilt;
              data.Angle = lastFrameData.Angle;
              framesData.Add(data);
            }
          }
          else
          {
            for (int i = (int)curCount; i < val; i++)
            {
              var data = new FrameData(i);
              data.PositionX = 0;
              data.PositionY = 0;
              data.PositionZ = 0;
              data.PorX = 0;
              data.PorY = 0;
              data.PorZ = 0;
              data.Tilt = 0;
              data.Angle = 0;
              framesData.Add(data);
            }
          }

          float?[] values = new float?[8];


          motion.FrameCount = (int)val;

          movieTables.SetCameraMotionFrame(motion);
          movieTables.CameraMotions[dgMotions.SelectedIndex].FrameCount = (int)val;

          modifiedCam = true;
        }
      }
      else if (val < curCount)
      {
        // 削除
        if (dataGrid.Name == "dgMotions")
        {
          var result = MessageWindow.Show(this, txt["ConfirmReduceFrames"] + "\r\n\r\n" + txt["ConfirmAllBones"], txt["Confirm"], txt["Continue"], txt["Cancel"]);
          if (result == MessageWindow.Result.Cancel)
          {
            tb.Text = curCount.ToString();
            return;
          }

          var motion = mpmData.Grps[movieTables.BoneMotionGrps[dgMotionGrps.SelectedIndex].Index].Motions[dataGrid.SelectedIndex];

          foreach (var part in motion.Parts)
          {
            for (int i = (int)curCount - 1; i >= val; i--)
            {
              part.Frames.Remove(i);
            }
          }

          motion.FrameCount = (int)val;
          foreach (var part in motion.Parts)
          {
            part.FrameCount = (int)val;
          }

          movieTables.SetBoneMotionFrame(motion, lbBones.SelectedIndex);
          movieTables.BoneMotions[dgMotions.SelectedIndex].FrameCount = (int)val;

          modifiedBone = true;
          motion.Modified = true;
        }
        else if (dataGrid.Name == "dgCameraMotions")
        {
          var result = MessageWindow.Show(this, txt["ConfirmReduceFrames"], txt["Confirm"], txt["Continue"], txt["Cancel"]);
          if (result == MessageWindow.Result.Cancel)
          {
            tb.Text = curCount.ToString();
            return;
          }

          var motion = camData.Motions[dataGrid.SelectedIndex];

          for (int i = (int)curCount - 1; i >= val; i--)
          {
            motion.Frames.RemoveAt(i);
          }

          motion.FrameCount = (int)val;

          movieTables.SetCameraMotionFrame(motion);
          movieTables.CameraMotions[dgMotions.SelectedIndex].FrameCount = (int)val;

          modifiedCam = true;
        }
      }

      Modified();
    }


    private void dgFrames_ContextMenuOpening(object sender, ContextMenuEventArgs e)
    {
      var dataGrid = sender as DataGrid;

      menuitemFramesDelete.Visibility = Visibility.Collapsed;

      if (dataGrid.SelectedItems.Count > 0)
      {
        menuitemFramesDelete.Visibility = Visibility.Visible;
      }
    }

    private void dgFrames_BeginningEdit(object sender, DataGridBeginningEditEventArgs e)
    {
      var dataGrid = sender as DataGrid;
      FrameworkElement contentElement = dataGrid.CurrentCell.Column.GetCellContent(dataGrid.CurrentCell.Item);
      var tb = contentElement as TextBlock;

      if (curCulture != null) Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");

      float val;
      if (float.TryParse(tb.Text, out val))
      {
        curValue = val;
      }

      if (curCulture != null) Thread.CurrentThread.CurrentCulture = curCulture;
    }

    private void dgFrames_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
    {
      var dataGrid = sender as DataGrid;
      if (dataGrid.SelectedCells.Count < 1) return;

      var tb = e.EditingElement as TextBox;

      if (curCulture != null) Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");

      bool canParse = true;
      float val;
      if (!float.TryParse(tb.Text, out val)) canParse = false;

      if (curCulture != null) Thread.CurrentThread.CurrentCulture = curCulture;

      if (!canParse)
      {
        tb.Text = curValue.ToString();
        return;
      }
      else if (val == curValue) return;

      if (dataGrid.Name == "dgMotionFrames")
      {
        var item = dataGrid.SelectedCells[0].Item as MovieTables.BoneMotionFrameData;
        var motion = mpmData.Grps[movieTables.BoneMotionGrps[dgMotionGrps.SelectedIndex].Index].Motions[dgMotions.SelectedIndex];
        var part = motion.Parts[lbBones.SelectedIndex * 9 + dataGrid.SelectedCells[0].Column.DisplayIndex];
        part.Frames[dataGrid.Items.IndexOf(item)].Param = val;

        modifiedBone = true;
        motion.Modified = true;
      }
      else if (dataGrid.Name == "dgCameraFrames")
      {
        var item = dataGrid.SelectedCells[0].Item as MovieTables.CameraMotionFrameData;
        var frameData = camData.Motions[dgCameraMotions.SelectedIndex].Frames[item.Frame];
        SetCameraFrameData(frameData, dataGrid.SelectedCells[0].Column.SortMemberPath, val);

        modifiedCam = true;
      }

      Modified();
    }

    private void DataGrid_CommitEdit()
    {
      if (tabMovie.IsSelected)
        Common.Styles.DataGridCommitEdit(dgMovieParams);
      else if (tabBone.IsSelected)
        Common.Styles.DataGridCommitEdit(dgMotionFrames);
      else if (tabCamera.IsSelected)
        Common.Styles.DataGridCommitEdit(dgCameraFrames);
    }


    private void OpenFile(string filePath)
    {
      tabControl.IsEnabled = false;
      DoEvents();

      try
      {
        gridMovieParamGrps.IsEnabled = false;
        gridMovieParams.IsEnabled = false;
        gridCuts.IsEnabled = false;

        gridLightGrps.IsEnabled = false;
        gridLightParams.IsEnabled = false;
        ClearLightParams();

        gridHdrGrps.IsEnabled = false;
        gridHdrParams.IsEnabled = false;
        ClearHdrParams();

        gridWindGrps.IsEnabled = false;
        gridWindParams.IsEnabled = false;
        ClearWindParams();

        gridMotionGrps.IsEnabled = false;
        gridMotions.IsEnabled = false;
        gridMotionFrames.IsEnabled = false;

        gridCameraMotions.IsEnabled = false;
        gridCameraFrames.IsEnabled = false;


        modified = false;
        modifiedMovie = false;
        modifiedScene = false;
        modifiedLight = false;
        modifiedHdr = false;
        modifiedWind = false;
        modifiedBone = false;
        modifiedCam = false;

        tdpData = null;
        movData = null;
        scnData = null;
        mpmData = null;
        camData = null;

        bn = System.IO.File.ReadAllBytes(filePath);
        if (bn.Length < 0x30)
        {
          MessageWindow.Show(this, txt["UnsupportedFile"], txt["Error"]);
          return;
        }
        char[] charsToTrim = { '\0' };
        string Name = Encoding.ASCII.GetString(bn, 0, 8).TrimEnd(charsToTrim);
        if (Name == "tdpack")
        {
          tdpData = new TdpData(bn);

          if (
            (tdpData.H.Offsets[0] == 0 && tdpData.H.Offsets[1] == 0 && tdpData.H.Offsets[2] == 0) ||
            Encoding.ASCII.GetString(bn, tdpData.H.Offsets[0], 8).TrimEnd(charsToTrim) == "tdpack"
            )
          {
            MessageWindow.Show(this, txt["UnsupportedFile"], txt["Error"]);
            return;
          }

          if (tdpData.H.Offsets[0] != 0)
          {
            movData = new MovData(tdpData.H.Offsets[0], bn);
          }
          if (tdpData.H.Offsets[1] != 0)
          {
            camData = new CamData(tdpData.H.Offsets[1], bn);
          }
          if (tdpData.H.Offsets[2] != 0)
          {
            mpmData = new MpmData(tdpData.H.Offsets[2], bn);
          }
          if (tdpData.H.Offsets[3] != 0)
          {
            scnData = new ScnData(tdpData.H.Offsets[3], bn);
          }
        }
        else if (Name == "SCENE")
        {
          scnData = new ScnData(0, bn);
        }
        else if (Name == "char_dat")
        {
          mpmData = new MpmData(0, bn);
        }
        else if (Path.GetExtension(filePath).ToUpper() == ".CAM")
        {
          camData = new CamData(0, bn);
        }
        else
        {
          MessageWindow.Show(this, txt["UnsupportedFile"], txt["Error"]);
          return;
        }


        if (movData != null)
        {
          gridMovieParamGrps.IsEnabled = true;
          if (movData.Cuts.Count > 0) gridCuts.IsEnabled = true;
        }

        if (scnData != null)
        {
          if (scnData.Lights.Count > 0) gridLightGrps.IsEnabled = true;
          if (scnData.Hdrs.Count > 0) gridHdrGrps.IsEnabled = true;
          if (scnData.Winds.Count > 0) gridWindGrps.IsEnabled = true;
        }

        if (mpmData != null)
        {
          gridMotionGrps.IsEnabled = true;
        }

        if (camData != null)
        {
          gridCameraMotions.IsEnabled = true;
        }

        if (movData != null || scnData != null || mpmData != null || camData != null)
        {
          movieTables = null;
          movieTables = new MovieTables(movData, scnData, mpmData, camData);
          this.DataContext = movieTables;

          if (movieTables.MovieParamGrps.Count > 0) dgMovieParamGrps.SelectedIndex = 0;
          if (movieTables.Cuts.Count > 0) dgCuts.SelectedIndex = 0;
          if (movieTables.LightGrps.Count > 0) dgLightGrps.SelectedIndex = 0;
          if (movieTables.HdrGrps.Count > 0) dgHdrGrps.SelectedIndex = 0;
          if (movieTables.WindGrps.Count > 0) dgWindGrps.SelectedIndex = 0;
          if (movieTables.BoneMotionGrps.Count > 0) dgMotionGrps.SelectedIndex = 0;
          if (movieTables.CameraMotions.Count > 0) dgCameraMotions.SelectedIndex = 0;

          textStatus.Path = filePath;
          curFilePath = filePath;
          curFileWriteTime = System.IO.File.GetLastWriteTime(filePath);

          this.Activate();

          if (scnData != null && movData == null && mpmData == null && camData == null) tabControl.SelectedItem = tabScene;
          else if (mpmData != null && scnData == null && movData == null && camData == null) tabControl.SelectedItem = tabBone;
          else if (camData != null && movData == null && scnData == null && mpmData == null) tabControl.SelectedItem = tabCamera;
          else if (
            movData != null &&
            (
              (tabControl.SelectedItem == tabBone && mpmData == null) ||
              (tabControl.SelectedItem == tabScene && scnData == null) ||
              (tabControl.SelectedItem == tabCamera && camData == null)
            )
          ) tabControl.SelectedItem = tabMovie;
        }
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }
      finally
      {
        tabControl.IsEnabled = true;
      }
    }

    private bool SaveFile(string filePath)
    {
      try
      {
        List<byte> exBin = new List<byte>();
        if (tdpData != null)
        {
          List<List<byte>> exBins = new List<List<byte>>();
          for (int i = 0; i < tdpData.H.Count1; i++)
          {
            var bin = new List<byte>();
            if (tdpData.H.Offsets[i] != 0)
            {
              bin = bn.Skip(tdpData.H.Offsets[i]).Take(tdpData.H.Sizes[i]).ToList();
            }
            exBins.Add(bin);
          }

          if (modifiedMovie && exBins[0].Count != 0) exBins[0] = BuildMovBin();
          if (modifiedCam && exBins[1].Count != 0) exBins[1] = BuildCamBin();
          if (modifiedBone && exBins[2].Count != 0) exBins[2] = BuildMotBin();
          if (modifiedScene && exBins[3].Count != 0) exBins[3] = BuildScnBin(exBins[3]);

          var tdpBin = BuildHeaderBaseBin("tdpack");

          BuildBin(tdpBin, exBins, null, true, true);

          exBin = tdpBin;
        }
        else if (camData != null)
        {
          exBin = BuildCamBin();
        }
        else if (mpmData != null)
        {
          exBin = BuildMotBin();
        }
        else if (scnData != null)
        {
          exBin = BuildScnBin(bn.ToList());
        }


        int dgMovieParamGrpsSelected = dgMovieParamGrps.SelectedIndex;
        int dgCutsSelected = dgCuts.SelectedIndex;

        int dgLightGrpsSelected = dgLightGrps.SelectedIndex;
        int dgHdrGrpsSelected = dgHdrGrps.SelectedIndex;
        int dgWindGrpsSelected = dgWindGrps.SelectedIndex;

        int dgMotionGrpsSelected = dgMotionGrps.SelectedIndex;
        int dgMotionsSelected = dgMotions.SelectedIndex;
        int lbBonesSelected = lbBones.SelectedIndex;

        int dgCameraMotionsSelected = dgCameraMotions.SelectedIndex;


        updateChecking = false;

        System.IO.File.WriteAllBytes(filePath, exBin.ToArray());

        OpenFile(filePath);


        dgMovieParamGrps.SelectedIndex = dgMovieParamGrpsSelected;
        dgCuts.SelectedIndex = dgCutsSelected;

        dgLightGrps.SelectedIndex = dgLightGrpsSelected;
        dgHdrGrps.SelectedIndex = dgHdrGrpsSelected;
        dgWindGrps.SelectedIndex = dgWindGrpsSelected;

        dgMotionGrps.SelectedIndex = dgMotionGrpsSelected;
        dgMotions.SelectedIndex = dgMotionsSelected;
        lbBones.SelectedIndex = lbBonesSelected;

        dgCameraMotions.SelectedIndex = dgCameraMotionsSelected;


        ShowTextBlockMessage(txt["Saved"]);

        updateChecking = true;

        return true;
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
        return false;
      }
    }

    private string CreateBackup()
    {
      try
      {
        if (!File.Exists(curFilePath)) return null;

        string dirPath = Path.GetDirectoryName(curFilePath);
        string name = Path.GetFileNameWithoutExtension(curFilePath);
        string ext = Path.GetExtension(curFilePath);

        List<string> files = Directory.GetFiles(dirPath, name + "*" + ext, SearchOption.TopDirectoryOnly).ToList();
        string regStr = name + @" - ([0-9]+)";
        int count = 1;

        foreach (string file in files)
        {
          string fileName = Path.GetFileNameWithoutExtension(file);

          MatchCollection mc = Regex.Matches(fileName, regStr);
          foreach (Match m in mc)
          {
            int num = int.Parse(m.Groups[1].Value);
            if (count <= num) count = num + 1;
          }
        }

        string newPath;
        while (File.Exists(newPath = dirPath + @"/" + name + " - " + count + ext))
        {
          count++;
        }

        File.Move(curFilePath, newPath);

        return newPath;
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
        return null;
      }
    }



    private void CheckUpdated()
    {
      if (curFilePath == "" || !System.IO.File.Exists(curFilePath)) return;

      var lastWriteTime = System.IO.File.GetLastWriteTime(curFilePath);
      if (curFileWriteTime.CompareTo(lastWriteTime) != 0)
      {
        if (MessageWindow.Show(this, txt["ConfirmFileUpdated"] + "\r\n\r\n" + curFilePath, txt["Confirm"], txt["Yes"], txt["No"]) == MessageWindow.Result.OK)
        {
          OpenFile(curFilePath);
        }
        else
        {
          curFileWriteTime = lastWriteTime;
        }
      }
    }
  }
}
