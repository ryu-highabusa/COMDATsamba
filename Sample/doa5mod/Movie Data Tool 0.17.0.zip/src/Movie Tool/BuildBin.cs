﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace Movie_Tool
{
  public partial class MainWindow : Window
  {
    private List<byte> BuildMovBin()
    {
      var exMovBin = new List<byte>(new byte[0x40]);
      var movOffsets = new List<int>();

      ReplaceByteList(exMovBin, BitConverter.GetBytes(exMovBin.Count), 0x0C);

      exMovBin.AddRange(new byte[0x20]);


      // Offset0

      // Data0
      var paramGrpOffsets = new List<int>();

      for (int i = 0; i < movData.Grps.Count; i++)
      {
        paramGrpOffsets.Add(exMovBin.Count);

        foreach (var param in movData.Grps[i].Params)
        {
          exMovBin.AddRange(BitConverter.GetBytes(param.Type));
          exMovBin.AddRange(BitConverter.GetBytes((short)(param.Nums.Count + 1)));

          foreach (var num in param.Nums)
          {
            exMovBin.AddRange(BitConverter.GetBytes(num));
          }
        }

        //if (i != movData.Grps.Count - 1) FillZeroBin(exMovBin, 0x20);
        //if (i < 2) FillZeroBin(exMovBin, 0x20);
        if (i < movData.Flag) FillZeroBin(exMovBin, 0x20);
      }

      ReplaceByteList(exMovBin, BitConverter.GetBytes(exMovBin.Count), 0x40);

      foreach (var offset in paramGrpOffsets)
      {
        exMovBin.AddRange(BitConverter.GetBytes(offset));
      }
      FillZeroBin(exMovBin, 0x20);

      ReplaceByteList(exMovBin, BitConverter.GetBytes(exMovBin.Count), 0x44);


      // Data1
      foreach (var num in movData.Data1)
      {
        exMovBin.AddRange(BitConverter.GetBytes(num));
      }
      exMovBin.AddRange(BitConverter.GetBytes(-1));


      // Data2
      var data2Offsets = new List<int>();

      foreach (var bytes in movData.Data2)
      {
        data2Offsets.Add(exMovBin.Count);

        exMovBin.AddRange(bytes);
      }

      ReplaceByteList(exMovBin, BitConverter.GetBytes(exMovBin.Count), 0x48);

      foreach (var offset in data2Offsets)
      {
        exMovBin.AddRange(BitConverter.GetBytes(offset));
      }
      exMovBin.AddRange(BitConverter.GetBytes(0));
      exMovBin.AddRange(BitConverter.GetBytes(1));


      ReplaceByteList(exMovBin, BitConverter.GetBytes(movData.Flag), 0x4C);


      // Data3
      ReplaceByteList(exMovBin, BitConverter.GetBytes(movData.Data3.Count), 0x50);
      ReplaceByteList(exMovBin, BitConverter.GetBytes(exMovBin.Count), 0x54);

      foreach (var list in movData.Data3)
      {
        foreach (var num in list)
        {
          exMovBin.AddRange(BitConverter.GetBytes(num));
        }
      }


      // Data4
      var data4Offsets = new List<int>();

      foreach (var list in movData.Data4)
      {
        data4Offsets.Add(exMovBin.Count);

        foreach (var num in list)
        {
          exMovBin.AddRange(BitConverter.GetBytes(num));
        }
      }
      if (movData.Data4.Count > 0) FillZeroBin(exMovBin, 0x20);

      ReplaceByteList(exMovBin, BitConverter.GetBytes(movData.Data4.Count), 0x58);
      ReplaceByteList(exMovBin, BitConverter.GetBytes(exMovBin.Count), 0x5C);

      foreach (var offset in data4Offsets)
      {
        exMovBin.AddRange(BitConverter.GetBytes(offset));
      }
      exMovBin.AddRange(BitConverter.GetBytes(0));
      exMovBin.AddRange(BitConverter.GetBytes(1));



      // Offset1 & Offset2

      int offset1Offset = exMovBin.Count;
      ReplaceByteList(exMovBin, BitConverter.GetBytes(offset1Offset), 0x14);
      exMovBin.AddRange(BitConverter.GetBytes(0));
      exMovBin.AddRange(BitConverter.GetBytes(movData.Offset1Flag));

      int offset2Offset = exMovBin.Count;
      ReplaceByteList(exMovBin, BitConverter.GetBytes(offset2Offset), 0x1C);
      exMovBin.AddRange(BitConverter.GetBytes(0));
      exMovBin.AddRange(BitConverter.GetBytes(movData.Offset2Flag));

      int strOffset = 0;
      if (movData.Offset1Flag == 1)
      {
        strOffset = exMovBin.Count;
        exMovBin.AddRange(Encoding.ASCII.GetBytes(movData.Offset1Str));
        FillZeroBin(exMovBin, 8);
      }

      ReplaceByteList(exMovBin, BitConverter.GetBytes(exMovBin.Count), offset1Offset);

      if (strOffset != 0) exMovBin.AddRange(BitConverter.GetBytes(strOffset));
      exMovBin.AddRange(BitConverter.GetBytes(0));
      exMovBin.AddRange(BitConverter.GetBytes(1));

      ReplaceByteList(exMovBin, BitConverter.GetBytes(exMovBin.Count), offset2Offset);

      exMovBin.AddRange(BitConverter.GetBytes(0));
      exMovBin.AddRange(BitConverter.GetBytes(1));



      // Cut
      if (movData.Cuts.Count > 0)
      {
        int cutsOffset = exMovBin.Count;
        ReplaceByteList(exMovBin, BitConverter.GetBytes(cutsOffset), 0x24);

        exMovBin.AddRange(BitConverter.GetBytes(0));
        exMovBin.AddRange(BitConverter.GetBytes(0));

        foreach (var id in movData.CutIDs)
        {
          exMovBin.AddRange(BitConverter.GetBytes(id));
        }
        ReplaceByteList(exMovBin, BitConverter.GetBytes(exMovBin.Count), cutsOffset + 4);
        exMovBin.AddRange(BitConverter.GetBytes(cutsOffset + 8));

        FillZeroBin(exMovBin, 0x20);


        var cutOffsets = new List<int>();

        foreach (var cut in movData.Cuts)
        {
          cutOffsets.Add(exMovBin.Count);

          exMovBin.AddRange(Encoding.ASCII.GetBytes(cut.Name));
          FillZeroBin(exMovBin, 0x10);

          foreach (var num in cut.Ints)
          {
            exMovBin.AddRange(BitConverter.GetBytes(num));
          }
          foreach (var f in cut.Floats)
          {
            exMovBin.AddRange(BitConverter.GetBytes(f));
          }
          exMovBin.AddRange(new byte[0x10]);
        }

        int cutsOffsetsOffset = exMovBin.Count;
        foreach (var offset in cutOffsets)
        {
          exMovBin.AddRange(BitConverter.GetBytes(offset));
        }
        FillZeroBin(exMovBin, 0x10);

        ReplaceByteList(exMovBin, BitConverter.GetBytes(exMovBin.Count), cutsOffset);

        exMovBin.AddRange(BitConverter.GetBytes(cutsOffsetsOffset));
      }

      FillZeroBin(exMovBin, 0x40);



      // Ints
      ReplaceByteList(exMovBin, BitConverter.GetBytes(exMovBin.Count), 0);
      foreach (var num in movData.Ints)
      {
        exMovBin.AddRange(BitConverter.GetBytes(num));
      }

      FillZeroBin(exMovBin, 0x40);


      return exMovBin;
    }


    private List<byte> BuildMotBin()
    {
      var motionBins = new List<List<byte>>();

      foreach (var grp in mpmData.Grps)
      {
        if (grp == null)
        {
          motionBins.Add(new List<byte>());
          continue;
        }

        var motionBin = BuildHeaderBaseBin("char_dat");

        var motionPartBins = new List<List<byte>>();
        for (int i = 0; i < grp.H.Count1; i++)
        {
          var motionPartBin = new List<byte>();
          motionPartBins.Add(motionPartBin);
        }

        int count = 0;
        motionPartBins[0].AddRange(new byte[4 * grp.Motions.Count + 0x10]);
        motionPartBins[0].AddRange(new byte[16 - (motionPartBins[0].Count % 16)]);
        foreach (var motion in grp.Motions)
        {
          BuildMotionPartBin(motion, motionPartBins[0], count);

          if (grp.BoneCount < 20) motionPartBins[0].AddRange(new byte[16]);

          count++;
        }

        // Block1
        if (grp.Block1Bin != null) motionPartBins[1].AddRange(grp.Block1Bin);

        // Block2
        if (grp.Block2Bin != null) motionPartBins[2].AddRange(grp.Block2Bin);

        // Block3
        motionPartBins[3].AddRange(BitConverter.GetBytes(grp.Unknown));
        motionPartBins[3].AddRange(BitConverter.GetBytes(grp.MotionCount));
        motionPartBins[3].AddRange(BitConverter.GetBytes(grp.BoneCount));
        motionPartBins[3].AddRange(BitConverter.GetBytes(0));
        motionPartBins[3].AddRange(Encoding.ASCII.GetBytes(grp.BaseBoneName));
        motionPartBins[3].AddRange(new byte[0x120 - motionPartBins[3].Count]);

        // Block4 Hierarchy
        motionPartBins[4] = BuildHeaderBaseBin("char_dat");

        var hieBins = new List<List<byte>>();
        foreach (var hie in grp.Hies)
        {
          var hieBin = new List<byte>();
          hieBin.AddRange(BitConverter.GetBytes(hie.Parent));
          hieBin.AddRange(BitConverter.GetBytes(hie.ChildrenCount));
          foreach (var child in hie.Children)
          {
            hieBin.AddRange(BitConverter.GetBytes(child));
          }
          if (hieBin.Count % 16 != 0) hieBin.AddRange(new byte[16 - (hieBin.Count % 16)]);
          hieBins.Add(hieBin);
        }
        BuildBin(motionPartBins[4], hieBins, null, false, false);

        // Block5
        motionPartBins[5].AddRange(BitConverter.GetBytes(grp.Block5.Count));
        foreach (var block5 in grp.Block5)
        {
          motionPartBins[5].AddRange(BitConverter.GetBytes(block5.Num1));
          motionPartBins[5].AddRange(BitConverter.GetBytes(block5.Num2));
        }
        motionPartBins[5].AddRange(new byte[16 - (motionPartBins[5].Count % 16)]);
        if (grp.AddEmptyAfterBlock5) motionPartBins[5].AddRange(new byte[16]);

        // Block6
        if (motionPartBins.Count > 6)
        {
          foreach (var block6 in grp.Block6)
          {
            motionPartBins[6].AddRange(BitConverter.GetBytes(block6.Num));
            motionPartBins[6].AddRange(BitConverter.GetBytes((short)0));
            motionPartBins[6].AddRange(BitConverter.GetBytes((short)block6.Nums.Count));
            foreach (var num in block6.Nums)
            {
              motionPartBins[6].AddRange(BitConverter.GetBytes(num));
            }
          }
          motionPartBins[6].AddRange(BitConverter.GetBytes(-1));
          motionPartBins[6].AddRange(new byte[32 - (motionPartBins[6].Count % 32)]);
        }

        BuildBin(motionBin, motionPartBins, null, false, true);

        motionBins.Add(motionBin);
      }

      var mpmBin = BuildHeaderBaseBin("char_dat");
      BuildBin(mpmBin, motionBins, null, false, true);

      return mpmBin;
    }

    private List<byte> BuildMotionPartBin(MotionData motion, List<byte> bin, int index)
    {
      var offsets = new Dictionary<int, int>();

      if (motion.Modified)
      {
        if (motion.Type == 0)
          ResetMotionPartDataBaked(motion);
      }

      var partPairs = new List<KeyValuePair<int, List<byte>>>(motion.DataBytes);
      partPairs.Sort(CompareDataBytesKeyValuePairByKey);

      foreach (var pair in partPairs)
      {
        offsets[pair.Key] = bin.Count;
        bin.AddRange(pair.Value);
      }
      if (bin.Count % 16 != 0) bin.AddRange(new byte[16 - (bin.Count % 16)]);

      ReplaceByteList(bin, BitConverter.GetBytes(bin.Count), 4 * index);

      foreach (var part in motion.Parts)
      {
        bin.AddRange(BitConverter.GetBytes(offsets[part.Offset]));
      }

      bin.AddRange(new byte[16 - (bin.Count % 16)]);

      return bin;
    }

    private void ResetMotionPartDataBaked(MotionData motion)
    {
      motion.DataBytes.Clear();
      motion.PartOffsets.Clear();

      int partCount = 0;
      foreach (var part in motion.Parts)
      {
        var bytes = new List<byte>();

        // Byteデータ構築
        bytes.Add(0);
        bytes.Add(7);

        int frame = 0;
        int curVal = (int)Math.Round(part.Frames[frame].Param * 0x4000, MidpointRounding.AwayFromZero);
        // 0x4000倍して整数にした数値を追加
        var b = BitConverter.GetBytes(curVal);
        bytes.AddRange(new byte[] { b[0], b[1], b[2] });
        frame++;

        int type = -1;
        var diffList = new List<short>();

        if (part.FrameCount == 1)
        {
          bytes.Insert(4, 0x80);
        }

        while (frame < part.FrameCount)
        {
          int val = (int)Math.Round(part.Frames[frame].Param * 0x4000, MidpointRounding.AwayFromZero);

          if (frame == part.FrameCount - 1)
          {
            bytes.AddRange(AddPartBytes(diffList, type));
            b = BitConverter.GetBytes(val);
            bytes.AddRange(new byte[] { b[0], b[1], 0x80, b[2] });
            break;
          }

          int diff = val - curVal;
          if (diff > 32767 || diff < -32768)
          {
            if (diffList.Count > 0)
            {
              bytes.AddRange(AddPartBytes(diffList, type));
              diffList.Clear();
              type = -1;
            }
            b = BitConverter.GetBytes(val);
            bytes.AddRange(new byte[] { b[0], b[1], b[2] });
          }
          else if (diff == 0)
          {
            if (type == -1)
            {
              type = 0x7D;
            }
            else if (type != 0x7D)
            {
              bytes.AddRange(AddPartBytes(diffList, type));
              diffList.Clear();
              type = 0x7D;
            }
            // 同じなら0を追加
            diffList.Add(0);
          }
          else
          {
            // 差分がInt8を超えているか(0x7D-0x80を除く？)
            if (diff > 124 || diff < -127)
            {
              if (type == -1)
              {
                type = 0x7E;
              }
              else if (type != 0x7E)
              {
                bytes.AddRange(AddPartBytes(diffList, type));
                diffList.Clear();
                type = 0x7E;
              }
            }
            else
            {
              if (type == -1)
              {
                type = 0x7F;
              }
              else if (type != 0x7F)
              {
                bytes.AddRange(AddPartBytes(diffList, type));
                diffList.Clear();
                type = 0x7F;
              }
            }

            // diffListにcurValとの差分を追加
            diffList.Add((short)diff);
          }

          curVal = val;
          frame++;
        }

        // 存在チェック
        bool contains = false;
        foreach (var pair in motion.DataBytes)
        {
          contains = CompareByteList(pair.Value, bytes);
          if (contains)
          {
            part.Offset = pair.Key;
            break;
          }
        }

        // 無ければ追加
        if (!contains)
        {
          motion.DataBytes[partCount] = bytes;
          part.Offset = partCount;
          partCount++;
        }

        motion.PartOffsets.Add(part.Offset);
      }
    }

    private List<byte> AddPartBytes(List<short> diffList, int type)
    {
      var bytes = new List<byte>();

      bytes.AddRange(BitConverter.GetBytes((short)diffList.Count));
      if (type == 0x7D)
      {
        bytes.Add(0x7D);
        bytes.Add(0);
      }
      else if (type == 0x7E)
      {
        bytes.Add(0x7E);
        foreach (var diff in diffList)
        {
          bytes.AddRange(BitConverter.GetBytes(diff));
        }
      }
      else if (type == 0x7F)
      {
        bytes.Add(0x7F);
        foreach (var diff in diffList)
        {
          var b = BitConverter.GetBytes(diff);
          bytes.Add(b[0]);
        }
      }

      return bytes;
    }

    private bool CompareByteList(List<byte> list1, List<byte> list2)
    {
      if (object.ReferenceEquals(list1, list2))
      {
        return true;
      }
      else if (list1 == null || list2 == null || list1.Count != list2.Count)
      {
        return false;
      }
      else
      {
        for (int i = 0; i < list1.Count; i++)
        {
          if (!list1[i].Equals(list2[i]))
          {
            return false;
          }
        }
      }
      return true;
    }

    static int CompareDataBytesKeyValuePairByKey(KeyValuePair<int, List<byte>> a, KeyValuePair<int, List<byte>> b)
    {
      return a.Key - b.Key;
    }


    private List<byte> BuildCamBin()
    {
      var exCamBin = new List<byte>(new byte[0x20]);
      var camOffsetsBin = new List<byte>();

      for (int i = 0; i < camData.Motions.Count; i++)
      {
        var motionBins = new List<List<byte>>();

        var motionInfoBin = new List<byte>();
        var motionPositionBin = new List<byte>();
        var motionPorBin = new List<byte>();
        var motionTiltBin = new List<byte>();
        var motionAngleBin = new List<byte>();

        foreach (var frameData in camData.Motions[i].Frames)
        {
          motionPositionBin.AddRange(BitConverter.GetBytes(frameData.PositionX));
          motionPositionBin.AddRange(BitConverter.GetBytes(frameData.PositionY));
          motionPositionBin.AddRange(BitConverter.GetBytes(frameData.PositionZ));
          motionPorBin.AddRange(BitConverter.GetBytes(frameData.PorX));
          motionPorBin.AddRange(BitConverter.GetBytes(frameData.PorY));
          motionPorBin.AddRange(BitConverter.GetBytes(frameData.PorZ));
          motionTiltBin.AddRange(BitConverter.GetBytes(frameData.Tilt));
          motionAngleBin.AddRange(BitConverter.GetBytes(frameData.Angle));
        }

        FillZeroBin(motionPositionBin, 0x20);
        FillZeroBin(motionPorBin, 0x20);
        motionTiltBin.AddRange(BitConverter.GetBytes(1.0f));
        FillZeroBin(motionTiltBin, 0x20);
        motionAngleBin.AddRange(BitConverter.GetBytes(1.0f));

        motionInfoBin.AddRange(BitConverter.GetBytes(camData.Motions[i].FrameCount));
        motionInfoBin.AddRange(BitConverter.GetBytes(1));
        motionInfoBin.AddRange(BitConverter.GetBytes(exCamBin.Count + motionPositionBin.Count));
        motionInfoBin.AddRange(BitConverter.GetBytes(exCamBin.Count));

        exCamBin.AddRange(motionPositionBin);
        exCamBin.AddRange(motionPorBin);

        motionInfoBin.AddRange(BitConverter.GetBytes(exCamBin.Count));
        exCamBin.AddRange(motionTiltBin);

        motionInfoBin.AddRange(BitConverter.GetBytes(exCamBin.Count));
        exCamBin.AddRange(motionAngleBin);

        // オフセット群にオフセット追加
        camOffsetsBin.AddRange(BitConverter.GetBytes(exCamBin.Count));

        // モーション情報追加
        exCamBin.AddRange(motionInfoBin);

        if (i != camData.Motions.Count - 1)
        {
          FillZeroBin(exCamBin, 0x20);
        }
      }

      ReplaceByteList(exCamBin, BitConverter.GetBytes(exCamBin.Count), 4);
      camOffsetsBin.AddRange(BitConverter.GetBytes(0));
      exCamBin.AddRange(camOffsetsBin);
      FillZeroBin(exCamBin, 0x20);


      #region Camera Param
      var paramBins = new List<List<byte>>();
      var paramOffsetsSet = new List<List<int>>();

      CamParamSetsChange();

      for (int i = 0; i < camData.ParamSets.Count; i++)
      {
        var paramBin = new List<byte>();
        var paramOffsets = new List<int>();

        foreach (var grp in camData.ParamSets[i].Groups)
        {
          int index = -1;
          paramOffsets.Add(paramBin.Count);
          foreach (var param in grp.Params)
          {
            paramBin.AddRange(BitConverter.GetBytes(param.Type));
            paramBin.AddRange(BitConverter.GetBytes((short)(param.Data.Count + 1)));
            if (param.Type == 0x12 && param.Data.Count > 3)
            {
              if (index == -1) index = (int)param.Data[2];

              if (grp.Params[0].Type == 0x12 && camData.Motions[index].RepeatStart != null)
              {
                param.Data[3] = camData.Motions[index].RepeatStart;
              }

              param.Data[0] = camData.Motions[index].FrameCount - (int)param.Data[3];
            }
            else if((param.Type == 0x10 || param.Type == 0x25) && param.Data.Count > 0)
            {
              if (grp.Params[0].Type == 0x12 && camData.Motions[index].RepeatStart != null)
              {
                param.Data[0] = camData.Motions[index].FrameCount - (int)camData.Motions[index].RepeatStart;
              }
              else
              {
                param.Data[0] = camData.Motions[index].FrameCount;
              }
            }

            foreach (var data in param.Data)
            {
              paramBin.AddRange(BitConverter.GetBytes(data));
            }
          }
        }

        if (i != camData.ParamSets.Count - 1)
        {
          FillZeroBin(paramBin, 0x20);
        }

        paramBins.Add(paramBin);
        paramOffsetsSet.Add(paramOffsets);
      }

      var offsetShifts = new List<int>();
      foreach (var paramBin in paramBins)
      {
        offsetShifts.Add(exCamBin.Count);
        exCamBin.AddRange(paramBin);
      }

      var paramOffsetsOffsets = new List<int>();
      for (int i = 0; i < camData.ParamSets[0].Groups.Count; i++)
      {
        paramOffsetsOffsets.Add(exCamBin.Count);
        for (int j = 0; j < paramOffsetsSet.Count; j++)
        {
          exCamBin.AddRange(BitConverter.GetBytes(paramOffsetsSet[j][i] + offsetShifts[j]));
        }
      }

      FillZeroBin(exCamBin, 0x20);

      ReplaceByteList(exCamBin, BitConverter.GetBytes(exCamBin.Count), 0);

      var paramOffsetsOffsetsBin = new List<byte>();
      foreach (var offset in paramOffsetsOffsets)
      {
        paramOffsetsOffsetsBin.AddRange(BitConverter.GetBytes(camData.ParamSets.Count));
        paramOffsetsOffsetsBin.AddRange(BitConverter.GetBytes(offset));
      }
      FillZeroBin(paramOffsetsOffsetsBin, 0x40);

      exCamBin.AddRange(paramOffsetsOffsetsBin);
      #endregion


      return exCamBin;
    }

    public void CamParamSetsChange()
    {
      int motionIndex = 0;
      foreach (var motion in camData.Motions)
      {
        if (motion.Repeat == motion.OriginalRepeat) continue;

        if (motion.Repeat)
        {
          int target = -1;
          int paramSetIndex = 0;
          foreach (var paramSet in camData.ParamSets)
          {
            if (paramSet.Groups.Count > 1) continue;

            foreach (var grp in paramSet.Groups)
            {
              if (grp.Params[0].Type == 0x12) continue;

              foreach (var param in grp.Params)
              {
                if (param.Type == 0x12 && param.Data.Count > 3 && motionIndex == param.Data[2])
                {
                  target = paramSetIndex;
                  break;
                }
              }
              if (target != -1) break;
            }
            if (target != -1) break;
            paramSetIndex++;
          }

          if (target != -1)
          {
            var newSet = new CameraParamSet();
            var newGroup = new CameraParamGroup();

            bool startCopy = false;
            foreach (var param in camData.ParamSets[target].Groups[0].Params)
            {
              if (param.Type != 0x12 && !startCopy) continue;

              startCopy = true;

              var newParam = new CameraParam();
              newParam.Type = param.Type;
              newParam.Data.AddRange(param.Data);
              newGroup.Params.Add(newParam);
            }
            newSet.Groups.Add(newGroup);

            camData.ParamSets.Insert(target + 1, newSet);
          }
        }
        else
        {
          int target = -1;
          int paramSetIndex = 0;
          foreach (var paramSet in camData.ParamSets)
          {
            foreach (var grp in paramSet.Groups)
            {
              if (grp.Params[0].Type == 0x12 && grp.Params[0].Data.Count > 3 && motionIndex == grp.Params[0].Data[2])
              {
                target = paramSetIndex;
              }
              if (target != -1) break;
            }
            if (target != -1) break;
            paramSetIndex++;
          }

          if (target != -1)
          {
            camData.ParamSets.RemoveAt(target);
          }
        }

        motionIndex++;
      }
    }


    private List<byte> BuildScnBin(List<byte> bin)
    {
      var sceneBins = new List<List<byte>>();

      for (int i = 0; i < scnData.H.Count1; i++)
      {
        var partBin = new List<byte>();

        if (scnData.H.Offsets[i] != 0)
        {
          partBin = bin.Skip(scnData.H.Offsets[i]).Take(scnData.H.Sizes[i]).ToList();
        }

        sceneBins.Add(partBin);
      }

      if (modifiedLight) ChangeLightBin(sceneBins[1]);
      if (modifiedHdr) ChangeHdrBin(sceneBins[4]);
      if (modifiedWind) ChangeWindBin(sceneBins[7]);


      var scnBin = BuildHeaderBaseBin("SCENE");
      BuildBin(scnBin, sceneBins, null, true, true);

      return scnBin;
    }

    private void ChangeLightBin(List<byte> bin)
    {
      foreach (var light in scnData.Lights)
      {
        for (int i = 0; i < light.AmbientColor.Length; i++)
          ReplaceByteList(bin, BitConverter.GetBytes(light.AmbientColor[i]), light.OffsetParams + 0x10 + 4 * i);
        for (int i = 0; i < light.AmbientSpeColor.Length; i++)
          ReplaceByteList(bin, BitConverter.GetBytes(light.AmbientSpeColor[i]), light.OffsetParams + 0x20 + 4 * i);
        ReplaceByteList(bin, BitConverter.GetBytes(light.AmbientFlag), light.OffsetParams + 0x30);
        for (int i = 0; i < light.AmbientSub1Color.Length; i++)
          ReplaceByteList(bin, BitConverter.GetBytes(light.AmbientSub1Color[i]), light.OffsetParams + 0x40 + 4 * i);
        for (int i = 0; i < light.AmbientSub2Color.Length; i++)
          ReplaceByteList(bin, BitConverter.GetBytes(light.AmbientSub2Color[i]), light.OffsetParams + 0x50 + 4 * i);

        for (int i = 0; i < light.MainColor.Length; i++)
          ReplaceByteList(bin, BitConverter.GetBytes(light.MainColor[i]), light.OffsetParams + 0x70 + 4 * i);
        ReplaceByteList(bin, BitConverter.GetBytes(light.MainAngleElevation), light.OffsetParams + 0x80);
        ReplaceByteList(bin, BitConverter.GetBytes(light.MainAngleDirection), light.OffsetParams + 0x84);
        ReplaceByteList(bin, BitConverter.GetBytes(light.MainPoint), light.OffsetParams + 0x88);
        ReplaceByteList(bin, BitConverter.GetBytes(light.MainEnable), light.OffsetParams + 0x8C);

        for (int i = 0; i < light.MainColor.Length; i++)
          ReplaceByteList(bin, BitConverter.GetBytes(light.MainColor[i]), light.OffsetParams + 0x70 + 4 * i);
        ReplaceByteList(bin, BitConverter.GetBytes(light.MainAngleElevation), light.OffsetParams + 0x80);
        ReplaceByteList(bin, BitConverter.GetBytes(light.MainAngleDirection), light.OffsetParams + 0x84);
        ReplaceByteList(bin, BitConverter.GetBytes(light.MainPoint), light.OffsetParams + 0x88);
        ReplaceByteList(bin, BitConverter.GetBytes(light.MainEnable), light.OffsetParams + 0x8C);

        for (int i = 0; i < light.Sub1Color.Length; i++)
          ReplaceByteList(bin, BitConverter.GetBytes(light.Sub1Color[i]), light.OffsetParams + 0xA0 + 4 * i);
        ReplaceByteList(bin, BitConverter.GetBytes(light.Sub1AngleElevation), light.OffsetParams + 0xB0);
        ReplaceByteList(bin, BitConverter.GetBytes(light.Sub1AngleDirection), light.OffsetParams + 0xB4);
        ReplaceByteList(bin, BitConverter.GetBytes(light.Sub1Point), light.OffsetParams + 0xB8);
        ReplaceByteList(bin, BitConverter.GetBytes(light.Sub1Enable), light.OffsetParams + 0xBC);

        for (int i = 0; i < light.Sub2Color.Length; i++)
          ReplaceByteList(bin, BitConverter.GetBytes(light.Sub2Color[i]), light.OffsetParams + 0xD0 + 4 * i);
        ReplaceByteList(bin, BitConverter.GetBytes(light.Sub2AngleElevation), light.OffsetParams + 0xE0);
        ReplaceByteList(bin, BitConverter.GetBytes(light.Sub2AngleDirection), light.OffsetParams + 0xE4);
        ReplaceByteList(bin, BitConverter.GetBytes(light.Sub2Point), light.OffsetParams + 0xE8);
        ReplaceByteList(bin, BitConverter.GetBytes(light.Sub2Enable), light.OffsetParams + 0xEC);

        for (int i = 0; i < light.SelfShadowColor.Length; i++)
          ReplaceByteList(bin, BitConverter.GetBytes(light.SelfShadowColor[i]), light.OffsetParams + 0x100 + 4 * i);
      }
    }

    private void ChangeHdrBin(List<byte> bin)
    {
      int baseOffset = 0x30;
      int count = 0;
      foreach (var hdr in scnData.Hdrs)
      {
        int offset = baseOffset + 0x30 * count;

        for (int i = 0; i < 8; i++)
          ReplaceByteList(bin, BitConverter.GetBytes(hdr.Params[i]), offset + 0x10 + 4 * i);

        count++;
      }
    }

    private void ChangeWindBin(List<byte> bin)
    {
      int baseOffset = 0x30;
      int count = 0;
      foreach (var wind in scnData.Winds)
      {
        int offset = baseOffset + 0xE0 * count;

        for (int i = 0; i < 4; i++)
          ReplaceByteList(bin, BitConverter.GetBytes(wind.Nums1[i]), offset + 0x10 + 4 * i);
        for (int i = 0; i < 3; i++)
        {
          ReplaceByteList(bin, BitConverter.GetBytes(wind.Params[i].Param1), offset + 0x20 + 0x10 * i);
          ReplaceByteList(bin, BitConverter.GetBytes(wind.Params[i].Param2), offset + 0x24 + 0x10 * i);
          ReplaceByteList(bin, BitConverter.GetBytes(wind.Params[i].Param3), offset + 0x28 + 0x10 * i);
        }

        for (int i = 0; i < 4; i++)
          ReplaceByteList(bin, BitConverter.GetBytes(wind.Nums2[i]), offset + 0x50 + 4 * i);
        for (int i = 0; i < 3; i++)
        {
          ReplaceByteList(bin, BitConverter.GetBytes(wind.Params[i + 3].Param1), offset + 0x60 + 0x10 * i);
          ReplaceByteList(bin, BitConverter.GetBytes(wind.Params[i + 3].Param2), offset + 0x64 + 0x10 * i);
          ReplaceByteList(bin, BitConverter.GetBytes(wind.Params[i + 3].Param3), offset + 0x68 + 0x10 * i);
        }

        for (int i = 0; i < 4; i++)
          ReplaceByteList(bin, BitConverter.GetBytes(wind.Nums3[i]), offset + 0x90 + 4 * i);
        for (int i = 0; i < 3; i++)
        {
          ReplaceByteList(bin, BitConverter.GetBytes(wind.Params[i + 6].Param1), offset + 0xA0 + 0x10 * i);
          ReplaceByteList(bin, BitConverter.GetBytes(wind.Params[i + 6].Param2), offset + 0xA4 + 0x10 * i);
          ReplaceByteList(bin, BitConverter.GetBytes(wind.Params[i + 6].Param3), offset + 0xA8 + 0x10 * i);
        }

        count++;
      }
    }

  }
}
