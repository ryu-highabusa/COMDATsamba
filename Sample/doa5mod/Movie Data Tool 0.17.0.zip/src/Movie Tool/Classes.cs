﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace Movie_Tool
{
  public class HeaderData
  {
    public HeaderData(int start, byte[] bin)
    {
      this.Start = start;
      this.Offsets = new List<int>(0);
      this.Sizes = new List<int>(0);

      if (BitConverter.ToUInt32(bin, Start + 0x08) != 0x01010000) return;

      this.Name = Encoding.ASCII.GetString(bin, start, 8).TrimEnd(new char[] { '\0' });
      this.Flg1 = BitConverter.ToUInt32(bin, start + 0x08);
      this.HSize = BitConverter.ToInt32(bin, start + 0x0C);
      this.Size = BitConverter.ToInt32(bin, start + 0x10);
      this.Count1 = BitConverter.ToInt32(bin, start + 0x14);
      this.Count2 = BitConverter.ToInt32(bin, start + 0x18);
      this.Count3 = BitConverter.ToInt32(bin, start + 0x1C);
      this.Offset1 = BitConverter.ToInt32(bin, start + 0x20);
      this.Offset2 = BitConverter.ToInt32(bin, start + 0x24);
      this.Offset3 = BitConverter.ToInt32(bin, start + 0x28);
      this.Flg2 = BitConverter.ToInt32(bin, start + 0x2C);

      for (int i = 0; i < this.Count1; i++)
      {
        this.Offsets.Add(BitConverter.ToInt32(bin, start + this.Offset1 + (i * 0x04)));
      }

      if (this.Offset2 > 0)
      {
        for (int i = 0; i < this.Count1; i++)
        {
          this.Sizes.Add(BitConverter.ToInt32(bin, start + this.Offset2 + (i * 0x04)));
        }
      }
    }

    public int Start { get; set; }
    public string Name { get; set; }
    public uint Flg1 { get; set; }
    public int HSize { get; set; }
    public int Size { get; set; }
    public int Count1 { get; set; }
    public int Count2 { get; set; }
    public int Count3 { get; set; }
    public int Offset1 { get; set; }
    public int Offset2 { get; set; }
    public int Offset3 { get; set; }
    public int Flg2 { get; set; }

    public List<int> Offsets { get; private set; }
    public List<int> Sizes { get; private set; }
  }

  public class TdpData
  {
    public TdpData(byte[] bin)
    {
      this.H = new HeaderData(0, bin);
    }

    public HeaderData H { get; private set; }

  }

  public class MovData
  {
    public MovData(int start, byte[] bin)
    {
      this.Grps = new List<MovieParamGroup>();
      this.Cuts = new List<CutData>();
      this.Ints = new List<int>();
      this.Offsets = new List<int>();
      this.Offset1Ints = new List<int>();
      this.Offset2Ints = new List<int>();
      this.CutIDs = new List<int>();


      this.Data1 = new List<int>();
      this.Data2 = new List<byte[]>();
      this.Data3 = new List<List<int>>();
      this.Data4 = new List<List<dynamic>>();


      this.IntsOffset = BitConverter.ToInt32(bin, start);
      int count = 0;
      while (true)
      {
        int num = BitConverter.ToInt32(bin, start + this.IntsOffset + 4 * count);
        if (this.Ints.Count > 0 && num == 0) break;
        this.Ints.Add(num);
        count++;
      }

      count = 0;
      while (true)
      {
        int offset = BitConverter.ToInt32(bin, start + 12 + 8 * count);
        if (this.Offsets.Count > 0 && offset == 0) break;
        this.Offsets.Add(offset);
        count++;
      }

      var dataOffsets = new List<int>();
      for (int i = 0; i < 3; i++)
      {
        dataOffsets.Add(BitConverter.ToInt32(bin, start + this.Offsets[0] + 4 * i));
      }

      count = 0;
      while (true)
      {
        int offset = BitConverter.ToInt32(bin, start + dataOffsets[0] + 4 * count);
        if (offset == 0) break;
        this.Grps.Add(new MovieParamGroup(start + offset, bin));
        count++;
      }

      count = 0;
      while (true)
      {
        int num = BitConverter.ToInt32(bin, start + dataOffsets[1] + 4 * count);
        if (num == -1) break;
        this.Data1.Add(num);
        count++;
      }

      var data2Offsets = new List<int>();
      var data2Sizes = new List<int>();
      count = 0;
      while (true)
      {
        int offset = BitConverter.ToInt32(bin, start + dataOffsets[2] + 4 * count);
        if (offset == 0)
        {
          if (data2Offsets.Count > 0) data2Sizes.Add(dataOffsets[2] - data2Offsets.Last());
          break;
        }
        else if (data2Offsets.Count > 0)
        {
          data2Sizes.Add(offset - data2Offsets.Last());
        }
        data2Offsets.Add(offset);
        count++;
      }
      for (int i = 0; i < data2Offsets.Count; i++)
      {
        this.Data2.Add(bin.Skip(start + data2Offsets[i]).Take(data2Sizes[i]).ToArray());
      }

      this.Flag = BitConverter.ToInt32(bin, start + this.Offsets[0] + 12);

      int paramCount = BitConverter.ToInt32(bin, start + this.Offsets[0] + 0x10);
      int paramOffset = BitConverter.ToInt32(bin, start + this.Offsets[0] + 0x14);
      for (int i = 0; i < paramCount; i++)
      {
        var data = new List<int>();
        data.Add(BitConverter.ToInt32(bin, start + paramOffset + 8 * i));
        data.Add(BitConverter.ToInt32(bin, start + paramOffset + 4 + 8 * i));
        this.Data3.Add(data);
      }

      paramCount = BitConverter.ToInt32(bin, start + this.Offsets[0] + 0x18);
      paramOffset = BitConverter.ToInt32(bin, start + this.Offsets[0] + 0x1C);
      for (int i = 0; i < paramCount; i++)
      {
        int offset = BitConverter.ToInt32(bin, start + paramOffset + 4 * i);
        var data = new List<dynamic>();
        for (int j = 0; j < 5; j++)
        {
          if (j < 2)
            data.Add(BitConverter.ToInt32(bin, start + offset + 4 * j));
          else
            data.Add(BitConverter.ToSingle(bin, start + offset + 4 * j));
        }
        this.Data4.Add(data);
      }

      if (this.Offsets.Count > 1)
      {
        int offset = BitConverter.ToInt32(bin, start + this.Offsets[1]);
        this.Offset1Flag = BitConverter.ToInt32(bin, start + this.Offsets[1] + 4);
        if (this.Offset1Flag == 1)
        {
          int strOffset = BitConverter.ToInt32(bin, start + offset);
          this.Offset1Str = Encoding.ASCII.GetString(bin, start + strOffset, 8).TrimEnd(new char[] { '\0' });
          this.Offset1Ints.Add(BitConverter.ToInt32(bin, start + offset + 4));
          this.Offset1Ints.Add(BitConverter.ToInt32(bin, start + offset + 8));
        }
        else
        {
          this.Offset1Ints.Add(BitConverter.ToInt32(bin, start + offset));
          this.Offset1Ints.Add(BitConverter.ToInt32(bin, start + offset + 4));
        }
      }

      if (this.Offsets.Count > 2)
      {
        int offset = BitConverter.ToInt32(bin, start + this.Offsets[2]);
        this.Offset2Flag = BitConverter.ToInt32(bin, start + this.Offsets[2] + 4);
        this.Offset2Ints.Add(BitConverter.ToInt32(bin, start + offset));
        this.Offset2Ints.Add(BitConverter.ToInt32(bin, start + offset + 4));
      }

      if (this.Offsets.Count > 3)
      {
        int offset1 = BitConverter.ToInt32(bin, start + this.Offsets[3]);
        int offset2 = BitConverter.ToInt32(bin, start + this.Offsets[3] + 4);

        int cutCount = (offset2 - this.Offsets[3]) / 4 - 2;
        for (int i = 0; i < cutCount; i++)
        {
          this.CutIDs.Add(BitConverter.ToInt32(bin, start + this.Offsets[3] + 8 + 4 * i));
        }

        int cutOffsetsOffset = BitConverter.ToInt32(bin, start + offset1);
        var cutOffsets = new List<int>();
        count = 0;
        while (true)
        {
          int cutOffset = BitConverter.ToInt32(bin, start + cutOffsetsOffset + 4 * count);
          if (cutOffset == 0) break;
          cutOffsets.Add(cutOffset);
          count++;
        }

        foreach (var offset in cutOffsets)
        {
          this.Cuts.Add(new CutData(start + offset, bin));
        }
      }
    }

    public void ResetMaxParamCount(MovieParamGroup grp)
    {
      grp.MaxParamCount = 0;

      foreach (var param in grp.Params)
      {
        if (grp.MaxParamCount < param.Nums.Count) grp.MaxParamCount = param.Nums.Count;
      }
    }


    public int IntsOffset { get; set; }
    public List<int> Ints { get; set; }
    public List<int> Offsets { get; set; }

    public List<int> Data1 { get; set; }
    public List<byte[]> Data2 { get; set; }
    public int Flag { get; set; }
    public List<List<int>> Data3 { get; set; }
    public List<List<dynamic>> Data4 { get; set; }

    public int Offset1Flag { get; set; }
    public string Offset1Str { get; set; }
    public List<int> Offset1Ints { get; set; }

    public int Offset2Flag { get; set; }
    public List<int> Offset2Ints { get; set; }

    public List<int> CutIDs { get; set; }


    public List<MovieParamGroup> Grps { get; set; }
    public List<CutData> Cuts { get; set; }
  }

  public class MovieParamGroup
  {
    public MovieParamGroup(int start, byte[] bin)
    {
      this.Params = new List<MovieFrameParam>();

      this.MaxParamCount = 0;
      int paramStart = start;
      while (true)
      {
        var param = new MovieFrameParam(paramStart, bin);
        this.Params.Add(param);
        if (this.MaxParamCount < param.Nums.Count) this.MaxParamCount = param.Nums.Count;
        if (param.Type == 1) break;
        paramStart += 4 * (param.Nums.Count + 1);
      }
    }

    public int MaxParamCount { get; set; }
    public List<MovieFrameParam> Params { get; set; }
  }

  public class MovieFrameParam
  {
    public MovieFrameParam()
    {
      this.Nums = new List<int>();
    }
    public MovieFrameParam(int start, byte[] bin)
    {
      this.Nums = new List<int>();

      this.Type = BitConverter.ToInt16(bin, start);
      short count = BitConverter.ToInt16(bin, start + 2);
      for (int i = 1; i < count; i++)
      {
        this.Nums.Add(BitConverter.ToInt32(bin, start + 4 * i));
      }
    }

    public short Type { get; set; }
    public List<int> Nums { get; set; }
  }

  [Serializable]
  public class CutData
  {
    public CutData()
    {
      Init();
    }
    public CutData(int start, byte[] bin)
    {
      Init();

      this.Name = Encoding.ASCII.GetString(bin, start, 0x10).TrimEnd(new char[] { '\0' });

      for (int i = 0; i < 4; i++)
      {
        this.Ints[i] = BitConverter.ToInt32(bin, start + 0x10 + 4 * i);
      }
      for (int i = 0; i < 12; i++)
      {
        this.Floats[i] = BitConverter.ToSingle(bin, start + 0x20 + 4 * i);
      }
    }

    private void Init()
    {
      this.Ints = new int[4];
      this.Floats = new float[12];
    }

    public void ParamsCopy(CutData cut)
    {
      if (cut.Floats != null) this.Floats = (float[])cut.Floats.Clone();
    }

    public string Name { get; set; }
    public int[] Ints { get; set; }
    public float[] Floats { get; set; }
  }


  public class ScnData
  {
    public ScnData(int start, byte[] bin)
    {
      this.Lights = new List<LightData>();
      this.Hdrs = new List<HdrData>();
      this.Winds = new List<WindData>();

      this.H = new HeaderData(start, bin);

      if (this.H.Offsets[1] != 0) ParseLightData(start + this.H.Offsets[1], bin);
      if (this.H.Count1 > 4 && this.H.Offsets[4] != 0) ParseHdrData(start + this.H.Offsets[4], bin);
      if (this.H.Count1 > 7 && this.H.Offsets[7] != 0) ParseWindData(start + this.H.Offsets[7], bin);
    }

    public void ParseLightData(int start, byte[] bin)
    {
      this.NameLightData = Encoding.ASCII.GetString(bin, start + 0x10, 8).TrimEnd(new char[] { '\0' });

      int offsetOffsets = BitConverter.ToInt32(bin, start + 0x20);

      int count = 0;
      while(true)
      {
        int offset = BitConverter.ToInt32(bin, start + offsetOffsets + 4 * count);
        if (offset == 0) break;

        var data = new LightData(start, offset, bin);
        this.Lights.Add(data);

        count++;
      }
    }

    public void ParseHdrData(int start, byte[] bin)
    {
      this.NameHdrData = Encoding.ASCII.GetString(bin, start + 0x10, 8).TrimEnd(new char[] { '\0' });

      int offset = BitConverter.ToInt32(bin, start + 0x20);
      int count = BitConverter.ToInt32(bin, start + 0x24);

      for (int i = 0; i < count; i++)
      {
        int dataOffset = start + offset + 0x30 * i;
        var data = new HdrData(dataOffset, bin);
        this.Hdrs.Add(data);
      }
    }

    public void ParseWindData(int start, byte[] bin)
    {
      this.NameWindData = Encoding.ASCII.GetString(bin, start + 0x10, 8).TrimEnd(new char[] { '\0' });

      int offset = BitConverter.ToInt32(bin, start + 0x20);
      int count = BitConverter.ToInt32(bin, start + 0x24);

      for (int i = 0; i < count; i++)
      {
        int dataOffset = start + offset + 0xE0 * i;
        var data = new WindData(dataOffset, bin);
        this.Winds.Add(data);
      }
    }

    public HeaderData H { get; private set; }

    public string NameLightData { get; set; }
    public string NameHdrData { get; set; }
    public string NameWindData { get; set; }
    public List<LightData> Lights { get; set; }
    public List<HdrData> Hdrs { get; set; }
    public List<WindData> Winds { get; set; }
  }

  [Serializable]
  public class LightData
  {
    public LightData()
    {
      this.Init();
    }
    public LightData(int start, int offset, byte[] bin)
    {
      this.Init();


      this.Offset = offset;

      this.Name = Encoding.ASCII.GetString(bin, start + offset, 0x10).TrimEnd(new char[] { '\0' });

      for (int i = 0; i < 8; i++)
        this.Nums[i] = BitConverter.ToInt32(bin, start + offset + 0x10 + 4 * i);


      this.OffsetParams = this.Nums[3];
      int startParams = start + this.Nums[3];

      for (int i = 0; i < 4; i++)
        this.ParamsNums[i] = BitConverter.ToInt32(bin, startParams + 4 * i);

      for (int i = 0; i < 4; i++)
        this.AmbientColor[i] = BitConverter.ToSingle(bin, startParams + 0x10 + 4 * i);
      for (int i = 0; i < 4; i++)
        this.AmbientSpeColor[i] = BitConverter.ToSingle(bin, startParams + 0x20 + 4 * i);
      this.AmbientFlag = BitConverter.ToInt32(bin, startParams + 0x30);
      for (int i = 0; i < 4; i++)
        this.AmbientSub1Color[i] = BitConverter.ToSingle(bin, startParams + 0x40 + 4 * i);
      for (int i = 0; i < 4; i++)
        this.AmbientSub2Color[i] = BitConverter.ToSingle(bin, startParams + 0x50 + 4 * i);

      for (int i = 0; i < 3; i++)
        this.Unknown1[i] = BitConverter.ToSingle(bin, startParams + 0x60 + 4 * i);
      this.Unknown1Flag = BitConverter.ToInt32(bin, startParams + 0x6C);

      for (int i = 0; i < 4; i++)
        this.MainColor[i] = BitConverter.ToSingle(bin, startParams + 0x70 + 4 * i);
      this.MainAngleElevation = BitConverter.ToSingle(bin, startParams + 0x80);
      this.MainAngleDirection = BitConverter.ToSingle(bin, startParams + 0x84);
      this.MainPoint = BitConverter.ToBoolean(bin, startParams + 0x88);
      this.MainEnable = BitConverter.ToBoolean(bin, startParams + 0x8C);

      for (int i = 0; i < 4; i++)
        this.Unknown2[i] = BitConverter.ToInt32(bin, startParams + 0x90 + 4 * i);

      for (int i = 0; i < 4; i++)
        this.Sub1Color[i] = BitConverter.ToSingle(bin, startParams + 0xA0 + 4 * i);
      this.Sub1AngleElevation = BitConverter.ToSingle(bin, startParams + 0xB0);
      this.Sub1AngleDirection = BitConverter.ToSingle(bin, startParams + 0xB4);
      this.Sub1Point = BitConverter.ToBoolean(bin, startParams + 0xB8);
      this.Sub1Enable = BitConverter.ToBoolean(bin, startParams + 0xBC);

      for (int i = 0; i < 4; i++)
        this.Unknown3[i] = BitConverter.ToInt32(bin, startParams + 0xC0 + 4 * i);

      for (int i = 0; i < 4; i++)
        this.Sub2Color[i] = BitConverter.ToSingle(bin, startParams + 0xD0 + 4 * i);
      this.Sub2AngleElevation = BitConverter.ToSingle(bin, startParams + 0xE0);
      this.Sub2AngleDirection = BitConverter.ToSingle(bin, startParams + 0xE4);
      this.Sub2Point = BitConverter.ToBoolean(bin, startParams + 0xE8);
      this.Sub2Enable = BitConverter.ToBoolean(bin, startParams + 0xEC);

      for (int i = 0; i < 4; i++)
        this.Unknown4[i] = BitConverter.ToInt32(bin, startParams + 0xF0 + 4 * i);

      for (int i = 0; i < 4; i++)
        this.SelfShadowColor[i] = BitConverter.ToSingle(bin, startParams + 0x100 + 4 * i);

      for (int i = 0; i < 4; i++)
        this.Unknown5[i] = BitConverter.ToInt32(bin, startParams + 0x110 + 4 * i);
      for (int i = 0; i < 4; i++)
        this.Unknown6[i] = BitConverter.ToInt32(bin, startParams + 0x120 + 4 * i);


      this.OffsetParams2 = this.Nums[4];
      for (int i = 0; i < 4; i++)
      {
        this.Params2[i] = BitConverter.ToInt32(bin, start + this.OffsetParams2 + 4 * i);
      }
    }

    public void Init()
    {
      this.Nums = new int[8];
      this.OffsetParams = this.Nums[3];
      this.ParamsNums = new int[4];
      this.AmbientColor = new float[4];
      this.AmbientSpeColor = new float[4];
      this.AmbientSub1Color = new float[4];
      this.AmbientSub2Color = new float[4];
      this.Unknown1 = new float[3];
      this.MainColor = new float[4];
      this.Unknown2 = new int[4];
      this.Sub1Color = new float[4];
      this.Unknown3 = new int[4];
      this.Sub2Color = new float[4];
      this.Unknown4 = new int[4];
      this.SelfShadowColor = new float[4];
      this.Unknown5 = new int[4];
      this.Unknown6 = new int[4];
      this.Params2 = new int[4];
    }

    public void ParamsCopy(LightData light)
    {
      if (light.AmbientColor != null) this.AmbientColor = (float[])light.AmbientColor.Clone();
      if (light.AmbientSpeColor != null) this.AmbientSpeColor = (float[])light.AmbientSpeColor.Clone();
      this.AmbientFlag = light.AmbientFlag;
      if (light.AmbientSub1Color != null) this.AmbientSub1Color = (float[])light.AmbientSub1Color.Clone();
      if (light.AmbientSub2Color != null) this.AmbientSub2Color = (float[])light.AmbientSub2Color.Clone();

      if (light.MainColor != null) this.MainColor = (float[])light.MainColor.Clone();
      this.MainAngleElevation = light.MainAngleElevation;
      this.MainAngleDirection = light.MainAngleDirection;
      this.MainPoint = light.MainPoint;
      this.MainEnable = light.MainEnable;

      if (light.Sub1Color != null) this.Sub1Color = (float[])light.Sub1Color.Clone();
      this.Sub1AngleElevation = light.Sub1AngleElevation;
      this.Sub1AngleDirection = light.Sub1AngleDirection;
      this.Sub1Point = light.Sub1Point;
      this.Sub1Enable = light.Sub1Enable;

      if (light.Sub2Color != null) this.Sub2Color = (float[])light.Sub2Color.Clone();
      this.Sub2AngleElevation = light.Sub2AngleElevation;
      this.Sub2AngleDirection = light.Sub2AngleDirection;
      this.Sub2Point = light.Sub2Point;
      this.Sub2Enable = light.Sub2Enable;

      if (light.SelfShadowColor != null) this.SelfShadowColor = (float[])light.SelfShadowColor.Clone();
    }

    public int Offset { get; private set; }
    public int OffsetParams { get; private set; }
    public int OffsetParams2 { get; private set; }

    public string Name { get; set; }
    public int[] Nums { get; set; }

    public int[] ParamsNums { get; set; }

    public float[] AmbientColor { get; set; }
    public float[] AmbientSpeColor { get; set; }
    public int     AmbientFlag { get; set; }
    public float[] AmbientSub1Color { get; set; }
    public float[] AmbientSub2Color { get; set; }

    public float[] Unknown1 { get; set; }
    public int Unknown1Flag { get; set; }

    public float[] MainColor { get; set; }
    public float   MainAngleElevation { get; set; }
    public float   MainAngleDirection { get; set; }
    public bool    MainPoint { get; set; }
    public bool    MainEnable { get; set; }

    public int[] Unknown2 { get; set; }

    public float[] Sub1Color { get; set; }
    public float   Sub1AngleElevation { get; set; }
    public float   Sub1AngleDirection { get; set; }
    public bool    Sub1Point { get; set; }
    public bool    Sub1Enable { get; set; }

    public int[] Unknown3 { get; set; }

    public float[] Sub2Color { get; set; }
    public float   Sub2AngleElevation { get; set; }
    public float   Sub2AngleDirection { get; set; }
    public bool    Sub2Point { get; set; }
    public bool    Sub2Enable { get; set; }

    public int[] Unknown4 { get; set; }

    public float[] SelfShadowColor { get; set; }

    public int[] Unknown5 { get; set; }
    public int[] Unknown6 { get; set; }

    public int[] Params2 { get; set; }
  }

  [Serializable]
  public class HdrData
  {
    public HdrData()
    {
      this.Init();
    }
    public HdrData(int start, byte[] bin)
    {
      this.Init();

      this.Name = Encoding.ASCII.GetString(bin, start, 0x10).TrimEnd(new char[] { '\0' });

      for (int i = 0; i < 8; i++)
        this.Params[i] = BitConverter.ToSingle(bin, start + 0x10 + 4 * i);
    }

    public void Init()
    {
      this.Params = new float[8];
    }

    public void ParamsCopy(HdrData hdr)
    {
      if (hdr.Params != null) this.Params = (float[])hdr.Params.Clone();
    }

    public string Name { get; set; }
    public float[] Params { get; set; }
  }

  [Serializable]
  public class WindData
  {
    public WindData()
    {
      this.Init();
    }
    public WindData(int start, byte[] bin)
    {
      this.Init();

      this.Name = Encoding.ASCII.GetString(bin, start, 0x10).TrimEnd(new char[] { '\0' });

      for (int i = 0; i < 4; i++)
        this.Nums1[i] = BitConverter.ToInt32(bin, start + 0x10 + 4 * i);

      for (int i = 0; i < 3; i++)
        this.Params.Add(new WindParam(start + 0x20 + 0x10 * i, bin));

      for (int i = 0; i < 4; i++)
        this.Nums2[i] = BitConverter.ToInt32(bin, start + 0x50 + 4 * i);

      for (int i = 0; i < 3; i++)
        this.Params.Add(new WindParam(start + 0x60 + 0x10 * i, bin));

      for (int i = 0; i < 4; i++)
        this.Nums3[i] = BitConverter.ToInt32(bin, start + 0x90 + 4 * i);

      for (int i = 0; i < 3; i++)
        this.Params.Add(new WindParam(start + 0xA0 + 0x10 * i, bin));
    }

    public void Init()
    {
      this.Params = new List<WindParam>();
      this.Nums1 = new int[4];
      this.Nums2 = new int[4];
      this.Nums3 = new int[4];
    }

    public void ParamsCopy(WindData wind)
    {
      if (wind.Nums1 != null) this.Nums1 = (int[])wind.Nums1.Clone();
      if (wind.Nums2 != null) this.Nums2 = (int[])wind.Nums2.Clone();
      if (wind.Nums3 != null) this.Nums3 = (int[])wind.Nums3.Clone();

      if (this.Params.Count > 0) this.Params.Clear();
      foreach (var param in wind.Params)
      {
        var newParam = new WindParam();
        newParam.Param1 = param.Param1;
        newParam.Param2 = param.Param2;
        newParam.Param3 = param.Param3;
        this.Params.Add(newParam);
      }
    }

    public string Name { get; set; }

    public int[] Nums1 { get; set; }
    public int[] Nums2 { get; set; }
    public int[] Nums3 { get; set; }

    public List<WindParam> Params { get; set; }
  }

  [Serializable]
  public class WindParam
  {
    public WindParam()
    {
    }
    public WindParam(int start, byte[] bin)
    {
      this.Param1 = BitConverter.ToSingle(bin, start);
      this.Param2 = BitConverter.ToSingle(bin, start + 4);
      this.Param3 = BitConverter.ToInt32(bin, start + 8);
    }

    public float Param1 { get; set; }
    public float Param2 { get; set; }
    public int Param3 { get; set; }
  }


  public class MpmData
  {
    public MpmData(int start, byte[] bin)
    {
      this.Grps = new List<MotionGroup>();

      this.H = new HeaderData(start, bin);

      for (int i = 0; i < this.H.Count1; i++)
      {
        MotionGroup motion = null;
        if (this.H.Offsets[i] != 0)
        {
          motion = new MotionGroup(start + this.H.Offsets[i], bin);
        }
        this.Grps.Add(motion);
      }
    }

    public HeaderData H { get; private set; }

    public List<MotionGroup> Grps { get; set; }
  }

  public class MotionGroup
  {
    public MotionGroup(int start, byte[] bin)
    {
      this.Hies = new List<Hierarchy>();
      this.Motions = new List<MotionData>();
      this.Block5 = new List<Block5Data>();
      this.Block6 = new List<Block6Data>();

      this.H = new HeaderData(start, bin);

      if (this.H.Offsets[1] != 0)
      {
        int nextIndex = 2;
        if (this.H.Offsets[2] == 0) nextIndex = 3;
        this.Block1Bin = bin.Skip(start + this.H.Offsets[1]).Take(this.H.Offsets[nextIndex] - this.H.Offsets[1]).ToArray();
      }
      if (this.H.Offsets[2] != 0)
      {
        this.Block2Bin = bin.Skip(start + this.H.Offsets[2]).Take(this.H.Offsets[3] - this.H.Offsets[2]).ToArray();
      }

      this.Unknown = BitConverter.ToInt32(bin, start + this.H.Offsets[3]);
      this.MotionCount = BitConverter.ToInt32(bin, start + this.H.Offsets[3] + 4);
      this.BoneCount = BitConverter.ToInt32(bin, start + this.H.Offsets[3] + 8);
      char[] charsToTrim = { '\0' };
      this.BaseBoneName = Encoding.ASCII.GetString(bin, start + this.H.Offsets[3] + 0x10, 0x20).TrimEnd(charsToTrim);

      // Hie
      this.HieH = new HeaderData(start + this.H.Offsets[4], bin);
      for (int i = 0; i < this.HieH.Count1; i++)
      {
        var hie = new Hierarchy(this.HieH.Start + this.HieH.Offsets[i], bin);
        hie.Index = i;
        this.Hies.Add(hie);
      }

      // Motions
      for (int i = 0; i < this.MotionCount; i++)
      {
        int offset = BitConverter.ToInt32(bin, start + this.H.Offsets[0] + (4 * i));
        var motion = new MotionData(start + this.H.Offsets[0], offset, this.BoneCount, bin);
        this.Motions.Add(motion);
      }

      int block5Count = BitConverter.ToInt32(bin, start + this.H.Offsets[5]);
      for (int i = 0; i < block5Count; i++)
      {
        var block5 = new Block5Data(start + this.H.Offsets[5], 4 + (8 * i), bin);
        this.Block5.Add(block5);
      }
      var size = 0;
      if (this.H.Count1 > 6)
      {
        size = this.H.Offsets[6] - this.H.Offsets[5];
      }
      else
      {
        size = this.H.Size - this.H.Offsets[5];
      }
      if (size > (8 * this.Block5.Count) + 16)
      {
        this.AddEmptyAfterBlock5 = true;
      }

      if (this.H.Count1 > 6)
      {
        int block6Offset = 0;
        while (true)
        {
          var block6 = new Block6Data(start + this.H.Offsets[6], block6Offset, bin);
          if (block6.Num == -1)
          {
            break;
          }
          block6Offset += 4 * (2 + block6.Nums.Count);
          this.Block6.Add(block6);
        }
      }

    }

    public HeaderData H { get; private set; }
    public HeaderData HieH { get; private set; }

    public int Unknown { get; set; }
    public int MotionCount { get; set; }
    public int BoneCount { get; set; }
    public string BaseBoneName { get; set; }

    public List<Hierarchy> Hies { get; set; }
    public List<MotionData> Motions { get; set; }

    public byte[] Block1Bin { get; set; }
    public byte[] Block2Bin { get; set; }
    public List<Block5Data> Block5 { get; set; }
    public bool AddEmptyAfterBlock5 { get; set; }
    public List<Block6Data> Block6 { get; set; }
  }

  public class Hierarchy
  {
    public Hierarchy(int start, byte[] bin)
    {
      this.Parent = BitConverter.ToInt32(bin, start);
      this.ChildrenCount = BitConverter.ToInt32(bin, start + 4);
      this.Children = new int[this.ChildrenCount];
      for (int i = 0; i < this.ChildrenCount; i++)
      {
        this.Children[i] = BitConverter.ToInt32(bin, start + 8 + (4 * i));
      }
    }

    public int Index { get; set; }
    public int Parent { get; set; }
    public int ChildrenCount { get; set; }
    public int[] Children { get; set; }
  }

  public class MotionData
  {
    public MotionData(int start, int offset, int boneCount, byte[] bin)
    {
      this.DataBytes = new Dictionary<int, List<byte>>();
      this.Parts = new List<MotionPartData>();
      this.PartOffsetSet = new List<int>();
      this.PartOffsets = new List<int>();
      this.PartSizes = new List<int>();
      var partOffsetSet = new SortedSet<int>();

      this.Offset = offset;

      int count = 0;

      for (int i = 0; i < boneCount * 9; i++)
      {
        int partOffset = BitConverter.ToInt32(bin, start + offset + (4 * i));
        if (partOffset == 0)
        {
          count = i / 9;
          break;
        }
        partOffsetSet.Add(partOffset);
        this.PartOffsets.Add(partOffset);
      }
      this.PartOffsetSet = partOffsetSet.ToList();

      if (count == 0)
        this.BoneCount = boneCount;
      else
        this.BoneCount = count;

      for (int i = 0; i < this.PartOffsetSet.Count; i++)
      {
        int partSize = 0;
        if (i < this.PartOffsetSet.Count - 1)
        {
          partSize = this.PartOffsetSet[i + 1] - this.PartOffsetSet[i];
        }
        else
        {
          partSize = offset - this.PartOffsetSet[i];
        }
        this.PartSizes.Add(partSize);

        var bytes = ParseDataBytes(start, this.PartOffsetSet[i], partSize, bin);
        this.DataBytes[this.PartOffsetSet[i]] = bytes;
      }

      for (int i = 0; i < this.PartOffsets.Count; i++)
      {
        var partData = new MotionPartData(start, this.PartOffsets[i], this.DataBytes[this.PartOffsets[i]]);
        this.Parts.Add(partData);
      }

      if (this.PartOffsetSet.Count > 0 && this.Parts.Count > 0)
      {
        this.Type = this.Parts[0].Type;
        this.FrameCount = this.Parts[0].FrameCount;
      }
    }

    public List<byte> ParseDataBytes(int start, int offset, int size, byte[] bin)
    {
      var bytes = new List<byte>();

      int count = 0;
      while (true)
      {
        byte data = bin[start + offset + count];
        bytes.Add(data);
        if (count >= size - 2)
        {
          data = bin[start + offset + count + 1];
          bytes.Add(data);
          break;
        }
        count++;
      }

      return bytes;
    }

    public int Offset { get; set; }

    public int Type { get; set; }
    public int FrameCount { get; set; }

    public int BoneCount { get; set; }

    public bool Modified { get; set; }

    public List<int> PartOffsetSet { get; set; }
    public List<int> PartOffsets { get; set; }
    public List<int> PartSizes { get; set; }
    public Dictionary<int, List<byte>> DataBytes { get; set; }
    public List<MotionPartData> Parts { get; set; }
  }

  public class MotionPartData
  {
    public MotionPartData(int start, int offset, List<byte> dataBytes)
    {
      this.Frames = new Dictionary<int, PartFrameData>();

      this.Offset = offset;
      this.Address = start + offset;

      if (dataBytes[0] == 0 && dataBytes[1] == 7)
      {
        this.Type = 0; // Baked
        this.ParseFramesBaked(dataBytes);
      }
      else
      {
        this.Type = 1; // Curve
        this.ParseFramesCurve(dataBytes);
      }
    }

    public void ParseFramesBaked(List<byte> data)
    {
      var tempParams = new List<int>();

      int p = 2;
      while (true)
      {
        byte[] tempBn = new byte[4];
        Array.Copy(data.ToArray(), p, tempBn, 0, 3);
        var tempBytes2 = new List<byte>() { data[p], data[p + 1] };
        p += 3;

        int frameCount = BitConverter.ToUInt16(tempBytes2.ToArray(), 0);

        if (tempBn[2] == 0x80) // terminator
        {
          tempBytes2.Add(data[p]);
          if (tempBytes2[2] > 0x7F)
            tempBytes2.Add(0xFF);
          else
            tempBytes2.Add(0);
          tempParams.Add(BitConverter.ToInt32(tempBytes2.ToArray(), 0));
          break;
        }
        else if (tempBn[2] == 0x7F) // 1 byte
        {
          for (int i = 0; i < frameCount; i++)
          {
            int curParam = tempParams[tempParams.Count - 1];
            byte tempByte = 0;
            if (data[p] > 0x7F) tempByte = 0xFF;
            int diff = BitConverter.ToInt16(new byte[] { data[p], tempByte }, 0);
            tempParams.Add(curParam + diff);
            p++;
          }
        }
        else if (tempBn[2] == 0x7E) // 2 bytes
        {
          for (int i = 0; i < frameCount; i++)
          {
            int curParam = tempParams[tempParams.Count - 1];
            int diff = BitConverter.ToInt16(new byte[] { data[p], data[p + 1] }, 0);
            tempParams.Add(curParam + diff);
            p += 2;
          }
        }
        else if (tempBn[2] == 0x7D) // constant
        {
          int curParam = tempParams[tempParams.Count - 1];
          p++;
          for (int i = 0; i < frameCount; i++)
          {
            tempParams.Add(curParam);
          }
        }
        else // 3 bytes
        {
          if (tempBn[2] > 0x7F) tempBn[3] = 0xFF;
          tempParams.Add(BitConverter.ToInt32(tempBn, 0));
        }
      }

      for (int i = 0; i < tempParams.Count; i++)
      {
        var frameData = new PartFrameData((float)tempParams[i] / 0x4000, null, null);
        this.Frames[i] = frameData;
      }

      this.FrameCount = tempParams.Count;
    }

    public void ParseFramesCurve(List<byte> data)
    {
      int totalFrameCount = 0;

      int p = 0;

      while (true)
      {
        byte[] countCheckBytes = new byte[] { data[p], data[p + 1] };
        p += 2;
        int countCheck = countCheckBytes[0] % 8 * 0x100 + countCheckBytes[1];
        int flag1 = countCheckBytes[0] / 8 * 8;

        int frameCount = countCheck / 4;
        int flag2 = countCheck % 4;

        byte byte4 = 0;

        byte[] paramBytes = null;
        int? num1 = null;
        int? num2 = null;
        if (flag1 == 0xA8)
        {
          paramBytes = new byte[] { data[p + 3], data[p + 2], data[p + 1], data[p] };
          num1 = BitConverter.ToInt16(new byte[] { data[p + 5], data[p + 4] }, 0);
          num2 = BitConverter.ToInt32(new byte[] { data[p + 9], data[p + 8], data[p + 7], data[p + 6] }, 0);
          p += 10;
        }
        else if (flag1 == 0x98)
        {
          paramBytes = new byte[] { data[p + 3], data[p + 2], data[p + 1], data[p] };
          num1 = BitConverter.ToInt16(new byte[] { data[p + 5], data[p + 4] }, 0);
          num2 = BitConverter.ToInt16(new byte[] { data[p + 7], data[p + 6] }, 0);
          p += 8;
        }
        else if (flag1 == 0x48)
        {
          paramBytes = new byte[] { data[p + 3], data[p + 2], data[p + 1], data[p] };
          p += 4;
        }
        else if (flag2 == 0 || flag2 == 1 || flag2 == 3)
        {
          byte byte3 = (byte)(flag1 / 0x10);
          if (flag1 > 0x7F)
          {
            byte3 += 0xF0;
            byte4 = 0xFF;
          }
          paramBytes = new byte[] { data[p + 1], data[p], byte3, byte4 };

          if (flag2 == 1)
          {
            p += 2;
          }
          else if (flag2 == 3)
          {
            num1 = BitConverter.ToInt16(new byte[] { data[p + 3], data[p + 2] }, 0);
            num2 = BitConverter.ToInt16(new byte[] { data[p + 5], data[p + 4] }, 0);
            p += 6;
          }
        }

        if (paramBytes == null)
        {
          Console.WriteLine(flag2.ToString(), countCheckBytes);
        }

        var frameData = new PartFrameData((float)BitConverter.ToInt32(paramBytes, 0) / 10000, num1, num2);
        this.Frames[totalFrameCount] = frameData;
        totalFrameCount += frameCount;

        if (flag2 == 0)
        {
          totalFrameCount++;
          break;
        }
      }

      this.FrameCount = totalFrameCount;
    }


    public int Offset { get; set; }
    public int Address { get; set; }

    public int Type { get; set; }
    public int FrameCount { get; set; }

    public Dictionary<int, PartFrameData> Frames { get; set; }
  }

  public class PartFrameData
  {
    public PartFrameData(float param, int? num1, int? num2)
    {
      this.Param = param;
      this.Num1 = num1;
      this.Num2 = num2;
    }

    public float Param { get; set; }
    public int? Num1 { get; set; }
    public int? Num2 { get; set; }
  }

  public class Block5Data
  {
    public Block5Data(int start, int offset, byte[] bin)
    {
      this.Num1 = BitConverter.ToInt32(bin, start + offset);
      this.Num2 = BitConverter.ToInt32(bin, start + offset + 4);
    }

    public int Num1 { get; set; }
    public int Num2 { get; set; }
  }

  public class Block6Data
  {
    public Block6Data(int start, int offset, byte[] bin)
    {
      this.Nums = new List<uint>();

      this.Num = BitConverter.ToInt32(bin, start + offset);
      int count = BitConverter.ToInt16(bin, start + offset + 6);

      for (int i = 0; i < count; i++)
      {
        Nums.Add(BitConverter.ToUInt32(bin, start + offset + 8 + (4 * i)));
      }
    }

    public int Num { get; set; }
    public List<uint> Nums { get; set; }
  }


  public class CamData
  {
    public CamData(int start, byte[] bin)
    {
      this.Motions = new List<CameraMotionData>();
      this.ParamSets = new List<CameraParamSet>();

      this.Start = start;

      this.ParamOffsetsOffset = BitConverter.ToInt32(bin, start);
      int count = 0;
      List<int> paramOffsets = new List<int>();
      while (true)
      {
        int offset1Count = BitConverter.ToInt32(bin, start + this.ParamOffsetsOffset + (8 * count));
        if (offset1Count == 0) break;
        int offset1 = BitConverter.ToInt32(bin, start + this.ParamOffsetsOffset + (8 * count) + 4);

        for (int i = 0; i < offset1Count; i++)
        {
          if (this.ParamSets.Count <= i)
          {
            this.ParamSets.Add(new CameraParamSet());
          }

          var offset = BitConverter.ToInt32(bin, start + offset1 + (4 * i));
          paramOffsets.Add(offset);
          this.ParamSets[i].Offsets.Add(offset);
          this.ParamSets[i].CameraParamParse(start + offset, bin);
        }

        count++;
      }
      this.ParamStart = paramOffsets.Min();

      this.InfoOffsetsOffset = BitConverter.ToInt32(bin, start + 4);
      count = 0;
      while (true)
      {
        int infoOffset = BitConverter.ToInt32(bin, start + this.InfoOffsetsOffset + (4 * count));
        if (infoOffset == 0) break;
        var motion = new CameraMotionData(start, infoOffset, bin);
        this.Motions.Add(motion);
        count++;
      }

      for (int i = 0; i < this.Motions.Count; i++)
      {
        foreach (var set in this.ParamSets)
        {
          this.Motions[i].Repeatable = true;
          if (set.Groups.Count > 1)
          {
            this.Motions[i].Repeatable = false;
            continue;
          }
          foreach (var grp in set.Groups)
          {
            if (grp.Params[0].Type != 0x12)
            {
              continue;
            }
            else
            {
              if (grp.Params[0].Type == 0x12 && grp.Params[0].Data.Count > 3 && grp.Params[0].Data[2] == i)
              {
                this.Motions[i].OriginalRepeat = true;
                this.Motions[i].Repeat = true;
                this.Motions[i].RepeatStart = grp.Params[0].Data[3];
                return;
              }
            }
          }
        }
      }
    }

    public int Start { get; set; }
    public int ParamStart { get; set; }
    public int ParamOffsetsOffset { get; set; }
    public int InfoOffsetsOffset { get; set; }

    public List<CameraParamSet> ParamSets { get; set; }
    public List<CameraMotionData> Motions { get; set; }
  }

  public class CameraMotionData
  {
    public CameraMotionData(int start, int offset, byte[] bin)
    {
      this.Frames = new List<FrameData>();
      this.Offsets = new Dictionary<string, int>();

      this.Offset = offset;

      this.FrameCount = BitConverter.ToInt32(bin, start + offset);
      this.Unknown = BitConverter.ToInt32(bin, start + offset + 4);
      this.Offsets["Por"] = BitConverter.ToInt32(bin, start + offset + 8);
      this.Offsets["Position"] = BitConverter.ToInt32(bin, start + offset + 12);
      this.Offsets["Tilt"] = BitConverter.ToInt32(bin, start + offset + 16);
      this.Offsets["Angle"] = BitConverter.ToInt32(bin, start + offset + 20);

      for (int i = 0; i < this.FrameCount; i++)
      {
        var frame = new FrameData(start, this.Offsets, i, bin);
        this.Frames.Add(frame);
      }
    }

    public int Offset { get; set; }

    public int FrameCount { get; set; }
    public int Unknown { get; set; }
    public bool Repeatable { get; set; }
    public bool OriginalRepeat { get; set; }
    public bool Repeat { get; set; }
    public uint? RepeatStart { get; set; }

    public Dictionary<string, int> Offsets { get; set; }
    public List<FrameData> Frames { get; set; }
  }

  public class FrameData
  {
    public FrameData(int start, Dictionary<string, int> offsets, int frame, byte[] bin)
    {
      this.Frame = frame;
      this.PositionX = BitConverter.ToSingle(bin, start + offsets["Position"] + (12 * frame));
      this.PositionY = BitConverter.ToSingle(bin, start + offsets["Position"] + (12 * frame) + 4);
      this.PositionZ = BitConverter.ToSingle(bin, start + offsets["Position"] + (12 * frame) + 8);
      this.PorX = BitConverter.ToSingle(bin, start + offsets["Por"] + (12 * frame));
      this.PorY = BitConverter.ToSingle(bin, start + offsets["Por"] + (12 * frame) + 4);
      this.PorZ = BitConverter.ToSingle(bin, start + offsets["Por"] + (12 * frame) + 8);
      this.Tilt = BitConverter.ToSingle(bin, start + offsets["Tilt"] + (4 * frame));
      this.Angle = BitConverter.ToSingle(bin, start + offsets["Angle"] + (4 * frame));
    }
    public FrameData(int frame)
    {
      this.Frame = frame;
    }

    public int Frame { get; set; }
    public float PositionX { get; set; }
    public float PositionY { get; set; }
    public float PositionZ { get; set; }
    public float PorX { get; set; }
    public float PorY { get; set; }
    public float PorZ { get; set; }
    public float Tilt { get; set; }
    public float Angle { get; set; }
  }

  public class CameraParamSet
  {
    public CameraParamSet()
    {
      this.Offsets = new List<int>();
      this.Groups = new List<CameraParamGroup>();
    }
    public void CameraParamParse(int start, byte[] bin)
    {
      this.Groups.Add(new CameraParamGroup(start, bin));
    }

    public List<int> Offsets { get; set; }
    public List<CameraParamGroup> Groups { get; set; }
  }

  public class CameraParamGroup
  {
    public CameraParamGroup()
    {
      this.Params = new List<CameraParam>();
    }
    public CameraParamGroup(int start, byte[] bin)
    {
      this.Params = new List<CameraParam>();

      int offset = start;
      bool check = false;
      do
      {
        var param = new CameraParam();
        param.Type = BitConverter.ToInt16(bin, offset);
        short count = BitConverter.ToInt16(bin, offset + 2);

        for (int i = 1; i < count; i++)
        {
          if (
            param.Type == 0x01 ||
            (param.Type == 0x02 && i > 2) ||
            (param.Type == 0x03 && i > 2) ||
            (param.Type == 0x05 && i > 2) ||
            (param.Type == 0x10 && i > 3) ||
            param.Type == 0x19
          )
          {
            param.Data.Add(BitConverter.ToSingle(bin, offset + (4 * i)));
          }
          else
          {
            param.Data.Add(BitConverter.ToUInt32(bin, offset + (4 * i)));
          }
        }
        this.Params.Add(param);
        offset += 4 * count;

        check = false;
        if (param.Type == 0 || param.Type == 0x12 || (this.Params.Count > 1 && param.Type != 0x26)) check = true;
      } while (check);
    }

    public List<CameraParam> Params { get; set; }
  }

  public class CameraParam
  {
    public CameraParam()
    {
      this.Data = new List<dynamic>();
    }

    public short Type { get; set; }
    public List<dynamic> Data { get; set; }
  }



  public class MovieTables
  {
    public MovieTables(MovData movData, ScnData scnData, MpmData mpmData, CamData camData)
    {
      this.MovieParamGrps = new ObservableCollection<MovieParamGrpData>();
      this.MovieParams = new ObservableCollection<MovieParamData>();
      this.Cuts = new ObservableCollection<MovieCutData>();
      this.LightGrps = new ObservableCollection<LightGrpData>();
      this.HdrGrps = new ObservableCollection<HdrGrpData>();
      this.WindGrps = new ObservableCollection<WindGrpData>();
      this.BoneMotionGrps = new ObservableCollection<BoneMotionGrpData>();
      this.BoneMotions = new ObservableCollection<BoneMotionBaseData>();
      this.BoneMotFrames = new ObservableCollection<BoneMotionFrameData>();
      this.CameraMotions = new ObservableCollection<CameraMotionBaseData>();
      this.CamMotFrames = new ObservableCollection<CameraMotionFrameData>();

      if (movData != null)
      {
        for (int i = 0; i < movData.Grps.Count; i++)
        {
          if (movData.Grps[i] == null) continue;
          this.MovieParamGrps.Add(new MovieParamGrpData(i, movData.Grps[i]));
        }
        for (int i = 0; i < movData.Cuts.Count; i++)
        {
          if (movData.Cuts[i] == null) continue;
          this.Cuts.Add(new MovieCutData(i, movData.Cuts[i]));
        }
      }

      if (scnData != null)
      {
        for (int i = 0; i < scnData.Lights.Count; i++)
        {
          if (scnData.Lights[i] == null) continue;
          this.LightGrps.Add(new LightGrpData(i, scnData.Lights[i]));
        }
        for (int i = 0; i < scnData.Hdrs.Count; i++)
        {
          if (scnData.Hdrs[i] == null) continue;
          this.HdrGrps.Add(new HdrGrpData(i, scnData.Hdrs[i]));
        }
        for (int i = 0; i < scnData.Winds.Count; i++)
        {
          if (scnData.Winds[i] == null) continue;
          this.WindGrps.Add(new WindGrpData(i, scnData.Winds[i]));
        }
      }

      if (mpmData != null)
      {
        for (int i = 0; i < mpmData.Grps.Count; i++)
        {
          if (mpmData.Grps[i] == null) continue;
          this.BoneMotionGrps.Add(new BoneMotionGrpData(i, mpmData.Grps[i]));
        }
      }

      if (camData != null)
      {
        for (int i = 0; i < camData.Motions.Count; i++)
        {
          this.CameraMotions.Add(new CameraMotionBaseData(i, camData.Motions[i]));
        }
      }
    }

    public class MovieParamGrpData
    {
      public MovieParamGrpData(int index, MovieParamGroup grp)
      {
        this.Index = index;
      }

      public int Index { get; set; }
    }

    public class MovieParamData
    {
      public MovieParamData(MovieFrameParam param, int index, int maxParamCount)
      {
        this.Nums = Enumerable.Repeat<int?>(null, maxParamCount).ToArray();

        this.Index = index;
        this.Type = "0x" + param.Type.ToString("X4");

        switch (param.Type)
        {
          case 0x00:
            this.Note = "Start";
            break;
          case 0x01:
            this.Note = "End";
            break;
          case 0x16:
            this.Note = "Frame Count";
            break;
          case 0x24:
            this.Note = "Character";
            break;
          case 0x2F:
            this.Note = "Fade In";
            break;
          case 0x30:
            this.Note = "Fade Out";
            break;
          case 0xEC:
            this.Note = "Cut";
            break;
          case 0xEF:
            this.Note = "Offset";
            break;
          case 0xFF:
            this.Note = "Dirty";
            break;
          case 0xDC:
          case 0xDD:
          case 0xDE:
          case 0x011C:
          case 0x011D:
          case 0x011E:
            this.Note = "Sound";
            break;
          case 0x0135:
            this.Note = "Damage";
            break;
          default:
            this.Note = "";
            break;
        }

        for (int i = 0; i < param.Nums.Count; i++)
        {
          this.Nums[i] = param.Nums[i];
        }
      }

      public int Index { get; set; }
      public string Type { get; set; }
      public string Note { get; set; }
      public int?[] Nums { get; set; }
    }

    public class MovieCutData
    {
      public MovieCutData(int index, CutData data)
      {
        this.Index = index;
        this.Name = data.Name;
      }

      public int Index { get; set; }
      public string Name { get; set; }
    }


    public class LightGrpData
    {
      public LightGrpData(int index, LightData data)
      {
        this.Index = index;
        this.Name = data.Name;
      }

      public int Index { get; set; }
      public string Name { get; set; }
    }

    public class HdrGrpData
    {
      public HdrGrpData(int index, HdrData data)
      {
        this.Index = index;
        this.Name = data.Name;
      }

      public int Index { get; set; }
      public string Name { get; set; }
    }

    public class WindGrpData
    {
      public WindGrpData(int index, WindData data)
      {
        this.Index = index;
        this.Name = data.Name;
      }

      public int Index { get; set; }
      public string Name { get; set; }
    }


    public class BoneMotionGrpData
    {
      public BoneMotionGrpData(int index, MotionGroup grp)
      {
        this.Index = index;
        this.MotionCount = grp.MotionCount;
        this.BoneCount = grp.BoneCount;
        this.BaseBoneName = grp.BaseBoneName;
      }

      public int Index { get; set; }
      public int MotionCount { get; set; }
      public int BoneCount { get; set; }
      public string BaseBoneName { get; set; }
    }

    public class BoneMotionBaseData : INotifyPropertyChanged
    {
      public BoneMotionBaseData(int index, MotionData motion)
      {
        this.Index = index;
        this.BoneCount = motion.BoneCount;
        this.FrameCount = motion.FrameCount;
        if (motion.Type == 0)
        {
          this.Type = "Baked";
        }
        else if (motion.Type == 1)
        {
          this.Type = "Curve";
        }
      }

      public int Index { get; set; }
      public int BoneCount { get; set; }
      private int _frameCount;
      public int FrameCount
      {
        get { return _frameCount; }
        set
        {
          _frameCount = value;
          OnPropertyChanged("FrameCount");
        }
      }
      private string _type;
      public string Type
      {
        get { return _type; }
        set
        {
          _type = value;
          OnPropertyChanged("Type");
        }
      }

      public event PropertyChangedEventHandler PropertyChanged;
      private void OnPropertyChanged(string name)
      {
        if (PropertyChanged != null)
        {
          PropertyChanged(this, new PropertyChangedEventArgs(name));
        }
      }
    }

    public class BoneMotionFrameData : INotifyPropertyChanged
    {
      public BoneMotionFrameData(MotionData motion, int boneIndex, int frame)
      {
        var part0 = motion.Parts[boneIndex * 9 + 0];
        var part1 = motion.Parts[boneIndex * 9 + 1];
        var part2 = motion.Parts[boneIndex * 9 + 2];
        var part3 = motion.Parts[boneIndex * 9 + 3];
        var part4 = motion.Parts[boneIndex * 9 + 4];
        var part5 = motion.Parts[boneIndex * 9 + 5];
        var part6 = motion.Parts[boneIndex * 9 + 6];
        var part7 = motion.Parts[boneIndex * 9 + 7];
        var part8 = motion.Parts[boneIndex * 9 + 8];

        this.Frame = frame;
        if (part0.Frames.ContainsKey(frame)) this.PositionX = (decimal)part0.Frames[frame].Param;
        if (part1.Frames.ContainsKey(frame)) this.PositionY = (decimal)part1.Frames[frame].Param;
        if (part2.Frames.ContainsKey(frame)) this.PositionZ = (decimal)part2.Frames[frame].Param;
        if (part3.Frames.ContainsKey(frame)) this.RotationX = (decimal)part3.Frames[frame].Param;
        if (part4.Frames.ContainsKey(frame)) this.RotationY = (decimal)part4.Frames[frame].Param;
        if (part5.Frames.ContainsKey(frame)) this.RotationZ = (decimal)part5.Frames[frame].Param;
        if (part6.Frames.ContainsKey(frame)) this.ScaleX = (decimal)part6.Frames[frame].Param;
        if (part7.Frames.ContainsKey(frame)) this.ScaleY = (decimal)part7.Frames[frame].Param;
        if (part8.Frames.ContainsKey(frame)) this.ScaleZ = (decimal)part8.Frames[frame].Param;
      }

      private int _frame;
      public int Frame
      {
        get { return _frame; }
        set
        {
          _frame = value;
          OnPropertyChanged("Frame");
        }
      }
      private decimal? _positionX;
      public decimal? PositionX
      {
        get { return _positionX; }
        set
        {
          _positionX = value;
          OnPropertyChanged("PositionX");
        }
      }
      private decimal? _positionY;
      public decimal? PositionY
      {
        get { return _positionY; }
        set
        {
          _positionY = value;
          OnPropertyChanged("PositionY");
        }
      }
      private decimal? _positionZ;
      public decimal? PositionZ
      {
        get { return _positionZ; }
        set
        {
          _positionZ = value;
          OnPropertyChanged("PositionZ");
        }
      }
      private decimal? _rotationX;
      public decimal? RotationX
      {
        get { return _rotationX; }
        set
        {
          _rotationX = value;
          OnPropertyChanged("RotationX");
        }
      }
      private decimal? _rotationY;
      public decimal? RotationY
      {
        get { return _rotationY; }
        set
        {
          _rotationY = value;
          OnPropertyChanged("RotationY");
        }
      }
      private decimal? _rotationZ;
      public decimal? RotationZ
      {
        get { return _rotationZ; }
        set
        {
          _rotationZ = value;
          OnPropertyChanged("RotationZ");
        }
      }
      private decimal? _scaleX;
      public decimal? ScaleX
      {
        get { return _scaleX; }
        set
        {
          _scaleX = value;
          OnPropertyChanged("ScaleX");
        }
      }
      private decimal? _scaleY;
      public decimal? ScaleY
      {
        get { return _scaleY; }
        set
        {
          _scaleY = value;
          OnPropertyChanged("ScaleY");
        }
      }
      private decimal? _scaleZ;
      public decimal? ScaleZ
      {
        get { return _scaleZ; }
        set
        {
          _scaleZ = value;
          OnPropertyChanged("ScaleZ");
        }
      }

      public event PropertyChangedEventHandler PropertyChanged;
      private void OnPropertyChanged(string name)
      {
        if (PropertyChanged != null)
        {
          PropertyChanged(this, new PropertyChangedEventArgs(name));
        }
      }
    }

    public class CameraMotionBaseData : INotifyPropertyChanged
    {
      public CameraMotionBaseData(int index, CameraMotionData motion)
      {
        this.Index = index;
        this.FrameCount = motion.FrameCount;
        this.Repeat = motion.Repeat;
        this.RepeatStart = motion.RepeatStart;
      }

      public int Index { get; set; }
      private int _frameCount;
      public int FrameCount
      {
        get { return _frameCount; }
        set
        {
          _frameCount = value;
          OnPropertyChanged("FrameCount");
        }
      }

      public bool Repeat { get; set; }
      public uint? RepeatStart { get; set; }


      public event PropertyChangedEventHandler PropertyChanged;
      private void OnPropertyChanged(string name)
      {
        if (PropertyChanged != null)
        {
          PropertyChanged(this, new PropertyChangedEventArgs(name));
        }
      }
    }

    public class CameraMotionFrameData : INotifyPropertyChanged
    {
      public CameraMotionFrameData(FrameData data)
      {
        this.Frame = data.Frame;
        this.PositionX = (decimal)data.PositionX;
        this.PositionY = (decimal)data.PositionY;
        this.PositionZ = (decimal)data.PositionZ;
        this.PorX = (decimal)data.PorX;
        this.PorY = (decimal)data.PorY;
        this.PorZ = (decimal)data.PorZ;
        this.Tilt = (decimal)data.Tilt;
        this.Angle = (decimal)data.Angle;
      }

      private int _frame;
      public int Frame
      {
        get { return _frame; }
        set
        {
          _frame = value;
          OnPropertyChanged("Frame");
        }
      }
      private decimal _positionX;
      public decimal PositionX
      {
        get { return _positionX; }
        set
        {
          _positionX = value;
          OnPropertyChanged("PositionX");
        }
      }
      private decimal _positionY;
      public decimal PositionY
      {
        get { return _positionY; }
        set
        {
          _positionY = value;
          OnPropertyChanged("PositionY");
        }
      }
      private decimal _positionZ;
      public decimal PositionZ
      {
        get { return _positionZ; }
        set
        {
          _positionZ = value;
          OnPropertyChanged("PositionZ");
        }
      }
      private decimal _porX;
      public decimal PorX
      {
        get { return _porX; }
        set
        {
          _porX = value;
          OnPropertyChanged("PorX");
        }
      }
      private decimal _porY;
      public decimal PorY
      {
        get { return _porY; }
        set
        {
          _porY = value;
          OnPropertyChanged("PorY");
        }
      }
      private decimal _porZ;
      public decimal PorZ
      {
        get { return _porZ; }
        set
        {
          _porZ = value;
          OnPropertyChanged("PorZ");
        }
      }
      private decimal _tilt;
      public decimal Tilt
      {
        get { return _tilt; }
        set
        {
          _tilt = value;
          OnPropertyChanged("Tilt");
        }
      }
      private decimal _angle;
      public decimal Angle
      {
        get { return _angle; }
        set
        {
          _angle = value;
          OnPropertyChanged("Angle");
        }
      }

      public event PropertyChangedEventHandler PropertyChanged;
      private void OnPropertyChanged(string name)
      {
        if (PropertyChanged != null)
        {
          PropertyChanged(this, new PropertyChangedEventArgs(name));
        }
      }
    }


    public void SetMovieParams(MovieParamGroup grp, int visibleFlag)
    {
      if (this.MovieParams.Count > 0) this.MovieParams.Clear();

      for (int i = 0; i < grp.Params.Count; i++)
      {
        var data = new MovieParamData(grp.Params[i], i, grp.MaxParamCount);

        if (
          (visibleFlag == 1 && data.Note == "") ||
          (visibleFlag == 2 && data.Note != "Frame Count" && data.Note != "Cut") ||
          (visibleFlag == 3 && data.Note != "Frame Count")
        )
        {
          continue;
        }

        this.MovieParams.Add(data);
      }
    }

    public void SetBoneMotions(MotionGroup grp)
    {
      if (this.BoneMotions.Count > 0) this.BoneMotions.Clear();

      for (int i = 0; i < grp.Motions.Count; i++)
      {
        this.BoneMotions.Add(new BoneMotionBaseData(i, grp.Motions[i]));
      }
    }

    public void SetBoneMotionFrame(MotionData motion, int boneIndex)
    {
      if (this.BoneMotFrames.Count > 0) this.BoneMotFrames.Clear();

      for (int i = 0; i < motion.FrameCount; i++)
      {
        this.BoneMotFrames.Add(new BoneMotionFrameData(motion, boneIndex, i));
      }
    }

    public void SetCameraMotionFrame(CameraMotionData motion)
    {
      if (this.CamMotFrames.Count > 0) this.CamMotFrames.Clear();

      foreach (var frameData in motion.Frames)
      {
        this.CamMotFrames.Add(new CameraMotionFrameData(frameData));
      }
    }


    public ObservableCollection<MovieParamGrpData> MovieParamGrps { get; set; }
    public ObservableCollection<MovieParamData> MovieParams { get; set; }
    public ObservableCollection<MovieCutData> Cuts { get; set; }

    public ObservableCollection<LightGrpData> LightGrps { get; set; }
    public ObservableCollection<HdrGrpData> HdrGrps { get; set; }
    public ObservableCollection<WindGrpData> WindGrps { get; set; }

    public ObservableCollection<BoneMotionGrpData> BoneMotionGrps { get; set; }
    public ObservableCollection<BoneMotionBaseData> BoneMotions { get; set; }
    public ObservableCollection<BoneMotionFrameData> BoneMotFrames { get; set; }

    public ObservableCollection<CameraMotionBaseData> CameraMotions { get; set; }
    public ObservableCollection<CameraMotionFrameData> CamMotFrames { get; set; }
  }

}
