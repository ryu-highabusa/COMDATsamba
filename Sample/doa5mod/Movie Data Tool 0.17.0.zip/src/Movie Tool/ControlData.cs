﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Globalization;
using System.Threading;
using Message;

namespace Movie_Tool
{
  public partial class MainWindow : Window
  {
    private decimal? GetBoneFrameData(MovieTables.BoneMotionFrameData frameData, string property)
    {
      switch (property)
      {
        case "PositionX":
          return frameData.PositionX;
        case "PositionY":
          return frameData.PositionY;
        case "PositionZ":
          return frameData.PositionZ;
        case "RotationX":
          return frameData.RotationX;
        case "RotationY":
          return frameData.RotationY;
        case "RotationZ":
          return frameData.RotationZ;
        case "ScaleX":
          return frameData.ScaleX;
        case "ScaleY":
          return frameData.ScaleY;
        case "ScaleZ":
          return frameData.ScaleZ;
        default:
          return null;
      }
    }
    private void SetBoneFrameData(MovieTables.BoneMotionFrameData frameData, string property, decimal val)
    {
      switch (property)
      {
        case "PositionX":
          frameData.PositionX = val;
          break;
        case "PositionY":
          frameData.PositionY = val;
          break;
        case "PositionZ":
          frameData.PositionZ = val;
          break;
        case "RotationX":
          frameData.RotationX = val;
          break;
        case "RotationY":
          frameData.RotationY = val;
          break;
        case "RotationZ":
          frameData.RotationZ = val;
          break;
        case "ScaleX":
          frameData.ScaleX = val;
          break;
        case "ScaleY":
          frameData.ScaleY = val;
          break;
        case "ScaleZ":
          frameData.ScaleZ = val;
          break;
      }
    }


    private decimal? GetCameraFrameData(dynamic frameData, string property)
    {
      switch (property)
      {
        case "PositionX":
          return frameData.PositionX;
        case "PositionY":
          return frameData.PositionY;
        case "PositionZ":
          return frameData.PositionZ;
        case "PorX":
          return frameData.PorX;
        case "PorY":
          return frameData.PorY;
        case "PorZ":
          return frameData.PorZ;
        case "Tilt":
          return frameData.Tilt;
        case "Angle":
          return frameData.Angle;
        default:
          return null;
      }
    }
    private void SetCameraFrameData(dynamic frameData, string property, dynamic val)
    {
      switch (property)
      {
        case "PositionX":
          frameData.PositionX = val;
          break;
        case "PositionY":
          frameData.PositionY = val;
          break;
        case "PositionZ":
          frameData.PositionZ = val;
          break;
        case "PorX":
          frameData.PorX = val;
          break;
        case "PorY":
          frameData.PorY = val;
          break;
        case "PorZ":
          frameData.PorZ = val;
          break;
        case "Tilt":
          frameData.Tilt = val;
          break;
        case "Angle":
          frameData.Angle = val;
          break;
      }
    }


    private void ImportCsvBone(string filePath)
    {
      tabControl.IsEnabled = false;
      DoEvents();

      try
      {
        bool ignoreFrame = (bool)cbIgnoreFrameMot.IsChecked;
        bool add = (bool)cbAddMot.IsChecked;
        if (!cbAddMot.IsEnabled) add = false;
        bool keepPos = (bool)cbKeepPos.IsChecked;

        var returnCsvTuple = ParseMotionCsv(filePath, ignoreFrame);
        var csvData = returnCsvTuple.Item1;
        var lastFrame = returnCsvTuple.Item2;
        var maxColCount = returnCsvTuple.Item3;

        var grp = mpmData.Grps[movieTables.BoneMotionGrps[dgMotionGrps.SelectedIndex].Index];
        var motion = grp.Motions[dgMotions.SelectedIndex];

        // 最初のボーン名チェック
        if (!String.IsNullOrEmpty(firstHeaderName) && bonenames.ContainsKey(grp.BaseBoneName) && firstHeaderName != bonenames[grp.BaseBoneName][0])
        {
          var result = MessageWindow.Show(this, String.Format(txt["ConfirmBoneIsDifferent"], firstHeaderName), txt["Confirm"], txt["Continue"], txt["Cancel"]);
          if (result == MessageWindow.Result.Cancel) return;
        }

        // 列数チェック
        if (maxColCount > motion.Parts.Count)
        {
          MessageWindow.Show(this, txt["OverColumnCount"], txt["Error"]);
          return;
        }

        bool curve = false;
        if (motion.Type == 1) curve = true;

        int frameCount = movieTables.BoneMotions[dgMotions.SelectedIndex].FrameCount;

        int checkResult = 0;
        if (add)
        {
          lastFrame += frameCount;
        }
        else
        {
          checkResult = CheckFrameCount(frameCount, lastFrame, curve);
          if (checkResult == -1) return;
        }

        foreach (KeyValuePair<int, float?[]> data in csvData)
        {
          if (data.Key < 0 || (data.Key >= frameCount && checkResult != 2)) continue;

          int frame = data.Key;
          if (add) frame += frameCount;

          SetCsvRowBone(motion, frame, data.Value, grp.BaseBoneName, keepPos);
        }

        if (checkResult == 1)
        {
          // 最終フレームのデータで埋める処理
          for (int i = lastFrame + 1; i < frameCount; i++)
          {
            SetCsvRowBone(motion, i, csvData[lastFrame], grp.BaseBoneName, keepPos);
          }
        }
        else if (checkResult == 2 || add)
        {
          // フレームが抜けている場合は1つ前のフレームの値をセット
          for (int i = frameCount; i < lastFrame + 1; i++)
          {
            List<int> addList = new List<int>();
            for (int j = 0; j < grp.BoneCount; j++)
            {
              if (!motion.Parts[9 * j].Frames.ContainsKey(i))
              {
                addList.Add(j);
              }
            }

            if (addList.Count > 0)
            {
              float?[] values = new float?[motion.Parts.Count];
              for (int j = 0; j < grp.BoneCount; j++)
              {
                if (addList.Contains(j))
                {
                  for (int k = 9 * j; k < 9 * j + 9; k++)
                  {
                    values[k] = motion.Parts[k].Frames[i - 1].Param;
                  }
                }
              }
              SetCsvRowBone(motion, i, values, grp.BaseBoneName, keepPos);
            }
          }

          motion.FrameCount = lastFrame + 1;
          movieTables.BoneMotions[dgMotions.SelectedIndex].FrameCount = lastFrame + 1;
          foreach (var part in motion.Parts)
          {
            part.FrameCount = lastFrame + 1;
          }
        }

        motion.Type = 0;
        movieTables.BoneMotions[dgMotions.SelectedIndex].Type = "Baked";
        btnExportCsvBone.IsEnabled = true;
        if (grp.BaseBoneName == "OPT_Face_Root") panelFacePosAdjust.IsEnabled = true;
        movieTables.SetBoneMotionFrame(motion, lbBones.SelectedIndex);

        curCsvPath = filePath;
        Modified();
        modifiedBone = true;
        motion.Modified = true;

        ShowTextBlockMessage(txt["Imported"]);
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }
      finally
      {
        tabControl.IsEnabled = true;
      }
    }

    private void SetCsvRowBone(MotionData motion, int frame, float?[] values, string baseBoneName, bool keepPos)
    {
      for (int i = 0; i < values.Length; i++)
      {
        bool keepPosition = false;
        if (values[i] == null ||
            (
              keepPos &&
              (baseBoneName != "OPT_Face_Root" && (i % 9 == 0 || i % 9 == 1 || i % 9 == 2)) &&
              !(baseBoneName == "MOT00_Hips" && i < 3)
            )
          )
          keepPosition = true;

        //if (values[i] == null) Console.WriteLine(i);

        var part = motion.Parts[i];

        if (part.Frames.ContainsKey(frame))
        {
          if (keepPosition) continue;

          float val = (float)values[i];
          part.Frames[frame].Param = val;
          part.Frames[frame].Num1 = null;
          part.Frames[frame].Num2 = null;
        }
        else
        {
          PartFrameData frameData;
          if (keepPosition && motion.FrameCount > 0)
          {
            frameData = new PartFrameData(part.Frames[motion.FrameCount - 1].Param, null, null);
          }
          else
          {
            float val = (float)values[i];
            frameData = new PartFrameData(val, null, null);
          }
          part.Frames[frame] = frameData;
        }
      }
    }

    private void ExportCsvBone(string filePath)
    {
      tabControl.IsEnabled = false;
      DoEvents();

      try
      {
        var grp = mpmData.Grps[movieTables.BoneMotionGrps[dgMotionGrps.SelectedIndex].Index];
        var motion = grp.Motions[dgMotions.SelectedIndex];

        string str = "";

        foreach (var item in lbBones.Items)
        {
          str += "," + item.ToString();
          str += ",,,,,,,,";
        }
        str += "\r\n";

        str += "Frame";
        foreach (var item in lbBones.Items)
        {
          str += ",PositionX";
          str += ",PositionY";
          str += ",PositionZ";
          str += ",RotationX";
          str += ",RotationY";
          str += ",RotationZ";
          str += ",ScaleX";
          str += ",ScaleY";
          str += ",ScaleZ";
        }
        str += "\r\n";

        if (curCulture != null) Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");

        for (int i = 0; i < motion.FrameCount; i++)
        {
          string row = "";

          row += i.ToString();
          for (int j = 0; j < motion.PartOffsets.Count; j++)
          {
            row += "," + motion.Parts[j].Frames[i].Param;
          }
          row += "\r\n";

          str += row;
        }

        if (curCulture != null) Thread.CurrentThread.CurrentCulture = curCulture;

        System.Text.Encoding enc = System.Text.Encoding.GetEncoding("utf-8");
        System.IO.File.WriteAllText(filePath, str, enc);
        curCsvPath = filePath;

        ShowTextBlockMessage(txt["Exported"]);
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }
      finally
      {
        tabControl.IsEnabled = true;
      }
    }


    private void ImportCsvCam(string filePath)
    {
      tabControl.IsEnabled = false;
      DoEvents();

      try
      {
        bool ignoreFrame = (bool)cbIgnoreFrameCam.IsChecked;
        bool add = (bool)cbAddCam.IsChecked;

        var returnCsvTuple = ParseMotionCsv(filePath, ignoreFrame);
        var csvData = returnCsvTuple.Item1;
        var lastFrame = returnCsvTuple.Item2;

        int selIndex = dgCameraMotions.SelectedIndex;
        var framesData = camData.Motions[selIndex].Frames;
        int frameCount = framesData.Count;

        int checkResult = 0;
        if (add)
        {
          lastFrame += frameCount;
        }
        else
        {
          checkResult = CheckFrameCount(frameCount, lastFrame, false);
          if (checkResult == -1) return;
        }

        List<int> addFrames = new List<int>();
        if (checkResult == 2 || add)
        {
          for (int i = frameCount; i < lastFrame + 1; i++)
          {
            framesData.Add(new FrameData(i));
          }
        }

        foreach (KeyValuePair<int, float?[]> data in csvData)
        {
          if (data.Key < 0 || (data.Key >= frameCount && checkResult != 2)) continue;

          int frame = data.Key;
          if (add)
          {
            frame += frameCount;
            addFrames.Add(frame);
          }
          else if (frame >= frameCount)
          {
            addFrames.Add(frame);
          }

          SetCsvRowCam(framesData[frame], data.Value);
        }

        if (checkResult == 1)
        {
          // 最終フレームのデータで埋める処理
          for (int i = lastFrame + 1; i < frameCount; i++)
          {
            SetCsvRowCam(framesData[i], csvData[lastFrame]);
          }
        }
        else if (checkResult == 2 || add)
        {
          camData.Motions[selIndex].FrameCount = lastFrame + 1;
          movieTables.CameraMotions[selIndex].FrameCount = lastFrame + 1;

          // フレームが抜けている場合は1つ前のフレームの値をセット
          for (int i = frameCount; i < lastFrame + 1; i++)
          {
            if (!addFrames.Contains(i))
            {
              framesData[i].PositionX = framesData[i - 1].PositionX;
              framesData[i].PositionY = framesData[i - 1].PositionY;
              framesData[i].PositionZ = framesData[i - 1].PositionZ;
              framesData[i].PorX = framesData[i - 1].PorX;
              framesData[i].PorY = framesData[i - 1].PorY;
              framesData[i].PorZ = framesData[i - 1].PorZ;
              framesData[i].Tilt = framesData[i - 1].Tilt;
              framesData[i].Angle = framesData[i - 1].Angle;
            }
          }
        }

        movieTables.SetCameraMotionFrame(camData.Motions[selIndex]);

        curCsvPath = filePath;
        Modified();
        modifiedCam = true;

        ShowTextBlockMessage(txt["Imported"]);
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }
      finally
      {
        tabControl.IsEnabled = true;
      }
    }

    private void SetCsvRowCam(FrameData frameData, float?[] values)
    {
      for (int i = 0; i < values.Length; i++)
      {
        if (i > 7) break;
        if (values[i] == null) continue;

        float val = (float)values[i];

        switch (i)
        {
          case 0:
            frameData.PositionX = val;
            break;
          case 1:
            frameData.PositionY = val;
            break;
          case 2:
            frameData.PositionZ = val;
            break;
          case 3:
            frameData.PorX = val;
            break;
          case 4:
            frameData.PorY = val;
            break;
          case 5:
            frameData.PorZ = val;
            break;
          case 6:
            frameData.Tilt = val;
            break;
          case 7:
            frameData.Angle = val;
            break;
        }
      }
    }

    private void ExportCsvCam(string filePath)
    {
      tabControl.IsEnabled = false;
      DoEvents();

      try
      {
        string str = "";

        str += "Frame";
        str += ",PositionX";
        str += ",PositionY";
        str += ",PositionZ";
        str += ",PorX";
        str += ",PorY";
        str += ",PorZ";
        str += ",Tilt";
        str += ",Angle";
        str += "\r\n";

        if (curCulture != null) Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");

        foreach (var frameData in movieTables.CamMotFrames)
        {
          string row = "";

          row += frameData.Frame;
          row += "," + frameData.PositionX;
          row += "," + frameData.PositionY;
          row += "," + frameData.PositionZ;
          row += "," + frameData.PorX;
          row += "," + frameData.PorY;
          row += "," + frameData.PorZ;
          row += "," + frameData.Tilt;
          row += "," + frameData.Angle;
          row += "\r\n";

          str += row;
        }

        if (curCulture != null) Thread.CurrentThread.CurrentCulture = curCulture;

        System.Text.Encoding enc = System.Text.Encoding.GetEncoding("utf-8");
        System.IO.File.WriteAllText(filePath, str, enc);
        curCsvPath = filePath;

        ShowTextBlockMessage(txt["Exported"]);
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }
      finally
      {
        tabControl.IsEnabled = true;
      }
    }


    private Tuple<Dictionary<int, float?[]>, int, int> ParseMotionCsv(string filePath, bool ignoreFrame)
    {
      var csvData = new Dictionary<int, float?[]>();
      int lastFrame = 0;
      int maxColCount = 0;

      string csvText = File.ReadAllText(filePath, Encoding.GetEncoding("utf-8"));
      string[] rows = csvText.Trim().Replace("\r", "").Split('\n');

      if (curCulture != null) Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");

      firstHeaderName = "";
      int count = 0;
      foreach (string row in rows)
      {
        if (String.IsNullOrWhiteSpace(row)) continue;

        string[] cols = row.Split(',');
        float?[] rowData = new float?[cols.Length - 1];
        int frame = -1;

        for (int i = 0; i < cols.Length; i++)
        {
          string cell = cols[i].Trim(new char[] { '"', ' ' });

          if (i == 0)
          {
            int outInt;
            if (int.TryParse(cell, out outInt))
            {
              frame = outInt;
            }
            else
            {
              if (String.IsNullOrEmpty(firstHeaderName) && i < cols.Length - 1)
              {
                string nextCell = cols[i + 1].Trim(new char[] { '"', ' ' });
                firstHeaderName = nextCell;
              }

              break;
            }
          }
          else
          {
            float outFloat;
            if (float.TryParse(cell, out outFloat))
            {
              rowData[i - 1] = outFloat;
            }
            else
            {
              rowData[i - 1] = null;
            }
          }
        }

        if (frame == -1) continue;

        if (ignoreFrame)
        {
          frame = count;
          count++;
        }

        csvData[frame] = rowData;
        if (frame > lastFrame) lastFrame = frame;
        if (maxColCount < rowData.Length) maxColCount = rowData.Length;
      }

      if (curCulture != null) Thread.CurrentThread.CurrentCulture = curCulture;

      return Tuple.Create(csvData, lastFrame, maxColCount);
    }

    private int CheckFrameCount(int frameCount, int lastFrame, bool curve)
    {
      string frameStr = txt["MotionFrameCount"] + " : " + frameCount + " / " + txt["ImportFrameCount"] + " : " + (lastFrame + 1) + "\r\n\r\n";

      if (lastFrame + 1 < frameCount)
      {
        // 元がCurveの場合はImportedOnlyは無効に
        if (curve)
        {
          var result = MessageWindow.Show(this, frameStr + txt["ConfirmFrameNotEnough"], txt["Confirm"], txt["FillByLastFrame"], txt["Cancel"]);
          if (result == MessageWindow.Result.Cancel)
          {
            return -1;
          }
          else
          {
            // Fill By Last Frame
            return 1;
          }
        }
        else
        {
          var result = MessageWindow.Show(this, frameStr + txt["ConfirmFrameNotEnough"], txt["Confirm"], txt["ImportedOnly"], txt["Cancel"], txt["FillByLastFrame"]);
          if (result == MessageWindow.Result.Cancel)
          {
            return -1;
          }
          else if (result == MessageWindow.Result.Other)
          {
            // Fill By Last Frame
            return 1;
          }
        }
      }
      else if (lastFrame + 1 > frameCount)
      {
        var result = MessageWindow.Show(this, frameStr + txt["ConfirmFrameOver"], txt["Confirm"], txt["CurrentFrameCountOnly"], txt["Cancel"], txt["CsvFrameCount"]);
        if (result == MessageWindow.Result.Other)
        {
          return 2;
        }
        else if (result == MessageWindow.Result.Cancel)
        {
          return -1;
        }
      }

      // Imported Only
      return 0;
    }



    private Dictionary<int, SortedSet<int>> PreCheckFillDown(DataGrid dataGrid)
    {
      if (dataGrid == null) return null;

      var selIndices = new Dictionary<int, SortedSet<int>>();
      List<int> colSet = new List<int>();

      try
      {
        foreach (var cell in dataGrid.SelectedCells)
        {
          int selColIndex = cell.Column.DisplayIndex;

          colSet.Add(selColIndex);

          if (!selIndices.ContainsKey(selColIndex))
          {
            var selRowIndices = new SortedSet<int>();
            selIndices[selColIndex] = selRowIndices;
          }

          int selRowIndex = -1;

          if (dataGrid.Name == "dgMotionFrames")
          {
            var item = cell.Item as MovieTables.BoneMotionFrameData;
            selRowIndex = dataGrid.Items.IndexOf(item);
          }
          else if (dataGrid.Name == "dgCameraFrames")
          {
            var item = cell.Item as MovieTables.CameraMotionFrameData;
            selRowIndex = dataGrid.Items.IndexOf(item);
          }

          selIndices[selColIndex].Add(selRowIndex);
        }

        if (colSet.Count == 0 || selIndices[colSet[0]].Count < 2)
        {
          return null;
        }

        SortedSet<int> checkSet = new SortedSet<int>();
        foreach (var set in selIndices)
        {
          checkSet.UnionWith(set.Value);
          if (checkSet.Count != set.Value.Count)
          {
            return null;
          }
        }

        int num = selIndices[colSet[0]].ToArray()[0];
        for (int i = 1; i < selIndices[colSet[0]].Count; i++)
        {
          num++;
          if (selIndices[colSet[0]].ToArray()[i] != num)
          {
            return null;
          }
        }
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }

      return selIndices;
    }

    private void FillDown(DataGrid dataGrid)
    {
      try
      {
        DataGridCellInfo dataGridCellInfo;

        if (dataGrid.Name == "dgMotionFrames")
        {
          var motion = mpmData.Grps[movieTables.BoneMotionGrps[dgMotionGrps.SelectedIndex].Index].Motions[dgMotions.SelectedIndex];
          if (motion == null || motion.Type == 1) return;

          foreach (var set in selCellIndices)
          {
            var deci = GetBoneFrameData(movieTables.BoneMotFrames[set.Value.ToArray()[0]], dataGrid.Columns[set.Key].SortMemberPath);
            if (deci == null) continue;
            float val = (float)deci;

            for (int i = 1; i < set.Value.Count; i++)
            {
              dataGridCellInfo = new DataGridCellInfo(dataGrid.Items[set.Value.ToArray()[i]], dataGrid.Columns[set.Key]);
              var item = dataGridCellInfo.Item as MovieTables.BoneMotionFrameData;

              SetBoneFrameData(item, dataGridCellInfo.Column.SortMemberPath, (decimal)val);

              var part = motion.Parts[lbBones.SelectedIndex * 9 + dataGridCellInfo.Column.DisplayIndex];
              part.Frames[item.Frame].Param = val;
            }

            modifiedBone = true;
            motion.Modified = true;
          }
        }
        else if (dataGrid.Name == "dgCameraFrames")
        {
          var motion = camData.Motions[dgCameraMotions.SelectedIndex];
          if (motion == null) return;

          foreach (var set in selCellIndices)
          {
            var deci = GetCameraFrameData(movieTables.CamMotFrames[set.Value.ToArray()[0]], dataGrid.Columns[set.Key].SortMemberPath);
            if (deci == null) continue;
            float val = (float)deci;

            for (int i = 1; i < set.Value.Count; i++)
            {
              dataGridCellInfo = new DataGridCellInfo(dataGrid.Items[set.Value.ToArray()[i]], dataGrid.Columns[set.Key]);
              var item = dataGridCellInfo.Item as MovieTables.CameraMotionFrameData;

              SetCameraFrameData(item, dataGridCellInfo.Column.SortMemberPath, (decimal)val);

              var frameData = motion.Frames[item.Frame];
              SetCameraFrameData(frameData, dataGridCellInfo.Column.SortMemberPath, val);
            }

            modifiedCam = true;
          }
        }

        Modified();

        selCellIndices = null;
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }
    }

    private void DeleteFrames(DataGrid dataGrid)
    {
      try
      {
        if (dataGrid.Name == "dgMotionFrames")
        {
          var motion = mpmData.Grps[movieTables.BoneMotionGrps[dgMotionGrps.SelectedIndex].Index].Motions[dgMotions.SelectedIndex];
          if (motion == null || motion.Type == 1) return;

          var result = MessageWindow.Show(this, txt["ConfirmReduceFrames"] + "\r\n\r\n" + txt["ConfirmAllBones"], txt["Confirm"], txt["Continue"], txt["Cancel"]);
          if (result == MessageWindow.Result.Cancel) return;

          var deleteList = new List<int>();

          foreach (var item in dataGrid.SelectedItems)
          {
            var row = item as MovieTables.BoneMotionFrameData;
            deleteList.Add(row.Frame);
          }

          if (dataGrid.SelectedItems.Count == motion.FrameCount)
          {
            deleteList.Remove(0);
          }

          foreach (var part in motion.Parts)
          {
            int newFrame = 0;
            var frameList = new List<int>(part.Frames.Keys);
            foreach (var frame in frameList)
            {
              if (deleteList.Contains(frame))
              {
                continue;
              }

              if (newFrame < frame)
              {
                part.Frames[newFrame] = part.Frames[frame];
              }
              newFrame++;
            }

            for (int i = newFrame; i < frameList.Count; i++)
            {
              part.Frames.Remove(i);
            }

            part.FrameCount = part.Frames.Count;
          }

          motion.FrameCount -= deleteList.Count;
          movieTables.BoneMotions[dgMotions.SelectedIndex].FrameCount = motion.FrameCount;

          movieTables.SetBoneMotionFrame(motion, lbBones.SelectedIndex);

          modifiedBone = true;
          motion.Modified = true;
        }
        else if (dataGrid.Name == "dgCameraFrames")
        {
          var motion = camData.Motions[dgCameraMotions.SelectedIndex];
          if (motion == null) return;

          var result = MessageWindow.Show(this, txt["ConfirmReduceFrames"], txt["Confirm"], txt["Continue"], txt["Cancel"]);
          if (result == MessageWindow.Result.Cancel) return;

          var deleteList = new List<int>();

          foreach (var item in dataGrid.SelectedItems)
          {
            var row = item as MovieTables.CameraMotionFrameData;
            deleteList.Add(row.Frame);
          }

          if (dataGrid.SelectedItems.Count == motion.FrameCount)
          {
            deleteList.Remove(0);
          }

          deleteList.Sort();
          deleteList.Reverse();

          foreach (var frame in deleteList)
          {
            motion.Frames.RemoveAt(frame);
          }

          for (int i = 0; i < motion.Frames.Count; i++)
          {
            motion.Frames[i].Frame = i;
          }

          motion.FrameCount = motion.Frames.Count;
          movieTables.CameraMotions[dgCameraMotions.SelectedIndex].FrameCount = motion.FrameCount;

          movieTables.SetCameraMotionFrame(motion);

          modifiedCam = true;
        }

        Modified();
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }
    }

  }
}
