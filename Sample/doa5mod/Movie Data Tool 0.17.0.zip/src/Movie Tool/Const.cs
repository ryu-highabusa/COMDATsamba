﻿using System.Collections.Generic;
using System.Windows;

namespace Movie_Tool
{
  public partial class MainWindow : Window
  {
    public static Dictionary<string, string[]> bonenames;

    private void SetBoneNames()
    {
      bonenames = new Dictionary<string, string[]>();

      bonenames["MOT00_Hips"] = new string[]
      {
        "MOT00_Hips",
        "MOT01_Head",
        "MOT02_Chest",
        "MOT03_LeftFoot",
        "MOT04_LeftForeArm",
        "MOT05_LeftHand",
        "MOT06_LeftUpLeg",
        "MOT07_LeftLeg",
        "MOT08_LeftArm",
        "MOT09_RightFoot",
        "MOT10_RightForeArm",
        "MOT11_RightHand",
        "MOT12_RightUpLeg",
        "MOT13_RightLeg",
        "MOT14_RightArm",
        "MOT15_Neck",
        "MOT16_Waist",
        "MOT17_LeftShoulder",
        "MOT18_LeftToe",
        "MOT19_RightShoulder",
        "MOT20_RightToe"
      };

      bonenames["OPT_Face_Root"] = new string[]
      {
        "OPT_Face_c_eyebrow",
        "OPT_Face_c_lip_lower",
        "OPT_Face_c_lip_upper",
        "OPT_Face_c_nose",
        "OPT_Face_c_tongue_a",
        "OPT_Face_c_tongue_b",
        "OPT_Face_jaw",
        "OPT_Face_l_cheek_a",
        "OPT_Face_l_cheek_b",
        "OPT_Face_l_cheek_c",
        "OPT_Face_l_eye",
        "OPT_Face_l_eye_lower_a",
        "OPT_Face_l_eye_lower_b",
        "OPT_Face_l_eyebrow_a",
        "OPT_Face_l_eyebrow_b",
        "OPT_Face_l_eyebrow_c",
        "OPT_Face_l_eyelid",
        "OPT_Face_l_forehead",
        "OPT_Face_l_lip_lower",
        "OPT_Face_l_lip_outside",
        "OPT_Face_l_lip_upper",
        "OPT_Face_l_nose_a",
        "OPT_Face_l_nose_b",
        "OPT_Face_l_nose_c",
        "OPT_Face_l_nose_d",
        "OPT_Face_r_cheek_a",
        "OPT_Face_r_cheek_b",
        "OPT_Face_r_cheek_c",
        "OPT_Face_r_eye",
        "OPT_Face_r_eye_lower_a",
        "OPT_Face_r_eye_lower_b",
        "OPT_Face_r_eyebrow_a",
        "OPT_Face_r_eyebrow_b",
        "OPT_Face_r_eyebrow_c",
        "OPT_Face_r_eyelid",
        "OPT_Face_r_forehead",
        "OPT_Face_r_lip_lower",
        "OPT_Face_r_lip_outside",
        "OPT_Face_r_lip_upper",
        "OPT_Face_r_nose_a",
        "OPT_Face_r_nose_b",
        "OPT_Face_r_nose_c",
        "OPT_Face_r_nose_d",
        "OPT_Face_Root"
      };

      bonenames["OPT_Hand_Left_Root"] = new string[]
      {
        "OPT_Hand_Left_Index1",
        "OPT_Hand_Left_Index2",
        "OPT_Hand_Left_Index3",
        "OPT_Hand_Left_Metacarpal04",
        "OPT_Hand_Left_Middle1",
        "OPT_Hand_Left_Middle2",
        "OPT_Hand_Left_Middle3",
        "OPT_Hand_Left_Pinky1",
        "OPT_Hand_Left_Pinky2",
        "OPT_Hand_Left_Pinky3",
        "OPT_Hand_Left_Ring1",
        "OPT_Hand_Left_Ring2",
        "OPT_Hand_Left_Ring3",
        "OPT_Hand_Left_Root",
        "OPT_Hand_Left_Thumb1",
        "OPT_Hand_Left_Thumb2",
        "OPT_Hand_Left_Thumb3"
      };

      bonenames["OPT_Hand_Right_Root"] = new string[]
      {
        "OPT_Hand_Right_Index1",
        "OPT_Hand_Right_Index2",
        "OPT_Hand_Right_Index3",
        "OPT_Hand_Right_Metacarpal04",
        "OPT_Hand_Right_Middle1",
        "OPT_Hand_Right_Middle2",
        "OPT_Hand_Right_Middle3",
        "OPT_Hand_Right_Pinky1",
        "OPT_Hand_Right_Pinky2",
        "OPT_Hand_Right_Pinky3",
        "OPT_Hand_Right_Ring1",
        "OPT_Hand_Right_Ring2",
        "OPT_Hand_Right_Ring3",
        "OPT_Hand_Right_Root",
        "OPT_Hand_Right_Thumb1",
        "OPT_Hand_Right_Thumb2",
        "OPT_Hand_Right_Thumb3"
      };

      bonenames["OPT_wings_Root"] = new string[]
      {
        "OPT_wing_l_01",
        "OPT_wing_l_02",
        "OPT_wing_l_03",
        "OPT_wing_l_04",
        "OPT_wing_l_05",
        "OPT_wing_l_06",
        "OPT_wing_l_07",
        "OPT_wing_l_08",
        "OPT_wing_l_09",
        "OPT_wing_l_10",
        "OPT_wing_l_11",
        "OPT_wing_l_12",
        "OPT_wing_l_13",
        "OPT_wing_r_01",
        "OPT_wing_r_02",
        "OPT_wing_r_03",
        "OPT_wing_r_04",
        "OPT_wing_r_05",
        "OPT_wing_r_06",
        "OPT_wing_r_07",
        "OPT_wing_r_08",
        "OPT_wing_r_09",
        "OPT_wing_r_10",
        "OPT_wing_r_11",
        "OPT_wing_r_12",
        "OPT_wing_r_13",
        "OPT_wings_Root"
      };

      bonenames["OPT_uchiwa_r_Root"] = new string[]
      {
        "OPT_uchiwa_r",
        "OPT_uchiwa_r_Root"
      };

      bonenames["OPT_uchiwa_l_Root"] = new string[]
      {
        "OPT_uchiwa_l",
        "OPT_uchiwa_l_Root"
      };

      bonenames["OPT_uchiwa_bone_Root"] = new string[]
      {
        "OPT_uchiwa_bone_01",
        "OPT_uchiwa_bone_02",
        "OPT_uchiwa_bone_03",
        "OPT_uchiwa_bone_04",
        "OPT_uchiwa_bone_05",
        "OPT_uchiwa_bone_06",
        "OPT_uchiwa_bone_07",
        "OPT_uchiwa_bone_08",
        "OPT_uchiwa_bone_Root"
      };

      bonenames["OPT_uchiwa_Root"] = new string[]
      {
        "OPT_uchiwa_bone_01",
        "OPT_uchiwa_bone_02",
        "OPT_uchiwa_bone_03",
        "OPT_uchiwa_bone_04",
        "OPT_uchiwa_bone_05",
        "OPT_uchiwa_bone_06",
        "OPT_uchiwa_bone_07",
        "OPT_uchiwa_bone_08",
        "OPT_uchiwa_bone_Root"
      };

    }
  }
}
