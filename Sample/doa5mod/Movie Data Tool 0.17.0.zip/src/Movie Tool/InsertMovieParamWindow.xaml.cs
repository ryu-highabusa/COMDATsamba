﻿using System;
using System.Globalization;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Data;
using System.ComponentModel;
using System.Collections.ObjectModel;
using Message;

namespace Movie_Tool
{
  /// <summary>
  /// EditMaterialWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class InsertMovieParamWindow : Window
  {
    private static Dictionary<string, string> txt = new Dictionary<string, string>();

    private static short[] parameterSet = new short[2];

    private static bool validateType;
    private static bool validateCount;

    private static bool dialogResult;

    private bool IsActivated = false;

    public InsertMovieParamWindow()
    {
      InitializeComponent();

      this.MouseLeftButtonDown += (sender, e) => this.DragMove();
      this.ShowInTaskbar = false;

      txt = MainWindow.txt;

      labelType.Content = txt["labelType"];
      labelCount.Content = txt["labelCount"];
      btnOk.Content = txt["OK"];
      btnCancel.Content = txt["Cancel"];
    }

    private void okCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (validateType && validateCount)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void okCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      dialogResult = true;
      this.Close();
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = false;
    }

    private void tbType_KeyDown(object sender, KeyEventArgs e)
    {
      TextBox tb = sender as TextBox;
      ModifierKeys modifierKeys = Keyboard.Modifiers;

      //Console.WriteLine(e.Key.GetHashCode());

      if (e.Key == Key.Enter && btnOk.IsEnabled == true)
      {
        dialogResult = true;
        this.Close();
      }

      if (e.Key == Key.System || e.Key == Key.Tab)
      {
        e.Handled = false;
      }
      else if ((Key.D0 <= e.Key && e.Key <= Key.D9) || (Key.NumPad0 <= e.Key && e.Key <= Key.NumPad9))
      {
        e.Handled = false;
      }
      else if (e.Key.GetHashCode() >= 44 && e.Key.GetHashCode() <= 49)
      {
        e.Handled = false;
      }
      else
      {
        e.Handled = true;
      }
    }

    private void tbType_KeyUp(object sender, KeyEventArgs e)
    {
      CheckType();
      SetCount();
      CheckCount();
    }

    private void tbType_LostFocus(object sender, RoutedEventArgs e)
    {
      CheckType();
      SetCount();
      CheckCount();
    }

    private void tbCount_KeyDown(object sender, KeyEventArgs e)
    {
      TextBox target = sender as TextBox;

      if (e.Key == Key.Enter && btnOk.IsEnabled == true)
      {
        dialogResult = true;
        this.Close();
      }

      if (e.Key == Key.System || e.Key == Key.Tab)
      {
        e.Handled = false;
      }
      else if ((Key.D0 <= e.Key && e.Key <= Key.D9) || (Key.NumPad0 <= e.Key && e.Key <= Key.NumPad9))
      {
        e.Handled = false;
      }
      else
      {
        e.Handled = true;
      }
    }

    private void tbCount_KeyUp(object sender, KeyEventArgs e)
    {
      CheckType();
      CheckCount();
    }

    private void tbCount_LostFocus(object sender, RoutedEventArgs e)
    {
      CheckType();
      CheckCount();
    }

    private void TextBox_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
      TextBox target = sender as TextBox;
      if (target == null) return;
      target.SelectAll();
    }



    public static short[] Show(Window owner)
    {
      validateType = false;
      validateCount = false;

      var dlg = new InsertMovieParamWindow();
      dlg.Owner = owner;
      dlg.Owner.IsEnabled = false;

      if (dlg.ActualHeight != 0)
      {
        dlg.Top = owner.Top + (owner.ActualHeight / 2) - (dlg.ActualHeight / 2);
        dlg.Left = owner.Left + (owner.ActualWidth / 2) - (dlg.ActualWidth / 2);
      }

      dlg.tbType.Focus();

      dlg.IsActivated = false;
      dlg.ShowDialog();

      dlg.Owner.IsEnabled = true;
      dlg.Owner.Focus();

      if (dialogResult)
        return parameterSet;
      else
        return null;
    }

    public void CheckType()
    {
      validateType = false;

      try
      {
        short num = Int16.Parse(tbType.Text, NumberStyles.HexNumber);

        if (num == 0 || num == 1 || num == 0x3A) return;

        parameterSet[0] = num;
        //MessageWindow.Show(this, num + "\r\n0x" + num.ToString("X4"), txt["Info"]);
      }
      catch (FormatException)
      {
        //Console.WriteLine("Unable to convert '{0}'.", tbType.Text);
        return;
      }
      catch (OverflowException)
      {
        //Console.WriteLine("'{0}' is out of range of the Int16 type.", tbType.Text);
        return;
      }

      validateType = true;
    }

    public void CheckCount()
    {
      validateCount = false;

      try
      {
        short num = Byte.Parse(tbCount.Text);
        parameterSet[1] = num;
      }
      catch (FormatException)
      {
        return;
      }
      catch (OverflowException)
      {
        return;
      }

      validateCount = true;
    }

    public void SetCount()
    {
      switch (parameterSet[0])
      {
        case 0x16:
          //Frame Count
          tbCount.Text = "1";
          break;
        case 0x24:
          //Character
          tbCount.Text = "3";
          break;
        case 0x2F:
          //Fade In
          tbCount.Text = "3";
          break;
        case 0x30:
          //Fade Out
          tbCount.Text = "3";
          break;
        case 0xEC:
          //Cut
          tbCount.Text = "1";
          break;
        case 0xFF:
          //Dirty
          tbCount.Text = "2";
          break;
      }
    }



    private void Window_Activated(object sender, EventArgs e)
    {
      if (!IsActivated) IsActivated = true;
    }

    private void Window_Closing(object sender, CancelEventArgs e)
    {
      e.Cancel = true;
      IsActivated = false;
      this.Hide();
      if (this.Owner != null) this.Owner.Activate();
    }
  }
}
