﻿using System;
using System.Globalization;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Data;
using System.ComponentModel;
using System.Collections.ObjectModel;
using Message;

namespace Movie_Tool
{
  /// <summary>
  /// EditMaterialWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class CharacterChangeWindow : Window
  {
    private static Dictionary<string, string> txt = new Dictionary<string, string>();

    private static bool dialogResult;

    private bool IsActivated = false;



    public CharacterChangeWindow()
    {
      InitializeComponent();

      this.MouseLeftButtonDown += (sender, e) => this.DragMove();
      this.ShowInTaskbar = false;

      txt = MainWindow.txt;

      btnOk.Content = txt["OK"];
      btnCancel.Content = txt["Cancel"];
    }

    private void okCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (cmbCur.SelectedIndex != -1 && cmbDest.SelectedIndex != -1)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void okCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      dialogResult = true;
      this.Close();
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = false;
    }

    private void SetCharaComboBox()
    {
      var CharaNames = new List<string>();
      foreach (var chara in MainWindow.CharaList)
      {
        CharaNames.Add(txt[chara]);
      }
      if (MainWindow.langType != "Jpn") CharaNames.Sort();

      foreach (var name in CharaNames)
      {
        cmbCur.Items.Add(name);
        cmbDest.Items.Add(name);
      }
    }



    public static string[] Show(Window owner)
    {
      var dlg = new CharacterChangeWindow();
      dlg.Owner = owner;
      dlg.Owner.IsEnabled = false;

      dlg.SetCharaComboBox();

      if (dlg.ActualHeight != 0)
      {
        dlg.Top = owner.Top + (owner.ActualHeight / 2) - (dlg.ActualHeight / 2);
        dlg.Left = owner.Left + (owner.ActualWidth / 2) - (dlg.ActualWidth / 2);
      }

      dlg.IsActivated = false;
      dlg.ShowDialog();

      dlg.Owner.IsEnabled = true;
      dlg.Owner.Focus();


      if (dialogResult)
        return new string[] { dlg.cmbCur.SelectedValue.ToString(), dlg.cmbDest.SelectedValue.ToString() };
      else
        return null;
    }



    private void Window_Activated(object sender, EventArgs e)
    {
      if (!IsActivated) IsActivated = true;
    }

    private void Window_Closing(object sender, CancelEventArgs e)
    {
      e.Cancel = true;
      IsActivated = false;
      this.Hide();
      if (this.Owner != null) this.Owner.Activate();
    }
  }
}
