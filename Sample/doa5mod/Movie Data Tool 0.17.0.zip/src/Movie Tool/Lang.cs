﻿using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows;

namespace Movie_Tool
{
  public partial class MainWindow : Window
  {

    private void changeLanguage()
    {
      Dictionary<string, string> language = new Dictionary<string, string>();
      txt["btnOpen"] = "開く";
      txt["OK"] = "OK";
      txt["Cancel"] = "キャンセル";
      txt["Yes"] = "はい";
      txt["No"] = "いいえ";
      txt["Info"] = "情報";
      txt["Error"] = "エラー";
      txt["Caution"] = "注意";
      txt["Confirm"] = "確認";
      txt["Message"] = "メッセージ";
      txt["textStatus"] = "ファイルを開いて下さい";
      txt["ExitWithoutSave"] = "変更後保存されていません。このまま終了しますか？";
      txt["Exit"] = "終了する";
      txt["Continue"] = "続行";
      txt["UnsupportedArea"] = "";
      txt["Overwrite"] = "ファイルを上書きしますか？";
      txt["OverwriteYes"] = "上書きする";
      txt["Saved"] = "保存しました";
      txt["FailedToCreateBackup"] = "バックアップの作成に失敗したため保存出来ませんでした";
      txt["UnsupportedFile"] = "対応しているファイルではありません";
      txt["FailedToReopen"] = "再読込に失敗しました";
      txt["ConfirmOpenFile"] = "このファイルを開きますか？";
      txt["ConfirmFileUpdated"] = "下記ファイルが更新されました。開きなおしますか？";

      txt["AlreadyExists"] = "同じ名前のファイルが既にあります。別名で保存しますか？";
      txt["SaveAs"] = "別名で保存する";

      txt["Extracted"] = "書き出しが完了しました";

      txt["Imported"] = "入力したデータに更新しました";
      txt["Exported"] = "出力しました";

      txt["MotionDataNotIncluded"] = "モーションデータは含まれていません";

      txt["MotionFrameCount"] = "モーションのフレーム数";
      txt["ImportFrameCount"] = "読み込むフレーム数";
      txt["ConfirmFrameNotEnough"] = "読み込むデータがモーションのフレーム数に足りません。";
      txt["ImportedOnly"] = "該当フレームのみ変更";
      txt["FillByLastFrame"] = "最終フレームで埋める";
      txt["ConfirmFrameOver"] = "モーションのフレーム数より多いデータにした場合は問題が発生する可能性があります。\r\n現在のフレーム数分だけインポートしますか？";
      txt["CurrentFrameCountOnly"] = "現在のフレーム数";
      txt["CsvFrameCount"] = "CSVのフレーム数";
      txt["ConfirmConvertToBaked"] = "モーションタイプがBakedへ変換されます。\r\n続行しますか？";
      txt["ConfirmDeleteParameters"] = "パラメータを削除しますか？";
      txt["ConfirmExtendFrames"] = "フレームが追加されます。\r\n続行しますか？";
      txt["ConfirmReduceFrames"] = "削除されるフレームは元に戻せません。\r\n続行しますか？";
      txt["ConfirmAllBones"] = "（全てのボーンが変更されます）";
      txt["ConfirmBoneIsDifferent"] = "CSVのヘッダーに書かれている最初のボーン名が選択しているモーションのボーン名と違っています。\r\n\r\n  {0}\r\n\r\nCSVは違う部位のモーションのようです。\r\n続行しますか？";
      txt["OverColumnCount"] = "CSVの列数が選択しているモーションが使用する数よりも多くなっているため中止しました。\r\nモーションの選択とインポートしたCSVどちらにも間違いが無いか確認してください。";

      txt["Copy"] = "コピー";
      txt["Paste"] = "貼り付け";

      txt["FillDown"] = "下方向へコピー";

      txt["Delete"] = "削除";
      txt["Insert"] = "挿入";

      txt["labelType"] = "パラメータタイプ";
      txt["labelCount"] = "データ数";

      txt["AYANE"] = "あやね";
      txt["HELENA"] = "エレナ";
      txt["KASUMI"] = "かすみ";
      txt["CHRISTIE"] = "クリスティ";
      txt["KOKORO"] = "こころ";
      txt["SARAH"] = "サラ";
      txt["TINA"] = "ティナ";
      txt["NYOTENGU"] = "女天狗";
      txt["PAI"] = "パイ・チェン";
      txt["HITOMI"] = "ヒトミ";
      txt["PHASE4"] = "PHASE-4";
      txt["HONOKA"] = "ほのか";
      txt["LISA"] = "リサ";
      txt["RACHEL"] = "レイチェル";
      txt["LEIFANG"] = "レイファン";
      txt["MARIE"] = "マリー・ローズ";
      txt["MILA"] = "ミラ";
      txt["MOMIJI"] = "紅葉";
      txt["NAOTORA"] = "井伊直虎";
      txt["MAI"] = "不知火舞";



      string filePath = System.AppDomain.CurrentDomain.BaseDirectory + @"\Language.dat";
      if (!File.Exists(filePath))
      {
        return;
      }

      using (var sr = new StreamReader(filePath))
      {
        while (!sr.EndOfStream)
        {
          string[] inLine = sr.ReadLine().Split('\t');
          if (inLine.Length == 0)
          {
            continue;
          }
          else if (inLine[0] == "Type")
          {
            langType = inLine[2].Trim();
          }
          else if (inLine[0] == langType)
          {
            language[inLine[1].Trim()] = inLine[2].Trim();
          }
        }

        List<string> keys = new List<string>();
        foreach (var key in txt.Keys)
        {
          keys.Add(key);
        }
        foreach (string key in keys)
        {
          if (language.ContainsKey(key)) txt[key] = Regex.Unescape(language[key]);
        }

        if (language.ContainsKey("btnOpen")) btnOpen.Content = language["btnOpen"];
        if (language.ContainsKey("btnSave"))
        {
          btnSave.Content = language["btnSave"];
          cmdSave.Header = language["btnSave"];
        }
        if (language.ContainsKey("SaveWithBackup")) cmdSaveWithBackup.Header = language["SaveWithBackup"];
        if (language.ContainsKey("btnSaveAs")) btnSaveAs.Content = language["btnSaveAs"];
        if (language.ContainsKey("textStatus")) textStatus.Path = language["textStatus"];

        if (language.ContainsKey("tabMovie")) tabMovie.Header = language["tabMovie"];
        if (language.ContainsKey("tabScene")) tabScene.Header = language["tabScene"];
        if (language.ContainsKey("tabBone")) tabBone.Header = language["tabBone"];
        if (language.ContainsKey("tabCamera")) tabCamera.Header = language["tabCamera"];

        if (language.ContainsKey("labelMovieParamGrps")) labelMovieParamGrps.Content = language["labelMovieParamGrps"];
        if (language.ContainsKey("labelMovieParams")) labelMovieParams.Content = language["labelMovieParams"];

        if (language.ContainsKey("cmbItemVisibleAll")) cmbItemVisibleAll.Content = language["cmbItemVisibleAll"];
        if (language.ContainsKey("cmbItemHiddenMinor")) cmbItemHiddenMinor.Content = language["cmbItemHiddenMinor"];
        if (language.ContainsKey("cmbItemCutAndFrameCount")) cmbItemCutAndFrameCount.Content = language["cmbItemCutAndFrameCount"];
        if (language.ContainsKey("cmbItemFrameCount")) cmbItemFrameCount.Content = language["cmbItemFrameCount"];

        if (language.ContainsKey("labelCutParams")) labelCutParams.Content = language["labelCutParams"];
        if (language.ContainsKey("labelCutDofDepth")) labelCutDofDepth.Content = language["labelCutDofDepth"];
        if (language.ContainsKey("labelCutDofBoundary")) labelCutDofBoundary.Content = language["labelCutDofBoundary"];
        if (language.ContainsKey("labelCutDofAmount1")) labelCutDofAmount1.Content = language["labelCutDofAmount1"];
        if (language.ContainsKey("labelCutDofAmount2")) labelCutDofAmount2.Content = language["labelCutDofAmount2"];

        if (language.ContainsKey("AngleElevation"))
        {
          labelLightMainElevation.Content = language["AngleElevation"];
          labelLightSub1Elevation.Content = language["AngleElevation"];
          labelLightSub2Elevation.Content = language["AngleElevation"];
        }
        if (language.ContainsKey("AngleDirection"))
        {
          labelLightMainDirection.Content = language["AngleDirection"];
          labelLightSub1Direction.Content = language["AngleDirection"];
          labelLightSub2Direction.Content = language["AngleDirection"];
        }
        if (language.ContainsKey("Point"))
        {
          cbLightMainPoint.Content = language["Point"];
          cbLightSub1Point.Content = language["Point"];
          cbLightSub2Point.Content = language["Point"];
        }
        if (language.ContainsKey("cbAmbient")) cbAmbient.Content = language["cbAmbient"];
        if (language.ContainsKey("AmbientSub"))
        {
          labelAmbientSub1.Content = language["AmbientSub"] + " 1";
          labelAmbientSub2.Content = language["AmbientSub"] + " 2";
        }
        if (language.ContainsKey("LightMain")) cbLightMain.Content = language["LightMain"];
        if (language.ContainsKey("LightSub"))
        {
          cbLightSub1.Content = language["LightSub"] + " 1";
          cbLightSub2.Content = language["LightSub"] + " 2";
        }
        if (language.ContainsKey("SelfShadow")) labelLightShadow.Content = language["SelfShadow"];

        if (language.ContainsKey("labelHdrColor")) labelHdrColor.Content = language["labelHdrColor"];
        if (language.ContainsKey("labelHdrParam")) labelHdrParam.Content = language["labelHdrParam"];
        if (language.ContainsKey("labelHdrUnknown")) labelHdrUnknown.Content = language["labelHdrUnknown"];

        if (language.ContainsKey("Wind"))
        {
          labelWind1and2.Content = language["Wind"] + "1 and " + language["Wind"] + "2";
          labelWind3and4.Content = language["Wind"] + "3 and " + language["Wind"] + "4";
          labelWind5and6.Content = language["Wind"] + "5 and " + language["Wind"] + "6";
          labelWind1.Content = language["Wind"] + "1";
          labelWind2.Content = language["Wind"] + "2";
          labelWind3.Content = language["Wind"] + "3";
          labelWind4.Content = language["Wind"] + "4";
          labelWind5.Content = language["Wind"] + "5";
          labelWind6.Content = language["Wind"] + "6";
        }
        if (language.ContainsKey("Force"))
        {
          labelWind1Force.Content = language["Force"];
          labelWind2Force.Content = language["Force"];
          labelWind3Force.Content = language["Force"];
          labelWind4Force.Content = language["Force"];
          labelWind5Force.Content = language["Force"];
          labelWind6Force.Content = language["Force"];
          labelWind1and2Force.Content = language["Force"];
          labelWind3and4Force.Content = language["Force"];
          labelWind5and6Force.Content = language["Force"];
        }
        if (language.ContainsKey("Vertical"))
        {
          labelWind1Vertical.Content = language["Vertical"];
          labelWind2Vertical.Content = language["Vertical"];
          labelWind3Vertical.Content = language["Vertical"];
          labelWind4Vertical.Content = language["Vertical"];
          labelWind5Vertical.Content = language["Vertical"];
          labelWind6Vertical.Content = language["Vertical"];
          labelWind1and2Vertical.Content = language["Vertical"];
          labelWind3and4Vertical.Content = language["Vertical"];
          labelWind5and6Vertical.Content = language["Vertical"];
        }
        if (language.ContainsKey("DirectionDeg"))
        {
          labelWind1Direction.Content = language["DirectionDeg"];
          labelWind2Direction.Content = language["DirectionDeg"];
          labelWind3Direction.Content = language["DirectionDeg"];
          labelWind4Direction.Content = language["DirectionDeg"];
          labelWind5Direction.Content = language["DirectionDeg"];
          labelWind6Direction.Content = language["DirectionDeg"];
        }
        if (language.ContainsKey("Direction"))
        {
          labelWind1and2Direction.Content = language["Direction"];
          labelWind3and4Direction.Content = language["Direction"];
          labelWind5and6Direction.Content = language["Direction"];
        }
        if (language.ContainsKey("UnknownParams"))
        {
          labelWind1and2Unknown.Content = language["UnknownParams"];
          labelWind3and4Unknown.Content = language["UnknownParams"];
          labelWind5and6Unknown.Content = language["UnknownParams"];
        }


        if (language.ContainsKey("MotionGrps")) labelMotionGrps.Content = language["MotionGrps"];
        if (language.ContainsKey("Motions"))
        {
          labelMotions.Content = language["Motions"];
          labelCameraMotions.Content = language["Motions"];
        }
        if (language.ContainsKey("MotionData"))
        {
          labelMotionData.Content = language["MotionData"];
          labelCameraFrames.Content = language["MotionData"];
        }
        if (language.ContainsKey("SelectedCells"))
        {
          labelMotShiftVal.Content = language["SelectedCells"];
          labelCamShiftVal.Content = language["SelectedCells"];
        }
        if (language.ContainsKey("ShiftValue"))
        {
          btnMotShiftVal.Content = language["ShiftValue"];
          btnCamShiftVal.Content = language["ShiftValue"];
        }
        if (language.ContainsKey("ImportCsv"))
        {
          btnImportCsvBone.Content = language["ImportCsv"];
          btnImportCsvCam.Content = language["ImportCsv"];
        }
        if (language.ContainsKey("ExportCsv"))
        {
          btnExportCsvBone.Content = language["ExportCsv"];
          btnExportCsvCam.Content = language["ExportCsv"];
        }
        if (language.ContainsKey("Add"))
        {
          cbAddMot.Content = language["Add"];
          cbAddCam.Content = language["Add"];
        }
        if (language.ContainsKey("cbIgnoreFrameMot")) cbIgnoreFrameMot.Content = language["cbIgnoreFrameMot"];
        if (language.ContainsKey("cbIgnoreFrameCam")) cbIgnoreFrameCam.Content = language["cbIgnoreFrameCam"];
        if (language.ContainsKey("KeepPos")) cbKeepPos.Content = language["KeepPos"];
        if (language.ContainsKey("labelFacePos")) labelFacePos.Content = language["labelFacePos"];
        if (language.ContainsKey("btnAdjust")) btnAdjust.Content = language["btnAdjust"];
        if (language.ContainsKey("Repeat")) cbCamRepeat.Content = language["Repeat"];
        if (language.ContainsKey("FpsToHalf")) btnCamFpsToHalf.Content = language["FpsToHalf"];
      }
    }

  }
}
