﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Message;

namespace ___C_File_Editor
{
  /// <summary>
  /// MainWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class MainWindow : Window
  {
    private static CData cData;
    public static CheckBox[] cb = new CheckBox[8];
    public static TextBox[] tb = new TextBox[9];

    private static byte[] bn;

    private static string cPath = "";

    private static bool autoSetComboBox = false;
    private static bool autoCheckChanged = false;

    private static bool appStarted = false;
    private static bool updateChecking = true;
    private static bool modified = false;
    private static bool exitConfirm = false;
    public static Dictionary<string, string> txt = new Dictionary<string, string>();
    public static string langType = "Jpn";



    public MainWindow()
    {
      InitializeComponent();

      for (int i = 0; i < 8; i++)
      {
        cb[i] = new CheckBox();
        cb[i].Content = "Type " + ((char)(65 + i)).ToString();
        cb[i].Width = 80;
        cb[i].Height = 15;
        //Binding bind = new Binding();
        //bind.ElementName = "cbType" + ((char)(65 + i)).ToString();
        //bind.Path = new PropertyPath(Slider.ValueProperty);
        //cb[i].SetBinding(CheckBox.IsCheckedProperty, bind);
        cb[i].Checked += new RoutedEventHandler(cb_CheckChanged);
        cb[i].Unchecked += new RoutedEventHandler(cb_CheckChanged);
        panelHairstyles.Children.Add(cb[i]);
      }

      for (int i = 0; i < 9; i++)
      {
        tb[i] = new TextBox();
        //tb[i].Text = ((char)(65 + i)).ToString();
        tb[i].Width = 68;
        tb[i].TextAlignment = TextAlignment.Right;
        tb[i].GotFocus += new RoutedEventHandler(TextBox_GotFocus);
        tb[i].PreviewMouseLeftButtonDown += new MouseButtonEventHandler(TextBox_PreMouseLeftDown);
        tb[i].KeyDown += new KeyEventHandler(TextBoxPositiveNum_KeyDown);
        tb[i].KeyUp += new KeyEventHandler(tb_KeyUp);
        tb[i].Margin = new Thickness(1, 0, 2, 0);
        panelAlpha152.Children.Add(tb[i]);
      }

      MainWindowTitle();
      changeLanguage();
      MessageWindow.lang(txt);

      Application.Current.ShutdownMode = ShutdownMode.OnMainWindowClose;
    }

    private void mainWindow_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      if (e.LeftButton == MouseButtonState.Pressed) this.DragMove();
    }

    private void mainWindow_Loaded(object sender, RoutedEventArgs e)
    {
      List<string> cmds = System.Environment.GetCommandLineArgs().ToList();
      cmds.RemoveAt(0);
      OpenDorpFile(cmds);
    }

    private void mainWindow_DragOver(object sender, DragEventArgs e)
    {
      e.Handled = true;
      if (e.Data.GetDataPresent(DataFormats.FileDrop))
        e.Effects = DragDropEffects.Move;
      else
        e.Effects = DragDropEffects.None;
    }

    private void mainWindow_DragDrop(object sender, DragEventArgs e)
    {
      List<string> filePaths = ((string[])e.Data.GetData(DataFormats.FileDrop, false)).ToList();
      OpenDorpFile(filePaths);
    }

    private void OpenDorpFile(List<string> filePaths)
    {
      if (filePaths.Count < 1) return;

      string filePath = "";
      List<string> lnkPaths = new List<string>();
      foreach (string path in filePaths)
      {
        if (filePath == "" && System.IO.Path.GetExtension(filePaths[0]).ToUpper() == ".---C" || System.IO.Path.GetExtension(filePaths[0]).ToUpper() == ".--C")
        {
          filePath = path;
        }
        else if (System.IO.Path.GetExtension(path).ToLower() == ".lnk")
        {
          lnkPaths.Add(path);
        }
      }

      if (lnkPaths.Count > 0)
      {
        Type t = Type.GetTypeFromCLSID(new Guid("72C24DD5-D70A-438B-8A42-98424B88AFB8"));
        dynamic shell = Activator.CreateInstance(t);
        List<string> shortcutPaths = new List<string>();
        foreach (string path in lnkPaths)
        {
          var shortcut = shell.CreateShortcut(path);
          shortcutPaths.Add(shortcut.TargetPath);
          System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shortcut);
        }
        System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shell);

        foreach (string path in shortcutPaths)
        {
          if (filePath == "" && System.IO.Path.GetExtension(filePaths[0]).ToUpper() == ".---C" || System.IO.Path.GetExtension(filePaths[0]).ToUpper() == ".--C")
          {
            filePath = path;
            break;
          }
        }
      }

      if (filePath != "")
      {
        OpenFile(filePath);
      }
    }

    private void OpenFromClipboard()
    {
      var pathText = Clipboard.GetText();
      if (Clipboard.ContainsFileDropList())
      {
        //データを取得する（取得できなかった時はnull）
        System.Collections.Specialized.StringCollection files = Clipboard.GetFileDropList();
        if (files != null) pathText = files[0];
      }
      if (!string.IsNullOrEmpty(pathText) && File.Exists(pathText) && (System.IO.Path.GetExtension(pathText).ToUpper() == ".---C" || System.IO.Path.GetExtension(pathText).ToUpper() == ".--C"))
      {
        var result = MessageWindow.Show(this, pathText + "\r\n\r\n" + txt["ConfirmOpenFile"], txt["Info"], txt["btnOpen"], txt["Cancel"]);
        if (result == MessageWindow.Result.OK)
        {
          OpenFile(pathText);
        }
        Keyboard.Focus(mainWindow);
      }
    }

    private void openCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      e.CanExecute = true;
    }
    private void openCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
      if (cPath == "")
      {
        dlg.FileName = "";
      }
      else
      {
        dlg.InitialDirectory = Path.GetDirectoryName(cPath);
        dlg.FileName = Path.GetFileName(cPath);
      }
      dlg.DefaultExt = ".---C";
      dlg.Filter = "---C Files|*.---C;*.--C";

      Nullable<bool> result = dlg.ShowDialog();

      if (result == true)
      {
        OpenFile(dlg.FileName);
      }
    }

    private void revertCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (cData != null && cPath != "" && modified)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void revertCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      OpenFile(null);
    }

    private void saveCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (cData != null && cPath != "" && modified)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void saveCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      var result = MessageWindow.Show(this, txt["Overwrite"], txt["Confirm"], txt["OverwriteYes"], txt["Cancel"]);
      if (result == MessageWindow.Result.OK)
      {
        SaveFile(cPath);
      }
    }
    private void saveWithBackupCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      string newPath = CreateBackup();
      if (newPath != null)
      {
        if (!SaveFile(cPath))
        {
          if (File.Exists(newPath)) File.Move(newPath, cPath);
        }
      }
      else
      {
        MessageWindow.Show(this, txt["FailedToCreateBackup"], txt["Error"]);
      }
    }

    private void saveAsCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
      if (cData != null)
        e.CanExecute = true;
      else
        e.CanExecute = false;
    }
    private void saveAsCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
      dlg.InitialDirectory = Path.GetDirectoryName(cPath);
      dlg.FileName = Path.GetFileName(cPath);
      dlg.DefaultExt = ".---C";
      dlg.Filter = "---C Files|*.---C;*.--C";

      Nullable<bool> result = dlg.ShowDialog();

      if (result == true)
      {
        SaveFile(dlg.FileName);
      }
    }

    private void cmbSelection_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (!this.IsInitialized || autoSetComboBox) return;

      ComboBox target = sender as ComboBox;

      if (target.SelectedIndex == 0)
      {
        return;
      }
      else if (target.SelectedIndex == 1)
      {
        foreach (var checkbox in cb)
        {
          checkbox.IsChecked = false;
        }
      }
      else
      {
        var item = target.SelectedItem as ComboBoxItem;

        var value = item.Content.ToString();

        autoCheckChanged = true;

        for (int i = 0; i < 8; i++)
        {
          char c = Convert.ToChar(0x41 + i);

          if (value.IndexOf(c) != -1)
          {
            Console.WriteLine(value + " : " + c);
            cb[i].IsChecked = true;
          }
          else
            cb[i].IsChecked = false;
        }

        autoCheckChanged = false;
      }

      modified = true;
    }

    private void cb_CheckChanged(object sender, RoutedEventArgs e)
    {
      if (autoCheckChanged) return;

      var target = sender as CheckBox;
      if (target != null && cb.Contains(target))
      {
        autoSetComboBox = true;
        cmbPresetVisibleFlag.SelectedIndex = 0;
        autoSetComboBox = false;
      }

      modified = true;
    }

    private void Show_Aplha152Param()
    {
      gbAlpha152.Visibility = Visibility.Visible;
    }

    private void Hide_Aplha152Param()
    {
      gbAlpha152.Visibility = Visibility.Collapsed;
    }

    private void tb_KeyUp(object sender, KeyEventArgs e)
    {
      TextBox target = sender as TextBox;
      if ((Key.D0 <= e.Key && e.Key <= Key.D9) || (Key.NumPad0 <= e.Key && e.Key <= Key.NumPad9))
      {
        modified = true;
      }
      else if (e.Key == Key.Decimal || e.Key == Key.OemPeriod)
      {
        if (target.Text.IndexOf(".") < 0 || target.SelectedText.IndexOf(".") >= 0)
        {
          modified = true;
        }
      }
    }



    private void OpenFile(string filePath)
    {
      this.IsEnabled = false;
      DoEvents();

      try
      {
        panelPreset.IsEnabled = false;
        gbVisibleFlag.IsEnabled = false;
        gbOtherFlag.IsEnabled = false;
        gbAlpha152.IsEnabled = false;
        cbHideGlasses.IsChecked = false;
        Hide_Aplha152Param();
        foreach (TextBox tbox in tb)
        {
          tbox.Text = "";
        }
        textStatus.Path = txt["textStatus"];
        foreach (CheckBox cbox in cb)
        {
          cbox.IsChecked = false;
        }

        // null when Revert
        if (filePath != null || bn == null)
        {
          var bin = System.IO.File.ReadAllBytes(filePath);
          char[] charsToTrim = { '\0' };
          string Name = Encoding.ASCII.GetString(bin, 0, 8).TrimEnd(charsToTrim);
          if (Name != "texch")
          {
            MessageWindow.Show(this, txt["UnsupportedFile"] + "\r\n" + filePath, txt["Error"]);
            return;
          }
          if (BitConverter.ToUInt32(bin, 0x08) != 0x01010000)
          {
            MessageWindow.Show(this, txt["UnsupportedFile"] + "\r\n" + filePath, txt["Error"]);
            return;
          }

          bn = bin;
        }
        else
        {
          filePath = cData.Path;
        }


        HeaderData cH = new HeaderData(0, bn);

        cData = new CData(cH, bn, cb);

        if (cData == null) return;

        if (cData.Unknown)
        {
          MessageWindow.Show(this, txt["UnsupportedFile"] + "\r\n" + filePath, txt["Error"]);
          return;
        }

        cData.Path = filePath;
        cData.WriteTime = System.IO.File.GetLastWriteTime(filePath);

        if (cData.Alpha152.Length > 0)
        {
          gbAlpha152.IsEnabled = true;
          Show_Aplha152Param();
          for (int i = 0; i < cData.Alpha152.Length; i++)
          {
            tb[i].Text = cData.Alpha152[i].ToString();
          }
        }

        if (cData.hideGlasses)
        {
          cbHideGlasses.IsChecked = true;
        }

        autoSetComboBox = true;
        cmbPresetVisibleFlag.SelectedIndex = 0;
        autoSetComboBox = false;

        panelPreset.IsEnabled = true;
        gbVisibleFlag.IsEnabled = true;
        if (cData.Alpha152.Length == 0) gbOtherFlag.IsEnabled = true;
        textStatus.Path = filePath;
        cPath = filePath;
        modified = false;

        CommandManager.InvalidateRequerySuggested();
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
      }
      finally
      {
        this.IsEnabled = true;
        this.Activate();
        this.Focus();
      }
    }

    private bool SaveFile(string filePath)
    {
      try
      {
        var newBins = new List<List<byte>>();
        for (int i = 0; i < cData.Offsets.Count; i++)
        {
          var newBin = new List<byte>();
          if (i != 0 && cData.Sizes[i] != 0)
          {
            newBin = bn.Skip(cData.Offsets[i]).Take(cData.Sizes[i]).ToList();
          }
          newBins.Add(newBin);
        }

        int count = 0;
        for (int i = 0; i < cb.Length; i++)
        {
          if (cb[i].IsChecked == true)
          {
            newBins[0].AddRange(new byte[8] { 1, 0, 0, 0, (byte)i, 0, 0, 0 });
            count++;
          }
        }
        if (cbHideGlasses.IsChecked == true)
        {
          newBins[0].AddRange(new byte[8] { 10, 0, 0, 0, 0, 0, 0, 0 });
          count++;
        }

        if (cData.Alpha152.Length != 0)
        {
          newBins[0].InsertRange(0, BitConverter.GetBytes((int)4));
          newBins[0].AddRange(BitConverter.GetBytes((int)5));
          for (int i = 0; i < cData.Alpha152.Length; i++)
          {
            newBins[0].AddRange(BitConverter.GetBytes(Single.Parse(tb[i].Text)));
          }
          if (newBins[0].Count <= 0x30)
          {
            newBins[0].AddRange(new byte[16]);
          }
        }

        if (newBins[0].Count == 0)
        {
          newBins[0].AddRange(new byte[16]);
        }
        else if (newBins[0].Count % 16 != 0)
        {
          newBins[0].AddRange(new byte[16 - (newBins[0].Count % 16)]);
        }

        if (cData.Offsets.Count > 1 && cData.Offsets[1] != 0)
        {
          newBins[0].AddRange(new byte[16]);
        }

        var exBin = BuildHeaderBaseBin("texch");
        BuildBin(exBin, newBins, null, false, true);

        updateChecking = false;

        // 保存
        System.IO.File.WriteAllBytes(filePath, exBin.ToArray());
        textStatus.Path = filePath;
        cPath = filePath;
        cData.WriteTime = System.IO.File.GetLastWriteTime(filePath);
        modified = false;

        ShowTextBlockMessage(txt["Saved"]);

        updateChecking = true;

        return true;
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);

        return false;
      }
    }

    private string CreateBackup()
    {
      try
      {
        if (!File.Exists(cPath)) return null;

        string dirPath = Path.GetDirectoryName(cPath);
        string name = Path.GetFileNameWithoutExtension(cPath);
        string ext = Path.GetExtension(cPath);

        List<string> files = Directory.GetFiles(dirPath, name + "*" + ext, SearchOption.TopDirectoryOnly).ToList();
        string regStr = name + @" - ([0-9]+)";
        int count = 1;

        foreach (string file in files)
        {
          string fileName = Path.GetFileNameWithoutExtension(file);

          MatchCollection mc = Regex.Matches(fileName, regStr);
          foreach (Match m in mc)
          {
            int num = int.Parse(m.Groups[1].Value);
            if (count <= num) count = num + 1;
          }
        }

        string newPath;
        while (File.Exists(newPath = dirPath + @"/" + name + " - " + count + ext))
        {
          count++;
        }

        File.Move(cPath, newPath);

        return newPath;
      }
      catch (Exception e)
      {
        MessageWindow.Show(this, e.Message + "\r\n\r\n" + e.StackTrace, txt["Error"]);
        return null;
      }
    }


    private void CheckUpdated()
    {
      if (cData == null || !System.IO.File.Exists(cData.Path)) return;

      var lastWriteTime = System.IO.File.GetLastWriteTime(cData.Path);
      if (cData.WriteTime.CompareTo(lastWriteTime) != 0)
      {
        if (MessageWindow.Show(this, txt["ConfirmFileUpdated"] + "\r\n\r\n" + cData.Path, txt["Confirm"], txt["Yes"], txt["No"]) == MessageWindow.Result.OK)
        {
          OpenFile(cData.Path);
        }
        else
        {
          cData.WriteTime = lastWriteTime;
        }
      }
    }
  }
}
