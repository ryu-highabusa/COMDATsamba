﻿using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows;

namespace ___C_File_Editor
{
  public partial class MainWindow : Window
  {

    private void changeLanguage()
    {
      Dictionary<string, string> language = new Dictionary<string, string>();
      txt["btnOpen"] = "開く";
      txt["OK"] = "OK";
      txt["Cancel"] = "キャンセル";
      txt["Yes"] = "はい";
      txt["No"] = "いいえ";
      txt["Info"] = "情報";
      txt["Error"] = "エラー";
      txt["Caution"] = "注意";
      txt["Confirm"] = "確認";
      txt["Message"] = "メッセージ";
      txt["textStatus"] = "ファイルを開いて下さい";
      txt["ExitWithoutSave"] = "変更後保存されていません。このまま終了しますか？";
      txt["Exit"] = "終了する";
      txt["Overwrite"] = "ファイルを上書きしますか？";
      txt["OverwriteYes"] = "上書きする";
      txt["Saved"] = "保存しました";
      txt["FailedToCreateBackup"] = "バックアップの作成に失敗したため保存出来ませんでした";
      txt["UnsupportedFile"] = "対応しているファイルではありません";
      txt["FailedToReopen"] = "再読込に失敗しました";
      txt["ConfirmOpenFile"] = "このファイルを開きますか？";
      txt["ConfirmFileUpdated"] = "下記ファイルが更新されました。開きなおしますか？";

      txt["AlreadyExists"] = "同じ名前のファイルが既にあります。別名で保存しますか？";
      txt["SaveAs"] = "別名で保存する";

      string filePath = System.AppDomain.CurrentDomain.BaseDirectory + @"\Language.dat";
      if (!File.Exists(filePath))
      {
        return;
      }

      using (var sr = new StreamReader(filePath))
      {
        while (!sr.EndOfStream)
        {
          string[] inLine = sr.ReadLine().Split('\t');
          if (inLine.Length == 0)
          {
            continue;
          }
          else if (inLine[0] == "Type")
          {
            langType = inLine[2].Trim();
          }
          else if (inLine[0] == langType)
          {
            language[inLine[1].Trim()] = inLine[2].Trim();
          }
        }

        List<string> keys = new List<string>();
        foreach (var key in txt.Keys)
        {
          keys.Add(key);
        }
        foreach (string key in keys)
        {
          if (language.ContainsKey(key)) txt[key] = Regex.Unescape(language[key]);
        }

        if (language.ContainsKey("gbVisibleFlag")) gbVisibleFlag.Header = language["gbVisibleFlag"];
        if (language.ContainsKey("gbOtherFlag")) gbOtherFlag.Header = language["gbOtherFlag"];
        if (language.ContainsKey("cbHideGlasses")) cbHideGlasses.Content = language["cbHideGlasses"];
        if (language.ContainsKey("gbAlpha152")) gbAlpha152.Header = language["gbAlpha152"];

        if (language.ContainsKey("btnOpen"))
        {
          btnOpen.Content = language["btnOpen"];
          cmdOpen.Header = language["btnOpen"];
        }
        if (language.ContainsKey("cmdRevert")) cmdRevert.Header = language["cmdRevert"];

        if (language.ContainsKey("btnSave"))
        {
          btnSave.Content = language["btnSave"];
          cmdSave.Header = language["btnSave"];
        }
        if (language.ContainsKey("SaveWithBackup")) cmdSaveWithBackup.Header = language["SaveWithBackup"];

        if (language.ContainsKey("btnSaveAs")) btnSaveAs.Content = language["btnSaveAs"];

        if (language.ContainsKey("labelPresetVisibleFlag")) labelPresetVisibleFlag.Content = language["labelPresetVisibleFlag"];
        if (language.ContainsKey("cmbItemManual")) cmbItemManual.Content = language["cmbItemManual"];
        if (language.ContainsKey("cmbItemNone")) cmbItemNone.Content = language["cmbItemNone"];

        if (language.ContainsKey("textStatus")) textStatus.Path = language["textStatus"];
      }
    }

  }
}
