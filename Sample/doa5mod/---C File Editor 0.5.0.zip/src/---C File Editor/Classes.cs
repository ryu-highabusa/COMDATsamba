﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Controls;

namespace ___C_File_Editor
{
  public class HeaderData
  {
    public HeaderData(int Start, byte[] bin)
    {
      this.Start = Start;
      this.Offsets = new List<int>(0);
      this.Sizes = new List<int>(0);

      char[] charsToTrim = { '\0' };
      this.Name = Encoding.ASCII.GetString(bin, Start, 8).TrimEnd(charsToTrim);
      this.Flg1 = BitConverter.ToInt32(bin, Start + 0x08);
      this.HSize = BitConverter.ToInt32(bin, Start + 0x0C);
      this.Size = BitConverter.ToInt32(bin, Start + 0x10);
      this.Count1 = BitConverter.ToInt32(bin, Start + 0x14);
      this.Count2 = BitConverter.ToInt32(bin, Start + 0x18);
      this.Count3 = BitConverter.ToInt32(bin, Start + 0x1C);
      this.Offset1 = BitConverter.ToInt32(bin, Start + 0x20);
      this.Offset2 = BitConverter.ToInt32(bin, Start + 0x24);
      this.Offset3 = BitConverter.ToInt32(bin, Start + 0x28);
      this.Flg2 = BitConverter.ToInt32(bin, Start + 0x2C);

      for (int i = 0; i < this.Count1; i++)
      {
        this.Offsets.Add(BitConverter.ToInt32(bin, Start + this.Offset1 + (i * 0x04)));
      }

      if (this.Offset2 > 0)
      {
        for (int i = 0; i < this.Count1; i++)
        {
          this.Sizes.Add(BitConverter.ToInt32(bin, Start + this.Offset2 + (i * 0x04)));
        }
      }
    }

    public int Start { get; set; }
    public string Name { get; set; }
    public int Flg1 { get; set; }
    public int HSize { get; set; }
    public int Size { get; set; }
    public int Count1 { get; set; }
    public int Count2 { get; set; }
    public int Count3 { get; set; }
    public int Offset1 { get; set; }
    public int Offset2 { get; set; }
    public int Offset3 { get; set; }
    public int Flg2 { get; set; }

    public List<int> Offsets { get; private set; }
    public List<int> Sizes { get; private set; }
  }

  public class CData
  {
    public CData(HeaderData h, byte[] bin, CheckBox[] cb)
    {
      this.Offsets = new List<int>();
      this.Sizes = new List<int>();

      for (int i = 0; i < h.Count1; i++)
      {
        if (h.Offsets[i] != 0)
        {
          int nextOffset = 0;
          int count = i + 1;
          while (count < h.Count1 && h.Offsets[count] == 0)
          {
            count++;
          }
          if (count < h.Count1)
          {
            nextOffset = h.Offsets[count];
          }
          else
          {
            nextOffset = h.Size;
          }

          this.Offsets.Add(h.Offsets[i]);
          this.Sizes.Add(nextOffset - h.Offsets[i]);
        }
        else
        {
          this.Offsets.Add(0);
          this.Sizes.Add(0);
        }
      }

      this.HType = new bool[8];

      this.Alpha152 = new float[0];
      this.Unknown = false;
      if (bin[h.Offsets[0]] == 0)
      {

      }
      else if (bin[h.Offsets[0]] == 1)
      {
        int count = 0;
        while (count < 8 && h.Offsets[0] + (8 * count) < bin.Length && bin[h.Offsets[0] + (8 * count)] == 1)
        {
          cb[bin[h.Offsets[0] + (count * 8) + 4]].IsChecked = true;
          count++;
        }
        if (h.Offsets[0] + (8 * count) < h.Size && bin[h.Offsets[0] + (8 * count)] == 10)
        {
          this.hideGlasses = true;
        }
      }
      else if (bin[h.Offsets[0]] == 4)
      {
        this.Alpha152 = new float[9];
        int count = 0;
        while (count < 8 && bin[h.Offsets[0] + 4 + (count * 8)] == 1)
        {
          cb[bin[h.Offsets[0] + (count * 8) + 8]].IsChecked = true;
          count++;
        }
        if (bin[h.Offsets[0] + 4 + (count * 8)] == 5)
        {
          for (int i = 0; i < Alpha152.Length; i++)
          {
            Alpha152[i] = BitConverter.ToSingle(bin, (int)h.Offsets[0] + 8 + (count * 8) + (4 * i));
          }
        }
      }
      else if (bin[h.Offsets[0]] == 10)
      {
        this.hideGlasses = true;
      }
      else
      {
        Unknown = true;
      }

    }

    public string Path { get; set; }
    public DateTime WriteTime { get; set; }

    public List<int> Offsets { get; set; }
    public List<int> Sizes { get; set; }
    public bool[] HType { get; set; }
    public float[] Alpha152 { get; set; }
    public bool hideGlasses { get; set; }
    public bool Unknown { get; set; }
  }


}
