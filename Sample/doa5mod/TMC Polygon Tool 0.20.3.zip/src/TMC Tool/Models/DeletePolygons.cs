﻿using System;
using System.Collections.Generic;
using System.Linq;
using Common;
using Tmc;
using TMC_Tool.ViewModels;
using Language;

namespace TMC_Tool.Models
{
  public class DeletePolygons
  {
    public DeletePolygons(MainWindowViewModel data)
    {
      txt = MainWindow.txt;
      mainWindow = data.mainWindow;
      Bin = data.Bin;
      TmcData = data.TmcData;
      Vertices = data.Vertices.Distinct().Where(e => e.IsChecked == true).ToList();
      DoubleSided = data.DoubleSided;
      DeleteAddedOnly = data.DeleteAddedOnly;
      ErrorMessage = "";
    }


    #region プロパティ

    /// <summary>
    /// エラーメッセージ
    /// </summary>
    public string ErrorMessage { get; set; }

    /// <summary>
    /// TMCの出力バイナリ
    /// </summary>
    public List<byte> ExBin { get; set; }


    /// <summary>
    /// メインウィンドウオブジェクト
    /// </summary>
    private MainWindow mainWindow { get; set; }

    /// <summary>
    /// 言語テキストデータ
    /// </summary>
    private Lang.Text txt;

    /// <summary>
    /// TMCのバイナリ
    /// </summary>
    private byte[] Bin { get; set; }


    /// <summary>
    /// TMCデータ
    /// </summary>
    private TmcData TmcData { get; set; }

    /// <summary>
    /// 表のメッシュデータ
    /// </summary>
    private List<VertexItem> Vertices { get; set; }

    /// <summary>
    /// ポリゴンパーツ
    /// </summary>
    private List<PolygonPart> PolygonParts { get; set; }

    /// <summary>
    /// 各パートのバイナリリスト
    /// </summary>
    private List<List<byte>> PartBins { get; set; }

    /// <summary>
    /// VtxLayのバイナリリスト
    /// </summary>
    private List<List<byte>> VtxBins { get; set; }

    /// <summary>
    /// IdxLayのバイナリリスト
    /// </summary>
    private List<List<byte>> IdxBins { get; set; }


    /// <summary>
    /// 削除する頂点リスト
    /// </summary>
    private List<int> DeleteVertices { get; set; }

    /// <summary>
    /// 頂点のインデックスの変換ディクショナリ
    /// </summary>
    private Dictionary<int, ushort> ConvertVtxIndex { get; set; }


    /// <summary>
    /// 両面表示にする
    /// </summary>
    private bool DoubleSided { get; set; }

    /// <summary>
    /// 対象を含む面のみ削除
    /// </summary>
    private bool DeleteAddedOnly { get; set; }

    #endregion



    /// <summary>
    /// 削除を実行します（TMC）
    /// </summary>
    public void Do()
    {
      Init();


      if (Vertices.Count == 0)
      {
        ErrorMessage = "NoTarget";
        return;
      }


      int offset = 0x60;


      foreach (var objGrp in TmcData.ObjGrp)
      {

        for (int i = 0; i < objGrp.Decl.Count; i++)
        {
          var decl = objGrp.Decl[i];


          var declVertices = Vertices.Where(e => e.VtxGrp == decl.VtxGrpIndex && e.Grp == objGrp.ID).OrderBy(e => e.Obj).ThenBy(e => e.Index).ToList();

          if (declVertices.Count == 0) continue;


          var vtxBin = VtxBins[decl.VtxGrpIndex];
          var idxBin = IdxBins[decl.IdxGrpIndex];
          var newVtxBin = new List<byte>();
          var newIdxBin = new List<byte>();
          ConvertVtxIndex = new Dictionary<int, ushort>();

          var indices = TmcData.IdxGrp[decl.IdxGrpIndex].Idx;
          var dataSize = decl.DataSize;

          var objectsInDecl = objGrp.Obj.Where(e => e.VtxGrpIndex == decl.VtxGrpIndex).OrderBy(e => e.VtxStartIndex);

          // 現在のDeclを使用しているオブジェクトを頂点開始位置が早い順に処理
          foreach (var obj in objectsInDecl)
          {
            var vtxStartIndex = newVtxBin.Count / dataSize;
            var idxStartIndex = newIdxBin.Count / 2;

            // VtxとIdxの開始位置を書き換え
            ByteListUtils.Replace(PartBins[0], BitConverter.GetBytes(vtxStartIndex), objGrp.Offset + obj.Offset + offset + 0x18);
            ByteListUtils.Replace(PartBins[0], BitConverter.GetBytes(idxStartIndex), objGrp.Offset + obj.Offset + offset + 0x10);


            var vertices = declVertices.Where(e => e.Obj == obj.ID).Select(e => e.Index).ToList();


            // 削除する頂点が無い場合
            if (vertices.Count == 0)
            {
              newVtxBin.AddRange(vtxBin.GetRange(dataSize * obj.VtxStartIndex, dataSize * obj.VtxCount));

              List<byte> bin = new List<byte>();
              for (int j = obj.IdxStartIndex; j < obj.IdxStartIndex + obj.IdxCount; j++)
              {
                int idx = indices[j] - (obj.VtxStartIndex - vtxStartIndex);
                if (idx < vtxStartIndex) idx = vtxStartIndex;
                bin.AddRange(BitConverter.GetBytes((ushort)idx));
              }
              newIdxBin.AddRange(bin);

              continue;
            }


            // 削除頂点アイテム群からDeclベースのインデックスに変換したリストを作成
            DeleteVertices = new List<int>();

            foreach (var index in vertices)
            {
              DeleteVertices.Add(obj.VtxStartIndex + index);
            }


            // 削除する頂点を追加
            PrepareDeleteVertices(obj, decl.IdxGrpIndex);


            // Vtx削除
            DeleteVtx(vtxBin, newVtxBin, obj, (ushort)vtxStartIndex, dataSize);


            // Idx削除
            DeleteIdx(newIdxBin, obj);


            // Vtx数とIdx数を書き換え
            ByteListUtils.Replace(PartBins[0], BitConverter.GetBytes(newVtxBin.Count / dataSize - vtxStartIndex), objGrp.Offset + obj.Offset + offset + 0x1C);
            ByteListUtils.Replace(PartBins[0], BitConverter.GetBytes(newIdxBin.Count / 2 - idxStartIndex), objGrp.Offset + obj.Offset + offset + 0x14);


            // 両面表示にする場合は書き換え
            if (DoubleSided)
            {
              PartBins[0][objGrp.Offset + obj.Offset + offset + 0x0C] = 1;
            }
          }


          int vtxCount = 1;
          int idxCount = 1;

          if (newVtxBin.Count == 0)
          {
            newVtxBin.AddRange(new byte[(dataSize + 15) / 16 * 16]); // Vtxが無い場合の処理
          }
          else if (newVtxBin.Count % 0x10 > 0)
          {
            vtxCount = newVtxBin.Count / dataSize;
            newVtxBin.AddRange(new byte[0x10 - newVtxBin.Count % 0x10]);
          }

          if (newIdxBin.Count == 0)
          {
            newIdxBin.AddRange(new byte[0x10]); // Idxが無い場合の処理
          }
          else if (newIdxBin.Count % 0x10 > 0)
          {
            idxCount = newIdxBin.Count / 2;
            newIdxBin.AddRange(new byte[0x10 - newIdxBin.Count % 0x10]);
          }


          // DeclのVtx数とIdx数を書き換え
          ByteListUtils.Replace(PartBins[0], BitConverter.GetBytes(vtxCount), objGrp.Offset + objGrp.DeclOffset + decl.Offset + 0x14);
          ByteListUtils.Replace(PartBins[0], BitConverter.GetBytes(idxCount), objGrp.Offset + objGrp.DeclOffset + decl.Offset + 0x10);


          // VtxとIdxのバイナリを置換
          VtxBins[decl.VtxGrpIndex] = newVtxBin;
          IdxBins[decl.IdxGrpIndex] = newIdxBin;
        }
      }


      // バイナリ構築
      BuildTmcBin();
    }

    /// <summary>
    /// 削除を実行します（tmcmesh）
    /// </summary>
    public void DoTmcmesh()
    {
      Init();


      DeleteVertices = Vertices.Where(e => e.VtxGrp == 0 && e.Grp == 0 && e.Obj == 0).OrderBy(e => e.Index).Select(e => e.Index).ToList();

      if (DeleteVertices.Count == 0)
      {
        ErrorMessage = "NoTarget";
        return;
      }


      int offset = 0x60;


      var vtxBin = VtxBins[0];
      var idxBin = IdxBins[0];
      var newVtxBin = new List<byte>();
      var newIdxBin = new List<byte>();
      ConvertVtxIndex = new Dictionary<int, ushort>();


      var indices = TmcData.IdxGrp[0].Idx;
      var dataSize = TmcData.VtxGrp[0].DataSize;
      var obj = TmcData.ObjGrp[0].Obj[0];


      // 削除する頂点を追加
      PrepareDeleteVertices(obj, 0);

      if (DeleteVertices.Count == obj.VtxCount)
      {
        ErrorMessage = "NoData";
        return;
      }


      // Vtx削除
      DeleteVtx(vtxBin, newVtxBin, obj, 0, dataSize);


      // Idx削除
      DeleteIdx(newIdxBin, obj);


      // Vtx数とIdx数を書き換え
      ByteListUtils.Replace(PartBins[0], BitConverter.GetBytes(newVtxBin.Count / dataSize), obj.Offset + offset + 0x1C);
      ByteListUtils.Replace(PartBins[0], BitConverter.GetBytes(newIdxBin.Count / 2), obj.Offset + offset + 0x14);


      // 両面表示にする場合は書き換え
      if (DoubleSided)
      {
        PartBins[0][obj.Offset + offset + 0x0C] = 1;
      }


      if (newVtxBin.Count % 0x10 > 0) newVtxBin.AddRange(new byte[0x10 - newVtxBin.Count % 0x10]);
      if (newIdxBin.Count % 0x10 > 0) newIdxBin.AddRange(new byte[0x10 - newIdxBin.Count % 0x10]);

      PartBins[2] = newVtxBin;
      PartBins[3] = newIdxBin;


      // バイナリ構築
      BuildTmcmeshBin();
    }


    /// <summary>
    /// プロパティを初期化します
    /// </summary>
    private void Init()
    {
      // 各部バイナリ
      //  0 MdlGeo
      //  1 TTX
      //  2 VtxLay
      //  3 IdxLay
      //  4 MtrCol
      //  5 MdlInfo
      //  6 HieLay
      //  7 LHeader
      //  8 NodeLay
      //  9 GlblMtx
      // 10 BnOfsMtx
      // 11 cpf
      // 12 MCAPACK
      // 13 RENPACK
      // 14 GEOXTRAS
      // 15 
      // 16 ACSCLS

      PartBins = new List<List<byte>>();

      int lastOffset = TmcData.H.Size;
      for (int i = TmcData.H.Count1 - 1; i >= 0; i--)
      {
        var partBin = new List<byte>();

        if (TmcData.H.Offsets[i] != 0)
        {
          partBin.AddRange(Bin.Skip(TmcData.H.Offsets[i]).Take(lastOffset - TmcData.H.Offsets[i]));
          lastOffset = TmcData.H.Offsets[i];
        }

        PartBins.Insert(0, partBin);
      }


      // for broken TMC
      if (TmcData.H.Count1 > 14 && TmcData.H.Offsets[14] != 0 && BitConverter.ToUInt32(Bin, TmcData.H.Offsets[14] + 8) != 0x01010000 && PartBins[14].Count > 0x40)
      {
        PartBins[14] = new List<byte>(new byte[0x40]);
      }


      // VtxとIdxのバイナリパートデータをセット
      List<byte> VtxPartBin = PartBins[2];
      List<byte> IdxPartBin = PartBins[3];


      // Vtxバイナリ
      VtxBins = new List<List<byte>>();
      foreach (var grp in TmcData.VtxGrp)
      {
        List<byte> bin = new List<byte>();
        bin = VtxPartBin.Skip(grp.Offset).Take(grp.Size).ToList();
        VtxBins.Add(bin);
      }


      // Idxバイナリ
      IdxBins = new List<List<byte>>();
      foreach (var grp in TmcData.IdxGrp)
      {
        List<byte> bin = new List<byte>();
        bin = IdxPartBin.Skip(grp.Offset).Take(grp.Size).ToList();
        IdxBins.Add(bin);
      }


      ExBin = new List<byte>();
    }

    /// <summary>
    /// 削除する頂点リストを準備します
    /// </summary>
    /// <param name="obj">オブジェクトデータ</param>
    /// <param name="idxGrpIndex">Idxグループインデックス</param>
    private void PrepareDeleteVertices(ObjectPart obj, int idxGrpIndex)
    {
      if (!DeleteAddedOnly) // 接続面を削除
      {
        // ポリゴンパーツを取得
        PolygonParts = IdxUtils.GetPolygonPartsTriangleStrip(TmcData, obj, idxGrpIndex);

        // 接続面へ対象を拡大して削除頂点リストに追加
        DeleteVertices = GetDeleteVertices(new HashSet<int>(DeleteVertices));
      }
    }

    /// <summary>
    /// 削除する接続面の頂点を取得します
    /// </summary>
    /// <param name="deleteVertices">削除頂点ハッシュリスト</param>
    private List<int> GetDeleteVertices(HashSet<int> deleteVertices)
    {
      // 接続面の頂点を削除頂点リストへ追加
      int deleteCount;
      List<PolygonPart> tempPolygonParts = new List<PolygonPart>(PolygonParts);
      do
      {
        deleteCount = deleteVertices.Count;

        foreach (var part in tempPolygonParts.ToList())
        {
          if (part.Selected) continue;

          foreach (var idx in part.Indices)
          {
            if (!deleteVertices.Contains(idx)) continue;

            for (int i = 0; i < part.Indices.Count; i++)
            {
              deleteVertices.Add(part.Indices[i]);
            }
            part.Selected = true;
            tempPolygonParts.Remove(part);
            break;
          }
        }
      } while (tempPolygonParts.Count > 0 && deleteCount < deleteVertices.Count);


      return deleteVertices.ToList();
    }

    /// <summary>
    /// Vtxを削除します
    /// </summary>
    /// <param name="vtxBin">Vtxバイナリデータ</param>
    /// <param name="newVtxBin">新しいVtxバイナリデータ</param>
    /// <param name="obj">オブジェクトデータ</param>
    /// <param name="startIndex">開始インデックス</param>
    /// <param name="dataSize">データサイズ</param>
    private void DeleteVtx(List<byte> vtxBin, List<byte> newVtxBin, ObjectPart obj, ushort startIndex, int dataSize)
    {
      ushort vtxCount = startIndex;

      // 範囲外のインデックスの頂点を無視するためにオブジェクトの頂点インデックス範囲を処理
      for (int j = obj.VtxStartIndex; j < obj.VtxStartIndex + obj.VtxCount; j++)
      {
        if (!DeleteVertices.Contains(j))
        {
          // 削除しない頂点のバイナリを新規バイナリに追加
          byte[] vBin = new byte[dataSize];
          Array.Copy(vtxBin.ToArray(), dataSize * j, vBin, 0, dataSize);
          newVtxBin.AddRange(vBin);

          // 置換辞書オブジェクトをセット
          ConvertVtxIndex[j] = vtxCount;

          vtxCount++;
        }
      }
    }

    /// <summary>
    /// Idxを削除します
    /// </summary>
    /// <param name="newIdxBin">新しいIdxバイナリデータ</param>
    /// <param name="obj">オブジェクトデータ</param>
    private void DeleteIdx(List<byte> newIdxBin, ObjectPart obj)
    {
      if (ConvertVtxIndex.Count > 0)
      {
        newIdxBin.AddRange(GetDeletedIdxBin(obj));
      }
    }

    /// <summary>
    /// ポリゴンを削除したIdxバイナリデータを取得します
    /// </summary>
    /// <param name="obj">オブジェクトデータ</param>
    private List<byte> GetDeletedIdxBin(ObjectPart obj)
    {
      List<ushort> addIndices = new List<ushort>();

      if (DeleteAddedOnly)
      {
        // 選択ポリゴンのみ削除
        // 置換辞書オブジェクトに含まれているものを追加して前後に追加
        addIndices.AddRange(IdxUtils.GetIndicesSelected(obj, TmcData.IdxGrp[obj.IdxGrpIndex].Idx, ConvertVtxIndex));
      }
      else
      {
        // 接続面削除
        // 置換辞書オブジェクトに含まれているものを追加
        addIndices.AddRange(IdxUtils.GetIndicesConnected(obj, PolygonParts, false));
      }


      List<byte> bin = new List<byte>();

      // インデックスを変換しつつバイナリデータへ追加
      foreach (ushort idx in addIndices)
      {
        if (!ConvertVtxIndex.ContainsKey(idx))
        {
          bin.AddRange(BitConverter.GetBytes(ConvertVtxIndex.Values.Min()));
        }
        else
        {
          bin.AddRange(BitConverter.GetBytes(ConvertVtxIndex[idx]));
        }
      }

      return bin;
    }

    /// <summary>
    /// TMCのバイナリを構築します
    /// </summary>
    private void BuildTmcBin()
    {
      // VtxLayバイナリパート再構築
      PartBins[2] = TmcUtils.BuildHeaderBaseBin("VtxLay");
      TmcUtils.BuildBin(PartBins[2], VtxBins, null, true, false);

      // IdxLayバイナリパート再構築
      PartBins[3] = TmcUtils.BuildHeaderBaseBin("IdxLay");
      TmcUtils.BuildBin(PartBins[3], IdxBins, null, true, false);


      ExBin.AddRange(Bin.Take(TmcData.H.Offset1));

      TmcUtils.BuildBin(ExBin, PartBins, null, false, true);
    }

    /// <summary>
    /// tmcmeshのバイナリを構築します
    /// </summary>
    private void BuildTmcmeshBin()
    {
      ExBin.AddRange(Bin.Take(TmcData.H.Offset1));

      TmcUtils.BuildBin(ExBin, PartBins, null, true, true);
    }

  }
}
