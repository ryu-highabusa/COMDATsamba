﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Data;
using System.Linq;
using System.ComponentModel;
using TMC_Tool.ViewModels;
using Tmc;
using Language;


namespace TMC_Tool
{
  /// <summary>
  /// OptionWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class ObjectSelectWindow : Window
  {
    public ObjectSelectWindowViewModel Data;

    private static Lang.Text txt;

    private static bool dialogResult;

    //public DataTable dtObject;

    private bool IsActivated = false;

    public ObjectSelectWindow()
    {
      InitializeComponent();

      this.MouseLeftButtonDown += (sender, e) => this.DragMove();
      this.ShowInTaskbar = false;

      txt = MainWindow.txt;

      Description.Text = txt.objSelDescription;
      dgcObjName.Header = txt.dgcObjName;
      btnOk.Content = txt.OK;
      btnCancel.Content = txt.Cancel;

      Data = new ObjectSelectWindowViewModel();
      this.DataContext = Data;
    }

    public bool Show(Window owner)
    {
      this.Owner = owner;

      if (this.ActualHeight != 0)
      {
        this.Top = owner.Top + (owner.ActualHeight / 2) - (this.ActualHeight / 2);
        this.Left = owner.Left + (owner.ActualWidth / 2) - (this.ActualWidth / 2);
      }

      IsActivated = false;
      this.ShowDialog();
      owner.Activate();
      owner.Focus();
      return dialogResult;
    }

    public void Init(TmcData tmcData)
    {
      if (Data.Objects.Count > 0)
      {
        Data.Objects.Clear();
      }
      List<int> list = new List<int>();

      for (int i = 0; i < tmcData.ObjGrp.Count; i++)
      {
        var grp = tmcData.ObjGrp[i];

        for (int j = 0; j < grp.Obj.Count; j++)
        {
          if (grp.Obj[j].VtxCount == 0) continue;

          string objName = grp.Name + "_" + grp.Obj[j].ID.ToString("x");
          if (tmcData.Node[grp.Node].Blends == null) objName += " *";

          ObjectItem newItem = new ObjectItem(true, objName, i, j);

          list.Add(Data.Objects.Count);
          Data.Objects.Add(newItem);
        }
      }

      cbHeader.IsChecked = true;
    }

    private void btnOk_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = true;
      Window_Hide();
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      dialogResult = false;
      Window_Hide();
    }



    private void CheckBox_Click(object sender, RoutedEventArgs e)
    {
      CheckBox cb = sender as CheckBox;
    
      if (dgObject.SelectedItems.Count > 1)
      {
        foreach (var item in dgObject.SelectedItems)
        {
          var obj = item as ObjectItem;

          obj.IsChecked = (bool)cb.IsChecked;
        }
      }
      if (dgObject.Items.Count == Data.Objects.Count(elem => elem.IsChecked == true))
        cbHeader.IsChecked = true;
      else
        cbHeader.IsChecked = false;
    }

    private void HeaderCheckBox_Click(object sender, RoutedEventArgs e)
    {
      CheckBox cb = sender as CheckBox;

      foreach (var obj in Data.Objects)
      {
        obj.IsChecked = (bool)cb.IsChecked;
      }
    }

    private void objSelWindow_Activated(object sender, EventArgs e)
    {
      if (!IsActivated)
      {
        var story = (System.Windows.Media.Animation.Storyboard)this.FindResource("fadeIn");
        story.Begin();
        IsActivated = true;

        this.SizeToContent = SizeToContent.Height;
        if (this.ActualHeight > this.Owner.ActualHeight - 10)
        {
          this.MaxHeight = this.Owner.ActualHeight - 10;
          this.SizeToContent = SizeToContent.Manual;
        }
        this.Top = this.Owner.Top + (this.Owner.ActualHeight / 2) - (this.ActualHeight / 2);
        this.Left = this.Owner.Left + (this.Owner.ActualWidth / 2) - (this.ActualWidth / 2);
        this.MaxHeight = Double.PositiveInfinity;

        btnCancel.Focus();
      }
    }

    private void FadeInAnimation_Completed(object sender, EventArgs e)
    {
      var story = (System.Windows.Media.Animation.Storyboard)this.FindResource("fadeIn");
      story.Stop();
    }

    private void Window_Closing(object sender, CancelEventArgs e)
    {
      e.Cancel = true;

      var story = (System.Windows.Media.Animation.Storyboard)this.FindResource("fadeOut");
      story.Begin();
      IsActivated = false;
    }

    private void Window_Hide()
    {
      var story = (System.Windows.Media.Animation.Storyboard)this.FindResource("fadeOut");
      story.Begin();
    }

    private void FadeOutAnimation_Completed(object sender, EventArgs e)
    {
      var story = (System.Windows.Media.Animation.Storyboard)this.FindResource("fadeOut");
      story.Stop();

      this.Hide();
      this.Owner.Activate();
    }
  }
}
