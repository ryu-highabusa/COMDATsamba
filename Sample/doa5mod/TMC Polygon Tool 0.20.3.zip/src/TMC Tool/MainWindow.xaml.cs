﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using TMC_Tool.ViewModels;
using Language;
using Message;

namespace TMC_Tool
{
  /// <summary>
  /// MainWindow.xaml の相互作用ロジック
  /// </summary>
  public partial class MainWindow : Window
  {
    private static MainWindowViewModel data;

    public static Lang lang;
    public static Lang.Text txt;

    private static bool appStarted = false;
    public static bool UpdateChecking = true;

    private static string curText = "";



    public MainWindow()
    {
      InitializeComponent();

      lang = new Lang(this);
      txt = lang.Txt;
      MessageWindow.SetTxt(txt);

      data = new MainWindowViewModel(this);
      this.DataContext = data;

      Application.Current.ShutdownMode = ShutdownMode.OnMainWindowClose;
    }

    private void mainWindow_Loaded(object sender, RoutedEventArgs e)
    {
      List<string> cmds = System.Environment.GetCommandLineArgs().ToList();
      cmds.RemoveAt(0);
      data.OpenDorpFile(cmds);
    }

    private void mainWindow_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      if (e.LeftButton == MouseButtonState.Pressed) this.DragMove();
    }

    private void mainWindow_DragOver(object sender, DragEventArgs e)
    {
      e.Handled = true;
      if (e.Data.GetDataPresent(DataFormats.FileDrop))
        e.Effects = DragDropEffects.Move;
      else
        e.Effects = DragDropEffects.None;
    }

    private void mainWindow_DragDrop(object sender, DragEventArgs e)
    {
      List<string> paths = ((string[])e.Data.GetData(DataFormats.FileDrop, false)).ToList();
      data.OpenDorpFile(paths);
    }


    private void CheckBox_Click(object sender, RoutedEventArgs e)
    {
      CheckBox cb = sender as CheckBox;

      data.IsCheckedChanged((bool)cb.IsChecked);
    }

    private void tbNum_GotFocus(object sender, RoutedEventArgs e)
    {
      TextBox tb = sender as TextBox;
      if (tb == null) return;

      curText = tb.Text;
      tb.SelectAll();
    }

    private void tbNum_LostFocus(object sender, RoutedEventArgs e)
    {
      TextBox tb = sender as TextBox;
      tb.Text = tb.Text.Trim();

      if (!float.TryParse(tb.Text, out float f))
      {
        tb.Text = curText;
      }
    }

  }
}
