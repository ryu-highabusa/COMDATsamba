﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text.RegularExpressions;
using Common;
using Tmc;
using TMC_Tool.Models;
using Message;

namespace TMC_Tool.ViewModels
{
  public partial class MainWindowViewModel : BindableBase
  {
    /// <summary>
    /// 保存前のチェックを行います
    /// </summary>
    private bool PreSaveCheck()
    {
      if (Vertices.Count(elem => elem.IsChecked == true) > 0)
      {
        return true;
      }

      return false;
    }

    /// <summary>
    /// TMCにメッシュデータを挿入して保存します
    /// </summary>
    /// <param name="path">ファイルパス</param>
    private bool Save(string path)
    {
      mainWindow.IsEnabled = false;
      MainWindow.DoEvents();

      try
      {
        MainWindow.UpdateChecking = false;


        var delete = new DeletePolygons(this);

        if (DataType == "tmcmesh")
          delete.DoTmcmesh();
        else
          delete.Do();

        if (delete.ExBin.Count == 0)
        {
          if (delete.ErrorMessage == "NoData")
            MessageWindow.Show(mainWindow, txt.ErrorNotSavedBecauseNoData, txt.Error);
          else
            MessageWindow.Show(mainWindow, txt.ErrorNotSavedBecauseNotDeleted, txt.Error);

          mainWindow.IsEnabled = true;
          return false;
        }

        // TMC保存
        File.WriteAllBytes(path, delete.ExBin.ToArray());


        if (IsKeepData)
        {
          Status = path;
          TmcData.WriteTime = File.GetLastWriteTime(TmcData.Path);
          mainWindow.IsEnabled = true;
        }
        else
        {
          Open(path);
        }


        ShowTextBlockMessage(txt.Saved);


        return true;
      }
      catch (Exception e)
      {
        MessageWindow.Show(mainWindow, e.Message + "\r\n\r\n" + e.StackTrace, txt.Error);
        mainWindow.IsEnabled = true;
        return false;
      }
      finally
      {
        MainWindow.UpdateChecking = true;
        mainWindow.Activate();
        mainWindow.Focus();
      }
    }

    /// <summary>
    /// TMCのバックアップファイルを作成します
    /// </summary>
    private string CreateBackup()
    {
      try
      {
        if (!File.Exists(TmcData.Path)) return null;

        string dirPath = Path.GetDirectoryName(TmcData.Path);
        string name = Path.GetFileNameWithoutExtension(TmcData.Path);
        string ext = Path.GetExtension(TmcData.Path);

        List<string> files = Directory.GetFiles(dirPath, name + "*" + ext, SearchOption.TopDirectoryOnly).ToList();
        string regStr = name + @" - ([0-9]+)";
        int count = 1;

        foreach (string file in files)
        {
          string fileName = Path.GetFileNameWithoutExtension(file);

          MatchCollection mc = Regex.Matches(fileName, regStr);
          foreach (Match m in mc)
          {
            int num = int.Parse(m.Groups[1].Value);
            if (count <= num) count = num + 1;
          }
        }

        string newPath;
        while (File.Exists(newPath = dirPath + @"/" + name + " - " + count + ext))
        {
          count++;
        }

        File.Move(TmcData.Path, newPath);

        return newPath;
      }
      catch (Exception e)
      {
        MessageWindow.Show(mainWindow, e.Message + "\r\n\r\n" + e.StackTrace, txt.Error);
        return null;
      }
    }



    /// <summary>
    /// メッシュを抽出
    /// </summary>
    private bool Extract()
    {
      mainWindow.IsEnabled = false;
      MainWindow.DoEvents();

      try
      {
        var extract = new ExtractMeshes(this);

        if (DataType == "tmcmesh")
          extract.DoTmcmesh();
        else
          extract.Do();

        if (extract.Count != 0)
          ShowTextBlockMessage(txt.Extracted);
        else
          ShowTextBlockMessage(txt.NotExtracted, alertBg);

        return true;
      }
      catch (Exception e)
      {
        MessageWindow.Show(mainWindow, e.Message + "\r\n\r\n" + e.StackTrace, txt.Error);
        return false;
      }
      finally
      {
        MainWindow.UpdateChecking = true;
        mainWindow.IsEnabled = true;
        mainWindow.Activate();
        mainWindow.Focus();
      }
    }
  }
}
