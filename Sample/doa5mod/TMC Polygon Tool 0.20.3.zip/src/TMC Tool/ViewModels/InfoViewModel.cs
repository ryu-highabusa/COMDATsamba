﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows;
using Common;
using Tmc;
using TMC_Tool.Models;
using Language;

namespace TMC_Tool.ViewModels
{
  public class InfoViewModel : BindableBase
  {
    /// <summary>
    /// 表示するテキスト
    /// </summary>
    private string _Text;
    public string Text
    {
      get => _Text;
      set => SetProperty(ref _Text, value);
    }

    /// <summary>
    /// 有効・無効の状態
    /// </summary>
    private bool _IsEnabled;
    public bool IsEnabled
    {
      get => _IsEnabled;
      set => SetProperty(ref _IsEnabled, value);
    }

    /// <summary>
    /// 言語テキストデータ
    /// </summary>
    private Lang.Text txt;

    /// <summary>
    /// オブジェクトグループ名の最大長さ
    /// </summary>
    private int MaxGrpNameLength { get; set; }

    /// <summary>
    /// ObjGeoでの合計頂点数
    /// </summary>
    private int TotalVtxCountObj { get; set; }

    /// <summary>
    /// VtxLayへのオフセット
    /// </summary>
    private int OffsetVtxLay { get; set; }

    /// <summary>
    /// IdxLayへのオフセット
    /// </summary>
    private int OffsetIdxLay { get; set; }



    /// <summary>
    /// 出力テキストを構築します。
    /// </summary>
    /// <param name="tmcData">TMCデータ</param>
    public void BuildText(TmcData tmcData)
    {
      IsEnabled = false;

      Text = "During build...";

      txt = MainWindow.txt;


      string text = "";

      MaxGrpNameLength = 0;
      foreach (var grp in tmcData.ObjGrp)
      {
        foreach (var obj in grp.Obj)
        {
          string type = "";
          if (obj.MaterialType == "Skin")
            type = " (Skin)";
          else if (obj.MaterialType == "WetTex")
            type = " (Wet)";

          if (MaxGrpNameLength < grp.Name.Length + obj.ID.ToString("x").Length + type.Length + 1)
          {
            MaxGrpNameLength = grp.Name.Length + obj.ID.ToString("x").Length + type.Length + 1;
          }
        }
      }

      string objPartInfo = txt.Objects;
      string vtxInfo = "";

      OffsetVtxLay = tmcData.H.Offsets[2];
      OffsetIdxLay = tmcData.H.Offsets[3];


      TotalVtxCountObj = 0;
      for (int i = 0; i < tmcData.ObjGrp.Count; i++)
      {
        //objInfo += String.Format("{0, -" + objNameMax + "} / {1, 8:X8}\r\n", objData.Grp[i].Name, objData.Grp[i].Start);

        foreach (var obj in tmcData.ObjGrp[i].Obj)
        {
          objPartInfo += BuildObjPartInfoText(tmcData, tmcData.ObjGrp[i], obj);
        }
      }

      vtxInfo += String.Format("\r\n{0} (VtxLay)", txt.VertexGroups);
      for (int i = 0; i < tmcData.VtxGrp.Count; i++)
      {
        vtxInfo += String.Format("\r\n{0}{1} / ", txt.Group, i);
        vtxInfo += String.Format("{0} {1, 8:X8} / ", txt.Address, OffsetVtxLay + tmcData.VtxGrp[i].Offset);
        //vtxInfo += String.Format("{0} {1, 8:X8} / ", "データサイズ", tmcData.VtxGrp[i].Size);

        if (tmcData.VtxGrp[i].DataSize == 0)
        {
          vtxInfo += "Not Linked\r\n";
          continue;
        }

        vtxInfo += txt.VertexDataSize;
        vtxInfo += String.Format(" {0, 4:X4} / {1} {2} / ", tmcData.VtxGrp[i].DataSize, txt.UVCount, tmcData.VtxGrp[i].UVCount);
        vtxInfo += String.Format("{0} {1, 5}", txt.Count, tmcData.VtxGrp[i].Size / tmcData.VtxGrp[i].DataSize);
      }
      int vtxCountTotal = 0;
      for (int i = 0; i < tmcData.VtxGrp.Count; i++)
      {
        vtxCountTotal += tmcData.VtxGrp[i].Vtx.Count;
      }

      vtxInfo += "\r\n";
      if (TotalVtxCountObj == vtxCountTotal)
      {
        vtxInfo += String.Format(txt.InfoTotalVertexCount, vtxCountTotal);
      }
      else
      {
        vtxInfo += String.Format(txt.InfoDifferentVertexCount, TotalVtxCountObj, vtxCountTotal);
      }
      text += objPartInfo + "\r\n" + vtxInfo;

      string idxInfo = "";
      idxInfo += String.Format("\r\n{0} (IdxLay)", txt.IdxGroups);
      int viewCount = 8;
      for (int i = 0; i < tmcData.IdxGrp.Count; i++)
      {
        idxInfo += String.Format("\r\n{0}{1} / ", txt.Group, i);
        idxInfo += String.Format("{0} {1, 8:X8} / ", txt.Address, OffsetIdxLay + tmcData.IdxGrp[i].Offset);
        idxInfo += String.Format("{0} {1, 5} / ", txt.Count, tmcData.IdxGrp[i].Idx.Length);
        idxInfo += String.Format(txt.InfoFisrtData + " :", viewCount);
        for (int j = 0; j < viewCount && j < tmcData.IdxGrp[i].Idx.Length; j++)
        {
          idxInfo += " " + tmcData.IdxGrp[i].Idx[j];
        }
      }
      text += "\r\n" + idxInfo;


      if (!String.IsNullOrEmpty(text)) IsEnabled = true;

      Text = text;
    }

    /// <summary>
    /// オブジェクトの情報テキストを構築
    /// </summary>
    /// <param name="tmcData">TMCデータ</param>
    /// <param name="objGrp">オブジェクトグループデータ</param>
    /// <param name="obj">オブジェクトデータ</param>
    private string BuildObjPartInfoText(TmcData tmcData, ObjectGroup objGrp, ObjectPart obj)
    {
      string text = "\r\n";


      var vtxGrp = tmcData.VtxGrp[obj.VtxGrpIndex];
      var idxGrp = tmcData.IdxGrp[obj.IdxGrpIndex];

      string type = "";
      if (obj.MaterialType == "Skin")
        type = " (Skin)";
      else if (obj.MaterialType == "WetTex")
        type = " (Wet)";

      text += String.Format("{0, -" + MaxGrpNameLength + "}", objGrp.Name + "_" + obj.ID.ToString("x") + type);

      text += String.Format(" / {0}( {1}{2} / {3} ", txt.Vertices, txt.GroupHalf, obj.VtxGrpIndex, txt.AddressHalf);
      text += String.Format("{0, 8:X8} {1} ", OffsetVtxLay + vtxGrp.Offset + obj.VtxStartIndex * vtxGrp.DataSize, txt.WaveDash);
      if (obj.VtxCount != 0)
      {
        text += String.Format("{0, 8:X8}", vtxGrp.Vtx[obj.VtxStartIndex + obj.VtxCount - 1].Address + vtxGrp.DataSize - 1);
      }
      else
      {
        text += "--------";
      }
      text += String.Format(" / {0} {1, 5} {2} ", txt.IndexHalf, obj.VtxStartIndex, txt.WaveDash);
      if (obj.VtxCount != 0)
      {
        text += String.Format("{0, 5}", obj.VtxStartIndex + obj.VtxCount - 1);
      }
      else
      {
        text += "-----";
      }
      text += String.Format(" / {0} {1, 5} )", txt.Count, obj.VtxCount, txt.AddressHalf);
      text += String.Format(" / Idx( {0} {1, 8:X8} {2} ", txt.AddressHalf, OffsetIdxLay + idxGrp.Offset + obj.IdxStartIndex * 2, txt.WaveDash);
      if (obj.IdxCount != 0)
      {
        text += String.Format("{0, 8:X8}", OffsetIdxLay + idxGrp.Offset + (obj.IdxStartIndex + obj.IdxCount) * 2 - 1);
      }
      else
      {
        text += "--------";
      }
      text += String.Format(" / {0} {1, 5} {2} ", txt.IndexHalf, obj.IdxStartIndex, txt.WaveDash);
      if (obj.IdxCount != 0)
      {
        text += String.Format("{0, 5}", obj.IdxStartIndex + obj.IdxCount - 1);
      }
      else
      {
        text += "-----";
      }
      text += " )";


      TotalVtxCountObj += obj.VtxCount;


      return text;
    }
  }
}
