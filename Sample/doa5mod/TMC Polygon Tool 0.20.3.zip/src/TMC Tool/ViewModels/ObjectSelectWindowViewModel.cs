﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using Common;

namespace TMC_Tool.ViewModels
{
  public class ObjectSelectWindowViewModel : BindableBase
  {
    /// <summary>
    /// コンストラクタ
    /// </summary>
    public ObjectSelectWindowViewModel()
    {
      Objects = new ObservableCollection<ObjectItem>();
    }


    #region Objects
    /// <summary>
    /// オブジェクトリスト
    /// </summary>
    public ObservableCollection<ObjectItem> Objects { get; set; }
    #endregion
  }

}
