﻿using System.Collections.Generic;

namespace Common
{
  public class ByteListUtils
  {
    /// <summary>
    /// バイトリストデータの指定インデックスからバイト配列の長さだけ置換します
    /// </summary>
    /// <param name="bin">バイトリストデータ</param>
    /// <param name="replace">置換バイト配列</param>
    /// <param name="index">置換開始インデックス</param>
    public static List<byte> Replace(List<byte> bin, byte[] replace, int index)
    {
      bin.RemoveRange(index, replace.Length);
      bin.InsertRange(index, replace);
      return bin;
    }

    /// <summary>
    /// バイトリストデータの長さが指定した数値の倍数になるように0埋めします
    /// </summary>
    /// <param name="bin">バイトリストデータ</param>
    /// <param name="num">この数値の倍数の長さに</param>
    public static void FillZero(List<byte> bin, int num)
    {
      if (bin.Count % num != 0) bin.AddRange(new byte[num - bin.Count % num]);
    }
  }
}
