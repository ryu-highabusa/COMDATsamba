﻿using System.Collections.Generic;
using System.Windows.Media.Media3D;

namespace Common
{
  public class MatrixUtils
  {
    /// <summary>
    /// Matrix3Dデータからfloatの配列に変換したものを取得します
    /// </summary>
    /// <param name="matrix">Matrix3Dデータ</param>
    public static List<float> Matrix3DToList(Matrix3D matrix)
    {
      List<float> m = new List<float>();
      m.Add((float)matrix.M11);
      m.Add((float)matrix.M12);
      m.Add((float)matrix.M13);
      m.Add((float)matrix.M14);
      m.Add((float)matrix.M21);
      m.Add((float)matrix.M22);
      m.Add((float)matrix.M23);
      m.Add((float)matrix.M24);
      m.Add((float)matrix.M31);
      m.Add((float)matrix.M32);
      m.Add((float)matrix.M33);
      m.Add((float)matrix.M34);
      m.Add((float)matrix.OffsetX);
      m.Add((float)matrix.OffsetY);
      m.Add((float)matrix.OffsetZ);
      m.Add((float)matrix.M44);
      return m;
    }

    /// <summary>
    /// floatの配列からMatrix3Dデータに変換したものを取得します
    /// </summary>
    /// <param name="list">floatの配列</param>
    public static Matrix3D ListToMatrix3D(List<float> list)
    {
      Matrix3D matrix = new Matrix3D();
      matrix.M11 = list[0];
      matrix.M12 = list[1];
      matrix.M13 = list[2];
      matrix.M14 = list[3];
      matrix.M21 = list[4];
      matrix.M22 = list[5];
      matrix.M23 = list[6];
      matrix.M24 = list[7];
      matrix.M31 = list[8];
      matrix.M32 = list[9];
      matrix.M33 = list[10];
      matrix.M34 = list[11];
      matrix.OffsetX = list[12];
      matrix.OffsetY = list[13];
      matrix.OffsetZ = list[14];
      matrix.M44 = list[15];
      return matrix;
    }
  }
}
