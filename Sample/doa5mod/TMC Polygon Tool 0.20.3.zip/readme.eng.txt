
!!! Caution !!!

If you downloaded from direct url, this might be old version.
Check this url.
https://www.mediafire.com/folder/9zi2gt8dyllaj/doa5mod

You are not permitted to use this tool without your agreement of the following document.
https://www.mediafire.com/folder/rbhtrb7pjlrgr/License -> License.txt

You need to install .NET Framework 4.5.x or 4.6.x.
https://msdn.microsoft.com/library/5a4x27ek.aspx



How to enable Language.dat (Delete file extension.)

Language.dat.disable => Language.dat


If you can't open it on noesis after you save on this tool,
download the plug-in(for Noesis TMC Plugin Custom).

If you can't open it on noesis after you extract on this tool,
download the plug-in(for Noesis tmcmesh Plugin).

Download from here.
https://www.mediafire.com/folder/9zi2gt8dyllaj/doa5mod



Sorry, more detailed information is not in English.



Please forgive me my lousy English.
(I was using Google a lot.)





Copyright 2015-now, dtk mnr

Released under the GPL v3.0 License.
http://www.gnu.org/licenses/gpl-3.0.txt
