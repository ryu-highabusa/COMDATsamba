DOA  = (universal tool= '*') or (unknown tool= '?')

DOA1 = Dead or Alive 1
DOA2 = Dead or Alive 2
DOA3 = Dead or Alive 3
DOA4 = Dead or Alive 4
DOA5 = Dead or Alive 5

DOAX = Dead or Alive Xtreme Beach Volleyball
DOAX2= Dead or Alive Xtreme Beach Volleyball 2
DOAP = Dead or Alive Paradise

DOAU = Dead or Alive Ultimate
DOAO = Dead or Alive Online
