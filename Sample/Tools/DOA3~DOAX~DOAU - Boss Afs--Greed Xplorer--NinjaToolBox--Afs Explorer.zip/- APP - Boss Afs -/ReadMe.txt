Bossafs by boss302

$Date: 6/15/04 8:28p $
$Revision: 11 $

This program is an xpr/afs file tuner.
Much of the functionality of this program was taken from xprtune.
*This program requires MFC 7.1 dll's
For anyone who is interested, this program is written in C++ using Dev Studio 2003 

What this program allows you to do, is manipulate afs files, and xpr files.

READ THE WHOLE DOCUMENT before asking why something doesn't work please.

The main dialog, prompts for a file. Either an xpr or afs file can be loaded.
Based on what type of file is loaded, the tree control will populate with the contained objects.
The information box, will contain information about the object currently selected in the tree control.
(in most cases)
The picture control will contain a preview of the selected object if one is available.
All operations from this dialog are done by right clicking on an object, and picking an option from the context menu.
If you right click on something and get no menu, then there are no functions available. There are several objects
that have disabled menu items that show in grey, that's because the feature isn't implemented yet.

Anyone that feels like writing a manual for this, I would appreciate it, as documentation is not one of my loves.
And I would also appreciate some feedback, what works, what doesn't etc.
To see upcoming features read todo.txt
------------------------------------------------------------------
Version 1.2.2.0
Fixed problem with rebuild of xpr file (thanks Keypel)
Minor code change 2 lines leftover crap from unicode conversion (1.0.0.9)
------------------------------------------------------------------
Version 1.2.1.0
Ability to open cat file directly
This is the final version of bossafs. 
Too many hacks on top of hacks, have made the code way too hard to
use. Any future tools will be written on a new code base.
------------------------------------------------------------------
Version 1.2.0.0 15821 (304)
Some bug fixes
patch files remained locked (because they were not closing)
display of picture was not updating (it's better but not perfect)
unable to open object 0 for xprtune
other stuff I can't remember
Only new feature is ability to adjust cat file material properties
Right button on a cat file (only inside afs for now) and cattune
I don't know that much about all the numbers but if you mess with them
cool stuff happens that we were unable to mess with before. You can change
the colors of the vkinis, lefangs hair, change the gem colors of the venus etc.
Post your discoveries on ninjahacker to share with others.
------------------------------------------------------------------
Version 1.1.0.1 
2 Bug fixes
Problem with name formatting due to new gstring code. Removed gstring, reverted back to 
CString. (cannot open mdl file and other file open errors)
Problem with exeption handler in vertex buffer load routine. (out of memory problem)
No new features.
------------------------------------------------------------------
Version 1.1.0.0 15517 (2644)
Major updates.
Bug fixes.
xpression xport/import was not processing file names correctly
added some status dialog stuff so you can see if something worked/failed
fixed out of memory error on processing some xpr files
fixed probelem with batch patch options dialog
fixed display update in resize dialog
changed behavior of tree control, now preloading all second level objects from afs file
    Needed this for sort, find and xpr-cat export to function properly. Takes a few seconds
    longer for program to start.

Features
Dates added to afs objects. Can be edited with afs object property page (page 2)
Import of dds file now checks to see if imported texture has more than 1 mip map and fails if it does.
Added options page (accessable from system menu)
   remember last file
   several default directories
   transparency (tune dialog) on 
   export cat with xpr
      If this is checked, then when you export an xpr file, you will be asked if you wish to export
      the associated cat file. 
Added sort tree control to main tree

------------------------------------------------------------------
Version 1.0.1.0  12873 (1273)
A couple of small bug fixes.
The major change, is the batch patch facility.
You can now generate and apply patches in batches.
This only works on AFS files, and is available through the context (right button) menu
To generate patches, 
1 Open the modfied afs file. 
2 Pick generate multiple patches from context menu.
3 Pick your options, leaving the default "all" is safe, it just takes longer
  If you don't understand the options, then leave the default it will always work.
4 Pick the directory for the patches
5 Pick the original afs file
6 Wait

To Apply patches
1 Open the afs file to be patched
2 Pick apply multiple patches from context menu
3 Pick directory with patches
4 Wait

I have included a skimped down version of the amber suit for you to mess with.
------------------------------------------------------------------
Version 1.0.0.9  11600 
Quite a few cosmetic and small bug fixes.

Little tweaks, so you get a little more feedback to see if something worked or not.

Added icons to tree control because it looks nicer.

The program is now MBCS (as opposed to Unicode) So the program "Should" work on Win9X.
This also means you will need different dll's
Dll's you need are: MFC71.DLL MSVCR71.DLL MSVCP71.DLL These dll's are should be available from the same site
You got this program from. 

The patch system is %50 complete.
You can now generate or apply a patch to a whole xpr, or afs, or an afs object.
The 2 new options "generate patch" "apply patch" will appear in the context menu.
*** You can only generate and apply patches to objects that are of the same size ***
What this allows you to do, is take an xpr change transparency textures, whatever and generate a single patch file
So if you have a new suit or costume that you want to distribute, you would say:
Take this patch yoda.bos, and apply it to the original yoda.xpr and yoda's bikini will now be green.
As far as I know, distributing patches in this fashion is legal, because the patch cannot be applied without the original
file. Also the patch contains ONLY changed codes, so it contains none of the original file.
There is no undue feature, and if a patch blows up, the file being patched will be in an "undefined" state, so work with 
backups as always.


Upcoming features
1) Patch system, patch objects of different sizes (most of this code is installed, but not integrated yet)
2) Object preview in main window (I need some sample code, I don't know much about this 3d rendering any help will be appreciated)
    I have gotten no help on this, and if someone doesn't give me a couple of hint's here, this feature is never going to happen
3) Bundler functionality built in ? Or mdlhack ?
    Waiting for _mirage_ the master to complete his work

------------------------------------------------------------------
Version 1.0.0.8 (they are all beta so why bother)
New features (not really, a couple of small things and some bug fixes)
Added a couple of status dialogs, so that when you export or import stuff, you get a dialog box that tells you 
How many were inported or exported.
Fixed a bug in the batch dds import.
Quite a bit of coding on the patch system has been integrated, but it's not enabled yet.


------------------------------------------------------------------
Version 1.0.0.7 Beta
New features
Batch import/export of dds files from xpr's and afs's in 3 different formats.
The 3 formats are: miteexpr, xpression, and bossafs. 
This batch import is FAST takes a little over 2 seconds to import a full set of nude textures (58 files).
DOA3 xprtune
This allows you to manipulate xpr files from doa3. No 256 bit transparency since we don't know how yet.
But you can automatically manipulate pad26,pad29,pad30 (as well as see there current values)
There is a little icon to indicate which mode your in at the top of the xprtune dialog.
The display is similar to xprtune, yes means one material transparent(1,1,1) no means 1 material (0,0,0)
Yes(4) means 4 materials (1,1,1) etc. ??? means the materials don't have matching values (1,1,1) 1,1,0 etc.
The current version set's 

------------------------------------------------------------------
Version 1.0.0.6 Beta
New features:
Cat tune is partially implemented but quite unusable (and disabled). 
XPR export and rebuild.
XPR export works similar to xpression it extracts all dds, vtf and 1 mdl file from an xpr.
These files are in the same format as the version of xpression I found on ninjahacker.

Here is how to rebuild an XPR.
First you must extract the xpr. You can do this from the afs file, or directly from the xpr.
Now you edit the files. 
*** All I have successfully edited is dds files.
You can change from DXT1 to DXT5, change dimensions add alpha channels.
There is a size limit to the dds file, I think it's 64K. There may also be a size limit to the xpr.
Once you edit whatever your going to edit, you then open the original xpr (not inside afs)
You pick rebuild.
Then you pick the directory where all the files you extracted are (your edits will be here also)
You will then be prompted for a new name (you are creating a new file)
Seconds later you have a new xpr. Import into afs file (you will most likely need resize) and done.

Here is a step by step example.
1) extract c:\temp\yaya.xpr from c:\yoyo.afs
2) extract all objects from c:\temp\yaya.xpr into c:\temp\objects
3) edit c:\temp\objects\yaya00.dds, change from DXT1 to DXT4 add alpha channel
4) import c:\temp\objects into c:\temp\yaya.xpr output to c:\temp\new\yaya.xpr
5) import c:\temp\new into c:\yoyo.afs
6) Modify transparency information of yaya.xpr inside yoyo.afs (you won't need to change dimensions or type)

Potential Issues:
Size of dds is too big, I have seen garbage on the screen I think it's a buffer overflow.
Size of xpr is too big, same issue buffer overflow.
I have no way to edit vtf or mdl files, and cannot test if editing them works. There are potentially buffer
overflow issues with these objects also.

Problems I have seen. 
1) I took one of Christies 2 piece suits (peridot), and made 3 of the 4 textures DXT5 with alpha channels. 
I did not resize the dds files, they had been DXT1. I rebuilt the xpr, set transparency, and imported the xpr 
the afs. Part of the crotch area of the suit appears quite garbled as if the dds information was scrambled.

2) I took ayane's ay00 figure, and took the 10 and 11 dds images (body front and body back) and doubled there size. 
I left them at DXT1, no alpha channel, I just doubled the dimensions. After rebuilding, importing, and transferring, 
Ayane renders quite strangely. Her arms and hands, neck feet and shins rendered with the same garbled texture 
as the crotch area described above.

3) I took ayane's ay00 figure, and doubled the dimensions of all textures. Rebuild, Import, ftp.
This time when I tried to use the xpr, the game locked tight.

We are going to have to experiment here.


Fixed several "hidden" undocumented features (read BUGS)
*** THIS IS BETA CODE ***
DON'T WORK ON FILES YOU DON'T HAVE COPIES OF.

-------------------------------------------------------------------
Version 1.0.0.5 Beta
New features:
Property pages for some objects.
These are for hacking, you could severly munge your afs file so be careful.
If an object has property pages, when you right button the object properties will be in the menu.
If it's not there I havn't implemented property pages for that object.

Afs Import/Export complete.
    Files are exported/imported as follows:
    First occurence of file.ext will be exported/imported to/from file.ext.
    Subsequent occurences of file.ext will be exported/imported to/from file.nnn.ext
    Where nnn is the afs object number for this entry.
	Example.
	if mdHt99ht.xpr is the Yodel bathing suit on Hitomi, and it's the first occurence in the file,
	and mdHt99ht.xpr is the Yodel bathing suit for the Manequin, and it's the second occurence in the file and it's object # 234
	The files will be exported (and imported) as mdHt99ht.xpr and mdHt99ht.234.xpr

-------------------------------------------------------------------
Version 1.0.0.4 Beta

All functionality of xprtune with new resizeable dialogs.
Ability to export and import SAME sized objects into afs file (single objects not directorys)
Find feature, right click on afs file and find dialog will do a case insensitive search of all EXPANDED objects.
If you have not exploded the xpr container, then it won't find yoda.xpr.
Descriptions
There is a file objects.txt that contains descriptions of objects. This file is a simple text file, and you can add or
edit to your hearts content. The format is simple NAME{space}description NAME is case sensitive, so if you add 
"yoda.xpr Yoda in Venus bathing suit"
And there is a file Yoda.xpr in the afs file, it won't find it.
You can xprtune an xpr file while it is inside an afs file.

	


*****************************************************************************************************************
Thanks to everyone who helped with xprtune, and everyone at ninjahacker.net for your support.
Special thanks to _mirage_ a great deal of my xpr and afs (almost all of it) code is based on his work.
If you have problems, you can usually find me on ninjahacker.net
