#FM77's 3D handling functions, version 1.0
#Created by FM77 of forums.ninjahacker.net in July 2004.

#This library is distributed under the terms of the Ruby license.
#See www.ruby-lang.org for details.


$nanaka3d_version = 1.2
$nanaka3d_description = "FM77's 3D handling functions, version 1.2"

#Version 1.0 - First version
#Version 1.1 - Added readxpr3 for DOA3 xprs. Since the only difference is in reading the
#                  object headers, this could and probably should be integrated into one function.
#                  But not today.
#Version 1.2 - Added apv morphtarget reading.


class Vertex
	#Some nice to_s functions and such should probably be here as well... but
	#again, we'll do it when we need it.

	def initialize(x=nil,y=nil,z=nil,u=nil,v=nil)
	#We may know all those when we make a new vertex.
	#But we probably won't.
	#We'll probably have all of xyz if we have one though, and probably both of uv if
	#we have either. And probably have xyz if we have uv.
	#So don't have to worry too much about initialization order.
	#There's some other properties sometimes attached to vertices, but we'll worry
	#about them when we need to.
		@x = x
		@y = y
		@z = z
		@u = u
		@v = v
	end
	
	attr_reader :x, :y, :z, :u, :v
	attr_writer  :x, :y, :z, :u, :v
	
	def to_s
		@x.to_s + ' ' + @y.to_s + ' ' + @z.to_s
	end
	
	def fullstring
		@x.to_s + ' ' + @y.to_s + ' ' + @z.to_s + ' ' +
			@u.to_s + ' ' + @v.to_s
	end
end

class Model
	
	def initialize(name=nil)
		@name = name
		#vertices = []
		#Initializing that way doesn't seem to work - have to do
		#objname.vertices = Array.new in the using function.
	end
	
	attr_reader :numvertices, :vertices, :name, :info
	attr_writer  :numvertices, :vertices, :name, :info
	
	#info is for information that is specific to a model from a particular
	#type of file. For instance, addressses within an xpr for a model that was
	#read from an xpr. If used, info will contain a class holding whatever
	#information is needed.

end

class XprInfo
	#This is for information on an object during the processing of an xpr.
	def initialize
		#Don't do anything.
	end
	
	attr_reader :vertextype, :numvertices, :voffset
	attr_writer  :vertextype, :numvertices, :voffset
	
	
end

class APVmorph
	def initialize
		#*whistles innocently*
	end
	
	attr_reader :numtargets, :meshnum, :numvertices, :indices, :vbufs, :indexadr, :vbufadrs
	attr_writer  :numtargets, :meshnum, :numvertices, :indices, :vbufs, :indexadr, :vbufadrs
end

def readapv(filename)
	incat = File.new(filename, File::RDONLY)
	incat.binmode
	incat.seek(12)
	apvstart = incat.read(4).unpack('V')[0]
	incat.seek(apvstart)
	if (incat.read(4) != "apv\000")
		raise "Bad cat file: apv magic not present"
	end
	morphs = []
	nummorphs = incat.read(4).unpack('V')[0]
	
	adrs = []
	for count in 0...nummorphs
		adrs << incat.read(4).unpack('V')[0]
	end
	
	for count in 0...nummorphs
		incat.seek(apvstart + adrs[count])
		cmorph = APVmorph.new
		cmorph.numtargets = incat.read(4).unpack('V')[0]
		cmorph.meshnum = incat.read(4).unpack('V')[0]
		cmorph.numvertices = incat.read(4).unpack('V')[0]
		incat.read(4)
		vlistadd = incat.read(4).unpack('V')[0]
		cmorph.indexadr = incat.read(4).unpack('V')[0] +
			apvstart
		
		cmorph.vbufadrs = Array.new
		incat.seek(vlistadd + apvstart)
		for count in 0...cmorph.numtargets
			cmorph.vbufadrs << incat.read(4).unpack('V')[0] +
				apvstart
			incat.read(4)
		end
		
		incat.seek(cmorph.indexadr)
		cmorph.indices = Array.new
		for count in 0...cmorph.numvertices
			cmorph.indices << incat.read(4).unpack('V')[0]
		end
		
		cmorph.vbufs = Array.new
		for count in 0...cmorph.numtargets
			cvbuf = []
			incat.seek(cmorph.vbufadrs[count])
			for count2 in 0...cmorph.numvertices
				x = incat.read(4).unpack('e')[0]
				y = incat.read(4).unpack('e')[0]
				z = incat.read(4).unpack('e')[0]
				cvbuf << Vertex.new(x,y,z)
			end
			cmorph.vbufs << cvbuf
		end
		
		morphs << cmorph
	end
	incat.close
	return morphs
end

def read3ds(filename)
	#As we start writing this, we're not yet certain what it will return...
	#Or what inputs it'll need. Other than a filename. Maybe just a filename?
	in3ds = File.new(filename, File::RDONLY)
	in3ds.binmode #Only important on intel systems...
	chunk = in3ds.read(2).unpack('v')[0]
	#Get used to that unpack syntax, you'll be seeing it a lot.
	if chunk != 0x4d4d
		#4d4d identifies a 3ds file. If it isn't there...
		raise "Bad 3ds file: Primary chunk mismatch"
	end
	#The next 4 bytes should contain the file size.
	pointer = in3ds.read(4).unpack('V')[0]
	#'v' for 2 bytes, 'V' for 4 bytes. At least when working with little-endian integers.
	if pointer != File.size(in3ds)
		raise "Bad 3ds file: Wrong file size"
	end
	#In files made by xpression (of the source I've seen), a chunk with the id 0x0002
	#is present. I don't know what it is, but it doesn't matter much. Of course, it's
	#not safe to assume it's there, with the way 3ds files work.
	#Right now, we need to get to the 0x3d3d chunk.
	flag = true
	while (flag)
		#So we'll just go through until we find it, and then make that false.
		#Probably not the most efficient way. But it's the way that will take the
		#least time for me to write.
		begin
		chunk = in3ds.read(2).unpack('v')[0]
		pointer = in3ds.read(4).unpack('V')[0]
		#puts chunk.to_s + " " + pointer.to_s
		if chunk == 0x3d3d
			#Here we are
			flag = false
			#If we need more than one subchunk of a particular chunk, we should
			#save the location when we find it, because chunks may not always be
			#in the same order. However, that's not the case here.
		else
			#There we aren't, so skip ahead.
			in3ds.seek(pointer - 6, IO::SEEK_CUR)
			# Need to subtract 6, since the size includes the chunk id and size.
			# 'pointer' is actually not a good name for it maybe...
		end
		rescue
			#Most likely cause of this is a corrupt 3ds. Though it's unlikely
			#one would get this far.
			raise "Error looking for 3d3d chunk: " + $!
		end
	end
	
	#Next up, find the 0x4000 chunk, which contains object data. Material data will
	#be before this most likely, but it doesn't matter for this application.
	flag = true
	while (flag)
		#Just c&ping code from before. Turning this into a function would probably
		#be possible, but wouldn't really save time or simplify things at this point.
		begin
		chunk = in3ds.read(2).unpack('v')[0]
		pointer = in3ds.read(4).unpack('V')[0]
		#puts chunk.to_s + " " + pointer.to_s
		if chunk == 0x4000
			#Here we are
			flag = false
		else
			in3ds.seek(pointer - 6, IO::SEEK_CUR)
		end
		rescue
			raise "Error looking for 4000 chunk: " + $!
		end
	end
	
	#Now that we've got to the 4000 chunk, we need to grab the object name from it...
	#... even if we probably won't do anything with it.
	objname = in3ds.gets([0x00].pack('C'))
	#That's a pretty ugly way to get a string containing 0x00, but it's the only one
	#I've found that works.
	#puts objname
	
	#It'll be surprising if we see anything but 4100 chunk next, which the docs I have
	#call "triangular polygon list". But we'll still do the same stuff again to be sure.
	flag = true
	while (flag)
		begin
		chunk = in3ds.read(2).unpack('v')[0]
		pointer = in3ds.read(4).unpack('V')[0]
		#puts chunk.to_s + " " + pointer.to_s
		if chunk == 0x4100
			#Here we are
			flag = false
		else
			in3ds.seek(pointer - 6, IO::SEEK_CUR)
		end
		rescue
			raise "Error looking for 4100 chunk: " + $!
		end
	end
	
	#Well, now we're at the beginning of chunk 4100, where the things we care about
	#are stored - chunk 4110, vertex list, and chunk 4140, mapping coordinates.
	#In practice, these will probably be stored in that order. In paranoia, we will code
	#with the possibility of them not being so in mind.
	
	flagv = true
	flagm = true
	chunkv = nil
	chunkm = nil
	while (flagv || flagm)
		begin
		chunk = in3ds.read(2).unpack('v')[0]
		pointer = in3ds.read(4).unpack('V')[0]
		#puts chunk.to_s + " " + pointer.to_s
		if chunk == 0x4110
			#Vertex list
			flagv = false
			chunkv = in3ds.pos
			#puts "Vertex list " + chunkv.to_s
		elsif chunk == 0x4140
			#Mapping coordinates
			flagm = false
			chunkm = in3ds.pos
			#puts "Mapping coordinates " + chunkm.to_s
		end
		
		if (flagm || flagv) != false
		#If either one is true...
			in3ds.seek(pointer - 6, IO::SEEK_CUR)
			#We need to keep looking.
		end
		rescue
			raise "Error looking for 4110 and 4140 chunks: " + $!
		end
	end

	#If we've made it here, we should know where everything we need is.
	#Of course, there's still another check to be made.
	in3ds.seek(chunkv)
	vlistsize = in3ds.read(2).unpack('v')[0]
	in3ds.seek(chunkm)
	mapsize = in3ds.read(2).unpack('v')[0]
	#puts vlistsize.to_s + ' ' + mapsize.to_s
	
	#If the number of vertices doesn't match the number of mapping coordinates...
	if vlistsize != mapsize
		#Then something's wrong.
		raise "Bad vertex count: " + vlistsize.to_s + ' ' 
			+ mapsize.to_s
	end
	
	#Well, since we're here, it did. So let's start putting together our model object.
	rmodel = Model.new(objname)
	rmodel.vertices = Array.new
	rmodel.numvertices = vlistsize
	
	in3ds.seek(chunkv + 2)
	
	for count in 0...vlistsize
		x = in3ds.read(4).unpack('e')[0]
		y = in3ds.read(4).unpack('e')[0]
		z = in3ds.read(4).unpack('e')[0]
		rmodel.vertices << Vertex.new(x,y,z)
	end
	
	in3ds.seek(chunkm + 2)
	
	for count in 0...vlistsize
		u = in3ds.read(4).unpack('e')[0]
		v = in3ds.read(4).unpack('e')[0]
		rmodel.vertices[count].u = u
		rmodel.vertices[count].v = v
	end
	
	#Name, size, vertex coordinates and map coordinates... I think that's all.
	
	in3ds.close
	return rmodel
end

def readxpr(filename)
	#This does much the same thing as read3ds. However, since an xpr file contains
	#multiple objects, this returns an array of Model objects.
	
	#Looking at the documents available to me, I'm not sure how to verify that
	#a file in fact *is* an xpr. So the error checking here won't be as good. But
	#trust me, if something goes wrong you'll be able to tell. ;)
	
	inxpr = File.new(filename, File::RDONLY)
	inxpr.binmode #Only important on intel systems.
	
	inxpr.read(8)
	voffset = inxpr.read(4).unpack('V')[0]
	inxpr.read(12)
	numobjs = inxpr.read(4).unpack('V')[0]
	#puts numobjs
	inxpr.read(12)
	
	objadrs = []
	for count in 0...numobjs
		objadrs << inxpr.read(4).unpack('V')[0]
	end
	#puts objadrs
	
	
	objinfos = []
	for count in 0...numobjs
		inxpr.seek(objadrs[count] + 4 )
		info = XprInfo.new
		info.vertextype = inxpr.read(4).unpack('V')[0]
		inxpr.read(24)
		info.numvertices = inxpr.read(4).unpack('V')[0]
		info.voffset = inxpr.read(4).unpack('V')[0]
		objinfos << info
	end
	
	#We know where the vertex buffers are, how many vertices they contain,
	#and how the data is structured... so let's put it in some models.
	
	rmodels = []
	for count in 0...numobjs
		smodel = Model.new
		smodel.vertices = Array.new
		smodel.info = objinfos[count]
		smodel.numvertices = objinfos[count].numvertices
		inxpr.seek(smodel.info.voffset)
		for count2 in 0...smodel.numvertices
			x = inxpr.read(4).unpack('e')[0]
			y = inxpr.read(4).unpack('e')[0]
			z = inxpr.read(4).unpack('e')[0]
			inxpr.read(4 * (smodel.info.vertextype + 3) )
			u = inxpr.read(4).unpack('e')[0]
			v = inxpr.read(4).unpack('e')[0]
			smodel.vertices << Vertex.new(x,y,z,u,v)
		end
		
		rmodels << smodel
	end

	inxpr.close
	return rmodels
end

def readxpr3(filename)
	#A modified version of readxpr for DOA3 xprs.
	#This is highly experimental.
	
	inxpr = File.new(filename, File::RDONLY)
	inxpr.binmode #Only important on intel systems.
	
	inxpr.read(8)
	voffset = inxpr.read(4).unpack('V')[0]
	#puts voffset
	inxpr.read(12)
	numobjs = inxpr.read(4).unpack('V')[0]
	#puts numobjs
	inxpr.read(12)
	
	objadrs = []
	for count in 0...numobjs
		objadrs << inxpr.read(4).unpack('V')[0]
	end
	#puts objadrs
	
	
	objinfos = []
	for count in 0...numobjs
		inxpr.seek(objadrs[count] + 4 )
		#Immediately after OBJ magic.
		info = XprInfo.new
		info.vertextype = inxpr.read(4).unpack('V')[0]
		#puts info.vertextype
		#DOA3 doesn't seem to use the same vertex structure...
		inxpr.read(8)
		#Vertexinfo structure should be here.
		info.numvertices = inxpr.read(4).unpack('V')[0]
		#This, as it turns out, *is* the correct number. It's just stupid
		#metasequoia droping vertices.
		info.voffset = inxpr.read(4).unpack('V')[0]
		objinfos << info
	end
	
	#We know where the vertex buffers are, how many vertices they contain,
	#and how the data is structured... so let's put it in some models.
	
	rmodels = []
	for count in 0...numobjs
		smodel = Model.new
		smodel.vertices = Array.new
		smodel.info = objinfos[count]
		smodel.numvertices = objinfos[count].numvertices
		inxpr.seek(smodel.info.voffset)
		for count2 in 0...smodel.numvertices
			x = inxpr.read(4).unpack('e')[0]
			y = inxpr.read(4).unpack('e')[0]
			z = inxpr.read(4).unpack('e')[0]
			inxpr.read(4 * (smodel.info.vertextype + 3) )
			u = inxpr.read(4).unpack('e')[0]
			v = inxpr.read(4).unpack('e')[0]
			smodel.vertices << Vertex.new(x,y,z,u,v)
		end
		
		rmodels << smodel
	end

	inxpr.close
	return rmodels
end