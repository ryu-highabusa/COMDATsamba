#CRIMP 2.01 - Combined Relative Importer
#Created by FM77 of forums.ninjahacker.net in July 2004.

#This program is distributed under the terms of the Ruby license.
#See www.ruby-lang.org for details.

#Version 1.0: First version. Supports xyzuv and uv only via seperate programs for DOAX.
#		CRIMP3 version 1.0 provides xyzuv insertation for *some* DOA3 meshes.
#Version 2.0: DOA3 and DOAX functionality combined into one program.
#		Command line options of various sorts added.
#		DOAX apv morphtarget support added.
#Version 2.01: Fixed upside-down texture problem. (Thanks to Keypel for pointing it out.)

require 'nanaka3d'
require 'getoptlong'

puts "CRIMP 2.01 - insert coordinates from 3ds files into xpr files"
puts "Created by FM77, based on the work of _mirage_, dony, and (many) others"
puts "DOAX morphtarget insertaion is supported."

if $nanaka3d_version < 1.2
	puts "Error: CRIMP requires version 1.2 or greater of nanaka3d.rb"
	exit
end

opts = GetoptLong.new(
#What kind of file do we have?
  [ "--doa3", GetoptLong::NO_ARGUMENT ],
  [ "--doax", GetoptLong::NO_ARGUMENT ],
#Is your input formatted unusually?
  [ "--scale",  GetoptLong::REQUIRED_ARGUMENT  ],
  [ "--axis", GetoptLong::REQUIRED_ARGUMENT ],
#Anyone want some of my strange optional processing?
  [ "--trim", GetoptLong::NO_ARGUMENT ],
#What do you want from me?
  [ "--noxyz", GetoptLong::NO_ARGUMENT ],
  [ "--nouv", GetoptLong::NO_ARGUMENT ],
  [ "--nomorph", GetoptLong::NO_ARGUMENT ],
#Know how you want your morphtargets done?
  [ "--morphtype", GetoptLong::REQUIRED_ARGUMENT ],
#Got a weird suit like condor skirt?
#I have no idea how to process these, so here's some messy overrides to make them work.
  [ "--forceapv", GetoptLong::REQUIRED_ARGUMENT ]
)

#opts.each do |opt, arg|
#  puts "Option: #{opt}, arg #{arg.inspect}"
#end
#puts "Remaining args: #{ARGV.join(', ')}"

options = []
arguments = []

opts.each do |opt, arg|
	options << opt
	arguments << arg
end

doax, doa3, trim = false, false, false
#Trim defaults false.
xyz, uv, morph = true, true, true
#These default to on.
scale = 100.0
#The default scaling factor for xpression-produced files.
axis = nil
#Unless told otherwise, no need to mess with that.
morphtype = nil
forceapv = nil

warn = false

if options.index("--doax")
#If the option wasn't set, the value of that will be nil, and false. If it was set, it will
#be a number. It doesn't matter what the number is for this purpose.
	doax = true
end

if options.index("--doa3")
	doa3 = true
end

if (doa3 && doax)
#Can't be both of them!
	puts "Error: Can't be both a DOAX and a DOA3 file!"
	exit
end

if !(doa3 || doax)
#I have an idea on how to do auto detection, but I don't feel like implementing it today.
	puts "Error: You must specifiy either DOAX or DOA3 processing."
	exit
end

if options.index("--axis")
	puts "Axis alteration function not yet available."
	exit
end

if options.index("--trim")
	#trim = true
	puts "Trim function not yet available."
	exit
end

if options.index("--scale")
	scale = arguments[options.index("--scale")].to_f
end

if options.index("--noxyz")
	xyz = false
end

if options.index("--nouv")
	uv = false
end

if options.index("--nomorph")
	morph = false
end

if options.index("--morphtype")
	morphtype = arguments[options.index("--morphtype")].to_i
end

if options.index("--forceapv")
	forceapv = arguments[options.index("--forceapv")].to_i
end

if !(xyz || uv || morph)
#What, you want me to do nothing?
	puts "Error: All processing options disabled."
	exit
end

if ARGV.size > 2
	#Then there's some unrecognized arguments in there, and who knows what the
	#rest of it is.
	puts "Error: Unrecognized arguments."
	exit
elsif ARGV.size < 2
	#Then we don't have the filenames we need.
	puts "Error: Not enough arguments."
	exit
end

#instream = IO.new($stdin.fileno, 'r')
#This seems to be needed to get around a strange error.
#... Or at least, it *works* to get around the strange error.
#Actually, something else should work too.

xprname = ARGV[0]
sourcename = ARGV[1]
#Theoretically it could be set up so they don't have to be in order, but I'm not going to
#mess with that today.

meshnum = nil

m3ds = read3ds(sourcename)
if doax
	msxpr = readxpr(xprname)
elsif doa3
	msxpr = readxpr3(xprname)
	morph = false
	#Since doa3 doesn't have apv blocks, don't even try doing them.
else
	puts "Error?! Getting to this line of code should be impossible!"
	exit
end

m3verts = m3ds.numvertices

mxverts = msxpr.collect { |mx| mx.numvertices }

if mxverts.index(m3verts) == nil
	#If there isn't a mesh in the xpr with the same number of vertices as the
	#one in the 3ds file...
	puts "Error: xpr contains no matching objects - wrong 3ds file?"
	exit
elsif mxverts.index(m3verts) != mxverts.rindex(m3verts)
	#If there are two meshes in the xpr file with the same number of vertices as
	#the one in the 3ds file...
	puts "Error: xpr contains multiple matching objects"
	#I don't expect this to happen. If there *are* suits that have two meshs with the
	#same number of vertices, I can work something out then.
	#And now I'm working something out for them. This is, as it turns out, a big issue
	#in DOA3.
	puts "Please enter the mesh number for this file:"
	inline = STDIN.gets.chomp
	mnum = inline.to_i
	if (mnum >= msxpr.size || mnum < 0)
	#If the number entered is greater than the number of meshes in the xpr...
	#... Or if it's negative!
		puts "Mesh number entered is invalid."
		exit
	elsif mxverts[mnum] != m3verts
		puts "Vertex count doesn't match."
		exit
	else
		mxpr = msxpr[mnum]
		meshnum = mnum
	end
else
	meshnum = mxverts.index(m3verts)
	mxpr = msxpr[meshnum]
end

#Well, we have the model we're going to write to, and the file we're getting the data from.
#In this version, we'll be preprocessing data.

#if xyz
#No need to do anything if we're not inserting xyz.
#... Or so we thought. However, not having the scaling applied will cause problems in
#morphtarget equation processing.
	for count in 0...m3verts
		m3ds.vertices[count].x = m3ds.vertices[count].x / scale
		m3ds.vertices[count].y = m3ds.vertices[count].y / scale
		m3ds.vertices[count].z = m3ds.vertices[count].z / scale
	end
#end

if uv
	for count in 0...m3verts
		m3ds.vertices[count].v = 1 - m3ds.vertices[count].v
		#u is just fine as it is.
	end
end

catname = nil
apvnum = nil
morphdata = nil
#Assuming there is a morphtarget to modify, that's where the data for it will end up.
if morph
	#Do any preparation for morphtarget insertation here.
	catname = xprname[0...-3] + 'cat'
	if !File.exists?(catname)
		puts "Cat file '" + catname + "' not found. Unable to process morphtargets."
		warn = true
	else
		#Okay, load the cat file.
		catdata = readapv(catname)
		
		#So, is there a morphtarget associated with the mesh we're working on?

		for count in 0...catdata.size
			if catdata[count].meshnum == meshnum
				apvnum = count
			end
		end
		
		if forceapv
			#If there's something in forceapv, ignore what that block above gave,
			#and just work with that apv.
			apvnum = forceapv
		end
		
		if !apvnum
			#If apvnum is still nil, there is no morphtarget for this mesh.
			morph = false
		else
			#Well, what shall we do with the morphbuffer?
			if morphtype
				#Well, I don't think we actually need to do anything on this logic branch.
			else			
				puts "CAT file contains apv morphtargets for mesh " + meshnum.to_s
				puts "Select a processing option:"
				#Here's where there'll be a list of options.
				puts "0. Cancel morphtarget insertation."
				puts "1. Load morphtarget data from files."
				puts "2. Set all morphtargets to mesh coordinates."
				puts "3. Set morphtargets relative to mesh modifications."
				puts "4. Set morphtargets according to an equation file."
				morphtype = STDIN.gets[0,1].to_i
				if (morphtype < 0 || morphtype > 4)
					puts "Invalid option."
					exit
				end
			end
			
			equations = []
			catmesh = catdata[apvnum]
			#That's what we'll do with the morphbuffer.
			if morphtype == 0
				morph = false
				puts "Morphtarget insertation canceled."
				warn = true
			elsif morphtype == 1
				#Get morphtarget data from files.
				#... But which files?
				#Well, for now you're stuck with the filenames from morph xpression.
				if meshnum > 9
					meshnumstring = meshnum.to_s
				else
					meshnumstring = (meshnum + 100).to_s[1,2]
				end
				#Doing a leftjustify and substitution would probably be more efficient, but the process makes me nervous.
				#Even if I do have to repeat that code 3 times.
				if apvnum > 9
					apvnumstring = apvnum.to_s
				else
					apvnumstring = (apvnum + 100).to_s[1,2]
				end
				basename = xprname[0...-4] + '_morphvbuf' + meshnumstring + '_morphtarget'
				
				for count in 0...catmesh.numtargets
					if count > 9
						targnumstring = count.to_s
					else
						targnumstring = (count + 100).to_s[1,2]
					end
					mofilename = basename + targnumstring + '_' + apvnumstring + '.3ds'
					if  !File.exists?(mofilename)
						puts "Morphtarget source file " + mofilename + " not found."
						warn = true
					end
					#Well, this should be simple, right? Take the coordinates from the 3ds file, stuff them into catmesh.
					#Long as you don't forget to apply the scale it'll be easy anyway.
					mo3ds = read3ds(mofilename)
					for count2 in 0...catmesh.indices.size
						catmesh.vbufs[count][count2].x = mo3ds.vertices[catmesh.indices[count2] / (4 * (8 + mxpr.info.vertextype))].x / scale
						catmesh.vbufs[count][count2].y = mo3ds.vertices[catmesh.indices[count2] / (4 * (8 + mxpr.info.vertextype))].y / scale
						catmesh.vbufs[count][count2].z = mo3ds.vertices[catmesh.indices[count2] / (4 * (8 + mxpr.info.vertextype))].z / scale
						#There ought to be an easier way to do that... I'll probably come up with it a day after releasing this.
						
					end
					puts catmesh.vbufs[count][30]
				end
				
			elsif morphtype == 2
				#Set morphtargets the same as the inserted mesh.
				equations = [["newx", "newy", "newz"]]
			elsif morphtype == 3
				#Set morphtargets relative to mesh.
				equations = [["newx + morphx - oldx", "newy + morphy - oldy", "newz + morphz - oldz"]]
			elsif morphtype == 4
				#Set morphtargets from an equation file.
				equname = xprname[0...-3] + 'equ'
				if !File.exists?(equname)
					puts "Cat file '" + catname + "' not found."
					warn = true
				else
					equfile = File.new(equname)
					for count in 0...catmesh.numtargets
						equations << [equfile.gets, equfile.gets, equfile.gets]
					end
					equfile.close
					#I think that's all that's needed now.
				end
			else
				puts "?! Getting here shouldn't be possible."
				exit
			end #End first stage of morphtype processing.
				#For morphtype 1 (from files, it ends here.
				#Since we've figured out how to reduce code by using the
				#equation function to handle some possibilities, there's going to be
				#a second stage invoked for some options...
			
			if (morphtype > 1 && morphtype < 5)
				#Equation processing.
				for count in 0...catmesh.numtargets
					cequ = equations[count]
					if !cequ
						cequ = equations[0]
					end
					#puts cequ
					for count2 in 0...catmesh.numvertices
						vertexnumber = catmesh.indices[count2] / (4 * (8 + mxpr.info.vertextype))
						newx = m3ds.vertices[vertexnumber].x
						newy = m3ds.vertices[vertexnumber].y
						newz = m3ds.vertices[vertexnumber].z
						#new_ = Value being inserted from 3ds.
						oldx = mxpr.vertices[vertexnumber].x
						oldy = mxpr.vertices[vertexnumber].y
						oldz = mxpr.vertices[vertexnumber].z
						#old_ = Value in xpr file before insertation.
						morphx = catmesh.vbufs[count][count2].x
						morphy = catmesh.vbufs[count][count2].y
						morphz = catmesh.vbufs[count][count2].z
						#morph_ = Original value stored in the morphtarget.
						
						#Now, what will we do with all those numbers?
						#Whatever the equations say to do!
						equx = eval(cequ[0])
						equy = eval(cequ[1])
						equz = eval(cequ[2])
						catmesh.vbufs[count][count2].x = equx
						catmesh.vbufs[count][count2].y = equy
						catmesh.vbufs[count][count2].z = equz
					end #End for numvertices
				end #End for numtargets
				
			end #End equation processing.
			
			morphdata = catmesh
		end #end if !apvnum
	end
end








#Now it's time to insert our coordinates!
outxpr = File.new(xprname, File::WRONLY)
outxpr.binmode #Only important on intel systems.

if xyz
	for count in 0...m3verts
		outxpr.seek(mxpr.info.voffset + (4 * count * (8 +
			mxpr.info.vertextype)))
		outxpr.write([m3ds.vertices[count].x].pack('e'))
		outxpr.write([m3ds.vertices[count].y].pack('e'))
		outxpr.write([m3ds.vertices[count].z].pack('e'))
	end
	puts "xyz coordinate insertation completed."
end

if uv
	for count in 0...m3verts
		outxpr.seek(mxpr.info.voffset + 4 * (count + 1) * (8 +
			mxpr.info.vertextype) - 8)
		outxpr.write([m3ds.vertices[count].u].pack('e'))
		outxpr.write([m3ds.vertices[count].v].pack('e'))
	end
	puts "uv coordinate insertation completed."
end

outxpr.close

if morph
	#This is the tricky one.
	outcat = File.new(catname, File::WRONLY)
	outcat.binmode
	for count in 0...morphdata.numtargets
		#Step through each morphtarget in the apv block.
		outcat.seek(morphdata.vbufadrs[count])
		#Go to the beginning of the data for that target.
		#Doing this individually for each one might not be necessary, but it won't hurt anything either.
		for count2 in 0...morphdata.numvertices
			catx = morphdata.vbufs[count][count2].x
			caty = morphdata.vbufs[count][count2].y
			catz = morphdata.vbufs[count][count2].z
			outcat.write([catx].pack('e'))
			outcat.write([caty].pack('e'))
			outcat.write([catz].pack('e'))
			#Since there isn't any interim data in the morphbuffers, we don't need
			#to do any seeks here.
		end
	end
	outcat.close
	puts "morphtarget insertation completed."
end
#Huh. Maybe it wasn't so tricky.