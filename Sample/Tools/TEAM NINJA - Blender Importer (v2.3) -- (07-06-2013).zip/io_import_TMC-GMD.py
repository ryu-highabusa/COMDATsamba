#blender 2.67 import script(version 2.3) for dead or alive 5 tmc/tm and ninja gaiden 3 gmd

bl_info = {
    "name": "TMC format",
    "author": "xentax fan",
    "location": "File > Import > Import TMC (.tmc)",
    "description": "tmc import.(vertex buffers)",
    "category": "Import-Export"}


from bpy_extras.io_utils import ExportHelper, ImportHelper
from bpy_extras.io_utils import unpack_list, unpack_face_list
from bpy.props import *
#----------------------------------------------------------
import bpy
import struct, os, io
from time import time
from mathutils import Vector, Matrix

def import_tmc(importoptions):
    starttime = time()
    import_now(importoptions)
    endtime = time()
    print("end() executed in %d seconds"%(endtime - starttime))
    for m in myset:
        print("%x"%m)

myset = []#for debugging purposes

def import_now(importoptions):
    filename, load_textures, sew_submeshes, xray_bones, custom_outfit, create_skeleton, remove_shit, merge_armatures = importoptions
    make_smooth = True
    istmc = True if filename[-3:].upper() != "GMD" else False
    #unnecessary blender scene fix
    if 'Cube' in bpy.data.scenes[0].objects:
        bpy.data.scenes[0].objects.unlink(bpy.data.objects['Cube'])
    if bpy.data.lamps:
        bpy.data.lamps[0].type = 'SUN'
    #important stuff bellow

    #HEADER: x0_name[8], x14_counter, x18_counter2, x20_offset, x24_offset2, x28_offset3
    for i in range(1):
        with open(filename, 'rb') as f:
            #set the file for the 'fread' function
            global fglb
            fglb["file"] = f

            if fread(0xf0 + 4 * 6) != 0x80000010: continue# skip ALPHA152_COS_001_A.TMC which has 6EdGemLy
            tmcoffs = fread(fread(0x20), "%dL"%fread(0x14))#0MdlGeo,1TTX,2VtxLay,3IdxLay,4MtrCol,5MdlInfo, ! 6HieLay,7LHeader,8NodeLay,9GlblMtx,10BnOfsMtx, !! 11cpf,12MCAPACK,13RENPACK
            tmcname = freadstring(0x50)
           #for 7LHeader read only offsets without sizes
            tmcloffs = fread(tmcoffs[7] + fread(tmcoffs[7] + 0x20), "3L")#0TTX,1VtxLay,2IdxLay
            vtxoffs = fread(tmcoffs[2] + fread(tmcoffs[2] + 0x20), "%dL"%fread(tmcoffs[2] + 0x14), False)
            idxoffs = fread(tmcoffs[3] + fread(tmcoffs[3] + 0x20), "%dL"%fread(tmcoffs[3] + 0x14), False)
           #material colors
            MtrCols = []
            MtrCollinks = {}#(obj,mat):color
            MtrColbase = tmcoffs[4]
            MtrColoffs =   fread(MtrColbase + fread(MtrColbase + 0x20), "%dL"%fread(MtrColbase + 0x14), False)
            for offs in MtrColoffs:
                ambient = fread(MtrColbase + offs,'4f')
                diffuse = fread('4f')
                specular = fread('4f')
                emissive = fread('4f')
                #more variables to parse here
                mtrindex, linkcount = fread(MtrColbase + offs + 0xD0, '2L')
                for i in range(linkcount):#define object material users for this colors
                    objindex, subobjnum_seq = fread("2L")
                MtrCols.append((ambient, diffuse, specular, emissive))
            #armature

#+++++++++++++++

            #parse HieLay
            maxbonelevel = 0
            HieLaybase = tmcoffs[6]
            HieLayoffs = fread(HieLaybase + fread(HieLaybase + 0x20), "%dL"%fread(HieLaybase + 0x14), False)
            HieLays = []
            for offs in HieLayoffs:
                f.seek(HieLaybase + offs)
                hmatrix = Matrix([fread("4f") for i in range(4)]).transposed()
                parent, bone_chlidren_count, bonelevel, bone_ukn02 = fread(HieLaybase + offs + 16*4, "4L")
                bchildren = fread(HieLaybase + offs + 16*4 + 4*4, "%dL"%bone_chlidren_count, False)
                HieLays.append((parent, bchildren, bonelevel, hmatrix))
                if bonelevel > maxbonelevel: maxbonelevel = bonelevel

            #parse GlblMtx
            GlblMtxbase = tmcoffs[9]
            GlblMtxoffs =   fread(GlblMtxbase + fread(GlblMtxbase + 0x20), "%dL"%fread(GlblMtxbase + 0x14), False)
            GlblMtxs = []
            for offs in GlblMtxoffs:
                f.seek(GlblMtxbase + offs)
                gmatrix = Matrix([fread("4f") for i in range(4)]).transposed()
                GlblMtxs.append(gmatrix)

##            #parse BnOfsMtx
##            BnOfsMtxbase = tmcoffs[10]
##            BnOfsMtxoffs =   fread(BnOfsMtxbase + fread(BnOfsMtxbase + 0x20), "%dL"%fread(BnOfsMtxbase + 0x14), False)
##            BnOfsMtxs = []
##            for offidx, offs in enumerate(BnOfsMtxoffs):
##                f.seek(BnOfsMtxbase + offs)
##                bmatrix = Matrix([fread("4f") for i in range(4)]).transposed()
##                BnOfsMtxs.append(bmatrix)


            #parse NodeLay
            NodeLays = []
            NodeLays_meshnodes = {}
            NodeLaybase = tmcoffs[8]
            NodeLayoffs =  fread(NodeLaybase + fread(NodeLaybase + 0x20), "%dL"%fread(NodeLaybase + 0x14), False)
            for offidx ,offs in enumerate(NodeLayoffs):
                nodebase = NodeLaybase + offs
                unk0_0, somenum, index, unk0_1 = fread(nodebase + 0x30, "4L")
                nodename = freadstring(nodebase + 0x40)

                mtxdataoffs = fread(nodebase + fread(nodebase + 0x20), "%dL"%fread(nodebase + 0x14), False)
                #add hielay data
                parent, bchildren, bonelevel, hmatrix = HieLays[index]
                gmatrix = GlblMtxs[index]
                #end adding
                for mtxoffs in mtxdataoffs:
                    objectindex, childrennum, nodeindex, unk00 = fread(nodebase + mtxoffs, "4L")
                    f.seek(nodebase + mtxoffs + 4*4)
                    nmatrix = Matrix([fread("4f") for i in range(4)]).transposed()
                    bonegroups = fread(nodebase + mtxoffs + 4*4 + 16*4, "%dL"%childrennum, False)
                    NodeLays_meshnodes[objectindex] = (nodename, gmatrix, bonegroups)#(offidx, hmatrix, nmatrix, bonegroups))
                NodeLays.append(nodename)

                #create bones
            if create_skeleton:
                if bpy.context.scene.objects.active:
                    if bpy.context.scene.objects.active.mode != 'OBJECT':
                        bpy.ops.object.mode_set(mode='OBJECT')
                        bpy.ops.object.select_all(action = 'DESELECT')#deselect everything
                name = tmcname
                origin = (0,0,0)
                bpy.ops.object.add(type='ARMATURE', enter_editmode=True, location=origin)
                ob = bpy.context.object
                ob.name = name+'Amt'
                if xray_bones:
                    ob.show_x_ray = True
                amt = ob.data
                amt.name = name+'Amt'
                amt.draw_type = 'STICK'#'OCTAHEDRAL', `STICK', `BBONE', `ENVELOPE', `WIRE'
                # Create bones
                bpy.ops.object.mode_set(mode='EDIT')


                for i in range(maxbonelevel+1):
                    for hidx, (parentidx, bchildren, bonelevel, hmatrix) in enumerate(HieLays):
                        if bonelevel == i:
                            gmatrix = GlblMtxs[hidx]
                            loc = gmatrix.decompose()[0]
                            bonename = NodeLays[hidx]
                            bone = amt.edit_bones.new(bonename)
                            bone.transform(gmatrix)
                            if i != 0:
                                if NodeLays[parentidx] in amt.edit_bones:#fix island2
                                    parent = amt.edit_bones[NodeLays[parentidx]]
                                    bone.parent = parent
                                    if len(HieLays[parentidx][1]) == 1:
                                        bone.use_connect = True
                                    if bone.head == parent.tail:
                                        bone.use_connect = True
                            if len(bchildren) == 1:
                                childhead = GlblMtxs[bchildren[0]].decompose()[0]
                                bone.tail = childhead# + bone.head
                            elif len(bchildren) > 1:
                                if "MOT" in bonename:#find mot children
                                    motos = []
                                    for chidx in bchildren:
                                        if "MOT" in NodeLays[chidx]:
                                            motos.append(GlblMtxs[chidx].decompose()[0])
                                    if len(motos) == 1:
                                        bone.tail = motos[0]
                                    elif istmc and len(motos) == 3:
                                        if i == 0:
                                            bone.tail = motos[2]
                                        elif i == 2:
                                            bone.tail = motos[0]
                                        else:
                                            bone.tail = Vector((0,0,0.005)) + bone.head
                                    else:
                                        bone.tail = Vector((0,0,0.005)) + bone.head
                                else:
                                    bone.tail = Vector((0,0,0.005)) + bone.head
                            else:#len is 0
                                if bone.parent:
                                    if len(HieLays[parentidx][1]) == 1:
                                        bone.tail = bone.parent.tail - bone.parent.head + bone.head#need to make it fixed size
                                    else:
                                        bone.tail = Vector((0,0,0.005)) + bone.head
                                else:
                                    bone.tail = Vector((0,0,0.005)) + bone.head
                            if bone.head == bone.tail:#this hapens and blender removes bones with lenght = 0
                                bone.tail += Vector((0,0,0.005))


##                #set the recorded pose
##                bpy.ops.object.mode_set(mode='POSE')
##                for i in range(maxbonelevel+1):
##                    for hidx, (parentidx, bchildren, bonelevel, hmatrix) in enumerate(HieLays):
##                        if bonelevel == i:
####                            bmatrix = BnOfsMtxs[hidx]
####                            gmatrix = GlblMtxs[hidx]
##
##                            bonename = NodeLays[hidx]
##                            pbone = ob.pose.bones[bonename]
##                            pbone.matrix_basis = hmatrix

##            bpy.context.scene.update()

                bpy.ops.object.mode_set(mode='OBJECT')


#---------------

            #open l file for ttx and mdlgeo
            minpos = 0
            maxpos = 0
            if istmc:
                lfilename = filename + "L"
            else:
                lfilename = filename[:-3] + "TTGL"
            with open(lfilename, 'rb') as fl:
                #parse 1TTX
                ttxbase = tmcoffs[1]
                if load_textures and fread(ttxbase + 0x18) == 1:#ttxbase + 0x18 = has xpr2 inside
                    xprinfos = []
                    xprbase = ttxbase + fread(ttxbase + fread(ttxbase + 0x20)) + 0xC#-0xC = magic, size, datasize

                    tempttx = parsetextures(fl, 0x1000, xprbase)
                    #load customized tex files here
                    if custom_outfit and istmc:
                        texfilename = filename[:-4] + "_00%d.--H"%custom_outfit
                        if not os.path.isfile(texfilename):
                            print(texfilename, "ALTERNATE UNDERWEAR NOT FOUND")
                        else:
                            print(texfilename, "custom underwear:")
                            texf = open(texfilename, 'rb')
                            texfl = open(texfilename+'L', 'rb')
                            #set fread context to texf
                            holdmybeer = fglb['file']
                            fglb['file'] = texf
                            parsetextures(texfl, 0, fread(fread(0x20) + 8))#no need to track, just replace low res
                            fglb['file'] = holdmybeer
                            texf.close()
                            texfl.close()
                    #end of customized tex

                    textures = []
                    for texname, tempimgpath, usealpha in tempttx:
                        img = bpy.data.images.load(tempimgpath)
                        img.use_alpha = usealpha
                        img.pack()#testhide for speed
                        tex = bpy.data.textures.new(texname.rstrip(".dds"), type = 'IMAGE')
                        tex.image = img
                        textures.append(tex)
                        os.remove(tempimgpath)#testhide for speed


                #parse 0MdlGeo
                mdlbase = tmcoffs[0]
                objs = []
                objoffs = fread(mdlbase + fread(mdlbase + 0x20), "%dL"%fread(mdlbase + 0x14), False)
                for objidx, objoffset in enumerate(objoffs):#parse ObjGeo (always has an offset to GeoDecl at 0x28)
                    objbase = mdlbase + objoffset
                    declbase = objbase + fread(objbase + 0x28)
                    objname = fread(objbase + 0x50, "16s").decode("ASCII").rstrip("\0")
                    if objidx in NodeLays_meshnodes:
                        objname = NodeLays_meshnodes[objidx][0]#battlefield key error 16 ???
                    print("#", objname)

                    matoffs = fread(objbase + fread(objbase + 0x20), "%dL"%fread(objbase + 0x14), False)
                    decloffs = fread(declbase + fread(declbase + 0x20), "%dL"%fread(declbase + 0x14), False)
                    decls = []
                    for decloffset in decloffs:#parse decls
                        subdeclbase = declbase + decloffset
                        BUFindex, IDXcount, VERTcount = fread(subdeclbase + 0xC, "3L")
                        vsize, vdatalayerscount = fread(subdeclbase + 0x34, "2L")
                        vdatalayers = [fread(subdeclbase + 0x40 + i*0xC, "2LH2B") for i in range(vdatalayerscount)]#vdatalayers[2]#(0,1,10000,20000,30000,50000,50100,50200,60000,a0000)
                        decls.append([BUFindex,vsize,vdatalayers, IDXcount, VERTcount])
                    mat_opac = []
                    mat_tran = []
                    declmats = [[] for i in range(len(decls))]
                    for matoffset in matoffs:#parse materials
                        matbase = objbase + matoffset
                        matindex, mtrcolindex, null, matTexCount = fread(matbase, "4L")
                        declfvfindex = fread(matbase + 0x38)
                        transparentmat = fread(matbase + 0x40)
                        IDXstart, IDXcount, VERTstart, VERTcount = fread(matbase + 0x70, "4L")
                        texbase = matbase + 0xD0 #textures info in mat

                        txrs = []
                        for texinfo in range(matTexCount):#parse material textueres
                            texSlot, texmaptype, texId = fread(texbase + texinfo * 0x70, "3L")#slot(0) = 0, slot(1,2) = 0,1,2,3, slot(3) = 1,2,3, slot(4) = 2,3
                            txrs.append((texSlot, texmaptype, texId))

                        declmats[declfvfindex].append((matindex, mtrcolindex, transparentmat, IDXstart, IDXcount, txrs))

                    #gather tmcl raw data
                    for enumdecl, (BUFindex,vsize,vdatalayers, IDXcount, VERTcount) in enumerate(decls):

                        faces = []
##                        indices = []
                        verts = []

                        blendweights = []
                        blendindicies = []
                        normals = []
                        uvLists = []
                        tangents = []
                        colors = []
                        if objname in bpy.data.meshes:
                            meshName = objname + "_" + str(enumdecl)
                        else:
                            meshName = objname

                        VBUFbase = tmcloffs[1] + vtxoffs[BUFindex]

                       #switch to lfile for "fread"(save initial file handle to restore later)
                        holdmybeer = fglb["file"]
                        fglb["file"] = fl

                        #read indicies
                        indices = fread(tmcloffs[2] + idxoffs[BUFindex], "%dH"%IDXcount)#H - usigned short

                        #read vertices
                        for i in range(VERTcount):
                            uvs = []
                            for vdatalayeroffset, vd3dtype, vusage, vusagelayer, padding  in vdatalayers:#vusage has usage enum and usage index packed
                                vals = freadd3dtype(vd3dtype, VBUFbase + (i * vsize) + vdatalayeroffset)
                                if vusage == 0x0:
                                    x,y,z = vals[:3]
                                    verts.append((x,y,z))#ignore forth 'w' value if exist
                                elif vusage == 0x1: blendweights.append(vals)#careful here: can have 2 or 3 or 4 floats
                                elif vusage == 0x2: blendindicies.append(vals)
                                elif vusage == 0x3: normals.append(vals[:3])#ignore forth 'w' value if exist
                                elif vusage == 0x5: # usagelayers 0,1,2
                                    for i in range(0, len(vals)-1, 2):
                                        uvs.append((vals[i], 1-vals[i+1]))#uv/uv2
                                elif vusage == 0x6: tangents.append(vals)
                                elif vusage == 0xa: colors.append(vals)#?colored vertices?
                            uvLists.append(uvs)

                       #revert initial file handle
                        fglb["file"] = holdmybeer

                        #make faces
                        matfaces = []
                        for enumm, mtr in enumerate(declmats[enumdecl]):
                            IDXstart = mtr[3]
                            IDXcount = mtr[4]

                            clockwise = True
                            for i in range(IDXstart, IDXstart+IDXcount-2):
                                if 0xffff in indices[i:i+3]:
                                    clockwise = True
                                    continue
                                if len(indices[i:i+3]) != len(set(indices[i:i+3])):
                                    clockwise = not clockwise
                                    continue
                                if clockwise:
                                    faces.append((indices[i:i+3]))
                                else:
                                    faces.append((indices[i], indices[i+2], indices[i+1]))
                                clockwise = not clockwise
                                matfaces.append(enumm)

                        #start assembling a blender mesh
                        me = bpy.data.meshes.new(meshName)# # # #
                        me.vertices.add(len(verts))
                        me.vertices.foreach_set("co", unpack_list(verts))
                        me.vertices.foreach_set("normal", unpack_list(normals))
                        me.tessfaces.add(len(faces))
                        me.tessfaces.foreach_set("vertices_raw", unpack_face_list(faces))
                        #append all uv layers
                        uvLists = [[row[i] for row in uvLists] for i in range(len(uvLists[0]))]#uvlists rows to collumns
                        for enum, uvList in enumerate(uvLists):
                            uvLayer = me.tessface_uv_textures.new('UV%d'%enum)
                            for faceIndex, face in enumerate(faces):
                                faceUV = uvLayer.data[faceIndex]
                                faceUV.uv1 = uvList[face[0]]
                                faceUV.uv2 = uvList[face[1]]
                                faceUV.uv3 = uvList[face[2]]


                        scn = bpy.context.scene
                        ob = bpy.data.objects.new(meshName, me)
                        scn.objects.link(ob)
                        scn.objects.active = ob

                        #create materials
                        for matindex, mtrcolindex, transparentmat, IDXstart, IDXcount, txrs in declmats[enumdecl]:
                            matname = objname + "_" + str(matindex)
                            mat = bpy.data.materials.new(matname)
                            mat.use_transparent_shadows = True
                            #assign mtrcolors
                            ambient, diffuse, specular, emissive = MtrCols[mtrcolindex]
                            mat.diffuse_color = specular[0:3]# should be diffuse[0:3]
##                            mat.mirror_color = ambient[0:3]
##                            mat.ambient = ambient[3]
                            mat.specular_color = specular[0:3]#no skin shine with this

##                            if True:#not shure about that; set specular power to 0 even if material doesn't have a specular map
##                                mat.specular_intensity = specular[3]#0.0
                            if transparentmat:
                                mat.alpha = 0
                                mat.use_transparency = True


                            #load textures and attach to uvlayers
                            if load_textures:
                                for texSlot, texmaptype, texId in txrs:
                                    if texId == 0xFFFFFFFF: continue #just skip the -1 texture
                                    mtex = mat.texture_slots.add()
                                    tex = textures[texId]
                                    mtex.texture = tex
                                    mtex.texture_coords = 'UV'
##                                    mtex.uv_layer = 'UV%d'%texSlot #can be more different uvs, but it's not selected that way
                                    #todo set up the map properties
                                    if texmaptype == 0:
                                        if texSlot == 0:
    ##                                    if True:
                                            if tex.image.use_alpha:
                                                if not transparentmat: #this is incorrect - and used to surpass the 2.67 limit of texture transparecy
                                                    pass
                                                    mtex1 = mat.texture_slots.add()
                                                    if (textures[texId].name + '.diffuse') not in bpy.data.textures:
                                                        imgdiff = tex.image.copy()
                                                        imgdiff.use_alpha = False
                                                        texname = textures[texId].name
                                                        texdiff = bpy.data.textures.new(texname.rstrip(".dds") + '.diffuse', type = 'IMAGE')
                                                        texdiff.image = imgdiff

                                                    tex1 = bpy.data.textures[textures[texId].name + '.diffuse']
                                                    mtex1.texture = mtex.texture
                                                    mtex1.texture_coords = 'UV'

                                                    mtex1.use_map_color_diffuse = False
                                                    mtex1.use_map_specular = True
                                                    mtex.texture = tex1
                                                    mat.specular_intensity = 0.0
                                                else:
                                                    mtex.use_map_alpha = True
    ##                                                mat.alpha = 0
    ##                                                mat.use_transparency = True
                                        else:
                                            mtex.use_map_color_diffuse = False
    ##                                        if tex.image.use_alpha == False and mat.specular_intensity != 0.0:
    ##                                            mtex.use_map_color_diffuse = False
    ##                                            mtex.use_map_specular = True
    ##                                            mat.specular_intensity = 0.0
                                    elif texmaptype == 1:
                                        mtex.use_map_color_diffuse = False
                                        mtex.use_map_normal = True
                                        mtex.normal_factor = 0.04
                                    elif texmaptype == 2:
                                        mtex.use_map_color_diffuse = False
    ##                                    texname = mat.texture_slots[0].name
                                        if not transparentmat:
                                            pass
                                        else:
    ##                                    if True:
                                            mtex.use_map_color_spec = True
                                    elif texmaptype == 3:
                                        mtex.use_map_color_diffuse = False
        ##                                if mat.specular_intensity != 0.0:
        ##                                    mat.specular_intensity = 0.0
        ##                                    mtex.use_map_specular = True
        ##                                mtex.use_map_mirror = True

                            me.materials.append(mat)

                      #assign materials to mesh
                        for enumf, fac in enumerate(me.tessfaces):
                            fac.material_index = matfaces[enumf]
                            if make_smooth:
                                fac.use_smooth = True
                      #create vertex groups for weights
                        if create_skeleton:
                            bpy.ops.object.select_all(action = 'DESELECT')#deselect everything
                            ob.select = True
                            vgroups = {}
                            invert_weights = False
                            if blendindicies:
                                for i in range(VERTcount):
                                    vweights = list(blendweights[i]) + [0.0 for i in range(len(blendindicies[i]) - len(blendweights[i]))]#fill with zeros to allign the length with blendindicies
                                    for j, wg in reversed(list(enumerate(vweights))):#reversing the iteration will fix some weight_group problems
                                        gr = blendindicies[i][j]
                                        if gr not in vgroups:
                                            grpid = NodeLays_meshnodes[objidx][2][gr]
                                            vgroups[gr] = ob.vertex_groups.new(NodeLays[grpid])
                                        vgroups[gr].add([i], wg, 'REPLACE')
                            else:#if not weighted - add a placeholder group for the bone with the same name
                                grp = ob.vertex_groups.new(objname)
                                for i in range(VERTcount):
                                    grp.add([i], 1.0, 'REPLACE')


                        me.update() #read only after this
                        mat_opac.append(ob)


                    if len(mat_opac) > 1:
                        #join obj_mats seamless
                        bpy.ops.object.select_all(action = 'DESELECT')#deselect everything
                        for o in mat_opac:
                            o.select = True
                        scn.objects.active = mat_opac[0]
                        bpy.ops.object.join()
                    if sew_submeshes:
                        #join the meshe's open edges
                        bpy.ops.object.mode_set(mode='EDIT')
                        #deselect everything
                        bpy.ops.mesh.select_all(action = 'DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')
                        #select the open edges then remove doubles(do not merge vertices surrounded by the mesh)
                        me = bpy.context.active_object.data
                        vertdict = dict([(e,0) for e in me.edge_keys])
                        for p in me.polygons:
                                for i in p.edge_keys:
                                    vertdict[i] += 1
                        for vert in vertdict:
                            if vertdict[vert] < 2:
                                me.vertices[vert[0]].select = True
                                me.vertices[vert[1]].select = True
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.mesh.remove_doubles()           #shouldn't merge this way 2 sides of the same surface(oposite normals)
                        bpy.ops.object.mode_set(mode='OBJECT')
                        if make_smooth and objidx in NodeLays_meshnodes:#fix batlefield is lacking some obj??
                            #add split edges modifier
                            ob = bpy.data.objects[NodeLays_meshnodes[objidx][0]]
                            semod = ob.modifiers.new(objname+"EdgeSplitModif", 'EDGE_SPLIT')
                            semod.use_edge_sharp = False
                            semod.split_angle = 1.57

                    objs.append(bpy.context.active_object)
                   #fix obj position
                    if objidx in NodeLays_meshnodes:#fix batlefield is lacking some obj??
                        objname = NodeLays_meshnodes[objidx][0]
                        ob = bpy.data.objects[objname]
                        ob.matrix_world = NodeLays_meshnodes[objidx][1]

                   #attach to armature
                    if create_skeleton:
                        # Give mesh object an armature modifier, using vertex groups but
                        # not envelopes
                        mod = ob.modifiers.new(tmcname+"RigModif", 'ARMATURE')
                        mod.object = bpy.data.objects[tmcname+'Amt']
                        mod.use_bone_envelopes = False
                        mod.use_vertex_groups = True

           #remove anoying sweat shit
            if remove_shit:
                text_to_delete = ("sweat", "zdmodel", "OPTblur")
                bpy.ops.object.select_all(action = 'DESELECT')#deselect everything
                scn = bpy.context.scene
                for textdel in text_to_delete:
                    for objdel in scn.objects:
                        if textdel in objdel.name:
                           objdel.select = True
                           print("deleted:", objdel)
                bpy.ops.object.delete()
           #merge_armatures for doa5
            if istmc and merge_armatures:
                armas = []
                for arma in [arm for arm in bpy.data.armatures if arm.users == 1]:#find armature's users in armatures with users
                    for o in bpy.data.objects:
                        if o.name == arma.name:
                            armas.append(o)
                            break
                if len(armas) != 2:
                    if len(armas) < 2: print('Error on merging armatures: no armature to merge to')
                    else: print('Error on merging armatures: too many armatures in the scene')
                else:#if we have in scene two armatures
                    armatypes = [0, 0]
                    for enum, arma in enumerate(armas):#identify whether armatures are 16cos or 4face or 1hair or 0notabodypart
                        if "MOT02_Chest" in arma.data.bones: armatypes[enum] += 16#cos
                        if "OPT_Face_Root" in arma.data.bones: armatypes[enum] += 4#face
                        if "WGT_hair" in arma.data.bones: armatypes[enum] += 1#hair

                    if armatypes[0]+armatypes[1] not in (1+4, 1+16, 4+16, 1+4+16):
                        print('Error on merging armatures: merged armatures should be doa5 cos or face or hair (different)')
                    else:#if both armatures are identified
                        if armatypes[0]>armatypes[1]:
                            armalive, armadie = armas
                            armalivetype, armadietype = armatypes
                        else:
                            armadie, armalive = armas
                            armadietype, armalivetype = armatypes

                        #change the "armature modifier" to armalive
                        armadienamemod = armadie.name[:-3]+"RigModif"#.rstrip("Amt")
                        armalivenamemod = armalive.name[:-3]+"RigModif"

                        for o in bpy.data.objects:
                            if armadienamemod in o.modifiers:
                                o.modifiers[armadienamemod].object = armalive
                                o.modifiers[armadienamemod].name = armalivenamemod

                        #join and switch to edit mode
                        bpy.ops.object.select_all(action = 'DESELECT')#deselect everything
                        armalive.select = True
                        armadie.select = True
                        bpy.context.scene.objects.active = armalive
                        bpy.ops.object.join()
                        bpy.ops.object.mode_set(mode='EDIT')
                        tmcname = armalive.name[:-3]#fix tmcname for the pose mode ik step

                        armabones = armalive.data.edit_bones
                        if armadietype in (4, 4+1) and armalivetype in (16, 16+1): #face[+hair] to ... ... to cos[+hair]
                            for bnname in ("MOT01_Head", "MOT15_Neck"): #delete doubled bones
                                if bnname+".001" in armabones:
                                    for bn in armabones: bn.select = False #deselect all bones
                                    armabones[bnname].select = True #select the double
                                    bpy.ops.armature.delete() #delete selected bone(s)
                                    armabones[bnname+".001"].name = bnname
                            armabones["MOT15_Neck"].parent = armabones["MOT02_Chest"]
                            if "WGT_cap" in armabones: armabones["WGT_cap"].parent = armabones["MOT01_Head"]
                            if "WGT_hair" in armabones: armabones["WGT_hair"].parent = armabones["MOT01_Head"]
                        if armalivetype in (4, 4+16, 16+1):#hair to face[+cos] or face to hair+cos
                            armabones["WGT_hair"].parent = armabones["MOT01_Head"]
                        bpy.ops.object.mode_set(mode='OBJECT')


           #TEST - set to posemode ik
            if create_skeleton:
                scn.objects.active = bpy.data.objects[tmcname+'Amt']
                bpy.ops.object.select_all(action = 'DESELECT')#deselect everything
                bpy.data.objects[tmcname+'Amt'].select = True
                bpy.ops.object.mode_set(mode='POSE')
                bpy.data.armatures[tmcname+'Amt'].use_auto_ik = True



def parsetextures(l, txblockoffs, xprbase):
    texturesinfo = []
    if True:
        magic, size, datasize, count = fread(xprbase - 0xC, "4s3L")
        print('textures =', count)

##        txblockoffs = 0x1000
        for i in range(count):#for each texture
            textype, texinfooff, texunk0, texnameoff = fread(xprbase + 4 + i*0x10, "4s3L")
            if textype not in (b'TX2D', b'TX3D', b'TXCM', ):
##                print(textype, 'not a texture type')
                continue
            texname = os.path.basename(freadstring(xprbase + texnameoff))
            if texname == "":
                texname = cleanname + "_%03d.dds"%(i+1)
            infbase = xprbase + texinfooff
            if fread(infbase) == 0x030001: #dead or alive 4 detected
                infbase -= 0xC

            inBuffOffset = txblockoffs + fread(infbase + 0x20) & 0xFFFFF000
            doafmt = fread(infbase + 0x20) & 0xFF
            dxfmt, TexelPitch = {2:("L8",1), 0x86:("ARGB",4), 0x52:("DXT1",8), 0x53:("DXT3",16), 0x54:("DXT5",16), 0x71:("ATI2",16)}[doafmt]


            if textype == b'TX3D':
                Width = 1 + (fread(infbase + 0x24) & 0x7FF)
                Height = 1 + ((fread(infbase + 0x24) >> 11) & 0x7FF)
                Width *= 2 #include both textures from doa5 volume texture
                Height *= 2 #include both textures from doa5 volume texture
                textypenote = "\t(volume texture)"
            else:
                Width = 1 + (fread(infbase + 0x24) & 0x1FFF)
                Height = 1 + ((fread(infbase + 0x24) >> 13) & 0x1FFF)
                textypenote = ""
            Sides, ddsVar27, ddsVar28 = (1, 0x1000, 0)
            if textype == b'TXCM':
                 Sides, ddsVar27, ddsVar28 = (6, 0x1008, 0xFE00) #sides = 6 textures from cube texture
                 textypenote = "\t(cube texture)"
            fnc = 1 if doafmt in (2, 0x86) else 4
            tiledWidth = int((Width+fnc-1)/fnc)
            tiledHeight = int((Height+fnc-1)/fnc) * Sides

            noMipSize = int(Width * Height * {0x52:0.5, 0x86:4}.get(doafmt, 1)) * Sides
            ddsCap = [0x20534444, 0x7C, 0x81007, Height, Width, noMipSize] + [0]*(32-6)
            ddsCap[19] = 0x20
            ddsCap[27] = ddsVar27
            ddsCap[28] = ddsVar28
            ddsCap[20] = {0x86:0x41, 2:0x20000}.get(doafmt,4)
            ddsCap[21] = {0x52:0x31545844, 0x53:0x33545844, 0x54:0x35545844, 0x71:0x32495441}.get(doafmt,0)#fourcc
            if doafmt in (0x86,0x71):
                ddsCap[22:27] = [0x20, 0xFF0000, 0xFF00, 0xFF, 0xFF000000]
                if doafmt == 0x71:
                    ddsCap[7] = 1
            elif doafmt == 2:
                ddsCap[22:24] = [8, 0xFF]
            print("%3d"%(count-i), "%4s"%dxfmt, "%4d"%Width, "x", "%4d"%Height, texname, textypenote)
            tempimgpath = bpy.app.tempdir + '/' + texname
            with open(tempimgpath, "wb") as sf:
                if textype != b'TX3D':
                    sf.write(struct.pack("32L", *ddsCap))
                    Untile360(sf, l, inBuffOffset, TexelPitch, tiledWidth, tiledHeight)
                else:
                    with io.BytesIO() as tempstream:
                        ddsCap[4] = int(Width/2)
                        ddsCap[5] = int(noMipSize/2)
                        if False: # blender doesn't understand volume textures
                            ddsCap[2] &= 0x800000
                            ddsCap[6] = 2
                            ddsCap[28] = 0x200000
                        ddsCap[3] = int(Height/2) # load only first frame of this volume texture

                        sf.write(struct.pack("32L", *ddsCap))
                        Untile360(tempstream, l, inBuffOffset, TexelPitch, tiledWidth, tiledHeight)
                        fixDoa5VolumeTexture(sf, tempstream, TexelPitch, Width, Height)

            alpha = True if doafmt in (0x86, 0x53, 0x54) else False
            texturesinfo.append((texname, tempimgpath, alpha))
    return texturesinfo



def Untile360(outBuff, inBuff, inBuffOffset, TexelPitch, Width, Height):
    v12 = 1 << ((TexelPitch >> 4) - (TexelPitch >> 2) + 3)
    v51 = (TexelPitch >> 2) + (TexelPitch >> 1 >> (TexelPitch >> 2))
    v36 = ~(v12 - 1) & v12
    v42 = ~(v12 - 1) & Width
    rectWidth = (Width if Width < v36 else v36)
    for i in range(Height):
        v47 = (((Width + 0x1F) & 0xFFFFFFE0) >> 5) * (i >> 5)
        v44 = (i >> 4) & 1
        v46 = 16 * (i & 1) + (((i >> 3) & 1) << (v51 + 6))
        v41 = 4 * (i & 6)
        v45 = 0xFF & (2 * ((i >> 3) & 1))
        v22 = v46  + (((v41 << (v51 + 6)) >> 6) & 0xF) + 2 * ((((v41 << (v51 + 6)) >> 6) & 0xFFFFFFF0) + ((v47 << (v51 + 6)) & 0x1FFFFFFF))
        sourceOff = inBuffOffset + 8 * ((v22 & 0xFFFFFE00) + 4 * (((v44 + 2 * (v45 & 3)) & 0xFFFFFFFE) + 8 * (((v22 >> 6) & 7) + 8 * (((0xFF & v44) + 2 * (v45 & 3)) & 1)))) + (v22 & 0x3F)
        untilechunk(outBuff, inBuff, sourceOff, rectWidth << v51, TexelPitch)
        v48 = v36
        while ( v48 < v42 ):
            v25 = ((v41 + (v48 & 7)) << (v51 + 6)) >> 6
            v26 = v46 + (v25 & 0xF) + 2 * ((v25 & 0xFFFFFFF0) + (((v47 + (v48 >> 5)) << (v51 + 6)) & 0x1FFFFFFF))
            v27 = v44 + 2 * ((v45 + (0xFF & (v48 >> 3))) & 3)
            v28 = ((v26 >> 6) & 7) + 8 * (((0xFF & v44) + 2 * ((v45 + (0xFF & (v48 >> 3))) & 3)) & 1)
            sourceOff =  inBuffOffset + 8 * ((v26 & 0xFFFFFE00) + 4 * ((v27 & 0xFFFFFFFE) + 8 * v28)) + (v26 & 0x3F)
            untilechunk(outBuff, inBuff, sourceOff, v12 << v51, TexelPitch)
            v48 += v12
        if ( v48 < Width ):
            v31 = v44 + 2 * ((v45 + (0xFF & (v48 >> 3))) & 3)
            v32 = v46 + (((v41 + (v48 & 7)) << (v51 + 6) >> 6) & 0xF) + 2 * ((((v41 + (v48 & 7)) << (v51 + 6) >> 6) & 0xFFFFFFF0) + (((v47 + (v48 >> 5)) << (v51 + 6)) & 0x1FFFFFFF))
            sourceOff = inBuffOffset + 8 * ((v32 & 0xFFFFFE00) + 4 * ((v31 & 0xFFFFFFFE) + 8 * (((v32 >> 6) & 7) + 8 * (v31 & 1)))) + (v32 & 0x3F)
            untilechunk(outBuff, inBuff, sourceOff, (Width - v48) << v51, TexelPitch)

def untilechunk(outBuff, inBuff, sourceOff, size, TexelPitch):
    inBuff.seek(sourceOff)
    if TexelPitch == 4:#A8R8G8B8
        data = struct.unpack(">%dL"%int(size/4), inBuff.read(size))
        outBuff.write(struct.pack("<%dL"%int(size/4), *data))
    else:
        data = inBuff.read(size)
        if TexelPitch != 1:#L8
            data = bytes([data[(i-1) if i%2 else (i+1)] for i in range(size)])#swap every 2 bytes
        outBuff.write(data)

def fixDoa5VolumeTexture(outBuff, inBuff, TexelPitch, Width, Height): # doa5 specific(2 layers in volume)
    inBuff.seek(0)
    bytewidth = int(TexelPitch/2) * int(Width/2)
    cnksize = TexelPitch*16
    columns = int(Width/2/32)

    textures = 2# for a more general case pass this as a function argument
    for t in range(textures):                                       #for each texture:
        for y in range(int(Height/8)):                              # for each row:
            if y%textures == t:                                            #  if this row is for the current texture:
                for yb in range(8):                                 #   for tile height
                    for x in range(columns):                        #    for each column:
                        if x%4 in (0,1):                            #     skip padding:
                            if y%4 in (0,3):
                                p = 0
                            else:
                                p = (1 if x%2 == 0 else -1)         #swap twiddled blocks

                            inBuff.seek((y*8*bytewidth + yb*bytewidth + x*cnksize + p*cnksize))
                            outBuff.write(inBuff.read(cnksize))





#'fread' [seek and] read from ONE file just using the format; you have to set the file first
fglb = {'endian':">"}#'file' = filehandle
def fread(offset = -1, fmt = 'L', extractifsingle = True):
    global fglb
    if type(offset) is str:
        if type(fmt) is bool:
            extractifsingle = fmt
        fmt = offset
    elif offset != -1:
        fglb['file'].seek(offset)
    result = struct.unpack(fglb['endian'] + fmt, fglb['file'].read(struct.calcsize("!"+fmt)))
    if extractifsingle and len(result) == 1:
        return result[0]
    return result

def freadstring(offset = -1):
    global fglb
    if offset != -1:
        fglb['file'].seek(offset)
    mahbytes = b''
    while True:
        mahbytes += fglb['file'].read(1)
        if mahbytes[-1] == 0:
            return mahbytes[:-1].decode('ASCII')


#D3DDECLTYPE read guts;   careful with this - set the fglb to lfile, then switch back
def HalfToFloat(h):
    s = (h  & 0x8000) << 16  # sign
    e = (h >> 10) & 0x1f     # exponent
    f = h & 0x3ff            # fraction
    if e == 31: s |= 0x7f800000 |  (f << 13) if f else 0
    elif not e == f == 0:
        if e == 0 and f != 0:
            while not (f & 0x400):f <<= 1; e -= 1
            e += 1; f &= ~0x400
        s |= ((e + 112) << 23) | (f << 13)
    return struct.unpack('f', struct.pack('I',s))[0]

def Dec4NToFloat4(I):
    x = struct.unpack("h", struct.pack("H", (I       & 0x3FF | (0xfe00 if I & 0x200      else 0))))[0] / 511
    y = struct.unpack("h", struct.pack("H", (I >> 10 & 0x3FF | (0xfe00 if I & 0x80000    else 0))))[0] / 511
    z = struct.unpack("h", struct.pack("H", (I >> 20 & 0x3FF | (0xfe00 if I & 0x20000000 else 0))))[0] / 511
    w = struct.unpack("h", struct.pack("H", (I >> 30         | (0xfffe if I & 0x80000000 else 0))))[0] / 1
    return(x,y,z,w)

def HenD3NToFloat3(I):
    x = struct.unpack("h", struct.pack("H", (I       & 0x7FF | (0xfc00 if I & 0x400      else 0))))[0] / 1023
    y = struct.unpack("h", struct.pack("H", (I >> 11 & 0x7FF | (0xfc00 if I & 0x200000   else 0))))[0] / 1023
    z = struct.unpack("h", struct.pack("H", (I >> 22         | (0xfe00 if I & 0x80000000 else 0))))[0] / 511
    return (x,y,z)

d3dtypes = {0x2c23a5:"2f", 0x2a23b9:"3f", 0x1a23a6:"4f", 0x182886:"4B", 0x1a2286:"4B", 0x2c235f:"2H", 0x1a2360:"4H", 0x1a2187:"L", 0x2a2190:"L", 0x1a2086:"4B"}

#read compressed types; return a list that should be converted to vector
def freadd3dtype(declt, offset = -1):#declt = D3DDECLTYPE
    #0x1a2086 UBYTE4N;  0x2c23a5 FLOAT2;  0x2a23b9 FLOAT3;  0x1a23a6 FLOAT4;  0x2c235f FLOAT16_2;
    #0x182886 D3DCOLOR;  0x1a2187 DEC4N;  0x1a2286 UBYTE4;  0x2a2190 HEND3N;  0x1a2360 FLOAT16_4;
    global fglb
    if offset != -1:
        fglb['file'].seek(offset)
    if declt in d3dtypes:
        result = fread(d3dtypes[declt])

        if declt == 0x2c235f or declt == 0x1a2360: result = [HalfToFloat(H) for H in result]
        if declt == 0x1a2286 or declt == 0x182886: result = list(reversed(result))#will mess things up if little endian(UBYTE4,D3DCOLOR)
        elif declt == 0x1a2086: result = list(reversed([B/255 for B in result]))#will mess things up if little endian(UBYTE4N)
        elif declt == 0x1a2187: result = Dec4NToFloat4(result)
        elif declt == 0x2a2190: result = HenD3NToFloat3(result)
    else: result = []
    #maybe result list should be expanded to four elemets for convenience
    return result






class IMPORT_OT_tmc(bpy.types.Operator, ImportHelper):
    bl_idname= "import_scene.tmc"
    bl_description = 'Import from TMC/GMD (.tmc)'
    bl_label = "Import TMC"
    filename_ext = ".tmc"
    filter_glob = StringProperty(default="*.tmc;*.gmd", options={'HIDDEN'})

    load_textures = BoolProperty(
            name="Load Textures (can be slow)",
            description="Texture the model (can be slow)",
            default=True,
            )

    sew_submeshes = BoolProperty(
            name="Sew Sharp Edges",
            description="For smoothness sake (can be slow)",
            default=True,
            )

    create_skeleton = BoolProperty(
            name="Import The Skeleton(armature)",
            description="Guess what",
            default=True,
            )
    merge_armatures = BoolProperty(
            name="Merge DoA5 Armatures(cos+head+hair)",
            description = "will concatinate armatures for doa5 costume/face/hair; uncheck this if you don't need that",
            default=True,
            )
    xray_bones = BoolProperty(
            name="Xray Bones",
            description="See the bones inside the body",
            default=False,
            )


    custom_outfit = EnumProperty(
            name="Alternate Underwear(DoA5)",
            items=(("4", "name_cos_00x_004.--H", ""),
                   ("3", "name_cos_00x_003.--H", ""),
                   ("2", "name_cos_00x_002.--H", ""),
                   ("1", "name_cos_00x_001.--H", ""),
                   ("0", "None", "if 'None' and the costume is customizable then some textures will be extremely low resolution"),
                   ),
            default='0',
            description = "some costumes have customized underwear; only works with 'simple doa5 unpacker v4' names",
            )

    remove_shit = BoolProperty(
            name="Remove Unwanted Objects",
            description="remove unwanted shit like: 'OPTblur', 'zdmodel' and 'sweat paths'",
            default=True,
            )

    filepath= StringProperty(name="File Path", description="Filepath used for importing the TMC file", maxlen=1024, default="")

    def execute(self, context):
        import_tmc([self.properties.filepath, self.load_textures, self.sew_submeshes, self.xray_bones, int(self.custom_outfit), self.create_skeleton, self.remove_shit, self.merge_armatures])
        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "load_textures")
        layout.prop(self, "sew_submeshes")
        layout.prop(self, "create_skeleton")
        if self.create_skeleton == True:
            box = layout.box()
            box.prop(self, "merge_armatures")
            box.prop(self, "xray_bones")
        layout.prop(self, "custom_outfit")
        layout.prop(self, "remove_shit")


def menu_func(self, context):
    self.layout.operator(IMPORT_OT_tmc.bl_idname, text="TMC/GMD (.tmc)")

def register():
    bpy.utils.register_module(__name__)
    bpy.types.INFO_MT_file_import.append(menu_func)

def unregister():
    bpy.utils.unregister_module(__name__)
    bpy.types.INFO_MT_file_import.remove(menu_func)

if __name__ == "__main__":
    register()
