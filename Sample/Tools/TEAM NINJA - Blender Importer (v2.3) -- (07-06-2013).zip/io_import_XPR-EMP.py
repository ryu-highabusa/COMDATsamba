bl_info = {
    "name": "XPR/emp format",
    "author": "xentax goes corrupt",
    "location": "File > Import > Import XPR/emp (.xpr/.emp)",
    "description": "import Dead or Alive Ultimate/Xtreme/Online models",
    "category": "Import-Export"}

import bpy
from bpy.props import *
from bpy_extras.io_utils import ExportHelper, ImportHelper, unpack_list, unpack_face_list
#----------------------------------------------------------
import bpy, os
import struct
import chunk

def import_xpr(filepath, scale, swap_yz, load_textures, shadeless, one_piece):
    name = os.path.basename(filepath)
    if len(name) == 12: shortName = "v" + name[6:8]
    else: shortName = name[0:3]
    if shortName == 'wba': shortName = 'bas'
    realpath = os.path.realpath(os.path.expanduser(filepath))
    file = open(realpath, 'rb')    # Universal read
    print('Importing %s' % realpath)

    bonesXYZ = []
    emp = True
    if name[-1].lower() == 'r': emp = False
    bones2OBJs = []
    catBlock1Header = []
    versext = ["version", ".doax", ".doau", ".doa3"]
    version = 1
    hasEmbededSkeleton = False
    hasLowPoly = False
    bonesNames = ["Chest", "Head", "Hips", "LeftFoot", "LeftForeArm", "LeftHand", "LeftUpLeg", "LeftLeg",
     "LeftArm", "RightFoot", "RightForeArm", "RightHand", "RightUpLeg", "RightLeg", "RightArm", "Unknown0",
      "LeftArm", "LeftEyeBall", "LeftFoot", "Head", "RightArm", "RightEyeBall", "RightFoot", "Chest",
       "LeftWingBase", "LeftWingMid", "LeftWingTip", "RightWingBase", "RightWingMid", "RightWingTip"]#messed up for doax rig

#    bonesNames = ["Chest", "Head", "Hips", "LeftFoot", "LeftForeArm", "LeftHand", "LeftUpLeg", "LeftLeg",
#     "LeftArm", "RightFoot", "RightForeArm", "RightHand", "RightUpLeg", "RightLeg", "RightArm", "Unknown0",
#      "LeftShoulder", "LeftEyeBall", "LeftToe", "Neck", "RightShoulder", "RightEyeBall", "RightToe", "Waist",
#       "LeftWingBase", "LeftWingMid", "LeftWingTip", "RightWingBase", "RightWingMid", "RightWingTip"]
  #try to open cat file
    if emp: catpath = realpath.lower().replace('.emp','.cat')
    else: catpath = realpath.lower().replace('.xpr','.cat')
    if os.path.exists(catpath):
        print("cat found")
        with open(catpath, 'rb') as f:
            #go for block1
            if struct.unpack("<L", f.read(4))[0] == 0x20:
                savedOffset = 0x14
                while True:
                    f.seek(savedOffset)
                    pair1, pair2 = struct.unpack("<LL", f.read(8))
                    savedOffset = f.tell()
                    #print("pills here %d %d %d"% (version, pair1, pair2))
                    if pair1 == 0: break
                    elif pair2 == 0xFFFFFFFF:
                        if pair1 != 2: version = 3
                        else: version = 2
                    elif (version != 1 and (pair2 == 1 or pair2 == 9)) or (version == 1 and pair1 == 4): #doau low'n'high poly + doax low'n'high poly
                        f.seek(pair1 + 0x14)
                        if version == 1:
                            f.seek(pair2 + 0x14)
                            while True:
                                if struct.unpack("<B", f.read(1))[0] == 0xfe: break
                            bobj = struct.unpack("<B", f.read(1))[0]
                            c = 0
                            while bobj != 0xfe:
                                if bobj != 0xff:
                                    bones2OBJs.append((5, c, bobj))
                                c += 1
                                bobj = struct.unpack("<B", f.read(1))[0]
                            bobj = struct.unpack("<B", f.read(1))[0]
                            while bobj != 0xfe: bobj = struct.unpack("<B", f.read(1))[0]
                        while True:
                            hasSpecialBone = False
                            bid, bbone, bobj = struct.unpack("<BBB", f.read(3)) #B unsigned char
                            if bid == 0: break
                            elif bid == 1:
                                hasSpecialBone = True
                                specialBone = bbone
                                bbone = {0x80:4, 0x81:0xa, 0x86:8, 0x87:0xe, 0x8b:0x19, 0x8c:0x1a, 0x8e:0x1c, 0x8f:0x1d}.get(bbone, bbone)#"special bones?"
                            elif bid == 2:
                                hasSpecialBone = True
                                specialBone = bbone
                                bbone = {0:0x17, 2:0x10, 3:0x14, 7:0xc, 8:7, 9:0xd, 0xa:0, 0xb:2, 0xc:0, 0xd:0, 0xe:2, 0xf:0x13}.get(bbone, bbone) #6 is 6 #doax bones
                            elif bid == 0xa:
                                f.seek(f.tell() - 1)
                                continue
                            elif bid == 0xb:
                                f.seek(f.tell() - 2)
                                continue
                            else: continue
                            if pair2 == 9:
                                bid = 4
                                hasLowPoly = True
                            if hasSpecialBone: bones2OBJs.append((bid, bbone, bobj, specialBone))
                            else: bones2OBJs.append((bid, bbone, bobj))
                    elif version != 1 and pair2 == 5: #doau shadow shapes
                        f.seek(pair1 + 0x14)
                        if struct.unpack("<B", f.read(1))[0] == 0xF0:
                            for i in range(0xf):
                                bones2OBJs.append((5, i, struct.unpack("<B", f.read(1))[0]))
                    elif version != 1 and pair2 == 8: #built in skeleton
                        print("found skeleton in cat")
                        hasEmbededSkeleton = True
                        f.seek(pair1 + 0x14)
                        for i in range(0x18):
                            bonesXYZ.append(struct.unpack("<3f", f.read(12)))
                            tempb = f.read(4)
                #go for the joints
                f.seek(16) #go to joints offset
                joints_offset = struct.unpack("<L", f.read(4))[0]
                if joints_offset != 0:
                    f.seek(joints_offset) #go to joints offset
                    joints = []
                    joint = struct.unpack("<L", f.read(4))[0]
                    while joint != 0:
                        joints.append(joint)
                        joint = struct.unpack("<L", f.read(4))[0]
                    for i in range(len(joints)):
                        if joints[i] < 4: continue
                        f.seek(joints[i] + joints_offset + 8)
                        jointObj, jointBone, jointBone2 = struct.unpack("<3B", f.read(3))
                        if jointBone > 0x17: continue
                        #print("OBJ_%x B1_%x B2%x"% (jointObj, jointBone, jointBone2))
                        bones2OBJs.append((3, jointBone, jointObj))
                #go for the phisic objects
                f.seek(8) #go to phisic offset
                phisic_offset = struct.unpack("<L", f.read(4))[0]
                if phisic_offset != 0:
                    f.seek(phisic_offset) #go to phisic offset
                    phisics = []
                    phisic, poff = struct.unpack("<LL", f.read(8))
                    while phisic != 0xff:
                        if phisic == 0:
                            psavedoff = f.tell()
                            f.seek(poff + phisic_offset + 1)#bone
                            pbone = struct.unpack("<B", f.read(1))[0]
                            #if pbone == 0x80: pbone = 1
                            f.seek(poff + phisic_offset + 28)#xyz
                            px,py,pz,temp1,prx,pry,prz,pobj = struct.unpack("<4f4H", f.read(0x18))
                            phisics.append((pbone, px, py, pz, prx/0x8000*3.14, pry/0x8000*3.14, prz/0x8000*3.14, pobj))
                            bones2OBJs.append((10, pbone, pobj))
                            f.seek(psavedoff)
                            print(pbone, pobj)
                        phisic, poff = struct.unpack("<LL", f.read(8))
                print("id_bone_OBJ: ",end = "")
                for i in range(len(bones2OBJs)): print("%d_%.2x_%.2x"% (bones2OBJs[i][0], bones2OBJs[i][1], bones2OBJs[i][2]),end = ",  ")
                print("%d bones found\r\njoints %d"% (len(bones2OBJs), len(joints)))
            else:print("wrong cat header")
        if hasEmbededSkeleton == False:
            skeletondir = bpy.utils.script_paths("addons\\skeletons\\", False, False)
            if len(skeletondir) != 0:
                print("skeleton found ", shortName)
                with open(skeletondir[0] + shortName + versext[version], 'rb') as f:
                    temp_read = f.read()
                    f.seek(0)
                    for i in range(0, len(temp_read), 0x10):
                        bonesXYZ.append(struct.unpack("<3f", f.read(12)))
                        tempb = f.read(4)
            else:print("skeleton not found. skeleton folder should be in the same folder with xpr and cat : %s"%skeletondir)
        #print("the skeleton has %d bones = {"% len(bonesXYZ))
        #for i in range(len(bonesXYZ)): print("%.2d_%s \t%.4f, %.4f, %.4f"% (i, bonesNames[i], bonesXYZ[i][0], bonesXYZ[i][1], bonesXYZ[i][2]))
        #print("}")
    else:print("cat not found")

    # bones id's: 1-highpoly; 2-doax; 3-joints; 4-lowpoly; 5-shadowshape; ?6-doax;

    if(len(bonesXYZ) > 0):
        bonesHierarchy = [0x17, 0x13, -1, 7, 8, 4, 2, 6, 0x10, 0xd, 0xe, 0xa, 2, 0xc, 0x14, -1, 0, 1, 3, 0, 0, 1, 9, 2, 0, 0x18, 0x19, 0, 0x1b, 0x1c]

        bonesDoa3Parents = [2, 0, -1, 7, 8, 4, 2, 6, 0, 0xd, 0xe, 0xa, 2, 0xc, 0, -1, -1, 1, -1, -1, -1, 1, -1, -1, -1, -1, -1, -1, -1, -1]
        bonesById = [2, 6,7,3, 0xc,0xd,9, 0, 1,0x11,0x15, 8,4,5, 0xe,0xa,0xb]
        boneTails = [0, 7,3,-1, 0xd,9,-1, 1, -1,-1,-1,   4,5,-1, 0xa,0xb,-1]

    for obje in bpy.data.objects:
        obje.select = False #deselect the lamp

    attempt2rig = True
    myAss = -1
    if len(bonesXYZ) == 0 or len(bpy.data.armatures) != 0: attempt2rig = False #hasLowPoly = False
    if attempt2rig: #and hasLowPoly:
        amt = bpy.data.armatures.new('ARigData')
        rig = bpy.data.objects.new('ARig', amt)
        #rig.show_x_ray = True
        amt.show_names = True
        # Link object to scene
        scn = bpy.context.scene
        scn.objects.link(rig)
        scn.objects.active = rig
        scn.update()
        # Create bones
        bpy.ops.object.editmode_toggle()

        for i in range(len(bonesById)):
            mybone = amt.edit_bones.new(bonesNames[bonesById[i]])
            posx, posy, posz = [0,0,0]
            bn = bonesById[i]
            while bn != -1:
                posx += scale*bonesXYZ[bn][0]
                if swap_yz:
                    posz += scale*bonesXYZ[bn][1]
                    posy -= scale*bonesXYZ[bn][2]
                else:
                    posy += scale*bonesXYZ[bn][1]
                    posz += scale*bonesXYZ[bn][2]
                bn = bonesHierarchy[bn]
            mybone.head = (posx, posy, posz)#move to -2
            if boneTails[i] == -1: posx, posy, posz = [posx, posy - 0.05*scale, posz]
            else:  posx, posy, posz = [0,0,0]
            bn = boneTails[i]
            while bn != -1:
                posx += scale*bonesXYZ[bn][0]
                if swap_yz:
                    posz += scale*bonesXYZ[bn][1]
                    posy -= scale*bonesXYZ[bn][2]
                else:
                    posy += scale*bonesXYZ[bn][1]
                    posz += scale*bonesXYZ[bn][2]
                bn = bonesHierarchy[bn]
            mybone.tail = (posx, posy, posz)
            myParrent = bonesDoa3Parents[bonesById[i]]
            if myParrent != -1:
                mybone.parent = bpy.data.armatures['ARigData'].edit_bones[bonesNames[myParrent]]
                #print("%s - %s"% (mybone.name, mybone.parent.name))
                if mybone.head == mybone.parent.tail:
                    mybone.use_connect = True
        #rig.location[0] = -2 * scale #move to lowpoly
        bpy.ops.object.mode_set(mode='OBJECT')

    try:
        if not emp:
            file.seek(8)
            dwHeaderSize = struct.unpack("<1L", file.read(4))[0]
        dwChunkID, dwMDLSize, dwMDLMagic, dwNumObj, dwNumTxt, dwUnk0, dwNumIVBuf = struct.unpack("<2L4s4L", file.read(28))
    except:
        print("Error parsing file header!")
        file.close()
        return

    offverts = []
    offimgs = []
    # Handle XPR
    if True: #dwXprMagic == b'XPR0' or version == 1:#is "xpr"
        if True:
            if dwMDLMagic == b'MDL\0':#is magic "mdl"
                print("mdl magic. objects %d"% dwNumObj)
                objects = []
                empoff1 = 0
                if emp: empoff1 = -0xC
                for object in range(dwNumObj): objects.append(struct.unpack("<1L", file.read(4))[0] + empoff1)
    #handle textures
                print('textures...')
                textures = []
                #make dds caption
                ddsCap = []
                for i in range(32): ddsCap.append(0)
                ddsCap[0] = 0x20534444
                ddsCap[1] = 0x7C
                ddsCap[2] = 0x81007
                ddsCap[19] = 0x20
                ddsCap[20] = 4
                ddsCap[27] = 0x1000
                imgCount = 0
                if emp:
                    file.seek(dwMDLSize + 0x8)
                    while True:
                        chunkid, chunksize = struct.unpack("<LL", file.read(8))
                        foff = file.tell()
                        if chunkid == 2:
                            offverts.append(foff + 0xC)
                            file.seek(foff + chunksize)
                        elif chunkid == 3:
                            #print('TXT at: %d'% foff, end = ' ')
                            mipmaps, txMagic = struct.unpack("<2L", file.read(8))
                            file.seek(0x14, 1)
                            sizeX, sizeY = struct.unpack("<2L", file.read(8))
                            transparency = False
                            if txMagic == 0x31545844: #'1TXD'
                                noMipSize = sizeX * sizeY / 2
                            elif txMagic == 0x34545844: #'4TXD'
                                noMipSize = sizeX * sizeY
                                transparency = True
                            elif txMagic == 0x15: #p8
                                print(imgCount, '_p8')
                                noMipSize = sizeX * sizeY * 4
                            elif txMagic == 0x3C: #argb
                                print(imgCount, '_argb')
                                noMipSize = sizeX * sizeY * 2
                            else:
                                print('unknown format')
                            offimgs.append((44 + foff, sizeX, sizeY, txMagic, noMipSize, transparency))
                            file.seek(foff + chunksize)
                            imgCount += 1
                        elif chunkid == 4:
                            break
                        else:
                            print('ERR at: %d'% foff)
                            break
                else: #if xpr
                    file.seek(dwMDLSize + 0x14)
                    while True:
                        chunkid = struct.unpack("<L", file.read(4))[0]
                        foff = file.tell()
                        if chunkid == 0x00800001:
                            offverts.append(dwHeaderSize + struct.unpack("<L", file.read(4))[0])
                            file.seek(foff + 8)
                        elif chunkid == 0x00040001:
                            #print('TXT at: %d'% foff, end = ' ')
                            txoff, unused0, flags = struct.unpack("<3L", file.read(12))
                           #resolve flags
                            mipmaps = (flags & 0xF0000) >> 16
                            sizeX = 1 << ((flags & 0xF00000) >> 20)
                            sizeY = 1 << ((flags & 0xF000000) >> 24)
                            textype = (flags & 0xFF00) >> 8
                            txMagic = 0
                            transparency = False
                            if textype == 0xC:
                                txMagic = 0x31545844#'1TXD'
                                noMipSize = sizeX * sizeY / 2
                            elif textype == 0xF:
                                txMagic = 0x34545844#'4TXD'
                                noMipSize = sizeX * sizeY
                                transparency = True
                            elif textype == 0x6:
                                print(imgCount, '_p8')
                                txMagic = 0x15#p8
                                noMipSize = sizeX * sizeY * 4
                            elif textype == 0x28:
                                print(imgCount, '_argb')
                                txMagic = 0x3C#argb
                                noMipSize = sizeX * sizeY * 2
                            else:
                                print('unknown format')
                            offimgs.append((dwHeaderSize + txoff, sizeX, sizeY, txMagic, noMipSize, transparency))
                            file.seek(foff + 0x10)
                            imgCount += 1
                        elif chunkid == 0xffffffff:
                            break
                        else:
                            print('ERR at: %d'% foff)
                            break
                imgCount = 0
                for txoff, sizeX, sizeY, txMagic, noMipSize, transparency in offimgs:
                    if True:
                        #if is dxt import texture (no desswisling is needed)
                        if (txMagic == 0x31545844 or txMagic == 0x34545844) and load_textures:
                            ddsCap[3] = sizeY
                            ddsCap[4] = sizeX
                            ddsCap[5] = noMipSize
                            ddsCap[21] = txMagic
                            tempimgpath = bpy.app.tempdir + name + ('%.3d'% imgCount) + '.dds'
                            dds_file = open(tempimgpath, 'wb')
                            for i in range(32):
                                dds_file.write(struct.pack('<L',int(ddsCap[i])))
                            file.seek(txoff)
                            dds_data = file.read(int(noMipSize))
                            dds_file.write(dds_data)
                            dds_file.close()
##                            mat = bpy.data.materials.new("mat%d"% (imgCount + 100))
                            img = bpy.data.images.load(tempimgpath)
                            #img.pack(as_png = True)
                            tex = bpy.data.textures.new('dds%.2x'% imgCount, type = 'IMAGE')
                            tex.image = img
##                            tex.image.alpha_mode = 'PREMUL' #is working inverse ?
##                            tex.image.use_premultiply = True #see the fix above
                            tex.use_alpha = True
                            textures.append((tex,transparency))
                            imgCount += 1
                        else: textures.append(0)
    # Handle OBJ
                vertscounter = 0
                dwWeight = 0
                for object in range(len(objects)):
                    file.seek(objects[object])
                    dwOBJMagic, dwWeight = struct.unpack("<4s1L", file.read(8))
                    if dwOBJMagic == b'OBJ\0':
                        file.seek(objects[object] + 0x10)
                        objbound = struct.unpack("<4f", file.read(16))
                        #bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=3, size=objbound[3], location=(objbound[0], -objbound[2], objbound[1]))
                        for buffer in range(4):#for each buffer
                            #load first vertex buffer
                            file.seek(objects[object] + 0x20 + buffer*0x10)
                            dwNumVertices, dwVBufOffset, dwNumIndices, dwIBufOffset = struct.unpack("<LLLL", file.read(16))
                            if dwNumVertices == 0: continue
                            if emp:
                                dwVBufOffset = offverts[vertscounter]
                                dwIBufOffset = dwIBufOffset + empoff1
                            vertscounter += 1

                            #print("%x obj magic"% (objects[object]))
                            verts = []
                            faces = []
                            indices = []
                            normals = []
                            diffuse = []
                            uv = []
                            weights = []
                            uvs = []
                            uvs0 = []
                            iranges = []#ranges in indices
                            mats2faces = []#ranges in faces
                            materials = []
                          #read indicies
                            file.seek(dwIBufOffset)
                            for i in range(dwNumIndices): indices.append(struct.unpack("<1H", file.read(2))[0])#H - usigned short
                          #load "materials"
                            file.seek(objects[object] + 160)
                            ismat, matsize = struct.unpack("<LL", file.read(8))
                            while ismat != 0:
                                temp11 = file.tell()
                                file.seek(temp11 + matsize - 0x16)
                                tbuf, tstart, tcount, garbagetemp = struct.unpack("<H3L", file.read(14))
                                if tbuf != buffer:
                                    file.seek(temp11 + matsize - 8)
                                    ismat, matsize = struct.unpack("<LL", file.read(8))
                                    continue
                                file.seek(temp11 + 0x8)
                                matbound = struct.unpack("<4f", file.read(16))
                                #bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=3, size=matbound[3], location=(matbound[0], -matbound[2], matbound[1]))
                                file.seek(temp11 + 0x18)
                                diffuse = struct.unpack('<4f', file.read(16))
                                ambient = struct.unpack('<4f', file.read(16))
                                specular = struct.unpack('<4f', file.read(16))
                                emissive = struct.unpack('<4f', file.read(16))
                                power, texturesnum = struct.unpack('<fL', file.read(8))

                                material = bpy.data.materials.new("mat%d"% (object + 100))
                                if True: material.diffuse_color = (specular[0:3])
                                else: material.diffuse_color = (diffuse[0:3])
                                material.diffuse_intensity = 1.0
                                #material.alpha = diffuse[3]
                                material.mirror_color = (ambient[0:3]) #find out how to enable mirror in the material
                                material.ambient = (ambient[3])
                                material.specular_color = (specular[0:3])
                                material.specular_intensity = power
                                material.emit = (emissive[3])
                                if shadeless: material.use_shadeless = True
                                material.use_transparent_shadows = True
                                file.seek(8, 1)
                                for tx in range(texturesnum):
                                    txid, unk0, unk1, txflags = struct.unpack("<LLLL", file.read(16))
                                    if txid != 0x888 and textures[txid] != 0: # (and txid < len(textures))
                                        mtex = material.texture_slots.add()
                                        mtex.texture = textures[txid][0]
                                        mtex.texture_coords = 'UV'
                                        mtex.use_map_color_diffuse = True
                                        if textures[txid][1] == True:
                                            mtex.use_map_alpha = True
                                            material.alpha = 0
                                            material.use_transparency = True
                                        #material.alpha = 0
                                        #material.use_transparency = ismat & 1
                                        #material.transparency_method='RAYTRACE'
                                materials.append(material)
                                file.seek(temp11 + matsize - 8)
                                clockwise = True
                          #make faces from indices
                                for i in range(tcount):
                                    clockwise = not clockwise
                                    v = (indices[tstart + i], indices[tstart + i + 1], indices[tstart + i + 2])
                                    if len(v) != len(set(v)):
                                        continue
                                    if not clockwise: faces.append(v)
                                    else: faces.append((v[0], v[2], v[1]))
                                mats2faces.append(len(faces))
                                ismat, matsize = struct.unpack("<LL", file.read(8))
                          #read vertices
                            file.seek(dwVBufOffset)
                            for v in range(dwNumVertices):
                                vx, vy, vz = struct.unpack("<fff", file.read(12))
                                if swap_yz:
                                    verts.append( (scale*vx, -scale*vz, scale*vy) )
                                else:
                                    verts.append( (scale*vx, scale*vy, scale*vz) )
                                if dwWeight > 0:
                                    weight = []
                                    for w in range(dwWeight):
                                        weight.append(struct.unpack("<f", file.read(4))[0])
                                    weights.append(weight)
                                if buffer == 0:#20
                                    nx, ny, nz = struct.unpack("<fff", file.read(12))#blender can't handle normals
                                    normals.append((nx, ny, nz))
                                elif buffer == 1:#18
                                    tempdiffuse = struct.unpack("<f", file.read(4))[0]
                                elif buffer == 2:#28
                                    nx, ny, nz = struct.unpack("<fff", file.read(12))
                                    normals.append((nx, ny, nz))
                                    u,v = struct.unpack("<ff", file.read(8))
                                    uvs0.append((u, -v))
                                elif buffer == 3:#20
                                    tempdiffuse = struct.unpack("<f", file.read(4))[0]
                                    u,v = struct.unpack("<ff", file.read(8))
                                    uvs0.append((u, -v))
                                else:
                                    print('error')
                                    nx, ny, nz = struct.unpack("<fff", file.read(12))
                                u,v = struct.unpack("<ff", file.read(8))
                                uvs.append((u, -v))
                          #create object from verts and faces
                            name = "vtf%d"% (object + 100)
                            me = bpy.data.meshes.new(name)

                            me.vertices.add(len(verts))
                            me.vertices.foreach_set("co", unpack_list(verts))
                            me.tessfaces.add(len(faces))
                            me.tessfaces.foreach_set("vertices_raw", unpack_face_list(faces))
                            uvtex = me.tessface_uv_textures.new()
##                            me.from_pydata(verts, [], faces)
##                            me.update()
##                            #if buffer > 1:
##                                #uvMain = createTextureLayer("UVMain", me, uv0)
##                            uvtex = me.uv_textures.new()
                            for face in range(len(faces)):
                                datum = uvtex.data[face]
                                datum.uv1 = uvs[faces[face][0]]
                                datum.uv2 = uvs[faces[face][1]]
                                datum.uv3 = uvs[faces[face][2]]
##                                me.tessfaces
                            for vert in range(len(normals)):
                                me.vertices[vert].normal = normals[vert]
                            #uvMain = createTextureLayer("UVFront", me, uv)
##                            me.update()
                          #add new obj to scene
                            scn = bpy.context.scene
                            ob = bpy.data.objects.new(name, me)
                            scn.objects.link(ob)
                            scn.objects.active = ob
                            cm = bpy.context.object.data
                          #assign materials to mesh
                            for m in range(len(materials)):
                                cm.materials.append(materials[m])
                            for f in cm.tessfaces:
                                thismat = 0
                                for m in range(len(mats2faces)):
                                    if f.index < mats2faces[m]:
                                        thismat = m
                                        break
                                f.material_index = thismat
                                f.use_smooth = True
                            me.update()

                            isHBone = False
                            for i in range(len(bones2OBJs)):
                                if object == bones2OBJs[i][2]:
                                    bn = bones2OBJs[i][1]
                                    if bn < len(bonesXYZ):
                                        isHBone = True
                                        myBone = bn
                                        ob.name = bonesNames[bn]
                                        while bn != -1:
                                            ob.location[0] += scale*bonesXYZ[bn][0]
                                            if swap_yz:
                                                ob.location[2] += scale*bonesXYZ[bn][1]
                                                ob.location[1] -= scale*bonesXYZ[bn][2]
                                            else:
                                                ob.location[1] += scale*bonesXYZ[bn][1]
                                                ob.location[2] += scale*bonesXYZ[bn][2]
                                            bn = bonesHierarchy[bn]
                                        if bones2OBJs[i][0] == 4:
                                            ob.location[0] -= scale*2
                                        if bones2OBJs[i][0] == 2 or bones2OBJs[i][0] == 3:
                                            if dwWeight > 0:
                                                print('#', object, myBone, dwWeight)
                                        if bones2OBJs[i][0] == 1 or bones2OBJs[i][0] == 2 or bones2OBJs[i][0] == 3:
                                            if bones2OBJs[i][0] == 1 and bones2OBJs[i][1] == 2: myAss = ob
                                            ob.select = True
                                            grp = ob.vertex_groups.new(ob.name)
                                            if dwWeight == 1:
                                                gprpar = ob.vertex_groups.new(bonesNames[bonesDoa3Parents[myBone]])
                                                for g in range(len(verts)):
                                                    grp.add([g], weights[g][0], 'REPLACE')
                                                    gprpar.add([g], 1-weights[g][0], 'REPLACE')
                                            elif dwWeight == 3:
                                                gprpar = ob.vertex_groups.new(bonesNames[bonesHierarchy[myBone]])
                                                for g in range(len(verts)):
                                                    grp.add([g], weights[g][0], 'REPLACE')
                                                    gprpar.add([g], weights[g][1], 'REPLACE')
                                            elif dwWeight == 2:#clothes problems
                                                gprpar = ob.vertex_groups.new(bonesNames[bonesHierarchy[myBone]])
                                                for g in range(len(verts)):
                                                    grp.add([g], weights[g][1], 'REPLACE')
                                                    gprpar.add([g], 1-weights[g][1], 'REPLACE')
                                            else:
                                                for g in range(len(verts)):
                                                    grp.add([g], 1.0, 'REPLACE')
                                        elif bones2OBJs[i][0] == 5: ob.location[0] += scale*2
                                        if bones2OBJs[i][0] == 10:
                                            for pob in range(len(phisics)):
                                                if object == phisics[pob][7]:
                                                    ob.location[0] += scale*phisics[pob][1]
                                                    if swap_yz:
                                                        ob.location[2] += scale*phisics[pob][2]
                                                        ob.location[1] -= scale*phisics[pob][3]
                                                    else:
                                                        ob.location[1] += scale*phisics[pob][2]
                                                        ob.location[2] += scale*phisics[pob][3]
                                                    ob.rotation_euler[:] = phisics[pob][4:7]
                            if isHBone == False: ob.location = [0, scale*2, 0]

##                            #go to edit mode and fix the mesh
##                            bpy.ops.object.mode_set(mode='EDIT')
##                            bpy.ops.mesh.select_all(action='SELECT')
##                            bpy.ops.mesh.normals_make_consistent(inside=False)
##                            bpy.ops.object.editmode_toggle()

                if len(bpy.data.armatures) != 0:
                    rig = bpy.context.scene.objects['ARig']
                    rig.select = True
                    scn.objects.active = rig
                    bpy.ops.object.parent_set(type='ARMATURE')
                    if one_piece:
                        rig.select = False
                        scn.objects.active = myAss
                        bpy.ops.object.join()

                        #join the meshes open edges(if has no transparent objects)
                        bpy.ops.object.mode_set(mode='EDIT')
                        #deselect everything
                        bpy.ops.mesh.select_all(action = 'DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')
                        #select the open edges then remove doubles(do not merge vertices surrounded by the mesh)
                        me = bpy.context.active_object.data
                        vertdict = dict([(e,0) for e in me.edge_keys])
                        for p in me.polygons:
                                for i in p.edge_keys:
                                    vertdict[i] += 1
                        for vert in vertdict:
                            if vertdict[vert] < 2:
                                me.vertices[vert[0]].select = True
                                me.vertices[vert[1]].select = True
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.mesh.remove_doubles()           #shouldn't merge this way 2 sides of the same surface(oposite normals)
                        bpy.ops.object.mode_set(mode='OBJECT')
##                        bpy.ops.object.mode_set(mode='EDIT')
##                        bpy.ops.mesh.remove_doubles()
##                        bpy.ops.object.mode_set(mode='OBJECT')
                        scn.objects.active = rig
                    bpy.ops.object.mode_set(mode='POSE')
                    bpy.data.armatures['ARigData'].use_auto_ik = True

            else: print("not mdl magic")
        else: print("first chunk is not mdl chunk %x " % dwChunkID)
    else:
        print("No XPR0 found! %s" % dwXprMagic)
        file.close()
        return

    file.close()

    return

class IMPORT_OT_xpr(bpy.types.Operator, ImportHelper):
    bl_idname= "import_scene.xpr"
    bl_description = 'Import from XPR or emp (.xpr/.emp)'
    bl_label = "Import XPR or emp"
    filename_ext = ".xpr"
    filter_glob = StringProperty(default="*.xpr;*.emp", options={'HIDDEN'})

    scale = FloatProperty(
            name="Scale",
            description="Scale the model by given value",
            min=0.0, max=10.0,
            soft_min=0.0, soft_max=10.0,
            default=1.0,
            )

    swap_yz = BoolProperty(
            name="Fix the \"Blender Z coordinate\"",
            description="Blender use Z as depth, while everyone else use Y for that",
            default=False,
            )

    load_textures = BoolProperty(
            name="Load textures(may be slow)",
            description="Texture the model",
            default=True,
            )

    shadeless = BoolProperty(
            name="Shadeles model(funny)",
            description="Use shadeless option for materials",
            default=False,
            )

    one_piece = BoolProperty(
            name="pighPoly as one piece",
            description="Join all parts of objects of the\n high poligonal model in one piece\n (messing up the duble faced shapes -_-)",
            default=False,
            )

    filepath= StringProperty(name="File Path", description="Filepath used for importing the XPR file", maxlen=1024, default="")

    def execute(self, context):
        import_xpr(self.properties.filepath, self.scale, self.swap_yz, self.load_textures, self.shadeless, self.one_piece)
        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


def menu_func(self, context):
    self.layout.operator(IMPORT_OT_xpr.bl_idname, text="Dead or Alive (.xpr/.emp)")

def register():
    bpy.utils.register_module(__name__)
    bpy.types.INFO_MT_file_import.append(menu_func)

def unregister():
    bpy.utils.unregister_module(__name__)
    bpy.types.INFO_MT_file_import.remove(menu_func)

if __name__ == "__main__":
    register()
