(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
// shim for using process in browser
var process = module.exports = {};

// cached from whatever global is present so that test runners that stub it
// don't break things.  But we need to wrap it in a try catch in case it is
// wrapped in strict mode code which doesn't define any globals.  It's inside a
// function because try/catches deoptimize in certain engines.

var cachedSetTimeout;
var cachedClearTimeout;

function defaultSetTimout() {
    throw new Error('setTimeout has not been defined');
}
function defaultClearTimeout () {
    throw new Error('clearTimeout has not been defined');
}
(function () {
    try {
        if (typeof setTimeout === 'function') {
            cachedSetTimeout = setTimeout;
        } else {
            cachedSetTimeout = defaultSetTimout;
        }
    } catch (e) {
        cachedSetTimeout = defaultSetTimout;
    }
    try {
        if (typeof clearTimeout === 'function') {
            cachedClearTimeout = clearTimeout;
        } else {
            cachedClearTimeout = defaultClearTimeout;
        }
    } catch (e) {
        cachedClearTimeout = defaultClearTimeout;
    }
} ())
function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) {
        //normal enviroments in sane situations
        return setTimeout(fun, 0);
    }
    // if setTimeout wasn't available but was latter defined
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
        cachedSetTimeout = setTimeout;
        return setTimeout(fun, 0);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedSetTimeout(fun, 0);
    } catch(e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
            return cachedSetTimeout.call(null, fun, 0);
        } catch(e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
            return cachedSetTimeout.call(this, fun, 0);
        }
    }


}
function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) {
        //normal enviroments in sane situations
        return clearTimeout(marker);
    }
    // if clearTimeout wasn't available but was latter defined
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
        cachedClearTimeout = clearTimeout;
        return clearTimeout(marker);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedClearTimeout(marker);
    } catch (e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
            return cachedClearTimeout.call(null, marker);
        } catch (e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
            // Some versions of I.E. have different rules for clearTimeout vs setTimeout
            return cachedClearTimeout.call(this, marker);
        }
    }



}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    if (!draining || !currentQueue) {
        return;
    }
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            if (currentQueue) {
                currentQueue[queueIndex].run();
            }
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        runTimeout(drainQueue);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;
process.prependListener = noop;
process.prependOnceListener = noop;

process.listeners = function (name) { return [] }

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };

},{}],2:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.findAob = exports.findAobs = exports.doesAobStrMatch = void 0;
function doesAobStrMatch(aobStr, test) {
    if (aobStr.length !== test.length)
        throw new Error("Something went wrong");
    for (let i = 0; i < aobStr.length; i += 1) {
        if (test[i] !== "?") {
            if (test[i] !== aobStr[i])
                return false;
        }
    }
    return true;
}
exports.doesAobStrMatch = doesAobStrMatch;
function findAobs(fileUint8Array, patternArray, posStart) {
    const results = [];
    let i = posStart;
    while (true) {
        i = findAob(fileUint8Array, patternArray, i);
        if (i === -1)
            return results;
        results.push(i);
        i += 1;
    }
}
exports.findAobs = findAobs;
function findAob(fileUint8Array, patternArray, posStart) {
    for (let i = posStart; i <= fileUint8Array.length - patternArray.length; i += 1) {
        if (patternArray.every((e, j) => e === fileUint8Array[i + j])) {
            return i;
        }
    }
    return -1;
}
exports.findAob = findAob;

},{}],3:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ptrSize = void 0;
exports.ptrSize = 4;

},{}],4:[function(require,module,exports){
(function (process){(function (){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createInputComparator = exports.isBaseBinMoveId = exports.getBaseBinMoveIdCategory = exports.getMoveCategoryAndIndex = exports.getMoveId = void 0;
require("./environment.d");
const doa5lrMoveIdCategoryData = [
    { category: 0, start: 0x0000 },
    { category: 1, start: 0x1f40 },
    { category: 2, start: 0x3e80 },
    // yep, category is out of order here
    { category: 5, start: 0x5dc0 },
    { category: 3, start: 0x7d00 },
    { category: 4, start: 0x9c40 }, // 5 * 8000 = 40000
];
function getMoveId(category, index) {
    console.assert(index < 8000);
    const entry = doa5lrMoveIdCategoryData.find(e => e.category === category);
    return (entry.start + index).asAob2Str;
}
exports.getMoveId = getMoveId;
function getMoveCategoryAndIndex(moveIdStr) {
    const moveId = moveIdStr.dehexUint;
    if (moveId < 0 || !isFinite(moveId)) {
        // TODO: this will probably never go off since it's all uints everywhere
        //       introduce a sign or add validation for the sign bit on read
        // OG asm code returns category 0, but what to return as index?
        throw new Error("Invalid move id");
    }
    // OG asm code to retrieve category:
    // if (moveId < 0x0000) return 0; // 0 * 8000 =     0
    // if (moveId < 0x1f40) return 0; // 1 * 8000 =  8000
    // if (moveId < 0x3e80) return 1; // 2 * 8000 = 16000
    // if (moveId < 0x5dc0) return 2; // 3 * 8000 = 24000
    // if (moveId < 0x7d00) return 5; // 4 * 8000 = 32000
    // if (moveId < 0x9c40) return 3; // 5 * 8000 = 40000
    // return 4;
    const entry = [...doa5lrMoveIdCategoryData].reverse().find(e => moveId >= e.start);
    const category = entry.category;
    const index = moveId - entry.start;
    console.assert(index < 8000);
    return { category, index };
}
exports.getMoveCategoryAndIndex = getMoveCategoryAndIndex;
function getBaseBinMoveIdCategory() { return 5; }
exports.getBaseBinMoveIdCategory = getBaseBinMoveIdCategory;
function isBaseBinMoveId(moveId) {
    return (getMoveCategoryAndIndex(moveId).category ===
        getBaseBinMoveIdCategory());
}
exports.isBaseBinMoveId = isBaseBinMoveId;
// TODO: do again with 1.10c
//
// Object.values(parsed.bins).flatMap(
//     charBin => genTools.getAllMoveIdsFromMoveInfos(charBin).flatMap(
//         moveId => genTools.findMoveIdInCommandList(charBin, moveId).flatMap(
//             e => e.match.arrayIJ.pInputStr.d.v.split("")
//         ),
//     ),
// ).filterUnique().sortAscending()
//
// All characters used in 1.02a: "12346789_FPKNAS+.CcHhYyIiLRT"
// F = H
// S = +H-H (e.g. `S+K` from akira)
// N = T
// A = Ap
// . = * (e.g. `2N.N`)
// c = charge (button, e.g. `1cP+K`)
// C = heavy charge (button, e.g. `46CN`)
// _ = hold (direction, e.g. `3_PP` or `PP4_`)
// h = 214
// H = 236
// y = 624
// Y = 426
// L = 248
// R = 268
// I = 4862
// i = 6842
// T = 36842 (e.g. `YN.46N.TN` or `H46N.hRN.TTN`)
function createInputComparator(inputPattern) {
    const processedPattern = process(inputPattern
        .replaceAll("p", "P")
        .replaceAll("k", "K")
        .replaceAll("t", "T")
        .replaceAll("h", "F")
        .replaceAll("H", "F")
        .replaceAll("4123698", "O")
        .replaceAll("4789632", "O")
        .replaceAll("6321478", "O")
        .replaceAll("6987432", "O")
        .replaceAll("23698", "R")
        .replaceAll("21478", "L")
        .replaceAll("63214", "y")
        .replaceAll("41236", "Y")
        .replaceAll("4268", "O")
        .replaceAll("4862", "O")
        .replaceAll("6248", "O")
        .replaceAll("6842", "O")
        .replaceAll("624", "y")
        .replaceAll("426", "Y")
        .replaceAll("268", "R")
        .replaceAll("248", "L")
        .replaceAll("214", "h")
        .replaceAll("236", "H")
        .replaceAll("24", "h")
        .replaceAll("26", "H")
        .replaceAll("AP", "A")
        .replaceAll("((", "C")
        .replaceAll("))", "")
        .replace(/\((\d)\)/g, (match, firstGroup) => `${firstGroup}_`)
        .replaceAll("(", "c")
        .replaceAll(")", "")
        .replaceAll("S", "F+P+K")
        .replaceAll("T", "N")
        .replaceAll("T", "O")
        .replaceAll("I", "O")
        .replaceAll("i", "O")
        .replaceAll("*", ".")
        .replaceAll("~", "."));
    return doesInputSatisfyPattern;
    function doesInputSatisfyPattern(input) {
        const processedInput = process(input
            .replaceAll("T", "O")
            .replaceAll("I", "O")
            .replaceAll("i", "O")
            .replaceAll("24", "h")
            .replaceAll("26", "H"));
        let j = 0;
        for (let i = 0; i < processedInput.length; i += 1) {
            if (processedInput[i] === processedPattern[j]) {
                j += 1;
                if (j >= processedPattern.length)
                    return true;
            }
        }
        return false;
    }
    function process(input) {
        return input.replaceAll(" ", "").split("");
    }
}
exports.createInputComparator = createInputComparator;

}).call(this)}).call(this,require('_process'))
},{"./environment.d":5,"_process":1}],5:[function(require,module,exports){

},{}],6:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createFileUsageHelper = void 0;
require("./environment.d");
const genericTools_1 = require("./genericTools");
const consts_1 = require("./consts");
;
;
function createFileUsageHelper(fileName, fileUint8Array, skipHeavyOperations) {
    // Whether fileSections was modified since sorting
    let dirty = false;
    // When changing, be sure to update the dirty flag
    const fileSections = new Array();
    const markFileSection = (from, bytesCount, varPath) => {
        if (skipHeavyOperations)
            return;
        if (varPath[0] === "insight")
            return;
        const entry = { from, to: from + bytesCount, varPath };
        if (fileSections.some(fs => isFsCoveredBy(entry, fs)))
            return;
        for (let i = 0; i < fileSections.length; i += 1) {
            if (isFsCoveredBy(fileSections[i], entry)) {
                fileSections.splice(i--, 1);
            }
        }
        fileSections.push(entry);
        dirty = true;
    };
    const pointerLocations = new Array();
    const reportPtr = (position, sizeOfThePtr) => {
        console.assert(sizeOfThePtr === consts_1.ptrSize);
        pointerLocations.push(position);
    };
    return {
        markFileSection,
        reportPtr,
        findOverlaps,
        makeFoundOverlapsReadable,
        findUnusedChunks,
        createGetHit,
        createGetSize,
        // readonly due to the dirty flag
        getFileSections: () => fileSections,
        getModifiedFile,
    };
    function getModifiedFile(modifications, params = { fileUint8Array, pointerLocations }) {
        const mutableNotifications = modifications.map(e => ({ ...e }));
        const negPtr = getNegPtr(consts_1.ptrSize);
        let fileUint8ArrayToUse = params.fileUint8Array;
        let ptrLocationsToUse = params.pointerLocations;
        let result = fileUint8ArrayToUse;
        for (let i = 0; i < mutableNotifications.length; i += 1) {
            const modification = mutableNotifications[i];
            const from = modification.from;
            const what = modification.insert ?? new Uint8Array();
            const removeAmount = modification.remove ?? 0;
            console.assert(from >= 0);
            console.assert(removeAmount >= 0);
            console.assert(from + removeAmount <= fileUint8ArrayToUse.length);
            const deltaSize = what.length - removeAmount;
            result = new Uint8Array(fileUint8ArrayToUse.length + deltaSize);
            for (let j = 0; j < from; j += 1) {
                result[j] = fileUint8ArrayToUse[j];
            }
            for (let j = 0; j < what.length; j += 1) {
                result[from + j] = what[j];
            }
            for (let j = from + removeAmount; j < fileUint8ArrayToUse.length; j += 1) {
                result[j + deltaSize] = fileUint8ArrayToUse[j];
            }
            ptrLocationsToUse = ptrLocationsToUse.filterUnique().flatMap(oldPtrLocation => {
                if (oldPtrLocation >= from &&
                    oldPtrLocation + consts_1.ptrSize <= from + removeAmount) {
                    return [];
                }
                console.assert(noOverlap([oldPtrLocation, oldPtrLocation + consts_1.ptrSize], [from, from + removeAmount]));
                const newPtrLocation = (oldPtrLocation + (oldPtrLocation >= from ? deltaSize : 0));
                const oldPtrValue = genericTools_1.readUintFrom(fileUint8ArrayToUse, oldPtrLocation, consts_1.ptrSize);
                if (oldPtrValue !== 0 && oldPtrValue !== negPtr) {
                    const newPtrValue = (oldPtrValue + (oldPtrValue >= from ? deltaSize : 0));
                    if (newPtrValue !== oldPtrValue) {
                        genericTools_1.writeUintTo(result, newPtrLocation, newPtrValue, consts_1.ptrSize);
                    }
                }
                return [newPtrLocation];
            });
            for (let j = i + 1; j < mutableNotifications.length; j += 1) {
                if (mutableNotifications[j].from >= from) {
                    mutableNotifications[j].from += deltaSize;
                }
            }
            fileUint8ArrayToUse = result;
        }
        return {
            result: {
                fileUint8Array: result,
                pointerLocations: ptrLocationsToUse,
            },
            get save() {
                fsTools.saveAs(result, `modified-${fileName}`);
                return "done";
            },
        };
        function getNegPtr(ptrSize) {
            const uint8Array = new Uint8Array(ptrSize);
            for (let i = 0; i < ptrSize; i += 1) {
                uint8Array[i] = 0xFF;
            }
            return genericTools_1.readUintFrom(uint8Array, 0, ptrSize);
        }
        function noOverlap(a, b) {
            return a[1] <= b[0] || a[0] >= b[1];
        }
    }
    function sortSections() {
        if (!dirty)
            return;
        fileSections.sort((a, b) => {
            return (a.from - b.from ||
                b.varPath.length - a.varPath.length ||
                (b.to - b.from) - (a.to - a.from));
        });
        dirty = false;
    }
    function findOverlaps(suppress) {
        sortSections();
        const overlaps = new Map();
        for (let i = 0; i < fileSections.length - 1; i += 1) {
            const fsi = fileSections[i];
            for (let j = i + 1; j < fileSections.length; j += 1) {
                const fsj = fileSections[j];
                if (doFsOverlap(fsi, fsj)) {
                    if (suppress(fsi, fsj))
                        continue;
                    if (!overlaps.has(fsi))
                        overlaps.set(fsi, []);
                    overlaps.get(fsi).push(fsj);
                }
            }
        }
        return overlaps;
    }
    function makeFoundOverlapsReadable(overlaps) {
        const readableOverlaps = {};
        for (const [key, value] of overlaps) {
            readableOverlaps[makeOverlapReadable(key)] = value.map(e => makeOverlapReadable(e));
        }
        return readableOverlaps;
        function makeOverlapReadable(overlap) {
            return (overlap.from.asX_HexStr + " " +
                overlap.to.asX_HexStr + " " +
                genericTools_1.finalizeName(overlap.varPath));
        }
    }
    function findUnusedChunks(patternToIgnore, range) {
        if (skipHeavyOperations)
            return { within: [] };
        sortSections();
        const unusedChunks = new Array();
        let inUseEnd = 0;
        let i = 0;
        const getHit = createGetHit();
        while (i < fileUint8Array.length) {
            const hit = getHit(i);
            if (hit) {
                const hitFrom = hit[0].dehexUint;
                const hitTo = hit[1].dehexUint;
                if (inUseEnd < i) {
                    console.assert(hitFrom > inUseEnd);
                    unusedChunks.push({ from: inUseEnd, to: hitFrom });
                }
                inUseEnd = hitTo;
                i = (hitTo === i) ? hitTo + 1 : hitTo;
            }
            else {
                i += 1;
            }
        }
        if (inUseEnd < fileUint8Array.length) {
            unusedChunks.push({ from: inUseEnd, to: fileUint8Array.length });
        }
        // FIXME: name is misleading
        return groupUnusedChunks(unusedChunks.filter(e => {
            return !unusedChunkConsistsOf(e, patternToIgnore);
        }).map(e => ({
            from: e.from.asX_HexStr,
            to: e.to.asX_HexStr,
        })), range);
        function unusedChunkConsistsOf(e, pattern) {
            const patternArray = pattern.dehexUintAob;
            let p = 0;
            for (let i = e.from; i < e.to; i += 1) {
                if (fileUint8Array[i] !== patternArray[p])
                    return false;
                p = (p + 1) % patternArray.length;
            }
            return true;
        }
    }
    // FIXME: name is misleading
    // after and before are not arrays and must be in touch with max and min
    function groupUnusedChunks(unusedChunks, { min = -Infinity, max = Infinity } = {}) {
        let before;
        let within = [];
        let after;
        for (let i = 0; i < unusedChunks.length; i += 1) {
            const chunk = unusedChunks[i];
            const from = chunk.from.dehexUint;
            const to = chunk.to.dehexUint;
            if (from > max)
                break;
            if (to === min) {
                before = chunk;
                continue;
            }
            if (from === min)
                throw new Error("something went wrong");
            if (from === max) {
                after = chunk;
                break;
            }
            if (from > min) {
                if (to >= max)
                    throw new Error("something went wrong");
                within.push(chunk);
            }
        }
        return {
            before,
            within,
            after,
        };
    }
    function createGetHit() {
        sortSections();
        let fsi = 0;
        return (pos) => {
            while (fsi < fileSections.length) {
                const fs = fileSections[fsi];
                if (fs.from > pos)
                    return null;
                if (fs.to > pos ||
                    fs.from === fs.to && fs.to === pos) {
                    return [
                        fs.from.asX_HexStr,
                        fs.to.asX_HexStr,
                        genericTools_1.finalizeName(fs.varPath),
                    ];
                }
                fsi += 1;
            }
            return null;
        };
    }
    function createGetSize() {
        sortSections();
        let i = 0;
        return (pos) => {
            while (i < fileSections.length && fileSections[i].from <= pos) {
                i += 1;
            }
            if (i === fileSections.length) {
                return fileUint8Array.length - pos;
            }
            return fileSections[i].from - pos;
        };
    }
}
exports.createFileUsageHelper = createFileUsageHelper;
function isFsCoveredBy(fs1, fs2) {
    return (fs2.from <= fs1.from &&
        fs2.to >= fs1.to &&
        fs2.varPath.length <= fs1.varPath.length &&
        fs2.varPath.every((e, i) => e === fs1.varPath[i]));
}
function doFsOverlap(fs1, fs2) {
    if (fs1.to <= fs2.from)
        return false;
    if (fs1.from >= fs2.to)
        return false;
    if (fs2.to <= fs1.from)
        return false;
    if (fs2.from >= fs1.to)
        return false;
    return true;
}

},{"./consts":3,"./environment.d":5,"./genericTools":7}],7:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.writeUintTo = exports.readUintFrom = exports.finalizeName = exports.reindent = exports.createDynamicMap = exports.createNamesGenerator = void 0;
function createNamesGenerator() {
    const map = createDynamicMap(prefix => createNameGenerator(prefix));
    return (prefix, pad) => map.getValue(prefix)(pad);
    function createNameGenerator(prefix) {
        let counter = 0;
        return (pad = 0) => `${prefix}${String(++counter).padStart(pad, "0")}`;
    }
}
exports.createNamesGenerator = createNamesGenerator;
function createDynamicMap(construct) {
    const map = new Map();
    return { getValue };
    function getValue(key) {
        if (!map.has(key)) {
            const value = construct(key);
            map.set(key, value);
            return value;
        }
        else {
            return map.get(key);
        }
    }
}
exports.createDynamicMap = createDynamicMap;
function reindent(delta, str) {
    if (delta < 0) {
        return str.split("\n").map(e => {
            if (e.substr(0, -delta).trim())
                throw new Error("Invalid reindent");
            return e.substr(-delta);
        }).join("\n");
    }
    else {
        let prefix = "";
        for (let i = 0; i < delta; i += 1)
            prefix += " ";
        return str.split("\n").map(e => `${prefix}${e}`).join("\n");
    }
}
exports.reindent = reindent;
function finalizeName(varPath) {
    console.assert(varPath.length > 0);
    let varName = varPath[0];
    for (let i = 1; i < varPath.length; i += 1) {
        if (varPath[i] === "->" &&
            i === varPath.length - 1) {
            varName = `*(${varName})`;
        }
        else if (varPath[i][0] === "[" ||
            (Number(varPath[i] === "->") ^ Number(varPath[i - 1] === "->"))) {
            varName += varPath[i];
        }
        else {
            varName += "." + varPath[i];
        }
    }
    return varName;
}
exports.finalizeName = finalizeName;
function readUintFrom(uint8Array, posStart, bytesCount) {
    console.assert([1, 2, 4, 8].includes(bytesCount));
    let value = 0;
    for (let i = 0; i < bytesCount; i += 1) {
        // Not using bit operations as they are messed up for big numbers
        value += uint8Array[posStart + i] * Math.pow(2, 8 * i);
    }
    return value;
}
exports.readUintFrom = readUintFrom;
function writeUintTo(outUint8Array, posStart, value, bytesCount) {
    console.assert([1, 2, 4, 8].includes(bytesCount));
    console.assert(posStart + bytesCount <= outUint8Array.length);
    const aob = value.asAob;
    if (aob.length > 1 && aob[aob.length - 1] === 0)
        aob.pop();
    console.assert(aob.length <= bytesCount);
    for (let i = 0; i < bytesCount; i += 1) {
        outUint8Array[posStart + i] = (i < aob.length) ? aob[i] : 0;
    }
}
exports.writeUintTo = writeUintTo;

},{}],8:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createHslHelper = exports.getUintHslType = exports.hslZStringName = exports.hslFloatName = exports.hslBlobName = void 0;
require("./environment.d");
const genericTools_1 = require("./genericTools");
const consts_1 = require("./consts");
exports.hslBlobName = "blob";
exports.hslFloatName = "FLOAT";
exports.hslZStringName = "zstring";
const hslUByteName = "UBYTE";
const hslWordName = "WORD";
const hslDWordName = "DWORD";
function getUintHslType(bytesCount) {
    if (bytesCount === 1)
        return hslUByteName;
    if (bytesCount === 2)
        return hslWordName;
    if (bytesCount === 4)
        return hslDWordName;
    throw new Error("unsupported uint bytes count");
}
exports.getUintHslType = getUintHslType;
function createHslHelper(markTerminators) {
    const maxArraySize = 16384;
    const maxArraySizes = new Array();
    maxArraySizes.push(1024);
    //
    const getName = genericTools_1.createNamesGenerator();
    const hslTypes = [];
    const hslLines = new Array();
    const generatedStructureNames = new Set();
    const usedStructureNames = new Set();
    let structsAdded = 0;
    const namePerDynamicStructBody = genericTools_1.createDynamicMap(body => {
        const name = getName("S", 3);
        generatedStructureNames.add(name);
        hslTypes.push(`typedef struct ${name} {` +
            (body.indexOf("\n") === -1 ? ` ${body} ` : "\n" + genericTools_1.reindent(4, body) + "\n") +
            `} ${name};`);
        return name;
    });
    //
    const getStructName = (structBody, terminatorBytesCountBefore, terminatorBytesCountAfter) => {
        const lines = [];
        if (markTerminators && terminatorBytesCountBefore > 0) {
            lines.push(getStructBodyLine(exports.hslBlobName, "terminatorBefore", [terminatorBytesCountBefore]));
        }
        lines.push(...structBody);
        if (markTerminators && terminatorBytesCountAfter > 0) {
            lines.push(getStructBodyLine(exports.hslBlobName, "terminatorAfter", [terminatorBytesCountAfter]));
        }
        return namePerDynamicStructBody.getValue(lines.join("\n"));
    };
    const getArrayTypeName = (type, dims, terminatorBytesCountBefore, terminatorBytesCountAfter) => {
        return getStructName([getStructBodyLine(type, "entries", dims)], terminatorBytesCountBefore, terminatorBytesCountAfter);
    };
    const addHslStructureAt = (pos, structName, varName, type) => {
        structsAdded += 1;
        usedStructureNames.add(structName);
        hslLines.push({ pos, structName, varName, type });
    };
    const addHslString = function (pos, varPath, hslType, arrayDims, terminatorBytesCountBefore, terminatorBytesCountAfter) {
        let posToUse = pos;
        if (markTerminators && terminatorBytesCountBefore) {
            posToUse -= terminatorBytesCountBefore;
        }
        let structName = hslType;
        if (arrayDims) {
            structName = getArrayTypeName(hslType, arrayDims, terminatorBytesCountBefore, terminatorBytesCountAfter);
        }
        else {
            if (!generatedStructureNames.has(hslType)) {
                structName = getStructName([getStructBodyLine(hslType, "unnamed")], terminatorBytesCountBefore, terminatorBytesCountAfter);
            }
        }
        addHslStructureAt(posToUse, structName, genericTools_1.finalizeName(varPath));
    };
    return {
        getStructName,
        getArrayTypeName,
        getStructBodyLine,
        addHslStructureAt,
        addHslString,
        markUnusedChunks,
        exportHslCode,
    };
    function getStructBodyLine(hslType, varName, arrayDims) {
        const optDimsStr = (arrayDims ?? []).map(e => `[${e}]`).join("");
        if (arrayDims) {
            const realSize = arrayDims.reduce((acc, e) => acc * e, 1);
            // FIXME: make sure this check in all relevant places
            if (maxArraySize <= realSize) {
                // TODO: use `reportValidationFail`?
                console.warn("Exceeding max array size: " +
                    arrayDims.join(" * ") +
                    ` = ${realSize} / ${maxArraySize}`);
                maxArraySizes.push(realSize);
            }
        }
        return `${hslType} ${varName}${optDimsStr};`;
    }
    function markUnusedChunks(unusedChunks, namePrefix = "unused") {
        for (const chunk of unusedChunks) {
            const bytesCount = chunk.to.dehexUint - chunk.from.dehexUint;
            addHslStructureAt(chunk.from.dehexUint, getArrayTypeName(exports.hslBlobName, [bytesCount]), genericTools_1.finalizeName([getName(namePrefix)]), "unused");
        }
    }
    function exportHslCode(name, params) {
        const reportStr = (`${usedStructureNames.size} / ${generatedStructureNames.size} ` +
            `generated names are used; ${structsAdded} marks added`);
        const hslHeader = getHslHeader(name, Math.min(maxArraySize, Math.max(...maxArraySizes)));
        const getPriority = (entry => (params.showUnusedFirst && entry.type === "unused") ? 1 : 0);
        let hslLinesToUse = [...hslLines];
        if (!params.unused) {
            hslLinesToUse = hslLinesToUse.filter(entry => entry.type !== "unused");
        }
        const hslFunction = getHslFunction(hslLinesToUse.sort((a, b) => {
            const priorityA = getPriority(a);
            const priorityB = getPriority(b);
            return (priorityB - priorityA ||
                a.pos - b.pos);
        }).map(e => (`__addStructureAt(` +
            `${e.pos.asXHexStr}, ` +
            `"${e.structName}", ` +
            `"${e.varName}"` +
            `);`)).join("\n"));
        return {
            reportStr,
            hslCode: [
                hslHeader,
                hslTypes.join("\n"),
                hslFunction,
            ].join("\n\n//\n\n") + "\n",
        };
    }
}
exports.createHslHelper = createHslHelper;
function getHslHeader(name, maxArraySize) {
    return genericTools_1.reindent(-8, `
        #pragma displayname("${name}")
        #pragma fileextensions(".bin")
        #pragma byteorder(little_endian)

        // Default pointer size (4 bytes / 32 bits).  This controls how many bytes are
        // dedicated to a pointer (e.g. struct myStructure* myName).
        #pragma ptrsize(${consts_1.ptrSize})

        // Default enumeration size (4 bytes / 32 bits).  You may set this to 1, 2, 4,
        // or 8 bytes.
        #pragma enumsize(4)
        // Default enumeration sign (either "signed" or "unsigned")
        #pragma enumsign("signed")

        // Default structure Packing (1 byte).
        #pragma pack(1)   // NOT YET IMPLEMENTED

        // Default max array length.  The maximum array size can range between 1 and 
        // 16384 entries, inclusively.  This limit helps guard against run-away arrays
        // when the data does not match expectations.
        #pragma maxarray(${maxArraySize})

        #pragma hide()

        // Standard Types
        typedef          char            CHAR ;
        typedef          wchar           WCHAR ;
        typedef signed   __int8          BYTE ;
        typedef          BYTE            byte ;
        typedef unsigned __int8          ${hslUByteName} ;
        typedef          ${hslUByteName} ubyte ;
        typedef unsigned __int16         ${hslWordName} ;
        typedef          ${hslWordName}  word ;
        typedef unsigned __int16         USHORT ;
        typedef          USHORT          ushort ;
        typedef          short           SHORT ;
        typedef unsigned __int32         ${hslDWordName} ;
        typedef          ${hslDWordName} dword ;
        typedef          long            LONG ;
        typedef unsigned __int32         ULONG ;
        typedef          ULONG           ulong ;
        typedef signed   __int64         QUAD ;
        typedef          QUAD            quad ;
        typedef unsigned __int64         UQUAD ;
        typedef          UQUAD           uquad ;
        typedef          float           ${exports.hslFloatName} ;
        typedef          double          DOUBLE ;
    `);
}
function getHslFunction(body) {
    return ("function AutoParseFile {\n" +
        genericTools_1.reindent(4, body) + "\n" +
        "}");
}

},{"./consts":3,"./environment.d":5,"./genericTools":7}],9:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("./environment.d");
const typeH_1 = require("./typeH");
const consts_1 = require("./consts");
const aobTools_1 = require("./aobTools");
const genericTools_1 = require("./genericTools");
const doa5lrTools_1 = require("./doa5lrTools");
const hslTools_1 = require("./hslTools");
const fileUsageHelper_1 = require("./fileUsageHelper");
const validators_1 = require("./validators");
// Set up file drag-n-drop listener to automatically parse bin files
fsTools.createFilesReceiver(async (files) => {
    const results = {};
    for (const file of files) {
        const charName = genTools.getCharName(file.name);
        console.log("%s =", charName);
        const result = await genTools.parseBin(file);
        console.log(result);
        results[charName] = result;
    }
    console.debug("Summary:");
    console.debug(results);
});
setTimeout(() => {
    console.log("genTools =", window.genTools);
    console.log("Ready to parse extracted *.bin");
});
//
window.genTools = (function (markTerminators = true, skipHeavyOperations = false) {
    const magics = {
        baseBinStart: "FF FF FF FF",
        charBinStart: "00 00 00 00",
        motionStart: "char_dat".split("").map(e => e.charCodeAt(0)).asAobStr,
        sectionStart: ("00 00 00 00 40 1F 00 00 80 3E 00 00 C0 5D 00 00 " +
            "00 7D 00 00 40 9C 00 00"),
        sectionEnd: "00 50 C3 47",
    };
    return {
        parseBin,
        getCharName,
        collapse,
        compareMems,
        findMoveIdInCommandList,
        moveIdFindResultToString,
        dumpAllMoves,
        findMoveIdsFromInput,
        getAllMoveIdsFromMoveInfos,
        getAllMoveIdsFromMoveInputs,
        getAllMoveIdsFromHitTables,
        getAllMoveInputs,
        getMoveId: doa5lrTools_1.getMoveId,
        getMoveInfo,
        getAnimationInfo,
        reportTagThrows,
        buildCharacter,
        analyzeHitTables,
    };
    //
    async function parseBin(file) {
        const charName = getCharName(file.name);
        // readonly
        const fileUint8Array = new Uint8Array(await file.arrayBuffer());
        //
        const fileType = getFileType(fileUint8Array);
        const isMotion = fileType === "motion";
        const isBaseBin = fileType === "baseBin";
        const isCharBin = fileType === "charBin";
        const isMovesetBin = isBaseBin || isCharBin;
        // hsl stands for "Hexworkshop Structure Language" or something like that
        const hslHelper = hslTools_1.createHslHelper(markTerminators);
        const fileUsageHelper = fileUsageHelper_1.createFileUsageHelper(file.name, fileUint8Array, skipHeavyOperations);
        const ignoreUnusedPattern = "00";
        // Blobls of unknown size to be post-process expanded until next referenced position in file
        const toExpand = new Array();
        // The main part of parsing the bin file
        const insights = getInsights(charName);
        let header = null;
        let hitTableEntries = null;
        let unlistedMoveInputs = null;
        let unusedHitTableEntries = null;
        if (isMotion) {
            header = parseMotion({ insights, fileUint8Array, readTypeH });
        }
        else {
            console.assert(isMovesetBin);
            const parseMovesetResult = parseMovesetBin({
                fileUint8Array,
                fileUsageHelper,
                isCharBin,
                insights,
                readTypeH,
                ignoreUnusedPattern,
            });
            header = parseMovesetResult.header;
            hitTableEntries = parseMovesetResult.hitTableEntries;
            unlistedMoveInputs = parseMovesetResult.unlistedMoveInputs;
            unusedHitTableEntries = parseMovesetResult.unusedHitTableEntries;
        }
        // Detect overlaps
        const overlaps = fileUsageHelper.findOverlaps((fsa, fsb) => (
        // TODO: uncomment?
        // fsa.varPath.slice(0, 3).join(".") === "header.pArrayOfPtrsToInputCommands.->" &&
        // fsb.varPath.slice(0, 3).join(".") === "header.pArrayOfPtrsToInputCommands.->" &&
        // There are pointers that point to the same data, that's ok
        // TODO: compare readers?
        fsa.from === fsb.from &&
            fsa.to === fsb.to));
        if (overlaps.size > 0) {
            console.warn("There are ~%i overlaps: %O", overlaps.size, fileUsageHelper.makeFoundOverlapsReadable(overlaps));
        }
        if (!skipHeavyOperations) {
            expandUnknowns();
        }
        // Report unused chunks
        const unusedChunks = fileUsageHelper.findUnusedChunks(ignoreUnusedPattern).within;
        if (unusedChunks.length > 0) {
            hslHelper.markUnusedChunks(unusedChunks);
            let maxUnusedChunkSize = -Infinity;
            const totalUnusedSize = unusedChunks.reduce((acc, chunk) => {
                const chunkSize = chunk.to.dehexUint - chunk.from.dehexUint;
                maxUnusedChunkSize = Math.max(chunkSize, maxUnusedChunkSize);
                return acc + chunkSize;
            }, 0);
            const percentStr = "~" + (100 * totalUnusedSize / fileUint8Array.length).toFixed(2) + "%";
            console.warn(("There are %i unused non-empty chunks " +
                `(${totalUnusedSize} bytes / ${percentStr}; ` +
                `max chunk size ${maxUnusedChunkSize} bytes)`), unusedChunks.length, unusedChunks);
        }
        //
        return {
            isBaseBin,
            isCharBin,
            isMotion,
            charName,
            fileUint8Array,
            header,
            hitTableEntries,
            fileUsageHelper,
            overlaps,
            unusedChunks,
            unlistedMoveInputs,
            unusedHitTableEntries,
            // Having this as a getter lets you run the code by clicking on "(...)" in chrome console
            get saveHslString() {
                return saveHslString({ unused: true, showUnusedFirst: true });
            },
            get saveHslStringWithoutUnused() {
                return saveHslString({ unused: false });
            },
            get saveHslStringWithoutSortingUnused() {
                return saveHslString({ unused: true, showUnusedFirst: false });
            },
        };
        //
        function saveHslString(params) {
            const { hslCode, reportStr } = hslHelper.exportHslCode(`DOA5LR ${charName}.bin`, params);
            fsTools.saveAs(hslCode, `generated_${charName.replaceAll(" ", "_")}.hsl`);
            return `done; ` + reportStr;
        }
        function readTypeH(typeH, posStart, varPath) {
            const readHEnv = {
                fileUint8Array,
                getStructName: hslHelper.getStructName,
                getArrayTypeName: hslHelper.getArrayTypeName,
                getStructBodyLine: hslHelper.getStructBodyLine,
                markFileSection: fileUsageHelper.markFileSection,
                reportPtr: fileUsageHelper.reportPtr,
                rememberToExpand: e => { toExpand.push(e); },
                reportValidationFail,
            };
            return typeH_1.doReadTypeH(typeH, readHEnv, posStart, varPath, hslHelper.addHslString, hslHelper.addHslString, null);
        }
        function expandUnknowns() {
            toExpand.sortAscending(e => e.posStart.dehexUint);
            const getSize = fileUsageHelper.createGetSize();
            for (const e of toExpand) {
                const size = getSize(e.posStart.dehexUint);
                e.rawU8A = fileUint8Array.subarray(e.posStart.dehexUint, e.posStart.dehexUint + size);
            }
        }
        function reportValidationFail(varPath, pos, errorMessage) {
            console.warn(`Validation failed for ${genericTools_1.finalizeName(varPath)} ` +
                `at ${pos.asXHexStr}: ` +
                errorMessage);
        }
    }
    //
    // TODO: types
    function parseMovesetBin({ fileUint8Array, fileUsageHelper, insights, isCharBin, readTypeH, ignoreUnusedPattern, }) {
        // Detect and section end type
        // 1.02a has them, 1.10c doesn't
        const ignoreSectionEnd = !hasMagicAt(fileUint8Array, -magics.sectionEnd.aobLength, magics.sectionEnd);
        // Validate file ending
        const fileEndMagicParts = [magics.sectionStart];
        if (!ignoreSectionEnd) {
            fileEndMagicParts.push(magics.sectionEnd);
        }
        const fileEndMagic = fileEndMagicParts.join(" ");
        console.assert(hasMagicAt(fileUint8Array, -fileEndMagic.aobLength, fileEndMagic));
        //
        const { headerStruct, baseHeaderStruct, hitTableType, } = getStructs(insights, pos => fileUint8Array[pos]);
        const header = readTypeH(isCharBin ? headerStruct : baseHeaderStruct, 0, ["header"]);
        //
        const hitTableEntries = [];
        if (isCharBin) {
            // Can't find an easy way to detect array size when the array is being parsed,
            // so instead after header was parsed, manually dereference "pointers" to hit table entries
            header.v.pMoveInfosArray.d.v.forEach((v, catI) => {
                v.d.v.forEach((v, i) => {
                    const type = v.v.moveType.v.dehexUint;
                    if (type !== 0x02 && type !== 0x03)
                        return;
                    const indexInHitTable = v.v.secondId.v.dehexUint;
                    hitTableEntries.push(readTypeH(hitTableType, header.v.pHitTable.v.dehexUint + indexInHitTable * 0x74, [
                        "*(" +
                            "header.pHitTable + " +
                            "0x74 * " +
                            `header.pMoveInfosArray->[${catI}]->[${i}].secondId` +
                            ")",
                    ]));
                });
            });
        }
        //
        // All moveset bins seem to have certain magic in several places,
        // as if they mark different sections; but I'm not sure it's being used as there are pointers
        // that point to actual data within these sections.
        // Still, mark them down so they don't show up as "unused"
        markSections();
        // Analyze what was parsed and what was left unused
        // Unlisted move inputs
        const unlistedMoveInputs = findUnlistedMoveInputs(fileUsageHelper.findUnusedChunks(ignoreUnusedPattern, findRange(
        // allListedMoveInputs
        header.v.pArrayOfPtrsToInputCommands.d.v.map(v => v.d.v.map(v => v.d)).flatten())));
        // Unused hit table entries
        let unusedHitTableEntries = [];
        if (isCharBin) {
            const rangeOfHitUsedHitTableEntries = findRange(hitTableEntries);
            unusedHitTableEntries = findUnusedHitTableEntries({
                ...rangeOfHitUsedHitTableEntries,
                min: Math.min(rangeOfHitUsedHitTableEntries.min, header.v.pHitTable.v.dehexUint),
            });
        }
        // Unlisted ai combos
        // const aiCombosRange = [
        //     // TODO: include insight
        //     Math.min(
        //         fileUint8Array.length,
        //         ...(header as any).v.pAiData.d.v.pAiCombos.d.v.map(v => v.d.posStart.dehexUint),
        //     ),
        //     Math.max(
        //         0,
        //         ...(header as any).v.pAiData.d.v.pAiCombos.d.v.map(
        //             v => v.d.posStart.dehexUint + v.d.rawU8A.length,
        //         ),
        //     ),
        // ];
        // if (
        //     chunk.from >= aiCombosRange[0] &&
        //     chunk.to   <= aiCombosRange[1] &&
        //     unusedChunkConsistsOf(chunk, "28 00 00 00 00 00 00 00")
        // ) {
        //     return false;
        // }
        //
        return {
            header,
            hitTableEntries,
            unlistedMoveInputs,
            unusedHitTableEntries,
        };
        //
        function markSections() {
            const sectionStartAob = magics.sectionStart.dehexUintAob;
            const sectionEndAob = magics.sectionEnd.dehexUintAob;
            const positions = aobTools_1.findAobs(fileUint8Array, sectionStartAob, 0);
            positions.forEach((e, i) => {
                const end = aobTools_1.findAob(fileUint8Array, sectionEndAob, e + sectionStartAob.length);
                if (end === -1 && !ignoreSectionEnd)
                    throw new Error("section end not found");
                readTypeH(typeH_1.h.blob({ size: sectionStartAob.length }), e, ["sections", `[${i}]`, "start"]);
                if (end !== -1) {
                    readTypeH(typeH_1.h.blob({ size: sectionEndAob.length }), end, ["sections", `[${i}]`, "end"]);
                }
            });
        }
        function findUnlistedMoveInputs(chunksToCheck) {
            return [
                ...reduceChunks("after", chunksToCheck.after ? [chunksToCheck.after] : []),
                ...reduceChunks("within", chunksToCheck.within),
                ...reduceChunks("before", chunksToCheck.before ? [chunksToCheck.before] : []),
            ].reverse().map((e, i) => {
                return readTypeH(typeH_1.h.blob({ size: e.size }), e.pos, ["unlistedMoveInputs", `[${i}]`]);
            });
            function reduceChunks(type, unusedChunks) {
                if (!unusedChunks || unusedChunks.length === 0)
                    return [];
                const result = [];
                let j = unusedChunks.length - 1;
                let chunk = unusedChunks[j];
                let pos = chunk.to.dehexUint - 1;
                if (type === "after") {
                    while (pos > chunk.from.dehexUint &&
                        fileUint8Array[pos] === 0 &&
                        fileUint8Array[pos - 1] === 0) {
                        pos -= 1;
                    }
                    if (pos <= chunk.from.dehexUint + 1)
                        return result;
                }
                while (true) {
                    if (type === "before") {
                        if (fileUint8Array[pos] === 0 &&
                            fileUint8Array[pos - 1] === 0)
                            break;
                    }
                    const { size, result: readResult } = InputParser.readInput(pos, chunk.from.dehexUint, readPos => fileUint8Array[readPos]);
                    if (readResult.error) {
                        if (type === "after" && fileUint8Array[pos] === 0) {
                            pos -= 1;
                        }
                        else {
                            console.warn(`Failed to parse unlisted input at ${pos.asX_HexStr}:`, readResult.error, readResult);
                            pos = chunk.from.dehexUint - 1;
                        }
                    }
                    else {
                        result.push({
                            size: size,
                            pos: pos + 1 - size
                        });
                        pos -= size;
                    }
                    if (pos < chunk.from.dehexUint) {
                        j -= 1;
                        if (j < 0)
                            break;
                        chunk = unusedChunks[j];
                        pos = chunk.to.dehexUint - 1;
                    }
                }
                return result;
            }
        }
        function findUnusedHitTableEntries(chunksToCheck) {
            return fileUsageHelper.findUnusedChunks(ignoreUnusedPattern, chunksToCheck).within.reduce((acc, chunk) => {
                console.assert((chunk.to.dehexUint - chunk.from.dehexUint) % 0x74 === 0);
                const result = Array.from(fileUint8Array.subarray(chunk.from.dehexUint, chunk.to.dehexUint)).addDimension(0x74).map((subChunk, i) => readTypeH(hitTableType, chunk.from.dehexUint + i * 0x74, [`unusedHitTableEntry_${acc.length + i}`]));
                return [...acc, ...result];
            }, []);
            // TODO: also include chunksToCheck.after and chunksToCheck.before?
        }
    }
    //
    // TODO: types
    function parseMotion({ insights, fileUint8Array, readTypeH, }) {
        console.log("(this can take a minute...)");
        const { motionStruct } = getStructs(insights, pos => fileUint8Array[pos]);
        const header = readTypeH(motionStruct, 0, ["header"]);
        return header;
    }
    //
    function getInsights(charName) {
        const holdTableElements = {
            "kasumi": { holdTableElements: 14 },
            "alpha": { holdTableElements: 11 },
            "brad wong": { holdTableElements: 9 },
            "mila": { holdTableElements: 4 },
            "helena": { holdTableElements: 10 },
            "kokoro": { holdTableElements: 13 },
            "bayman": { holdTableElements: 16 },
            "christie": { holdTableElements: 8 },
            "rig": { holdTableElements: 5 },
            "jann lee": { holdTableElements: 11 },
            "zack": { holdTableElements: 10 },
            "ayane": { holdTableElements: 12 },
            "hayabusa": { holdTableElements: 15 },
            "nyotengu": { holdTableElements: 10 },
            "eliot": { holdTableElements: 11 },
            "tina": { holdTableElements: 12 },
            "lisa": { holdTableElements: 10 },
            "akira": { holdTableElements: 7 },
            "sarah": { holdTableElements: 13 },
            "bass": { holdTableElements: 12 },
            "leifang": { holdTableElements: 20 },
            "hitomi": { holdTableElements: 12 },
            "phase 4": { holdTableElements: 15 },
            "hayate": { holdTableElements: 12 },
            "raidou": { holdTableElements: 10 },
            "marie rose": { holdTableElements: 17 },
            "momiji": { holdTableElements: 5 },
            "gen fu": { holdTableElements: 10 },
            "pai": { holdTableElements: 19 },
            "jacky": { holdTableElements: 8 },
            "ein": { holdTableElements: 8 },
            "rachel": { holdTableElements: 4 },
            "leon": { holdTableElements: 10 },
            "honoka": { holdTableElements: 14 },
        };
        return {
            // BASE insights
            ...{
                "BASE": {
                    // 1.02a
                    baseCommandListElements: 0x654 / 0xC, // 0x654 / 0xC = 135 (0x87)
                    // 1.10c
                    // baseCommandListElements: 0x69C / 0xC, // 0x69C / 0xC = 141 (0x8D)
                },
            }[charName],
            // common insights
            // ...
            // char specific insights
            ...{
                "rig": {
                    throwTableElements: 0x140 / 0x28,
                    headerIdk6Elements: 0x2B00 / 16,
                    headerIdk12Elements: 0x68 / 0x8,
                    headerIdk13Elements: 0x30 / 0x8, // 6,
                    // additonalMarks: [
                    //     // ground attacks
                    //     { from: 0x4b_80, size: 0x00_01, varName: "ga_2_k" },
                    //     { from: 0x4b_a0, size: 0x00_01, varName: "ga_8_p_k" },
                    //     { from: 0x4b_c0, size: 0x00_01, varName: "ga_8_s" },
                    //     // move infos
                    //     // { from: 0x7a_10, size: 0x00_08, varName: "src_of_ai_move_01_20" },
                    //     // 0x00_91_30: pointer to info used by AI from section above "10 7A 00 00"
                    //     // 0x01_17_60: move description "00 00 03 00  08 D7 00 00  E8 03 18 00"
                    // ],
                },
                "bayman": {
                    headerIdk12Elements: 0x78 / 0x8,
                },
            }[charName],
            ...holdTableElements[charName],
        };
    }
    // DOA5LR structs
    function getStructs(insights, silentReadByte) {
        return {
            headerStruct: getHeaderStruct(),
            baseHeaderStruct: getBaseHeaderStruct(),
            hitTableType: getHitTableType(),
            motionStruct: getMotionHeaderStruct(),
        };
        // Entry point for motion files
        function getMotionHeaderStruct() {
            const insights = {
                motIdk2Size: 0x4C8 / 4,
            };
            const unknown = typeH_1.h.blob({ size: typeH_1.unknownBlobSize });
            const relToMotIdk1 = {
                getOffset: (parent) => {
                    const parentStructPtr = parent._parent._parent;
                    return parentStructPtr.v.motBase.posStart.dehexUint;
                },
            };
            return typeH_1.h.struct([
                [
                    "unknown",
                    typeH_1.h.blob({ size: 0x40 }, [
                        "63 68 61 72 5F 64 61 74 00 00 01 01 30 00 00 00 " +
                            "00 22 30 00 01 00 00 00 01 00 00 00 00 00 00 00 " +
                            "30 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 " +
                            "40 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00"
                    ]),
                ], [
                    "motBase",
                    typeH_1.h.blob({ size: 0x20 }, [
                        "63 68 61 72 5F 64 61 74 00 00 01 01 30 00 00 00 " +
                            "C0 21 30 00 07 00 00 00 06 00 00 00 00 00 00 00"
                    ]),
                ],
                [
                    "pMotionSubHeader",
                    typeH_1.h.ptr(typeH_1.h.struct([
                        [
                            // pointers to actual animation data
                            "pPtrsToAnimations",
                            typeH_1.h.ptr(typeH_1.h.array(
                            // FIXME: this is only correct for Rig
                            { elementsCount: insights.motIdk2Size }, typeH_1.h.ptr(
                            // array of 189 entries
                            // each entry = ptr to timeline of animated property?
                            // e.g. root.pos.x, root.rot.x, ...
                            typeH_1.h.array({ elementsUntil: ["00 00 00 00"] }, typeH_1.h.ptr(unknown, 
                            // h.blob({ size: 13 }), // FIXME: and then more
                            // h.struct([
                            //     ["zero", h.zero(1)],
                            //     ["type", h.uint(1, [2, 3, 7])]
                            //     // ...
                            // ]),
                            { getOffset: parent => parent._parent._parent._parent.v.dehexUint })), { getOffset: parent => parent._parent.v.dehexUint })), {
                                getOffset: (parent) => {
                                    const parentStruct = parent._parent._parent;
                                    return parentStruct.v.motBase.posStart.dehexUint;
                                },
                            }),
                        ],
                        ["zero", typeH_1.h.zero(4)],
                        ["pMotIdk3", typeH_1.h.ptr(unknown, relToMotIdk1)],
                        ["pMotIdk4", typeH_1.h.ptr(unknown, relToMotIdk1)],
                        ["pMotIdk5", typeH_1.h.ptr(unknown, relToMotIdk1)],
                        [
                            // map of anim id -> index from pPtrsToAnimations
                            "pAnimationIndexPerAnimationId",
                            typeH_1.h.ptr(typeH_1.h.struct([
                                ["elementsCount", typeH_1.h.uint(4)],
                                [
                                    "elements",
                                    typeH_1.h.array({ getElementsCount: (parent) => parent.v.elementsCount.v.dehexUint }, typeH_1.h.struct([
                                        ["animId", typeH_1.h.uint(4)],
                                        // Index to use in pPtrsToAnimations
                                        ["index", typeH_1.h.uint(4)],
                                    ])),
                                ],
                            ]), relToMotIdk1),
                        ],
                        [
                            // some additional info per anim id?
                            "pExtraInfoPerAnimId",
                            typeH_1.h.ptr(typeH_1.h.array({
                                getShouldContinue: (i, pos, fileUint8Array) => {
                                    if (pos + 8 > fileUint8Array.length) {
                                        console.assert(false);
                                        return false;
                                    }
                                    return fileUint8Array.subarray(pos, pos + 2).asAobStr !== "FF FF";
                                },
                            }, typeH_1.h.struct([
                                ["animId", typeH_1.h.uint(4)],
                                ["unknown", typeH_1.h.blob({ size: 2 })],
                                ["payloadDwordsCount", typeH_1.h.uint(1)],
                                ["unknown2", typeH_1.h.blob({ size: 1 })],
                                [
                                    "payload",
                                    typeH_1.h.array({ getElementsCount: (parent) => parent.v.payloadDwordsCount.v.dehexUint }, typeH_1.h.blob({ size: 4 }), { dontReportEmpty: true }),
                                ]
                            ])), relToMotIdk1),
                        ],
                    ]), { getOffset: (parent) => parent.v.motBase.posStart.dehexUint }),
                ],
            ]);
        }
        // Entry point for the base.bin (different from a someParticularCharacter.bin)
        function getBaseHeaderStruct() {
            return typeH_1.h.struct([
                ["magic", typeH_1.h.uint(4, [magics.baseBinStart.dehexUint])],
                ["pArrayOfPtrsToInputCommands", typeH_1.h.ptr(getArrayOfPtrsToInputCommandsType())],
                ["zeros1", typeH_1.h.array({ elementsCount: 0x48 / 4 }, typeH_1.h.zero(4))],
                ["pBaseSubHeader", typeH_1.h.ptr(getBaseSubHeaderType())],
                ["pTimelines", typeH_1.h.ptr(getTimelinesType())],
                ["zeros2", typeH_1.h.array({ elementsCount: 2 }, typeH_1.h.zero(4))],
                ["pAnimsOrder", typeH_1.h.ptr(typeH_1.h.array({ elementsUntil: ["FF FF FF FF"] }, typeH_1.h.uint(4)))],
                ["zeros3", typeH_1.h.array({ elementsCount: 0x24 / 4 }, typeH_1.h.zero(4))],
                ["pCharacterOverrides", typeH_1.h.ptr(getCharacterOverridesType())],
                ["pMoveInfos", typeH_1.h.ptr(getMoveInfosCategoryType())],
                ["zeros4", typeH_1.h.array({ elementsCount: 2 }, typeH_1.h.zero(4))],
                ["pBaseCommandList",
                    typeH_1.h.ptr(
                    // partially resembles pCommandListPtrs
                    typeH_1.h.array({ elementsCount: insights.baseCommandListElements ?? 0 }, typeH_1.h.struct([
                        ["pInputStr", typeH_1.h.ptr(typeH_1.h.zString())],
                        ["pHeightsStr", typeH_1.h.ptr(typeH_1.h.zString())],
                        ["unknown1", typeH_1.h.uint(1)],
                        ["zero1", typeH_1.h.zero(1)],
                        ["unknown2", typeH_1.h.uint(1, [0x0, 0x3])],
                        ["zero2", typeH_1.h.zero(1)],
                    ]))),
                ],
                ["zero5", typeH_1.h.zero(4)],
            ]);
        }
        function getBaseSubHeaderType() {
            // pointers until 00000000 to ... various kinds of data, one of which is getAiComboType()?
            // [0..77] = ptrs to stuff,
            // [78..155] = ptrs to where the respective stuff from 0...77 is no more
            const createTempType = (arg) => arg;
            const type1 = createTempType({ elementsUntil: "FFFF0000FFFF00000000000000000000" });
            const type2 = createTempType({ elementSize: 0x4 }); // total bytes: 0x01B8
            const type3 = createTempType({ elementSize: 0x2 }); // total bytes: 0x0030 // (post ground stuff?)
            const type4 = createTempType({ elementSize: 0x2 }); // total bytes: 0x000C // (post ground stuff?)
            const type5 = createTempType({ elementSize: 0x18 }); // total bytes: 0x18d8
            const type6 = createTempType({ elementSize: 0xc }); // total bytes: 0x03cc
            const type7 = createTempType({ elementsUntil: "FF000000FFFF0000FFFF0000" });
            const type8 = createTempType({ elementsUntil: "FFFFFFFF" });
            const type9 = createTempType({ elementsUntil: "FF000000FFFF0000" });
            const type10 = createTempType({ elementsUntil: "FFFF" });
            const type11 = createTempType({ elementSize: 0xC }); // total bytes: 0x3C
            const type12 = createTempType({ elementsUntil: "FFFF0000000000000000000000000000" });
            const type13 = createTempType({ constValue: "FF000000FFFF0000FFFF0000" });
            const type14 = createTempType({ constValue: "FF000000FFFF000000000000" });
            const type15 = createTempType({ elementSize: 0x3c }); // total bytes: 0x348
            const type16 = createTempType({ elementSize: 0xc }); // total bytes: 0x15C
            const type17 = createTempType({ elementSize: 0x1 }); // total bytes: 0x165 // wtf
            const type18 = createTempType({ elementsUntil: "FF00000000000000" });
            const type19 = createTempType({ elementSize: 0x14 }); // total bytes: 0xADC
            const type20 = createTempType({ elementSize: 0x4 }); // total bytes: 0x050
            const type21 = createTempType({ elementsUntil: "FF000000FFFF0000FFFF0000FFFF0000FFFF0000000000000000000000000000" });
            const type22 = createTempType({ elementSize: 0x14 }); // total bytes: 0x2F8
            const type23 = createTempType({ elementsUntil: "FF00FFFF00000000" });
            const type24 = createTempType({ elementSize: 0x2C }); // total bytes: 0x39c0
            const type25 = createTempType({ elementSize: 0x18 }); // total bytes: 0x0090
            const type26 = createTempType({ elementSize: 0x14 }); // total bytes: 0x06f4
            const type27 = createTempType({ elementsUntil: "FF000000FFFF000000000000" });
            const type28 = createTempType({ elementsUntil: "FF000000FFFF0000000000000000000000000000" });
            const type29a = createTempType({ elementsUntil: "FFFF00000000000000000000" });
            const type29b = createTempType({ elementsUntil: "FFFF000000000000" });
            const type30 = createTempType({ elementSize: 0x4 }); // total bytes: 0x40
            const typesOrder = [
                type1,
                type1,
                type1,
                type1,
                type1,
                type1,
                type1,
                type1,
                type1,
                type1,
                type2,
                type3,
                type3,
                type3,
                type4,
                type5,
                type6,
                type7,
                type1,
                type1,
                type8,
                type1,
                type1,
                type9,
                type9,
                type1,
                type10,
                type11,
                type10,
                type12,
                type8,
                type13,
                type9,
                type14,
                type1,
                type1,
                type1,
                type1,
                type1,
                type1,
                type1,
                type1,
                type1,
                type1,
                type15,
                type16,
                type4,
                type17,
                type18,
                type18,
                type1,
                type19,
                type1,
                type20,
                type1,
                type21,
                type22,
                type23,
                type24,
                type25,
                type26,
                type1,
                type1,
                type1,
                type1,
                type27,
                type28,
                type9,
                type29a,
                type29a,
                type29b,
                type9,
                type1,
                type1,
                type1,
                type1,
                type30,
                type7, // index 77
            ];
            const getStartName = (i) => `pData${i}_start`;
            const getEndName = (i) => `pData${i}_end`;
            return typeH_1.h.struct([
                ...typesOrder.map((e, i) => [getStartName(i), createGetType(e, i)]),
                ...typesOrder.map((e, i) => [getEndName(i), typeH_1.h.uint(consts_1.ptrSize)]),
                ["zero", typeH_1.h.zero(4)],
            ]);
            function createGetType(e, i) {
                return typeH_1.h.ptr(parent => {
                    const endsAt = parent.v[getEndName(i)].v.dehexUint;
                    if ("elementsUntil" in e) {
                        const terminator = e.elementsUntil.dehexUintAob.map(e => e.asAobStr).join(" ");
                        const elementSize = terminator.aobLength;
                        return typeH_1.h.struct([
                            ["payload", typeH_1.h.array({ elementsUntilPtr: endsAt - elementSize }, typeH_1.h.blob({ size: elementSize }))],
                            ["terminator", typeH_1.h.blob({ size: elementSize }, [terminator])],
                        ]);
                    }
                    else if ("elementSize" in e) {
                        return typeH_1.h.array({ elementsUntilPtr: endsAt }, typeH_1.h.blob({ size: e.elementSize }));
                    }
                    else if ("constValue" in e) {
                        const expectedValue = e.constValue.dehexUintAob.map(e => e.asAobStr).join(" ");
                        return typeH_1.h.blob({ size: expectedValue.aobLength }, [expectedValue]);
                    }
                    throw new Error("Unexpected argument");
                });
            }
        }
        // Entry point for the someParticularCharacter.bin
        // as of v1.02a steam, this seems to be loaded to
        // ([(p2 ? 0 : 1 ) * 0x488+game.exe+D7BB5D] * 0x27 + 0x02) * 4 + game.exe + 1DFF398 - 8
        // so pointer pHitTable will be found at that addr + 8
        function getHeaderStruct() {
            const throwAndHoldInfosType = getThrowsAndHoldsInfosType();
            const collisionSphereType = typeH_1.h.array({ elementsUntil: ["00 00 00 00"] }, typeH_1.h.ptr(typeH_1.h.struct([
                ["unknown", typeH_1.h.uint(2)],
                ["zero", typeH_1.h.zero(2)],
                // XYZ
                ["offset", typeH_1.h.array({ elementsCount: 3 }, typeH_1.h.float())],
                ["radius", typeH_1.h.float()],
            ])));
            const collisionCapsuleType = typeH_1.h.array({ elementsUntil: ["00 00 00 00"] }, typeH_1.h.ptr(typeH_1.h.struct([
                ["unknown", typeH_1.h.uint(2)],
                ["zero", typeH_1.h.zero(2)],
                ["offsetStart", typeH_1.h.array({ elementsCount: 3 }, typeH_1.h.float())],
                ["offsetEnd", typeH_1.h.array({ elementsCount: 3 }, typeH_1.h.float())],
                ["radius", typeH_1.h.float()],
            ])));
            const collisionIdkType = typeH_1.h.array({ elementsUntil: ["00 00 00 00"] }, 
            // TODO: structure
            // array of elements of 3 bytes until "FF"; 1st byte tells where to copy (0..14, id of the bone?) the next 2 bytes
            // For rig:
            //  1st byte is 0..14 - id of bone/socket?
            //  2nd byte is always 01
            //  3rd byte from 00 to 1B but there are gaps (tells index of data to use from pCollision*, e.g. pCollision1_spheres1 for hitboxes)
            //  Also 3rd byte mostly matches 1st byte (but not always)
            typeH_1.h.ptr(typeH_1.bytesUntilFFType));
            const { pCommandListPtrsType, pCommandListSizesType, } = getCommandListTypes();
            return typeH_1.h.struct([
                ["magic", typeH_1.h.uint(4, [magics.charBinStart.dehexUint])],
                ["pArrayOfPtrsToInputCommands", typeH_1.h.ptr(getArrayOfPtrsToInputCommandsType())],
                ["pHitTable", typeH_1.h.ptr(typeH_1.dontDereferencePtr)],
                ["pHoldTable", typeH_1.h.ptr(typeH_1.h.array({ elementsCount: insights.holdTableElements ?? 1 }, typeH_1.h.struct([
                        ["highP", typeH_1.h.uint(2)],
                        ["highK", typeH_1.h.uint(2)],
                        ["midP", typeH_1.h.uint(2)],
                        ["midK", typeH_1.h.uint(2)],
                        ["lowP", typeH_1.h.uint(2)],
                        ["lowK", typeH_1.h.uint(2)],
                        // TODO: validate that it's either 0 or dup
                        // Presumably the same for the opposite stance?
                        ["legacy_highP", typeH_1.h.uint(2)],
                        ["legacy_highK", typeH_1.h.uint(2)],
                        ["legacy_midP", typeH_1.h.uint(2)],
                        ["legacy_midK", typeH_1.h.uint(2)],
                        ["legacy_lowP", typeH_1.h.uint(2)],
                        ["legacy_lowK", typeH_1.h.uint(2)],
                    ]))),
                ],
                ["pGroundHitTable", typeH_1.h.ptr(getGroundHitTableType())],
                // Something to do with ground attacks
                // Is read when ground attack lands on opponent who's waking up
                // perhaps move ids, based on orientation?
                ["pPostGroundHitTable", typeH_1.h.ptr(typeH_1.h.blob({
                        elementsWhile: [
                            "?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? 9D 61 9E 61",
                            // "03 7D 03 7D 03 7D 04 7D 04 7D 04 7D 9D 61 9E 61", // rachel
                            // "07 7D 07 7D 07 7D 08 7D 08 7D 08 7D 9D 61 9E 61", // tengu
                            // "0A 7D 0A 7D 0A 7D 0B 7D 0B 7D 0B 7D 9D 61 9E 61", // jann lee
                            // "16 7D 16 7D 16 7D 17 7D 17 7D 17 7D 9D 61 9E 61", // zack
                            // "6F 61 70 61 71 61 72 61 73 61 74 61 9D 61 9E 61", // common
                            // "F4 61 F5 61 F6 61 F7 61 F8 61 F9 61 9D 61 9E 61", // common
                            //  ^^^^^ ^^^^^ ^^^^^ ^^^^^ ^^^^^ ^^^^^ ^^^^^ ^^^^^
                        ],
                    }))],
                ["pThrowInfos", typeH_1.h.ptr(throwAndHoldInfosType)],
                ["pHoldInfos", typeH_1.h.ptr(throwAndHoldInfosType)],
                ["zero1", typeH_1.h.zero(4)],
                ["pAiData", typeH_1.h.ptr(getAiDataType())],
                ["pAiData_dup1", typeH_1.h.ptr(typeH_1.dontDereferencePtr), validators_1.validateDupOf("pAiData")],
                ["pAiData_dup2", typeH_1.h.ptr(typeH_1.dontDereferencePtr), validators_1.validateDupOf("pAiData")],
                ["pAiData_dup3", typeH_1.h.ptr(typeH_1.dontDereferencePtr), validators_1.validateDupOf("pAiData")],
                // hitboxes, hurtboxes and pushboxes?
                ["pCollision1_spheres1", typeH_1.h.ptr(collisionSphereType)],
                ["pCollision1_capsules", typeH_1.h.ptr(collisionCapsuleType)],
                ["pCollision1_spheres2", typeH_1.h.ptr(collisionSphereType)],
                ["pCollision2_spheres1", typeH_1.h.ptr(collisionSphereType)],
                ["pCollision2_capsules", typeH_1.h.ptr(collisionCapsuleType)],
                ["pCollision2_spheres2", typeH_1.h.ptr(collisionSphereType)],
                ["pCollisionIdk", typeH_1.h.ptr(collisionIdkType)],
                [
                    "pIdk6",
                    typeH_1.h.ptr(typeH_1.h.array({ elementsCount: insights.headerIdk6Elements ?? 1 }, typeH_1.h.blob({ size: 16 }))),
                ],
                // Something to do with animations and sounds
                ["pTimelines", typeH_1.h.ptr(getTimelinesType())],
                ["zero2", typeH_1.h.zero(4)],
                ["zero3", typeH_1.h.zero(4)],
                ["pAnimsOrder", typeH_1.h.ptr(typeH_1.h.array({ elementsUntil: ["FF FF FF FF"] }, typeH_1.h.uint(4)))],
                ["pIdk9", typeH_1.h.ptr(typeH_1.h.blob({ size: typeH_1.unknownBlobSize }))],
                ["pIdk10", typeH_1.h.ptr(typeH_1.h.blob({ size: typeH_1.unknownBlobSize }))],
                // bayman got 4 bytes here, "CD CC 4C 3E", no terminator
                // rig got nothing here (2 lines of 0s)
                ["pIdk11", typeH_1.h.ptr(typeH_1.h.blob({ size: typeH_1.unknownBlobSize }))],
                ["pIdk12", typeH_1.h.ptr(getIdk12Type())],
                ["pIdk98", typeH_1.h.ptr(getIdk98Type())],
                // points to throw move Ids + some data
                // completely broken for mila, marie and honoka
                // non-fixed length, no terminator
                // for marie and honoka, structure seems to resemble *(pCommandListPtrs[])
                ["pIdk13", typeH_1.h.ptr(getIdk13Type())],
                // for jann lee, 2 pointers to "00" and "0A"
                // for everyone else, 1 pointer to "00"
                ["pIdk14", typeH_1.h.ptr(typeH_1.h.array({ elementsUntil: ["FF FF FF FF"] }, typeH_1.h.ptr(typeH_1.bytesUntilFFType)))],
                ["pThrowTable", typeH_1.h.ptr(getThrowTableType())],
                ["pMoveInfosArray", typeH_1.h.ptr(getMoveInfosArrayType())],
                ["pCharacterOverrides", typeH_1.h.ptr(getCharacterOverridesType())],
                ["zero4", typeH_1.h.zero(4)],
                ["pCommandListPtrs", pCommandListPtrsType],
                ["pCommandListSizes", pCommandListSizesType],
                ["zero5", typeH_1.h.zero(4)],
                ["zero6", typeH_1.h.zero(4)],
            ]);
        }
        function getHitTableType() {
            // const elementsCount = Math.max(
            //     ...genTools.getAllMoveIdsFromMoveInfos(parsed.bins.rig).map(
            //         moveId => genTools.getMoveInfo(parsed.bins.rig, moveId)
            //     ).groupBy(
            //         e => e.rawU8A[2].asAobStr,
            //     ).sortAscending(e => e.value).map(e => {
            //         return {
            //           value: e.value,
            //           min: Math.min(...e.matches.map(m => m.rawU8A[3] === 255 ?  Infinity : m.rawU8A[3])),
            //           max: Math.max(...e.matches.map(m => m.rawU8A[3] === 255 ? -Infinity : m.rawU8A[3])),
            //         };
            //     }).filter(e => e.value === "02" || e.value === "03").map(e => e.max + 1)
            // );
            // size = 0x74 bytes
            return typeH_1.h.struct([
                // stun move id examples: EB 5D = lift stun, 3F 5E = sit-down stun
                ["nh", typeH_1.h.uint(2)], ["zero01", typeH_1.h.zero(2)],
                ["legacyBtNh", typeH_1.h.uint(2)], ["zero02", typeH_1.h.zero(2)],
                ["block", typeH_1.h.uint(2)], ["zero03", typeH_1.h.zero(2)],
                ["ch", typeH_1.h.uint(2)], ["zero04", typeH_1.h.zero(2)],
                ["btCh", typeH_1.h.uint(2)], ["zero05", typeH_1.h.zero(2)],
                // changing this is enough to change critical reversal reaction
                // but changing moveInfo that corresponds to this value doesn't affect it
                // because depending on open/closed stance value can be increased by 1 and I was changing wrong one?..
                // critical reversal is this + 0x204?..
                ["hch", typeH_1.h.uint(2)], ["zero06", typeH_1.h.zero(2)],
                ["btHch", typeH_1.h.uint(2)], ["zero07", typeH_1.h.zero(2)],
                ["crouchNh", typeH_1.h.uint(2)], ["zero08", typeH_1.h.zero(2)],
                ["legacyCrouchBtNh", typeH_1.h.uint(2)], ["zero09", typeH_1.h.zero(2)],
                ["crouchBlock", typeH_1.h.uint(2)], ["zero10", typeH_1.h.zero(2)],
                ["crouchCh", typeH_1.h.uint(2)], ["zero11", typeH_1.h.zero(2)],
                ["crouchBtCh", typeH_1.h.uint(2)], ["zero12", typeH_1.h.zero(2)],
                ["crouchHch", typeH_1.h.uint(2)], ["zero13", typeH_1.h.zero(2)],
                ["crouchBackHch", typeH_1.h.uint(2)], ["zero14", typeH_1.h.zero(2)],
                ["juggle", typeH_1.h.uint(2)], ["zero15", typeH_1.h.zero(2)],
                ["juggleBt", typeH_1.h.uint(2)], ["zero16", typeH_1.h.zero(2)],
                ["groundHitG86", typeH_1.h.uint(2)], ["zero17", typeH_1.h.zero(2)],
                ["groundHitG8R", typeH_1.h.uint(2)], ["zero18", typeH_1.h.zero(2)],
                ["groundHitG24", typeH_1.h.uint(2)], ["zero19", typeH_1.h.zero(2)],
                ["groundHitG2R", typeH_1.h.uint(2)], ["zero20", typeH_1.h.zero(2)],
                ["moveType1", typeH_1.h.uint(2)],
                ["moveType2", typeH_1.h.uint(2)],
                // but doesn't apply e.g. on block (unless it's gb) or on hit that caused wall bounce (wall ricochet is fine)
                ["moveIdOnHit", typeH_1.h.uint(2)],
                ["zero21", typeH_1.h.zero(2)],
                // for all rig's strikes it's 0x9, except his post-charge pb(super) which has value 0
                ["hitTableIdk1", typeH_1.h.uint(1, [0, 9])],
                ["disadvantageBlock", typeH_1.h.uint(1)],
                ["disadvantageNh", typeH_1.h.uint(1)],
                ["disadvantageCh", typeH_1.h.uint(1)],
                ["disadvantageHch", typeH_1.h.uint(1)],
                // for most rig's strikes (320/348) has value of 0, for rest = 1
                ["hitTableIdk2", typeH_1.h.uint(1, [0, 1])],
                // for most rig's strikes (291/348) has value of 0, for rest = 1
                ["hitTableIdk3", typeH_1.h.uint(1, [0, 1])],
                ["dmg", typeH_1.h.uint(1)],
                ["knocbkack", typeH_1.h.float()],
                ["hitTableMagic1", typeH_1.h.uint(4, ["9A 99 99 3E".dehexUint])],
                // for most rig's strikes (284/348) has value of 0, for rest = 1
                ["hitTableIdk5", typeH_1.h.uint(1, [0, 1])],
                ["knockbackForCounterPlusOnly", typeH_1.h.uint(1, [0, 1])],
                ["hitTableMagic2", typeH_1.h.uint(1, [1])],
                ["tracking", typeH_1.h.uint(1, [0, 1])],
                ["zero22", typeH_1.h.zero(4)],
                ["zero23", typeH_1.h.zero(4)],
            ]);
        }
        function getThrowTableType() {
            return typeH_1.h.array({ elementsCount: insights.throwTableElements ?? 1 }, typeH_1.h.struct([
                ["nhReaction", typeH_1.h.uint(2)],
                ["chReaction", typeH_1.h.uint(2)],
                ["btNhReaction", typeH_1.h.uint(2)],
                ["btChReaction", typeH_1.h.uint(2)],
                ["throwTableIdk1", typeH_1.h.blob({ size: 8 })],
                ["throwTableIdk2", typeH_1.h.uint(4, [0xFF_FF_FF_FF])],
                ["throwTableIdk3", typeH_1.h.uint(4, [0xFF_FF_FF_FF])],
                ["throwTableIdk4", typeH_1.h.uint(4, [0xFF_FF_FF_FF])],
                ["throwTableIdk5", typeH_1.h.uint(4, [0xFF_FF_FF_FF])],
                ["throwTableIdk6", typeH_1.h.blob({ size: 8 })],
            ]));
        }
        function getGroundHitTableType() {
            return typeH_1.h.array({
                elementsUntil: [
                    "00 00 00 00 FF FF FF FF 00 00 00 00 00 00 00 00 " +
                        "00 00 00 00 00 00 00 00 FF FF FF FF 01 00 00 00"
                ],
            }, typeH_1.h.struct([
                ["groundHitTableIdk1", typeH_1.h.blob({ size: 4 })],
                [
                    "pGroundHitDamage",
                    typeH_1.h.ptr(typeH_1.h.array({ elementsUntil: ["FF"] }, typeH_1.h.uint(1))),
                ],
                ["groundHitTableIdk2", typeH_1.h.blob({ size: 0x10 })],
                ["missMoveId", typeH_1.h.uint(2)],
                ["hitMoveId", typeH_1.h.uint(2)],
                ["groundHitTableIdk3", typeH_1.h.blob({ size: 4 })],
            ]));
        }
        function getThrowsAndHoldsInfosType() {
            return typeH_1.h.array({
                elementsUntil: [
                    "00 00 00 00 00 00 00 00 FF FF FF FF 00 00 00 00 " +
                        "00 00 00 00 00 00 00 00",
                ],
            }, typeH_1.h.struct([
                ["unknownFloat", typeH_1.h.float()],
                ["unknownFlag1", typeH_1.h.uint(1, [0, 1])],
                ["unknownFlag2", typeH_1.h.uint(1, [0, 1])],
                ["zero1", typeH_1.h.zero(1)],
                ["zero2", typeH_1.h.zero(1)],
                ["pDmgs", typeH_1.h.ptr(typeH_1.h.array({ elementsUntil: ["FF"] }, typeH_1.h.uint(1)))],
                ["zero3", typeH_1.h.zero(1)],
                ["canWallsplat", typeH_1.h.uint(1, [0, 1])],
                ["zero4", typeH_1.h.zero(2)],
                ["knockback", typeH_1.h.float()],
                ["unknown1", typeH_1.h.uint(2)],
                ["unknown2", typeH_1.h.uint(2)],
            ]));
        }
        function getIdk13Type() {
            return typeH_1.h.array({ elementsCount: insights.headerIdk13Elements ?? 1 }, typeH_1.h.struct([
                ["throwMoveId", typeH_1.h.uint(2)],
                ["zero1", typeH_1.h.zero(2)],
                ["zero2", typeH_1.h.zero(1)],
                ["one", typeH_1.h.uint(1, [1])],
                ["zero3", typeH_1.h.zero(2)],
            ]));
        }
        // 
        function getArrayOfPtrsToInputCommandsType() {
            return typeH_1.h.array({ elementsUntil: ["00 00 00 00"] }, typeH_1.h.ptr(typeH_1.h.array({ elementsUntil: ["00 00 00 00"] }, typeH_1.h.ptr(
            // move input
            typeH_1.h.blob({
                getBlobProps: posStart => {
                    const { size, result } = InputParser.readInput(posStart, 0, silentReadByte);
                    // TODO: move out from "get props" and use reportValidationFail
                    if (result.error) {
                        console.warn(`Failed to parse input at ${posStart.asX_HexStr}:`, result.error, result);
                    }
                    return {
                        size,
                        payloadPosMin: posStart + 1 - size,
                    };
                },
            })), { dontReportEmpty: true })));
        }
        //
        // no terminator, not fixed size
        function getIdk12Type() {
            return typeH_1.h.array({ elementsCount: insights.headerIdk12Elements ?? 1 }, typeH_1.h.struct([
                ["idk12idk1", typeH_1.h.uint(1, [0])],
                ["idk12idk2", typeH_1.h.uint(1, [0, 1, 0xFF])],
                ["idk12idk3", typeH_1.h.uint(2, [0x00_FF])],
                ["idk12idk4", typeH_1.h.uint(4, [0x3F_8C_CC_CD])], // a float?
            ]));
        }
        function getIdk98Type() {
            return typeH_1.h.array({ elementsUntil: ["FF FF 00 00 00 00 00 00"] }, typeH_1.h.struct([
                ["unknown1", typeH_1.h.uint(2)],
                ["zero1", typeH_1.h.zero(2)],
                ["unknown2", typeH_1.h.uint(2)],
                ["zero2", typeH_1.h.zero(2)],
            ]), { dontReportEmpty: true });
        }
        // ai data
        // messing with this can break "sidestep option" select from char select screen
        function getAiDataType() {
            // Duplicates:
            // alpha, hayabusa, nyotengu, phase 4, raidou, marie rose, momiji, jacky, rachel, leon, honoka
            // pIdk19[[0, 1, 2, 3, 4, 5, 6]]
            // pIdk21[[0, 1, 2, 3, 4, 5, 6]]
            // pIdk20[[0, 1, 2, 3, 4, 5, 6]]
            // ayane, sarah, leifang
            // pIdk19[[0, 3, 4, 5], [1], [2], [6]]
            // pIdk21[[0, 3, 4, 5], [1], [2], [6]]
            // pIdk20[[0, 1, 2, 3, 4, 5], [6]]
            // bayman, eliot, hayate
            // pIdk19[[0, 5, 6], [1], [2], [3], [4]]
            // pIdk21[[0, 5, 6], [1], [2], [3], [4]]
            // pIdk20[[0, 1, 2, 3, 4, 5, 6]]
            // mila, christie, lisa
            // pIdk19[[0], [1], [2], [3], [4], [5], [6]]
            // pIdk21[[0], [1], [2], [3], [4], [5], [6]]
            // pIdk20[[0, 1, 2, 3, 4, 5], [6]]
            // kasumi, hitomi
            // pIdk19[[0, 5], [1], [2], [3], [4], [6]]
            // pIdk21[[0, 5], [1], [2], [3], [4], [6]]
            // pIdk20[[0, 1, 2, 3, 4, 5], [6]]
            // helena, pai
            // pIdk19[[0, 1, 2, 3, 4, 5], [6]]
            // pIdk21[[0, 1, 2, 3, 4, 5], [6]]
            // pIdk20[[0, 1, 2, 3, 4, 5], [6]]
            // rig, brad wong
            // pIdk19[[0, 4, 5, 6], [1], [2], [3]]
            // pIdk21[[0, 4, 5, 6], [1], [2], [3]]
            // pIdk20[[0, 1, 2, 3, 4, 5, 6]]
            // kokoro
            // pIdk19[[0, 3, 4, 5], [1], [2], [6]]
            // pIdk21[[0, 3, 4, 5], [1], [2], [6]]
            // pIdk20[[0, 1, 3, 4, 5], [2], [6]]
            // jann lee
            // pIdk19[[0, 3, 4, 5, 6], [1], [2]]
            // pIdk21[[0, 3, 4, 5, 6], [1], [2]]
            // pIdk20[[0, 1, 2, 3, 4, 5, 6]]
            // zack
            // pIdk19[[0], [1], [2], [3], [4], [5], [6]]
            // pIdk21[[0], [1], [2], [3], [4], [5], [6]]
            // pIdk20[[0, 1, 2, 3, 4, 5, 6]]
            // tina
            // pIdk19[[0, 4, 5], [1], [2], [3], [6]]
            // pIdk21[[0, 4, 5], [1], [2], [3], [6]]
            // pIdk20[[0, 1, 2, 3, 4, 5], [6]]
            // akira
            // pIdk19[[0, 2, 3, 4, 5, 6], [1]]
            // pIdk21[[0, 2, 3, 4, 5, 6], [1]]
            // pIdk20[[0, 1, 2, 3, 4, 5, 6]]
            // bass
            // pIdk19[[0, 5, 6], [1], [2], [3], [4]]
            // pIdk21[[0, 5, 6], [1], [2], [3], [4]]
            // pIdk20[[0, 1, 2, 4, 5, 6], [3]]
            // gen fu
            // pIdk19[[0, 3, 4, 5, 6], [1], [2]]
            // pIdk21[[0, 3, 4, 5, 6], [1], [2]]
            // pIdk20[[0, 3, 4, 5, 6], [1], [2]]
            // ein
            // pIdk19[[0, 2, 3, 4, 5, 6], [1]]
            // pIdk21[[0, 2, 3, 4, 5, 6], [1]]
            // pIdk20[[0, 2, 3, 4, 5, 6], [1]]
            const terminator = "00 00 00 00 FF FF 00 00 09 00 00 00";
            const idk19AndIdk20SubType = typeH_1.h.array({ elementsUntil: [terminator] }, 
            // momiji:
            // total of 28+16+22 = 66 pointers to lists, 64 are unique
            // 64 unique pointers to arrays accumulate 461 elements, 257 are unique
            // XX 00 00 00 YY 00 00 00 05 ZZ 00 00
            // XX = one of 00 05 0A 0F 14 19 1E 28 32 3C 46 50 5A 64
            // YY = one of 01 02 03 04 05 06 07 08 09 0A       0D 0E 0F 10
            //             11 12 13 14 15 16 17 18 19 1A 1B 1C    1E 1F 20
            //             21       24 25 26 27 28    2A 2B 2C 2D    2F
            //                   33 34                      3C    3E 3F
            //                      44                4A 4B             50
            //                52 53          57 58          5C    5E 5F 60
            //                                  68    6A    6C 6D    6F 70
            //             71    73 74 75 76 77 78 79 7A 7B 7C 7D 7E 7F 80
            //             81 82 83 84    86 87    89 8A 8B
            //                   93 94 95 96 97 98 99
            //                                     A9
            // ZZ = one of 01 02 03 04 07 08 0C 0F 10 1C 1F 20 38 3C 3F 40 7C 80 C0 FC FF
            // when changing all lists to point to "10 68 00 00":
            // 14 00 00 00 58 00 00 00 05 3F 00 00 = 2T
            // if that list would consist of 2 entries, AI would somehow pick one  
            // modifying that to ... yields ...
            // 14 00 00 00 52 00 00 00 05 3F 00 00 = 5T
            // 14 00 00 00 53 00 00 00 05 3F 00 00 = 6T
            // 14 00 00 00 57 00 00 00 05 03 00 00 = 426T
            // 14 00 00 00 13 00 00 00 05 3F 00 00 = 6pkp combo
            // 14 00 00 00 13 00 00 00 05 07 00 00 = 6pkp combo
            // 14 00 00 00 1C 00 00 00 05 3F 00 00 = 1p2k combo
            // 14 00 00 00 5E 00 00 00 05 03 00 00 = 4h
            //             ^^
            //             ++--- index from pAiCombos?
            typeH_1.h.blob({ size: terminator.aobLength }), { dontReportEmpty: true });
            return typeH_1.h.struct([
                [
                    "pIdk19",
                    typeH_1.h.array({ elementsCount: 7 }, typeH_1.h.ptr(typeH_1.h.struct([
                        ["from00To27", typeH_1.h.array({ elementsCount: 28 }, typeH_1.h.ptr(idk19AndIdk20SubType))],
                        // FIXME: 28...31 are different for some reason
                        // For rig doesn't seem to have actual payload
                        ["from28to31", typeH_1.h.array({ elementsCount: 4 }, typeH_1.h.ptr(typeH_1.h.blob({ size: typeH_1.unknownBlobSize })))],
                        ["from32to47", typeH_1.h.array({ elementsCount: 16 }, typeH_1.h.ptr(idk19AndIdk20SubType))],
                    ]))),
                ],
                [
                    // pAiBehavior
                    "pIdk21",
                    typeH_1.h.array({ elementsCount: 7 }, typeH_1.h.ptr(typeH_1.h.struct([
                        // required distance for certain groups?
                        // is compared with current distance to opponent, at least some of them
                        ["someFloats", typeH_1.h.array({ elementsCount: 5 }, typeH_1.h.float())],
                        // strikes / (safe/low strikes) / throws / holds
                        // sums up to 100 (usually)
                        ["aiOffenseTypeWeights", typeH_1.h.array({ elementsCount: 4 }, typeH_1.h.uint(1))],
                        // strikes / crushes / throws / OHs
                        // sums up to 100 (usually)
                        ["aiDefenseTypeWeights", typeH_1.h.array({ elementsCount: 4 }, typeH_1.h.uint(1))],
                        ["zero", typeH_1.h.zero(4)],
                    ]))),
                ],
                [
                    // pAiAdditionalMixups?
                    "pIdk20",
                    typeH_1.h.array({ elementsCount: 7 }, typeH_1.h.ptr(typeH_1.h.array({ elementsUntil: ["00 00 00 00"] }, typeH_1.h.ptr(idk19AndIdk20SubType)))),
                ],
                [
                    "pAiCombos",
                    typeH_1.h.ptr(parent => typeH_1.h.array({ elementsCount: parent.v.aiCombosAmount.v.dehexUint }, typeH_1.h.ptr(getAiComboType()))),
                ],
                ["aiCombosAmount", typeH_1.h.uint(2, validators_1.validateNotZero)],
            ]);
        }
        function getAiComboType() {
            return typeH_1.h.array({
                elementsUntil: [
                    "28 00 00 00 00 00 00 00",
                    // FIXME: include in the payload?
                    // "00 00 00 00 00 00 00 00",
                    // "01 00 00 00 00 00 00 00",
                    // "05 00 00 00 ?? ?? 00 00",
                    // "06 00 00 00 96 00 00 00",
                    // "06 00 00 00 97 00 00 00",
                    // "24 00 00 00 ?? 00 00 00",
                    // "25 00 00 00 ?? 00 00 00",
                    // "28 00 00 00 ?? 00 00 00",
                    // "1F 00 00 00 ?? 00 00 00",
                    // "1F 00 00 00 ?? 01 00 00",
                    // "1F 00 00 00 ?? 02 00 00",
                    // "2A 00 00 00 3D 00 00 00",
                    // "2A 00 00 00 3E 00 00 00",
                    // "7F 00 00 00 00 00 00 00",
                    // "28 00 00 00 00 00 00 00",
                    // "1F 00 00 00 45 00 00 00",
                    // "1F 00 00 00 4C 00 00 00",
                    // "1F 00 00 00 4C 01 00 00",
                    // "1F 00 00 00 CA 00 00 00",
                    // "1F 00 00 00 CB 00 00 00",
                    // "1F 00 00 00 CC 00 00 00",
                    // ???
                    // "24 00 00 00 1C 00 00 00",
                    // "00 00 00 00 00 00 00 00",
                ],
            }, typeH_1.h.struct([
                ["commandType", typeH_1.h.uint(1 /*, [
                        // from Rig's data:
                        0x0, 0x1, 0x2, 0x5, 0x6, 0x8, 0xC, 0xE, 0xF, 0x11, 0x1F, 0x24, 0x25, 0x27,
                        0x2A, 0x2E, 0x30, 0x32, 0x35, 0x3C, 0x60, 0x72, 0x79, 0x7E, 0x92, 0x93,
                    ]*/)],
                // VV
                // 00 00 00 00 XX XX 00 00 // first, starting move id
                // 02 00 00 00 XX XX 00 00 // previous chain to move id (can stack up)
                // 25 00 00 00 01 00 00 00 // stance? bt? ability to cancel?.. (e.g. 3k6k4)
                // 25 00 00 00 02 00 00 00 // stance? bt? ability to cancel?.. (e.g. pp4)
                // 0C 00 00 00 05 00 00 00 // ??? (e.g. 1kk, 6kk4)
                // 0C 00 00 00 07 00 00 00 // ??? (e.g. 4k)
                // 0C 00 00 00 0A 00 00 00 // ??? crouching? (e.g. unsued 2(crouch)?)
                // 0C 00 00 00 0C 00 00 00 // ??? (e.g. kk)
                // ...
                // 28 00 00 00 00 00 00 00 // end
                ["unknown", typeH_1.h.uint(1, [0, 31, 32])],
                ["zero1", typeH_1.h.zero(2)],
                ["commandArg", typeH_1.h.uint(2)],
                ["zero2", typeH_1.h.zero(2)],
            ]), { dontReportEmpty: true });
        }
        //
        function getMoveInfosArrayType() {
            // does this map out to move category?
            // 0..0x1f40..0x3e80..0x5dc0..0x7d00..0x9c40
            // TODO: confirm if the category order correct, or [0, 1, 2, 5, 3, 4]
            return typeH_1.h.array({ elementsCount: 5 }, typeH_1.h.ptr(getMoveInfosCategoryType()));
        }
        function getMoveInfosCategoryType() {
            const bytesPerCommand = {
                [0x00_99]: 16,
                [0x00_a3]: 8,
                [0x00_b2]: 8,
                [0x00_c4]: 8,
                [0x00_c6]: 8,
                [0x00_ae]: 24,
                [0x01_2b]: 1,
                [0x01_53]: 8,
                [0x01_54]: 8,
                [0x01_55]: 8,
                [0x01_56]: 8,
                [0x01_57]: 12,
                [0x01_63]: 8,
                [0x01_99]: 8,
                // from BASE.bin
                [0x00_c3]: 1,
                [0x01_30]: 8,
                [0x01_32]: 8,
                [0x01_3f]: 8,
                [0x01_43]: 16,
                [0x00_bb]: 8, // 8-16 bytes
                // other:
                // 0xc8: not a pointer but has payload
            };
            return typeH_1.h.array({ elementsUntil: ["FF FF FF FF 00 00 00 00 FF FF FF 00"] }, typeH_1.h.struct([
                // for stuns it's mostly "BF 5D" which means nothing special?
                ["moveIdToPlayNext", typeH_1.h.uint(2)],
                ["moveType", typeH_1.h.uint(1, [
                        0x00,
                        0x01,
                        0x02,
                        0x03,
                        0x04,
                        0x05,
                        0x06,
                        0x07,
                        0x08,
                        0x09,
                        0x0A,
                        0x0B,
                        0x0C,
                        0x0D,
                        0x0E,
                        0x0F,
                        0x10, // throw / OH
                    ])],
                // based on moveType:
                // for 0x2 and 0x3 (also 0x1? 0x7? 0xD?), this is used to calc offset in hit table
                // for 0x04 (or 0xA? or 0x10? or all?) index in pThrowInfos?
                // for 0x5 (or 0x6? 0r 0xB? or all?), index in pHoldInfos?
                // for 0xE, index in pGroundHitTable?
                ["secondId", typeH_1.h.uint(1)],
                ["pPtr", typeH_1.h.ptr(getMoveInfosCategoryPtrType())],
                ["animId", typeH_1.h.uint(2)],
                ["unknown", typeH_1.h.uint(1)],
                ["zero1", typeH_1.h.zero(1)],
            ]), 
            // FIXME: only don't report for pCategory5
            { dontReportEmpty: true });
            function getMoveInfosCategoryPtrType() {
                return typeH_1.h.array({ elementsUntil: ["FF FF FF FF FF FF FF FF"] }, typeH_1.h.struct([
                    // TODO: validate for known commands
                    ["command", typeH_1.h.uint(4)],
                    [
                        "pPayload",
                        typeH_1.h.switch((parent) => Boolean(bytesPerCommand[parent.v.command.v.dehexUint]) ? 0 : 1, typeH_1.h.ptr((parent) => typeH_1.h.blob({
                            size: bytesPerCommand[parent.v.command.v.dehexUint],
                        })), typeH_1.h.uint(4)),
                    ],
                ]), { dontReportEmpty: true });
            }
        }
        //
        function getCharacterOverridesType() {
            const { switchOptions, addSwitchOption } = (function () {
                const switchOptions = new Array();
                return { switchOptions, addSwitchOption };
                function addSwitchOption(option) {
                    switchOptions.push(option);
                    return option;
                }
            }());
            //
            const anUnknown = addSwitchOption(typeH_1.h.blob({ size: 4 }));
            const animIdOrMoveIdType = typeH_1.h.struct([
                ["unknown1", typeH_1.h.uint(2)],
                ["zero", typeH_1.h.zero(2)],
            ]);
            const aFloat = addSwitchOption(typeH_1.h.float());
            const aNum = addSwitchOption(typeH_1.h.uint(4));
            const moveIdOrAnimId = addSwitchOption(animIdOrMoveIdType);
            const ptrTo4MoveIdsOrAnimIds = addSwitchOption(typeH_1.h.ptr(typeH_1.h.array({ elementsCount: 4 }, animIdOrMoveIdType)));
            const ptrToTwoNums = addSwitchOption(typeH_1.h.ptr(typeH_1.h.array({ elementsCount: 2 }, typeH_1.h.uint(4))));
            const ptrTo2Floats = addSwitchOption(typeH_1.h.ptr(typeH_1.h.array({ elementsCount: 2 }, typeH_1.h.float())));
            const ptrTo3Floats = addSwitchOption(typeH_1.h.ptr(typeH_1.h.array({ elementsCount: 3 }, typeH_1.h.float())));
            const ptrTo3FloatsAndTail = addSwitchOption(typeH_1.h.ptr(typeH_1.h.struct([
                ["floats", typeH_1.h.array({ elementsCount: 3 }, typeH_1.h.float())],
                // possibly just alignment and is not an actual part of this struct
                ["tail", typeH_1.h.array({ elementsCount: 2 }, typeH_1.h.zero(4))],
            ])));
            const ptrTo3NumsAnd2Floats = addSwitchOption(typeH_1.h.ptr(typeH_1.h.struct([
                ["nums", typeH_1.h.array({ elementsCount: 3 }, typeH_1.h.uint(4))],
                ["floats", typeH_1.h.array({ elementsCount: 2 }, typeH_1.h.float())],
            ])));
            const ptrTo2FloatsAndNum = addSwitchOption(typeH_1.h.ptr(typeH_1.h.struct([
                ["floats", typeH_1.h.array({ elementsCount: 2 }, typeH_1.h.float())],
                ["num", typeH_1.h.uint(4)],
            ])));
            // Possibly duplicate of ptrTo2FloatsAndNum
            const ptrToFloatZeroAndNum = addSwitchOption(typeH_1.h.ptr(typeH_1.h.struct([
                ["theFloat", typeH_1.h.float()],
                ["zero", typeH_1.h.zero(4)],
                ["num", typeH_1.h.uint(4)],
            ])));
            const gender = addSwitchOption(typeH_1.h.struct([
                ["isFemale", typeH_1.h.uint(4, [0, 1])],
            ]));
            // 00 = [feather..welter]; 01 = [middle..heavy]; 02 = super heavy
            // although mila, kokoro, hitomi, momiji, mai don't match their momentum multiplier (as of 1.10c)
            const weightClass = addSwitchOption(typeH_1.h.struct([
                ["weightClass", typeH_1.h.uint(4, [0, 1, 2])],
            ]));
            const ptrToSomeStructWithAFloat1 = addSwitchOption(typeH_1.h.ptr(typeH_1.h.struct([
                ["unknown1", typeH_1.h.blob({ size: 4 })],
                ["unknown2", typeH_1.h.blob({ size: 4 })],
                ["unknown3", typeH_1.h.blob({ size: 4 })],
                ["unknownFloat", typeH_1.h.float()],
                ["zero", typeH_1.h.zero(4)],
            ])));
            const ptrToSomeStructWithAFloat2 = addSwitchOption(typeH_1.h.ptr(typeH_1.h.struct([
                ["unknown1", typeH_1.h.blob({ size: 4 })],
                ["unknown2", typeH_1.h.blob({ size: 4 })],
                ["unknownFloat", typeH_1.h.float()],
                ["zero1", typeH_1.h.zero(4)],
                ["zero2", typeH_1.h.zero(4)],
            ])));
            return typeH_1.h.array({ elementsUntil: ["FF FF FF FF 00 00 00 00"] }, typeH_1.h.struct([
                ["payloadMeaning", typeH_1.h.uint(2)],
                ["zero", typeH_1.h.zero(2)],
                ["payload", typeH_1.h.switch((parent) => Math.max(0, switchOptions.indexOf({
                        // Pattern: Every char got exactly 1 instance of the following:
                        // "9A 01": "51 01 00 00" // same for everyone
                        // "9B 01": "A2 3E 00 00" // same for everyone
                        // "9C 01": h.struct(h.uint(1), h.uint(1, [0x20, 0x21, 0x1F]), h.zero(2))
                        // "9D 01": h.struct(h.uint(1), h.uint(1, [0x7D]), h.zero(2))
                        "DF 00": gender,
                        "E0 00": weightClass,
                        // momentum multiplier (always at index 2?)
                        "E1 00": aFloat,
                        // starting launch height multiplier (always at index 3?)
                        // aka "char's height" multiplier
                        // also applies to e.g. 66p just before the wallbounce but not wallsplat
                        "E2 00": aFloat,
                        //
                        "E3 00": aFloat,
                        "E4 00": aFloat,
                        "E5 00": aFloat,
                        "E6 00": aFloat,
                        // "E7 00": h.struct(h.uint(2), h.zero(2)); // alpha got FF FF
                        // "E8 00": h.struct(h.uint(2), h.zero(2)); // alpha got FF FF
                        // "EB 00": h.struct(h.uint(2), h.zero(2)); // move id for "standing throw" com (re)action
                        // "EC 00": h.struct(h.uint(2), h.zero(2)); // move id for "croucing throw" com (re)action
                        //
                        "75 01": ptrToSomeStructWithAFloat1,
                        "77 01": ptrToSomeStructWithAFloat2,
                        // Pattern: Every char got at least 2 and up to 15 instances of this:
                        "73 01": ptrToSomeStructWithAFloat1,
                        // Pattern: Everyone got at most 1, but maybe 0
                        // "E9 00": h.struct(h.uint(2), h.zero(2)) // alpha and pai got "FF FF"
                        // "EA 00": h.struct(h.uint(2), h.zero(2)) // alpha and pai got "FF FF"
                        // "EF 00": h.struct(h.uint(2), h.zero(2)) // mostly "00 00"; pai has "FF FF"; bayman, jann lee, tina, bass, leifang and leon have "?? 1F"
                        // "F1 00": h.struct(h.uint(2), h.zero(2)) // alpha, eliot and lisa got "00 00", pai got "FF FF", rest got either "?? 20" or "?? 1F"
                        // "9E 01": "40 9C 00 00" for everyone who has it
                        // "ED 00": h.struct(h.uint(2), h.zero(2)) // akira, sarah, pai and jacky got "FF FF", rest got either "?? 1F" or "?? 20"
                        // "7F 01": h.uint(4, [0xE9, 0xEA, 0xEB, 0xEC, 0xED])
                        //   "E9": alpha, mil, rig, eliot, sarah, pai
                        //   "EA": bass, lf
                        //   "EB": brad, kokoro, bayman, zack, hayabusa, tengu, lisa, hitomi, raidou, momiji, gen fu, leon
                        //   "EC": jl, ayane, mr
                        //   "ED": kasumi, helena, christie, tina, p4, hayate, ein, rachel, honoka
                        // "EE 00": h.struct(h.uint(2), h.zero(2)) // akira, sarah, pai and jacky got "FF FF", rest got either "?? 1F" or "?? 20"
                        // "F0 00": h.struct(h.uint(2), h.zero(2)) // akira, sarah, pai and jacky got "FF FF", rest got either "?? 1F" or "?? 20"
                        // "88 01": float // mila = "00 00 00 40"; helena, christie, ein = "00 00 00 3F";  rig, jl, zack, bass = "00 00 C0 3F"
                        // "5D 01": h.uint(4, ["10 21", "F6 20"]); bayman = "10 21"; leon = "F6 20"
                        // Pattern: no specific pattern
                        // "8E 01": ptr? // can any times per char, including 0
                        // "74 01": ptr? // can any times per char, including 0
                        // "76 01": ptr? // can any times per char, including 0
                        // "78 01": ptr? // can any times per char, including 0
                        // "7D 01": ptr? // not everyone got it, but who got have it between 7 and 8 times
                        // From BASE.bin:
                        "F4 00": aFloat,
                        "F7 00": aFloat,
                        "64 01": aFloat,
                        "65 01": aFloat,
                        "66 01": aFloat,
                        "AF 01": aFloat,
                        "B0 01": aFloat,
                        "B3 01": aFloat,
                        "C5 01": aFloat,
                        "C6 01": aFloat,
                        "F2 00": aNum,
                        "F3 00": aNum,
                        "F5 00": aNum,
                        "F6 00": aNum,
                        "F8 00": aNum,
                        "F9 00": aNum,
                        "FA 00": aNum,
                        "5E 01": aNum,
                        "68 01": aNum,
                        "69 01": aNum,
                        "6A 01": aNum,
                        "9F 01": moveIdOrAnimId,
                        "B6 01": moveIdOrAnimId,
                        "B7 01": moveIdOrAnimId,
                        "BC 01": moveIdOrAnimId,
                        "C1 01": moveIdOrAnimId,
                        "C7 01": moveIdOrAnimId,
                        "C8 01": moveIdOrAnimId,
                        "5B 01": ptrTo4MoveIdsOrAnimIds,
                        "5F 01": ptrToTwoNums,
                        "60 01": ptrToTwoNums,
                        "61 01": ptrToTwoNums,
                        "62 01": ptrToTwoNums,
                        "6B 01": ptrToTwoNums,
                        "67 01": ptrTo2Floats,
                        "7B 01": ptrTo3NumsAnd2Floats,
                        "7C 01": ptrTo3NumsAnd2Floats,
                        "B8 01": ptrTo2FloatsAndNum,
                        "B9 01": ptrToFloatZeroAndNum,
                        "BB 01": ptrTo3Floats,
                        "BA 01": ptrTo3FloatsAndTail,
                    }[parent.v.payloadMeaning.v])), switchOptions[0], switchOptions[1], ...switchOptions.slice(2))],
            ]));
        }
        //
        // TODO: validate that this has same length as pAnimsOrder
        //       anim ids from move info get mapped through pAnimsOrder to here
        function getTimelinesType() {
            return typeH_1.h.array({ elementsUntil: ["00 00 00 00"] }, typeH_1.h.ptr(
            // momiji: 
            // 00000000010002000A000100350346002301 = standing
            // 00000100010002000A0010000700 = crouching
            // 00001400010002000A0001000C0051000600010010006C00010030005100060001005000510006000100510046001000 = walk forward
            // 00001500010002000A000700 = walk back in block (slowly)
            // 00001E00010002000A000700 = walk forward (slowly)
            typeH_1.h.blob({
                elementsUntil: [
                    "FF FF",
                    // "0F 00", // FIXME: include in data?
                ],
            })));
        }
        //
        function getCommandListTypes() {
            const size = 15;
            const commandListPtrType = getCommandListPtrType();
            const pCommandListPtrsType = typeH_1.h.ptr(outerParent => typeH_1.h.array({ elementsCount: size }, typeH_1.h.ptr((innerParent, varPath) => {
                // FIXME
                const index = Number(varPath[varPath.length - 2].match(/\d+/)[0]);
                // WARNING: breaking "natural" order of dereferencing here
                const elementsCount = (outerParent.v.pCommandListSizes.dereference(outerParent).v.sizes.v[index].v.dehexUint);
                return typeH_1.h.array({ elementsCount }, commandListPtrType, { dontReportEmpty: true });
            }, { dontReportNullPtr: true })));
            const pCommandListSizesType = typeH_1.h.ptr(typeH_1.h.struct([
                ["sizes", typeH_1.h.array({ elementsCount: size }, typeH_1.h.uint(1))],
                ["zeros", typeH_1.h.array({ elementsCount: 21 }, typeH_1.h.zero(1))],
            ]));
            // TODO: cross-validate that size 0 === nullptr in both directions
            return {
                pCommandListPtrsType,
                pCommandListSizesType,
            };
        }
        function getCommandListPtrType() {
            // Somehow related to "fight screen info / move list"
            // For rig, only pairs are these:
            // bnd kkk4
            // 4kk and alike
            // 1kk and alike
            // bnd t + bnd t reaction
            // sidestep up p + sidestep down p
            // sidestep up k + sidestep down k
            // 33h+k / no meter + 33h+k / meter
            // And then more for pUnknown9?
            const matchingMoveIdsType = typeH_1.h.array({
                elementsUntil: ["FF FF 00 00"],
                direction: -1,
            }, typeH_1.h.struct([
                ["moveId", typeH_1.h.uint(2)],
                ["zero", typeH_1.h.zero(2)],
            ]));
            return typeH_1.h.struct([
                ["pInputStr", typeH_1.h.ptr(typeH_1.h.zString())],
                ["unknown1", typeH_1.h.uint(1)], ["zero1", typeH_1.h.zero(1)], ["zero2", typeH_1.h.zero(2)],
                ["pMatchingMoveIds", typeH_1.h.ptr(matchingMoveIdsType)],
                // what com does in combo training
                // 00 = nothing special
                // 01 = nothing, but you're supposed to be BT?
                // 02 = nothing, but you're supposed to be grounded / waking up? (used for WUKs)
                // 04 = BT
                // 0A = fall onto ground
                // 0B = high p
                // 0C = high k
                // 0D = mid p
                // 0E = mid k
                // 0F = low P
                // 10 = low k
                // 13 = nothing, but supposed to do jumping punch?
                // 14 = nothing, but supposed to do jumping kick?
                // 15 = crouch
                // 26 = BT crouch
                // 46 = nothing, but you're supposed to be jumping over a fence?
                ["situation", typeH_1.h.uint(1)], ["zero3", typeH_1.h.zero(1)], ["zero4", typeH_1.h.zero(2)],
                ["magic", typeH_1.h.uint(4, [0xFF_FF_FF_FF])], ["zero5", typeH_1.h.zero(4)], ["zero6", typeH_1.h.zero(4)],
                ["displayInMovelist", typeH_1.h.uint(1, [0, 1])], ["zero7", typeH_1.h.zero(1)], ["zero8", typeH_1.h.zero(2)],
                ["pHeightsStr", typeH_1.h.ptr(typeH_1.h.zString(), { dontReportNullPtr: true })],
                ["demoComboIndex", typeH_1.h.uint(2)],
                [
                    "label",
                    typeH_1.h.uint(2, [
                        0x00_01,
                        0x00_02,
                        0x00_03,
                        0x00_04,
                        0x00_05,
                        0x00_06,
                        0x00_07,
                        0x00_08, // Power launcher
                    ]),
                ],
                [
                    // On which page to show this move?..
                    "unknownMask",
                    typeH_1.h.uint(2, [
                        0xFF_FF,
                        0x00_00,
                        0x00_08,
                        0x00_10,
                        0x00_20,
                        0x00_40,
                        0x00_80,
                        0x01_00,
                        0x02_00, // bt?
                    ]),
                ],
                ["unknown5", typeH_1.h.uint(2, [0x00_00, 0xFF_FF])],
                [
                    "unknown6",
                    typeH_1.h.array({ elementsCount: 3 }, typeH_1.h.struct([
                        ["unknown", typeH_1.h.uint(1)],
                        ["zero", typeH_1.h.zero(1)],
                    ])),
                ],
                ["unknown7", typeH_1.h.uint(2, [0x00_00, 0x00_1C])],
                ["zero10", typeH_1.h.zero(4)],
                ["unknownBool", typeH_1.h.uint(1, [0, 1])],
                ["completed", typeH_1.h.uint(1, [0])],
                ["unknown8", typeH_1.h.blob({ size: 2 })],
                ["pUnknown9", typeH_1.h.ptr(matchingMoveIdsType, { dontReportNullPtr: true })],
                ["unknown10", typeH_1.h.blob({ size: 4 })],
            ]);
        }
    }
    // helpers
    function getCharName(fileName) {
        return fileName.split("_")[1];
    }
    function getFileType(fileUint8Array) {
        if (hasMagicAt(fileUint8Array, 0, magics.baseBinStart))
            return "baseBin";
        if (hasMagicAt(fileUint8Array, 0, magics.charBinStart))
            return "charBin";
        if (hasMagicAt(fileUint8Array, 0, magics.motionStart))
            return "motion";
        throw new Error("Unknown file type");
    }
    function hasMagicAt(fileUint8Array, pos, magic) {
        const actualPos = pos < 0 ? fileUint8Array.length - Math.abs(pos) : pos;
        console.assert(actualPos >= 0 &&
            actualPos + magic.aobLength <= fileUint8Array.length);
        return (magic ===
            fileUint8Array.subarray(actualPos, actualPos + magic.aobLength).asAobStr);
    }
    function findRange(stuff) {
        if (stuff.length === 0)
            return null;
        let min = Infinity;
        let max = -Infinity;
        for (const entry of stuff) {
            console.assert(entry.rawU8A.length > 0);
            min = Math.min(min, entry.posStart.dehexUint);
            max = Math.max(max, entry.posStart.dehexUint + entry.rawU8A.length);
        }
        return { min, max };
    }
    // Exposed tools
    function compareMems(bins, getPtr, // e.g. charBin => charBin.header.v.pIdk9.d.posStart,
    bytes = 256, width = 16) {
        const result = Object.values(bins).filter((charBin) => !charBin.isBaseBin).map((charBin) => {
            const charName = charBin.charName;
            const ptr = getPtr(charBin).dehexUint;
            const chunk = charBin.fileUint8Array.subarray(ptr, ptr + bytes);
            return {
                charName,
                ptr,
                memView: Array.from(chunk).addDimension(width).map(e => e.asAobStr),
                logMemView,
            };
            function logMemView() {
                const getHit = charBin.fileUsageHelper.createGetHit();
                console.log(`${charName}`, { whatIsAt: (pos) => charBin.fileUsageHelper.createGetHit()(pos) });
                chunk.logPrettyAob(width, ptr, getBgColorAt);
                function getBgColorAt(pos) {
                    const actualPos = Math.round(pos);
                    const hit = getHit(actualPos);
                    if (hit) {
                        const hitFrom = hit[0].dehexUint;
                        const hitTo = hit[1].dehexUint;
                        if (hitFrom === hitTo && pos < actualPos && hitFrom === actualPos) {
                            return "#700";
                        }
                        if (pos === actualPos && hitTo > hitFrom)
                            return "#000";
                        if (hitTo >= pos + 1 && hitFrom < pos)
                            return "#000";
                    }
                    return undefined;
                }
            }
            ;
        });
        return {
            result,
            get logMemView() {
                for (const { logMemView } of result) {
                    logMemView();
                }
                return "done";
            }
        };
    }
    function collapse(something) {
        if (!something.rawU8A)
            return something;
        const v = something.p ? something.d?.v : something.v;
        if (Array.isArray(v)) {
            return v.map(e => collapse(e));
        }
        else if (v && (v instanceof Uint8Array)) {
            return v.asAobStr;
        }
        else if (v && typeof v === "object") {
            const result = {};
            Object.entries(v).forEach(([key, value]) => {
                result[key] = collapse(value);
            });
            return result;
        }
        else {
            return v;
        }
    }
    function findMoveIdInCommandList(charBin, moveId) {
        const results = [];
        const array = charBin.header.v.pCommandListPtrs.d.v;
        for (let i = 0; i < array.length; i += 1) {
            const v = array[i];
            if (!v.d)
                continue;
            for (let j = 0; j < v.d.v.length; j += 1) {
                const v2 = v.d.v[j];
                for (let k = 0; k < v2.v.pMatchingMoveIds.d?.v.length ?? 0; k += 1) {
                    const v3 = v2.v.pMatchingMoveIds.d.v[k];
                    if (v3.v.moveId.v.dehexUint === moveId.dehexUint) {
                        results.push({
                            moveId,
                            match: { i, j, k, arrayIJ: v2.v },
                        });
                        // category: i
                        // inputStr:   charBin.header.v.pCommandListPtrs.d.v[i].d.v[j].v.pInputStr.d.v,
                        // heightsStr: charBin.header.v.pCommandListPtrs.d.v[i].d.v[j].v.pHeightsStr.d?.v,
                        // match:      charBin.header.v.pCommandListPtrs.d.v[i].d.v[j].v.pMatchingMoveIds.d.v[k],
                    }
                }
            }
        }
        return results;
    }
    function moveIdFindResultToString(findResult, optDb) {
        const { i, j, k, arrayIJ } = findResult.match;
        const category = i;
        const inputStr = arrayIJ.pInputStr.d.v;
        const heightsStr = arrayIJ.pHeightsStr.d?.v ?? "?";
        const sharedWith = arrayIJ.pMatchingMoveIds.d?.v.filter((e, i) => i !== k) || [];
        const matchesForThisMoveId = optDb?.filter(e => e.moveId === findResult.moveId).length ?? 1;
        const resultParts = [
            findResult.moveId,
            " ",
            (matchesForThisMoveId > 1
                ? `(+${matchesForThisMoveId - 1})`
                : "    "),
            " = ",
            "[" + [
                String(category).padStart(2, "0"),
                String(j).padStart(3, "0"),
                k,
            ].join("|") + "]",
            " ",
            inputStr.padStart(10, " "),
            " :: ",
            heightsStr.padStart(5, " "),
        ];
        if (sharedWith.length > 0) {
            resultParts.push(...[
                " // ",
                sharedWith.map(e => e.v.moveId.v).join(", "),
            ]);
        }
        return resultParts.join("");
    }
    function findMoveIdsFromInput(charBin, inputPattern) {
        const doesInputSatisfyPattern = doa5lrTools_1.createInputComparator(inputPattern);
        return getAllMoveIdsFromMoveInfos(charBin).flatMap(moveId => findMoveIdInCommandList(charBin, moveId)).filter(e => doesInputSatisfyPattern(e.match.arrayIJ.pInputStr.d.v)).map(e => moveIdFindResultToString(e));
    }
    // potentially doesn't include stuff like move ids from hit tabls (stun reaction)
    // or auto-transition move ids
    function getAllMoveIdsFromMoveInfos(charBin) {
        if (charBin.isBaseBin) {
            return charBin.header.v.pMoveInfos.d.v.map((moveInfo, i) => {
                return doa5lrTools_1.getMoveId(doa5lrTools_1.getBaseBinMoveIdCategory(), i);
            });
        }
        return charBin.header.v.pMoveInfosArray.d.v.map((v, catI) => {
            return v.d.v.map((moveInfo, i) => {
                return doa5lrTools_1.getMoveId(catI, i);
            });
        }).flatten();
    }
    function getAllMoveIdsFromMoveInputs(charBin, excludeUnlisted = false) {
        return getAllMoveInputs(charBin, excludeUnlisted).map(e => e.moveId).filter(Boolean).sortAscending(e => e.dehexUint);
    }
    function getAllMoveIdsFromHitTables(charBin, excludeUnused = false, excludeLegacy = false, excludeKnown = false) {
        const result = getAllHitTables(charBin, excludeUnused).flatMap(e => {
            return [
                e.value.v.nh,
                ...(excludeLegacy ? [] : [e.value.v.legacyBtNh]),
                e.value.v.block,
                e.value.v.ch,
                e.value.v.btCh,
                e.value.v.hch,
                e.value.v.btHch,
                e.value.v.crouchNh,
                ...(excludeLegacy ? [] : [e.value.v.legacyCrouchBtNh]),
                e.value.v.crouchBlock,
                e.value.v.crouchCh,
                e.value.v.crouchBtCh,
                e.value.v.crouchHch,
                e.value.v.crouchBackHch,
                e.value.v.juggle,
                e.value.v.juggleBt,
                e.value.v.groundHitG86,
                e.value.v.groundHitG8R,
                e.value.v.groundHitG24,
                e.value.v.groundHitG2R,
                e.value.v.moveIdOnHit,
            ].map(e => e.v).filter(e => !["FF FF", "00 00"].includes(e)).filterUnique();
        }).filterUnique().sortAscending(e => e.dehexUint);
        if (excludeKnown) {
            const moveIdsFromMoveInfos = getAllMoveIdsFromMoveInfos(charBin).map(e => e.dehexUint);
            return result.filter(e => !moveIdsFromMoveInfos.includes(e.dehexUint));
        }
        return result;
    }
    // TODO: because in-game command list is not the source of truth and contains bugs,
    //       add a validation that points these bugs out
    //       e.g. compare height of last attack for same move id (note: there are heights like "4" which mean 1+2, e.g. Rig's BND 6H+K)
    //            or check that all lists in pMatchingMoveIds have no intersections
    //       E.g. Rig's 85 1F (tlc k) is used again by mistake where F8 1F (tlc 6k) should be
    //            Same for Rig's 86 1F (tlc kk)
    function dumpAllMoves(charBin) {
        const allMoveIds = getAllMoveIdsFromMoveInfos(charBin);
        const result = allMoveIds.flatMap(moveId => findMoveIdInCommandList(charBin, moveId));
        return {
            allMoveIds,
            moveIdsNotInCommandList: allMoveIds.filter(moveId => {
                return !result.some(r => r.moveId.dehexUint === moveId.dehexUint);
            }),
            inCommandListByCommandListCategory: result.groupBy(e => e.match.i).sortAscending(e => e.value).map(e => groupByMoveId(e)),
            inCommandListByMoveIdCategory: result.groupBy(e => doa5lrTools_1.getMoveCategoryAndIndex(e.moveId).category).sortAscending(e => e.value).map(e => groupByMoveId(e)),
        };
        function groupByMoveId(e) {
            return e.matches.groupBy(e2 => e2.moveId).sortAscending(e => e.value.dehexUint).map(e => e.matches.map(m => moveIdFindResultToString(m, result)));
        }
    }
    function getMoveInfo(charBin, moveId) {
        const { category: moveCategory, index } = doa5lrTools_1.getMoveCategoryAndIndex(moveId);
        if (charBin.isBaseBin) {
            if (moveCategory !== doa5lrTools_1.getBaseBinMoveIdCategory()) {
                throw new Error("Unexpected move category for base bin");
            }
            return charBin.header.v.pMoveInfos.d.v[index];
        }
        return charBin.header.v.pMoveInfosArray.d.v[moveCategory]?.d.v[index];
    }
    function getAnimationInfo(charBin, moveId) {
        const animationId = getMoveInfo(charBin, moveId).v.animId.v;
        const index = charBin.header.v.pAnimsOrder.d.v.map(v => v.v.dehexUint).indexOf(animationId.dehexUint);
        if (index >= 0) {
            return charBin.header.v.pTimelines.d.v[index].d;
        }
        return null;
    }
    function reportTagThrows(charBin, includeUnlisted = false) {
        const moveIdsToIgnore = [
            "0D 01",
            "2C 01",
            "2D 01", // sidestep down
        ].map(str => str.dehexUint);
        const result = getAllMoveInputs(charBin, !includeUnlisted).flatMap(e => e.inputs.map(e => e.raw)).flatMap(e => {
            const aobStr = e.v.asAobStr;
            const parsed = InputParser.readInput(aobStr).result;
            if (parsed.error)
                return [];
            return [{
                    aobStr,
                    moveId: InputParser.getResultingMoveId(aobStr),
                    parsed,
                }];
        }).filter((e, i, a) => {
            return (
            // Apply blacklist
            !moveIdsToIgnore.includes(e.moveId.dehexUint) &&
                // Only inlcude moves that have S input
                InputParser.mentionsButton(e.aobStr, "S") &&
                // Exclude moves that have alternate inputs that ...
                !a.filter(e2 => e2 !== e && e2.moveId === e.moveId).some(e2 => (
                // ... alternate input uses taunt button
                InputParser.mentionsButton(e2.aobStr, "Ap") ||
                    // ... alternate input doesn't use S button
                    !InputParser.mentionsButton(e2.aobStr, "S")))
            // TODO: check move info to confirm it's a throw?
            );
        }).sortAscending(e => e.moveId.dehexUint).map(e => (InputParser.parsedDataToString(e.parsed.value).simplified +
            `   =   move '${e.moveId}'`)).filterUnique();
        return result;
    }
    function analyzeHitTables(charBin) {
        const enrichedHitTables = getAllHitTables(charBin).map(e => ({
            _move2ndId: e.move2ndId,
            ...collapse(e.value),
        }));
        return {
            groupedForEachKey: tools.groupForEachKey(enrichedHitTables, ["_move2ndId"]),
            groupedByIdks: enrichedHitTables.groupByMultiple(e => [
                [0, "hitTableIdk1", e.hitTableIdk1].join(" : "),
                [1, "hitTableIdk2", e.hitTableIdk2].join(" : "),
                [2, "hitTableIdk3", e.hitTableIdk3].join(" : "),
                [3, "hitTableMagic1", e.hitTableMagic1].join(" : "),
                [4, "hitTableIdk5", e.hitTableIdk5].join(" : "),
                [5, "hitTableMagic2", e.hitTableMagic2].join(" : "),
            ]).sortAscending(e => e.value.split(" : ")[0]),
        };
    }
    function getAllMoveInputs(charBin, excludeCharBinUnlisted, baseBin, excludeBaseBinUnlisted = false) {
        const sourceBase = "base";
        const sourceChar = "char";
        const iUnlisted = -1;
        const flat = [];
        if (baseBin) {
            flat.push(...baseBin.header.v.pArrayOfPtrsToInputCommands.d.v.flatMap((pMoveInputPtrs, i) => pMoveInputPtrs.d.v.map((pMoveInput, j) => ({ moveInput: pMoveInput.d, source: sourceBase, i, j }))));
        }
        flat.push(...charBin.header.v.pArrayOfPtrsToInputCommands.d.v.flatMap((pMoveInputPtrs, i) => pMoveInputPtrs.d.v.map((pMoveInput, j) => ({ moveInput: pMoveInput.d, source: sourceChar, i, j }))));
        if (baseBin && !excludeBaseBinUnlisted) {
            flat.push(...baseBin.unlistedMoveInputs.map((moveInput, j) => ({ moveInput, source: sourceBase, i: iUnlisted, j })));
        }
        if (!excludeCharBinUnlisted) {
            flat.push(...charBin.unlistedMoveInputs.map((moveInput, j) => ({ moveInput, source: sourceChar, i: iUnlisted, j })));
        }
        const grouped = flat.groupBy(e => e.source + " " + e.moveInput.posStart);
        grouped.forEach(e => {
            e.matches.forEach((e, i, a) => {
                console.assert(e.moveInput.rawU8A.asAobStr === a[0].moveInput.rawU8A.asAobStr);
            });
        });
        return grouped.flatMap(e => {
            const raw = e.matches[0].moveInput;
            const parseResult = InputParser.readInput(raw.rawU8A.asAobStr);
            if (parseResult.result.error) {
                return [];
            }
            return [{
                    raw,
                    parsedInput: parseResult.result.value,
                    sections: e.matches.map(e => `${e.source}|${e.i}|${e.j}`),
                }];
        }).groupBy(e => InputParser.getResultingMoveId(e.raw.rawU8A.asAobStr)).map(e => {
            return {
                moveId: e.value,
                inputs: e.matches,
            };
        });
    }
    function getAllHitTables(charBin, excludeUnused = false) {
        return [
            ...charBin.hitTableEntries,
            ...(excludeUnused ? [] : charBin.unusedHitTableEntries),
        ].filterUnique(e => e.posStart, e => e.rawU8A.asAob2Str).sortAscending(e => e.posStart.dehexUint).map(e => {
            const move2ndId = ((e.posStart.dehexUint - charBin.header.v.pHitTable.v.dehexUint) / 0x74);
            console.assert(move2ndId >= 0 &&
                move2ndId < 255 &&
                (move2ndId % 1) === 0);
            return {
                move2ndId,
                value: e,
            };
        });
    }
    function buildCharacter(baseBin, charBin, handmadeDescriptions) {
        const placeholder = null;
        const inputs = getAllMoveInputs(charBin, false, baseBin, false).map(e => ({
            ...e,
            // To be filled out later
            description: placeholder,
            inputs: e.inputs.map(e => ({
                ...e,
                // To be filled out later
                parsedStrings: placeholder,
            })),
            children: [],
            parents: [],
        }));
        inputs.forEach(outerE => {
            outerE.inputs.forEach(inputsE => {
                inputsE.parsedInput.forEach(e => {
                    // TODO: make this more robust
                    if (InputParser.parseCommand(e)?.prefix?.[0] === "during") {
                        const parentMoveId = e.args;
                        outerE.parents.addUnique(parentMoveId);
                        const parent = inputs.find(e => e.moveId === parentMoveId);
                        parent?.children.addUnique(outerE.moveId);
                    }
                });
            });
        });
        const missingMoveIdsInInputs = [];
        const circles = [];
        tools.createWalkOrder(inputs, function* getParents(e) {
            for (const parentMoveId of e.parents) {
                const match = inputs.find(e2 => e2.moveId === parentMoveId);
                if (match) {
                    yield match;
                }
                else {
                    missingMoveIdsInInputs.push(parentMoveId);
                }
            }
        }, circles).forEach(e => {
            e.inputs.forEach(e => {
                e.parsedStrings = InputParser.parsedDataToString(e.parsedInput, getStanceName, getMoveName);
            });
            e.description = getMoveName(e.moveId);
        });
        if (circles.length > 0) {
            console.debug("Circular dependencies:", circles);
        }
        if (missingMoveIdsInInputs.length > 0) {
            console.debug("Failed to find following move ids in inputs:", missingMoveIdsInInputs.filterUnique().sortAscending(e => e.dehexUint));
        }
        const hitTables = getAllHitTables(charBin);
        const charCommandListCache = getAllMoveIdsFromMoveInfos(charBin).flatMap(moveId => findMoveIdInCommandList(charBin, moveId));
        const reportError = (function () {
            const alreadyReported = [];
            return errorMessage => {
                if (alreadyReported.includes(errorMessage))
                    return;
                alreadyReported.push(errorMessage);
                console.warn(errorMessage);
            };
        }());
        return {
            inputs,
            hitTables,
            analyzeMoveId,
            get movesFromUnlistedInputs() {
                return inputs.map(e => analyzeMoveId(e.moveId)).filter(e => e.inputsForThisMoveId.every(e => e.sections.every(section => section.split("|")[1] === "-1"))).groupBy(e => e.moveInfo?.v.moveType.v).sortAscending(e => e.value.dehexUint).map(e => ({
                    ...e,
                    matches: [...e.matches].sortAscending(e => e.moveId.dehexUint),
                }));
            },
            get analyzeInputCommands() {
                return inputs.reduce((acc, m) => {
                    m.inputs.forEach(i => {
                        i.parsedInput.forEach(d => {
                            let t = d.command;
                            if ([InputParser.COMMAND_SUCCESS, "00", "12", "13", "14"].includes(t)) {
                                t += "(...)";
                            }
                            else {
                                t += "(" + d.args + ")";
                            }
                            let entry = acc.find(e => e.command === t);
                            if (!entry) {
                                entry = { command: t, count: 0, results: [] };
                                acc.push(entry);
                            }
                            entry.count += 1;
                            const existing = entry.results.find(r => r.move === m);
                            if (!existing) {
                                entry.results.push({
                                    move: m,
                                    inputs: [i],
                                });
                            }
                            else {
                                existing.inputs.push(i);
                            }
                        });
                    });
                    return acc;
                }, []).sortAscending(e => e.command);
            },
            get analyzeInputSections() {
                return inputs.groupByMultiple(m => m.inputs.flatMap(i => i.sections).map(section => section.split("|").slice(0, -1).join("|"))).sortAscending(e => [
                    e.value.split("|")[0],
                    Number(e.value.split("|")[1]),
                ]).map(e => ({
                    ...e,
                    matches: e.matches.filterUnique(),
                }));
            },
            get movesFromInputsByMoveType() {
                return inputs.map(e => analyzeMoveId(e.moveId)).groupBy(e => e.moveInfo?.v.moveType.v).sortAscending(e => e.value.dehexUint).map(e => ({
                    ...e,
                    matches: [...e.matches].sortAscending(e => e.moveId.dehexUint),
                }));
            },
        };
        function getStanceName(stanceHexString) {
            return handmadeDescriptions?.stanceCharacter?.[stanceHexString];
        }
        function getMoveName(moveId) {
            const a = handmadeDescriptions?.moveIdCharacter?.[moveId];
            if (a || a === "")
                return a;
            const b = handmadeDescriptions?.moveIdBase?.moveIdCharacter?.[moveId];
            if (b || b === "")
                return b;
            const c = handmadeDescriptions?.animIdCharacter?.[getMoveInfo(charBin, moveId)?.v.animId.v];
            // ANIM means auto description of an animation, no the move id
            if (c || c === "")
                return "ANIM: " + c;
            const d = generateDescription(moveId);
            // AUTO means auto generated description
            if (d || d === "")
                return "AUTO: " + d;
            return null;
        }
        function generateDescription(moveId) {
            const simplifiedInputs = inputs.find(e => e.moveId === moveId)?.inputs?.map(e => e.parsedStrings?.simplified).filter(Boolean) ?? [];
            if (simplifiedInputs.length > 0) {
                // TODO: try to find ones without ? and ..., and the shortest
                let desc = simplifiedInputs[0];
                if (simplifiedInputs.length > 1) {
                    desc += ` (+ ${simplifiedInputs.length - 1} other)`;
                }
                return desc;
            }
            return null;
        }
        function analyzeMoveId(moveId) {
            const inputsMatch = inputs.find(e => e.moveId === moveId);
            const parents = [...(inputsMatch?.parents ?? [])];
            const children = [...(inputsMatch?.children ?? [])];
            const moveInfo = (getMoveInfo(charBin, moveId) ??
                getMoveInfo(baseBin, moveId));
            let hitTableEntry;
            if (["02", "03"].includes(moveInfo?.v.moveType.v)) {
                const move2ndId = moveInfo.v.secondId.v.dehexUint;
                hitTableEntry = hitTables.find(e => e.move2ndId === move2ndId)?.value;
                if (hitTableEntry?.v.moveIdOnHit.v &&
                    hitTableEntry?.v.moveIdOnHit.v !== "FF FF") {
                    children.addUnique(hitTableEntry?.v.moveIdOnHit.v);
                }
            }
            // TODO: analogue of "hitTableEntry" for throws, holds, ground attacks etc
            if (moveInfo?.v.moveIdToPlayNext.v &&
                moveInfo?.v.moveIdToPlayNext.v !== "00 00") {
                children.addUnique(moveInfo?.v.moveIdToPlayNext.v);
            }
            const animationInfo = (getAnimationInfo(charBin, moveId) ??
                (doa5lrTools_1.isBaseBinMoveId(moveId) ? getAnimationInfo(baseBin, moveId) : null));
            if (!animationInfo) {
                reportError(`Missing animation info for move ${moveId}`);
            }
            const commandListEntries = charCommandListCache.filter(e => e.moveId === moveId).map(e => ({
                ...e,
                asString: moveIdFindResultToString(e, charCommandListCache),
            }));
            return {
                moveId,
                description: inputsMatch?.description,
                moveInfo,
                hitTableEntry,
                inputsForThisMoveId: inputsMatch?.inputs ?? [],
                parents,
                children,
                animationInfo,
                commandListEntries,
            };
        }
    }
}());

},{"./aobTools":2,"./consts":3,"./doa5lrTools":4,"./environment.d":5,"./fileUsageHelper":6,"./genericTools":7,"./hslTools":8,"./typeH":10,"./validators":11}],10:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.doReadTypeH = exports.bytesUntilFFType = exports.h = exports.unknownBlobSize = exports.dontDereferencePtr = void 0;
const consts_1 = require("./consts");
const aobTools_1 = require("./aobTools");
const hslTools_1 = require("./hslTools");
const validators_1 = require("./validators");
const genericTools_1 = require("./genericTools");
// TypeH
exports.dontDereferencePtr = null;
exports.unknownBlobSize = null;
class BlobHReader {
    constructor() {
        this.readH = (args, env, posStart, varPath, customAddHslString, realAddHslString, parent) => {
            const { elementsCount, elementSize, direction, payloadPosMin = posStart, terminatorBytesCountBefore, terminatorBytesCountAfter, } = (function () {
                const arg = args[0];
                if ("size" in arg) {
                    return {
                        elementsCount: arg.size,
                        elementSize: 1,
                        direction: 1,
                        payloadPosMin: posStart,
                        terminatorBytesCountBefore: 0,
                        terminatorBytesCountAfter: 0,
                    };
                }
                if ("elementsUntil" in arg) {
                    return findOutElementsCount(env.fileUint8Array, posStart, arg.elementsUntil, false);
                }
                if ("elementsWhile" in arg) {
                    return findOutElementsCount(env.fileUint8Array, posStart, arg.elementsWhile, true);
                }
                if ("getBlobProps" in arg) {
                    const props = arg.getBlobProps(posStart, env.fileUint8Array);
                    return {
                        elementsCount: props.size,
                        elementSize: 1,
                        direction: 1,
                        payloadPosMin: props.payloadPosMin,
                        terminatorBytesCountBefore: 0,
                        terminatorBytesCountAfter: 0,
                    };
                }
                throw new Error("Invalid arg");
            }());
            console.assert(direction === 1);
            const sizeAsArray = (elementSize !== 1
                ? [elementsCount ?? 1, elementSize]
                : [elementsCount ?? 1]);
            const payloadBytesCount = sizeAsArray.reduce((acc, e) => acc * e, 1);
            const actualPosStart = payloadPosMin;
            checkBounds(actualPosStart - terminatorBytesCountBefore, terminatorBytesCountBefore + payloadBytesCount + terminatorBytesCountAfter, env.fileUint8Array.length);
            const resultArray = env.fileUint8Array.subarray(actualPosStart, actualPosStart + payloadBytesCount);
            const result = {
                _parent: parent,
                posStart: (actualPosStart - terminatorBytesCountBefore).asX_HexStr,
                rawU8A: env.fileUint8Array.subarray(actualPosStart - terminatorBytesCountBefore, actualPosStart + payloadBytesCount + terminatorBytesCountAfter),
                v: resultArray,
            };
            if (elementsCount !== undefined && elementsCount !== null) {
                env.markFileSection(actualPosStart - terminatorBytesCountBefore, terminatorBytesCountBefore + payloadBytesCount + terminatorBytesCountAfter, varPath);
            }
            else {
                console.assert(!terminatorBytesCountBefore);
                console.assert(!terminatorBytesCountAfter);
                console.assert(actualPosStart === posStart);
                env.markFileSection(posStart, 0, varPath);
                env.rememberToExpand(result);
            }
            customAddHslString(actualPosStart, varPath, hslTools_1.hslBlobName, sizeAsArray, terminatorBytesCountBefore, terminatorBytesCountAfter);
            const expectedValues = args[1];
            if (expectedValues?.length > 0) {
                const errorMessage = validators_1.validateBlobOneOf(resultArray, expectedValues);
                if (errorMessage) {
                    env.reportValidationFail(varPath, posStart, errorMessage);
                }
            }
            return result;
        };
    }
}
class ZStringHReader {
    constructor() {
        this.readH = (args, env, posStart, varPath, customAddHslString, realAddHslString, parent) => {
            const result = new BlobHReader().readH([{ elementsUntil: ["00"] }], env, posStart, varPath, (pos, varPath, hslType) => customAddHslString(pos, varPath, hslTools_1.hslZStringName), realAddHslString, parent);
            return {
                ...result,
                v: String.fromCharCode(...Array.from(result.v)),
            };
        };
    }
}
class UintHReader {
    constructor() {
        this.readH = (args, env, posStart, varPath, customAddHslString, realAddHslString, parent) => {
            const bytesCount = args[0];
            checkBounds(posStart, bytesCount, env.fileUint8Array.length);
            const result = genericTools_1.readUintFrom(env.fileUint8Array, posStart, bytesCount);
            env.markFileSection(posStart, bytesCount, varPath);
            customAddHslString(posStart, varPath, hslTools_1.getUintHslType(bytesCount));
            const validationArg = args[1];
            if (validationArg !== undefined) {
                let errorMessage = "";
                if (Array.isArray(validationArg)) {
                    const validValues = validationArg;
                    errorMessage = validators_1.validateUintOneOf(result, validValues);
                }
                else {
                    errorMessage = validationArg(result);
                }
                if (errorMessage) {
                    env.reportValidationFail(varPath, posStart, errorMessage);
                }
            }
            return {
                _parent: parent,
                posStart: posStart.asX_HexStr,
                rawU8A: env.fileUint8Array.subarray(posStart, posStart + bytesCount),
                v: (bytesCount === 2 ? result.asAob2Str :
                    bytesCount === 4 ? result.asAob4Str :
                        result.asAobStr),
            };
        };
    }
}
class ZeroHReader {
    constructor() {
        this.readH = (args, ...restArgs) => {
            const bytesCount = args[0];
            return new UintHReader().readH([bytesCount, [0]], ...restArgs);
        };
    }
}
class FloatHReader {
    constructor() {
        this.readH = (args, env, posStart, varPath, customAddHslString, realAddHslString, parent) => {
            const bytesCount = 4;
            checkBounds(posStart, bytesCount, env.fileUint8Array.length);
            const result = new Float32Array(env.fileUint8Array.buffer.slice(posStart, posStart + bytesCount))[0];
            env.markFileSection(posStart, bytesCount, varPath);
            customAddHslString(posStart, varPath, hslTools_1.hslFloatName);
            return {
                _parent: parent,
                posStart: posStart.asX_HexStr,
                rawU8A: env.fileUint8Array.subarray(posStart, posStart + bytesCount),
                v: result,
            };
        };
    }
}
class PtrHReader {
    constructor() {
        this.readH = (args, env, posStart, varPath, customAddHslString, realAddHslString, parent) => {
            const bytesCount = consts_1.ptrSize;
            const params = args[1];
            checkBounds(posStart, bytesCount, env.fileUint8Array.length);
            const addr = (genericTools_1.readUintFrom(env.fileUint8Array, posStart, bytesCount) +
                (params?.getOffset?.(parent) ?? 0));
            const result = {
                _parent: parent,
                posStart: posStart.asX_HexStr,
                rawU8A: env.fileUint8Array.subarray(posStart, posStart + bytesCount),
                // FIXME: asAob8Str if ptrSize is 8
                v: addr.asAob4Str,
                p: true,
            };
            const errorMessage = validators_1.validatePtr(addr, env.fileUint8Array.length, { dontReportNullPtr: params?.dontReportNullPtr });
            if (errorMessage) {
                env.reportValidationFail(varPath, posStart, errorMessage);
            }
            else if (addr !== 0) {
                const underlayingTypeArg = args[0];
                if (underlayingTypeArg !== exports.dontDereferencePtr) {
                    result.dereference = (parent) => {
                        // TODO: check if parent was the same?
                        if (result.d)
                            return result.d;
                        const dereferencedVarPath = [...varPath, "->"];
                        let typeH;
                        if (typeof underlayingTypeArg === "function") {
                            typeH = underlayingTypeArg(parent, dereferencedVarPath);
                        }
                        else {
                            typeH = underlayingTypeArg;
                        }
                        result.d = doReadTypeH(typeH, env, addr, dereferencedVarPath, realAddHslString, realAddHslString, result);
                        return result.d;
                    };
                }
            }
            env.reportPtr(posStart, bytesCount);
            env.markFileSection(posStart, bytesCount, varPath);
            // TODO: turn into an actual pointer?
            customAddHslString(posStart, varPath, hslTools_1.getUintHslType(consts_1.ptrSize));
            return result;
        };
    }
}
class StructHReader {
    constructor() {
        this.readH = (args, env, posStart, varPath, customAddHslString, realAddHslString, parent) => {
            const resultAcc = createPropertyAccumulator();
            const result = {
                _parent: parent,
                posStart: posStart.asX_HexStr,
                rawU8A: null,
                v: resultAcc.result,
            };
            let pos = posStart;
            const entries = args[0];
            const dereferencer = createDereferencer();
            const toValidate = [];
            const hslStructBodyLines = [];
            for (const [varName, typeH, validator] of entries) {
                const propPos = pos;
                const propVarPath = [...varPath, varName];
                const fakeAddHslString = (pos, varPath, hslType, arrayDims, terminatorBytesCountBefore, terminatorBytesCountAfter) => {
                    console.assert(varPath.length === propVarPath.length &&
                        varPath.every((e, i) => e === propVarPath[i]));
                    console.assert(!terminatorBytesCountBefore);
                    console.assert(!terminatorBytesCountAfter);
                    hslStructBodyLines.push(env.getStructBodyLine(hslType, [...varPath].pop(), arrayDims));
                };
                const readHResult = doReadTypeH(typeH, env, propPos, propVarPath, fakeAddHslString, realAddHslString, result);
                console.assert(propPos === readHResult.posStart.dehexUint);
                pos += readHResult.rawU8A.length;
                resultAcc.addProperty(varName, readHResult);
                dereferencer.schedule(readHResult.dereference);
                if (validator) {
                    toValidate.push(() => {
                        const errorMessage = validator(readHResult.v, resultAcc.result);
                        if (errorMessage) {
                            env.reportValidationFail(propVarPath, propPos, errorMessage);
                        }
                    });
                }
            }
            result.rawU8A = env.fileUint8Array.subarray(posStart, pos);
            dereferencer.run(result);
            for (const validate of toValidate) {
                validate();
            }
            env.markFileSection(posStart, pos - posStart, varPath);
            const structName = env.getStructName(hslStructBodyLines);
            customAddHslString(posStart, varPath, structName);
            return result;
        };
    }
}
class ArrayHReader {
    constructor() {
        this.readH = (args, env, posStart, varPath, customAddHslString, realAddHslString, parent) => {
            const elementsCountArg = args[0];
            // const [elementsCount, terminatorBytesCount, direction] = (function(){
            const { elementsCount = undefined, 
            // FIXME
            // @ts-ignore
            elementSize: guessedElementSize = undefined, 
            // FIXME
            // @ts-ignore
            direction = 1, 
            // FIXME
            // @ts-ignore
            payloadPosMin = posStart, 
            // FIXME
            // @ts-ignore
            posMax = undefined, 
            // FIXME
            // @ts-ignore
            terminatorBytesCountBefore = 0, 
            // FIXME
            // @ts-ignore
            terminatorBytesCountAfter = 0, 
            // FIXME
            // @ts-ignore
            customShouldContinue = undefined, } = (function () {
                if ("elementsCount" in elementsCountArg) {
                    return { elementsCount: elementsCountArg.elementsCount };
                }
                if ("elementsUntil" in elementsCountArg) {
                    return findOutElementsCount(env.fileUint8Array, posStart, elementsCountArg.elementsUntil, false, elementsCountArg.direction);
                }
                ;
                if ("elementsWhile" in elementsCountArg) {
                    return findOutElementsCount(env.fileUint8Array, posStart, elementsCountArg.elementsWhile, true);
                }
                if ("elementsUntilPtr" in elementsCountArg) {
                    return { posMax: elementsCountArg.elementsUntilPtr };
                }
                if ("getElementsCount" in elementsCountArg) {
                    return { elementsCount: elementsCountArg.getElementsCount(parent) };
                }
                if ("getShouldContinue" in elementsCountArg) {
                    return { customShouldContinue: elementsCountArg.getShouldContinue };
                }
                throw new Error("Invalid array count argument");
            }());
            let pos = payloadPosMin;
            if ([elementsCount, posMax, customShouldContinue].filter(e => e !== undefined).length !== 1) {
                throw new Error("Invalid args");
            }
            const shouldContinue = ((elementsCount !== undefined)
                ? (i, pos) => i < elementsCount
                : customShouldContinue || ((i, pos) => pos < posMax));
            const resultArray = new Array();
            const result = {
                _parent: parent,
                posStart: null,
                rawU8A: null,
                v: resultArray,
            };
            const dereferencer = createDereferencer();
            const hslArrayEntries = new Array();
            const elementSizes = new Array();
            const typeH = args[1];
            let i = 0;
            while (shouldContinue(i, pos, env.fileUint8Array)) {
                const varName = `[${i}]`;
                const propPos = pos;
                const propVarPath = [...varPath, varName];
                const fakeAddHslString = (pos, varPath, hslType, arrayDims, terminatorBytesCountBefore, terminatorBytesCountAfter) => {
                    console.assert(varPath.length === propVarPath.length &&
                        varPath.every((e, i) => e === propVarPath[i]));
                    console.assert(!terminatorBytesCountBefore);
                    console.assert(!terminatorBytesCountAfter);
                    let newHslType = hslType;
                    if (arrayDims) {
                        newHslType = env.getArrayTypeName(hslType, arrayDims, terminatorBytesCountBefore, terminatorBytesCountAfter);
                    }
                    hslArrayEntries.push({
                        hslType: newHslType,
                        varName: "el" + [...varPath].pop().replaceAll("[", "").replaceAll("]", ""),
                    });
                };
                const readHResult = doReadTypeH(typeH, env, propPos, propVarPath, fakeAddHslString, realAddHslString, result);
                console.assert(propPos === readHResult.posStart.dehexUint);
                elementSizes.push(readHResult.rawU8A.length);
                if (elementsCount === undefined && readHResult.rawU8A.length === 0) {
                    throw new Error("Something went wrong");
                }
                pos += readHResult.rawU8A.length;
                resultArray.push(readHResult);
                dereferencer.schedule(readHResult.dereference);
                i += 1;
            }
            if (resultArray.length === 0) {
                const params = args[2];
                const errorMessage = validators_1.validateArrayNotEmpty(resultArray.length, params);
                if (errorMessage) {
                    env.reportValidationFail(varPath, posStart, errorMessage);
                }
                checkBounds(payloadPosMin - terminatorBytesCountBefore, terminatorBytesCountBefore + terminatorBytesCountAfter, env.fileUint8Array.length);
                env.markFileSection(payloadPosMin - terminatorBytesCountBefore, terminatorBytesCountBefore + terminatorBytesCountAfter, varPath);
                // TODO: figure out real type?
                customAddHslString(payloadPosMin, varPath, hslTools_1.hslBlobName, [0], terminatorBytesCountBefore, terminatorBytesCountAfter);
                result.posStart = (payloadPosMin - terminatorBytesCountBefore).asX_HexStr;
                result.rawU8A = env.fileUint8Array.subarray(payloadPosMin - terminatorBytesCountBefore, payloadPosMin + terminatorBytesCountAfter);
                return result;
            }
            // TODO: reverse dereferencer as well?
            if (direction === -1)
                resultArray.reverse();
            if (!hslArrayEntries.length ||
                hslArrayEntries.length !== elementSizes.length)
                throw new Error("something went wrong");
            result.posStart = (payloadPosMin - terminatorBytesCountBefore).asX_HexStr;
            result.rawU8A = env.fileUint8Array.subarray(payloadPosMin - terminatorBytesCountBefore, pos + terminatorBytesCountAfter);
            dereferencer.run(result);
            env.markFileSection(payloadPosMin - terminatorBytesCountBefore, pos - (payloadPosMin - terminatorBytesCountBefore) + terminatorBytesCountAfter, varPath);
            if (hslArrayEntries.every((e, i, a) => e.hslType === a[0].hslType) &&
                elementSizes.every((e, i, a) => e === a[0])) {
                customAddHslString(payloadPosMin, varPath, hslArrayEntries[0].hslType, [resultArray.length], terminatorBytesCountBefore, terminatorBytesCountAfter);
            }
            else {
                const structName = env.getStructName(hslArrayEntries.map(e => env.getStructBodyLine(e.hslType, e.varName)), terminatorBytesCountBefore, terminatorBytesCountAfter);
                customAddHslString(payloadPosMin, varPath, structName, undefined, terminatorBytesCountBefore, terminatorBytesCountAfter);
            }
            return result;
        };
    }
}
class SwitchHReader {
    constructor() {
        this.readH = (args, env, posStart, varPath, customAddHslString, realAddHslString, parent) => {
            const typeH = args[1 + args[0](parent)];
            return doReadTypeH(typeH, env, posStart, varPath, customAddHslString, realAddHslString, parent);
        };
    }
}
//
exports.h = {
    blob: createHelper(BlobHReader),
    zString: createHelper(ZStringHReader),
    uint: createHelper(UintHReader),
    zero: createHelper(ZeroHReader),
    float: createHelper(FloatHReader),
    ptr: createHelper(PtrHReader),
    struct: createHelper(StructHReader),
    array: createHelper(ArrayHReader),
    switch: createHelper(SwitchHReader),
};
exports.bytesUntilFFType = exports.h.blob({ elementsUntil: ["FF"] });
// FIXME: confirm types
function createHelper(hReaderClass) {
    return (...args) => {
        return {
            hReaderClass,
            args,
        };
    };
}
function doReadTypeH(typeH, env, posStart, varPath, customAddHslString, realAddHslString, parent) {
    return new typeH.hReaderClass().readH(typeH.args, env, posStart, varPath, customAddHslString, realAddHslString, parent);
}
exports.doReadTypeH = doReadTypeH;
// tools
function findOutElementsCount(fileUint8Array, posStart, aobStrs, include, direction = 1) {
    const elementSize = aobStrs[0].aobLength;
    console.assert(elementSize > 0 &&
        aobStrs.every(aobStr => aobStr.aobLength === elementSize));
    let pos = posStart;
    let elementsCount = 0;
    let payloadPosMin = undefined;
    while (true) {
        checkBounds(pos, elementSize, fileUint8Array.length);
        const aobStr = fileUint8Array.subarray(pos, pos + elementSize).asAobStr;
        const carryOn = (include
            ? aobStrs.some(pattern => aobTools_1.doesAobStrMatch(aobStr, pattern))
            : aobStrs.every(pattern => !aobTools_1.doesAobStrMatch(aobStr, pattern)));
        if (!carryOn) {
            return {
                elementsCount,
                elementSize,
                direction,
                payloadPosMin,
                terminatorBytesCountBefore: !include && direction < 0 ? elementSize : 0,
                terminatorBytesCountAfter: !include && direction > 0 ? elementSize : 0,
            };
        }
        payloadPosMin = Math.min(payloadPosMin ?? Infinity, pos);
        elementsCount += 1;
        pos += elementSize * direction;
    }
}
function checkBounds(from, bytes, length) {
    if (from < 0 || from + bytes > length) {
        // FIXME: better messsage
        throw new Error("EOF");
    }
}
function createPropertyAccumulator() {
    const result = Object.create(null);
    return {
        addProperty,
        result,
    };
    function addProperty(propName, value) {
        if (propName in result) {
            console.warn(`overwriting ${propName}`);
        }
        result[propName] = value;
    }
}
function createDereferencer() {
    const toDereference = new Array();
    return {
        schedule,
        run,
    };
    function schedule(dereference) {
        if (dereference) {
            toDereference.push(dereference);
        }
    }
    function run(parent) {
        for (const dereference of toDereference) {
            let dereferenced = dereference(parent);
            while (dereferenced.dereference) {
                dereferenced = dereferenced.dereference(dereferenced);
            }
        }
    }
}

},{"./aobTools":2,"./consts":3,"./genericTools":7,"./hslTools":8,"./validators":11}],11:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateArrayNotEmpty = exports.validatePtr = exports.validateBlobOneOf = exports.validateUintOneOf = exports.validateNotZero = exports.validateDupOf = void 0;
function validateDupOf(sourceVarName) {
    return (value, parent) => {
        const foundValue = parent[sourceVarName].v;
        if (value === foundValue)
            return "";
        return `${value} doesn't duplicate ${foundValue}`;
    };
}
exports.validateDupOf = validateDupOf;
function validateNotZero(value) {
    if (value !== 0)
        return "";
    return `${value.asX_HexStr} is not non-zero`;
}
exports.validateNotZero = validateNotZero;
function validateUintOneOf(result, validValues) {
    if (!validValues.includes(result)) {
        return (`${result.asX_HexStr} is not one of ` +
            `[${validValues.map(e => e.asX_HexStr).join(",")}]`);
    }
    return "";
}
exports.validateUintOneOf = validateUintOneOf;
function validateBlobOneOf(result, expectedValues) {
    const resultAsAobStr = result.asAobStr;
    if (!expectedValues.includes(resultAsAobStr)) {
        return ("Found value is not one of expected; " +
            `found =\n${resultAsAobStr}\n` +
            `expected =\n${expectedValues.join(",\n")}`);
    }
    return "";
}
exports.validateBlobOneOf = validateBlobOneOf;
function validatePtr(addr, fileLength, params) {
    if (addr >= fileLength) {
        return ("Pointer value is out of bounds (" +
            `${addr.asX_HexStr} / ${fileLength.asX_HexStr}` +
            ")");
    }
    else if (addr === 0) {
        if (!params?.dontReportNullPtr) {
            return "Pointer is a null pointer";
        }
    }
    return "";
}
exports.validatePtr = validatePtr;
function validateArrayNotEmpty(arrayLength, params) {
    if (arrayLength === 0 && !params?.dontReportEmpty) {
        return "Array is empty";
    }
    return "";
}
exports.validateArrayNotEmpty = validateArrayNotEmpty;

},{}]},{},[9]);
