export type VarName = string;
export type VarPath = Array<VarName>;

export type ErrorMessage = string;

export type AobStr = string;
export type FlatAobStr = string;
export type AobMatchStr = string;
export type NumberAsAobStr = AobStr;
export type NumberAsX_HexStr = string;

// TODO: move somewhere else
export type HslTypeName = string;
export type HslStructureName = HslTypeName;
