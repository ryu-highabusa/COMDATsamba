export const ptrSize = 4;
