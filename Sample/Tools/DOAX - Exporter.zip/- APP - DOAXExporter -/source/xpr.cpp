// DOAX XPR
//
#include <windows.h>
#include <stdio.h>
#include <d3d9types.h>
#include "xpr.h"


// D3D Flexible vertex format description
const static DWORD	pdwFVFType[4][4] = {  // [IVBufInfo No][Num Weights]
	{ (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX1), (D3DFVF_XYZB1|D3DFVF_NORMAL|D3DFVF_TEX1), (D3DFVF_XYZB2|D3DFVF_NORMAL|D3DFVF_TEX1), (D3DFVF_XYZB3|D3DFVF_NORMAL|D3DFVF_TEX1) },
	{ D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_TEX1, 0, 0, 0 },
	{ (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX2), (D3DFVF_XYZB1|D3DFVF_NORMAL|D3DFVF_TEX2), (D3DFVF_XYZB2|D3DFVF_NORMAL|D3DFVF_TEX2), (D3DFVF_XYZB3|D3DFVF_NORMAL|D3DFVF_TEX2) },
	{ D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_TEX2, 0, 0, 0 },
};

// D3D Flexible vertex format size
const static DWORD	pdwFVFSize[4][4] = {  // [IVBufInfo No][Num Weights]
	{ sizeof(ST_VERTEXFORMAT0_0), sizeof(ST_VERTEXFORMAT1_0), sizeof(ST_VERTEXFORMAT2_0), sizeof(ST_VERTEXFORMAT3_0) },
	{ sizeof(ST_VERTEXFORMAT0_1), 0, 0, 0 },
	{ sizeof(ST_VERTEXFORMAT0_2), sizeof(ST_VERTEXFORMAT1_2), sizeof(ST_VERTEXFORMAT2_2), sizeof(ST_VERTEXFORMAT3_2) },
	{ sizeof(ST_VERTEXFORMAT0_2), 0, 0, 0 },
};


///// DEBUG /////
#define	ID_XPR_HEADER			0
#define ID_MDL_HEADER			1
#define	ID_OBJ_HEADER			2
#define	ID_MAT_HEADER			3
#define	ID_MAT_TEXTURE			4
#define	ID_MAT_MESH				5
#define	ID_TXT_HEADER			6
#define	ID_VBUF_HEADER			7
#define	ID_IBUF_HEADER			8

static	DWORD	g_dwDebugOffset	= 0;
static	DWORD	dwDebugObj		= 0;
static	DWORD	dwDebugMat		= 0;
static	DWORD	dwDebugTxt		= 0;
static	DWORD	dwDebugVBuf		= 0;
static	DWORD	dwDebugIBuf		= 0;

static	FILE *g_pDebugFile		= NULL;
static	VOID PrintDebug( VOID *, DWORD );


///// GLOBAL /////
static	FILE		*g_pXprFile		= NULL;


///// FUNCTIONS /////
static	BOOL HandleResource( ST_MY_MDL * );
static	BOOL HandleMdl( ST_MY_MDL * pModel, DWORD * pdwHeaderOffset );
static	BOOL HandleObj( ST_MY_MDL * pModel, ST_MY_OBJ * pObject, DWORD * pdwIVBufNo );
static	BOOL HandleMat( ST_MY_MAT * pMaterial, DWORD * pdwIVBufNoList );
static	BOOL HandleVBuf( VOID );
static	BOOL HandleTxt( ST_DDSTEXTURE * pTexture, DWORD dwDataOffset );



//-----------------------------------------------------------------------------
// Name: XPR_Open()
// Desc: Program entry point
//-----------------------------------------------------------------------------
ST_MY_MDL * XPR_Open( CHAR *szFileName )
{
	ST_MY_MDL	*pModel;


	// Load XPR file
	g_pXprFile = fopen( szFileName, "rb" );

	if( !g_pXprFile )
		return NULL;

	pModel = new ST_MY_MDL;

	///// DEBUG
	g_pDebugFile = fopen( "debug.txt", "wt" );
	fprintf( g_pDebugFile, "%s\n\n", szFileName );

	// Parse XPR
	if( !HandleResource(pModel) )
	{
		///// DEBUG
		fclose(g_pDebugFile);
		
		return NULL;
	}
	
	///// DEBUG
	fclose(g_pDebugFile);

	fclose(g_pXprFile);


	return pModel;
}



//-----------------------------------------------------------------------------
// Name: XPR_Close()
// Desc: Program entry point
//-----------------------------------------------------------------------------
VOID XPR_Close( ST_MY_MDL * pModel )
{
	DWORD	i, j, k;
	
	
	if( !pModel )
		return;

	// Delete vertex buffers
	for( i = 0; i < pModel->dwNumVBuf; i++ )
		delete[]	pModel->pVBufList[i].pVertexList;
	delete[]	pModel->pVBufList;

	// Delete index buffers
	for( i = 0; i < pModel->dwNumIBuf; i++ )
		delete[]	pModel->pIBufList[i].pIndexList;
	delete[]	pModel->pIBufList;

	// Delete textures
	for( i = 0; i < pModel->dwNumTxt; i++ )
		delete[]	pModel->pTxtList[i].pbImageData;
	delete[]	pModel->pTxtList;

	// Delete objects
	for( i = 0; i < pModel->dwNumObj; i++ )
	{
		for( j = 0; j < pModel->pObjList[i].dwNumSubobj; j++ )
		{
			for( k = 0; k < pModel->pObjList[i].pSubobjList[j].dwNumMat; k++ )
			{
				// Delete materials
				delete[]	pModel->pObjList[i].pSubobjList[j].pMatList[k].pdwTxtList;
				delete[]	pModel->pObjList[i].pSubobjList[j].pMatList[k].pdwStripList;
			}
			delete[]	pModel->pObjList[i].pSubobjList[j].pMatList;
		}
		delete[]	pModel->pObjList[i].pSubobjList;
	}
	delete[]	pModel->pObjList;


	delete		pModel;
}



//-----------------------------------------------------------------------------
// Name: HandleResource()
// Desc: Handle resource
//-----------------------------------------------------------------------------
BOOL HandleResource( ST_MY_MDL * pModel )
{
	DWORD	dwObjNo, dwIVBufNo, dwVBufNo, dwTxtNo;
	DWORD	dwFilePos, dwTemp;
	DWORD	dwDataOffset, dwHeaderOffset;
	DWORD	dwObjOffset;


	// Handle XPR Header
	ST_XPR_HEADER *pXprHeader = new ST_XPR_HEADER;
	fread(pXprHeader, sizeof(ST_XPR_HEADER), 1, g_pXprFile);
	///// DEBUG
	PrintDebug(pXprHeader, ID_XPR_HEADER);
	dwDataOffset = pXprHeader->dwHeaderSize;
	delete pXprHeader;

	// Handle model
	if( !HandleMdl( pModel, &dwHeaderOffset ) )
		return FALSE;

	// Handle objects
	dwIVBufNo = 0;
	pModel->pVBufList = new ST_MY_VBUF[pModel->dwNumVBuf];
	pModel->pIBufList = new ST_MY_IBUF[pModel->dwNumIBuf];
	pModel->pObjList  = new ST_MY_OBJ[pModel->dwNumObj];
	for( dwObjNo = 0; dwObjNo < pModel->dwNumObj; dwObjNo++ )
	{
		// Read object offsets list
		fread( &dwObjOffset, sizeof(DWORD), 1, g_pXprFile);
		dwFilePos = ftell( g_pXprFile );
		fseek( g_pXprFile, dwObjOffset, SEEK_SET );
		// Handle object
		g_dwDebugOffset = dwObjOffset;
		if( !HandleObj( pModel, &pModel->pObjList[dwObjNo], &dwIVBufNo ) )
			return FALSE;
		fseek( g_pXprFile, dwFilePos, SEEK_SET );
	}
	// Objects offsets list end with 0x00000000
	fread( &dwTemp, sizeof(DWORD), 1, g_pXprFile );
	if( dwTemp != 0x00000000 )
		return FALSE;


	// Jump to vertex buffer and texture header
	fseek( g_pXprFile, dwHeaderOffset, SEEK_SET );
	g_dwDebugOffset = dwHeaderOffset;

	// Handle vertex buffers
	for( dwVBufNo = 0; dwVBufNo < pModel->dwNumVBuf; dwVBufNo++ )
	{
		if( !HandleVBuf() )
			return FALSE;
	}

	// Handle textures
	pModel->pTxtList = new ST_DDSTEXTURE[pModel->dwNumTxt];
	for( dwTxtNo = 0; dwTxtNo < pModel->dwNumTxt; dwTxtNo++ )
	{
		if( !HandleTxt( &pModel->pTxtList[dwTxtNo], dwDataOffset ) )
			return FALSE;
	}

	// XPR header end with 0xFFFFFFFF
	fread(&dwTemp, sizeof(DWORD), 1, g_pXprFile);
	if( dwTemp != 0xFFFFFFFF )
		return FALSE;


	return TRUE;
}



//-----------------------------------------------------------------------------
// Name: HandleMdl()
// Desc: Handle model information
//-----------------------------------------------------------------------------
BOOL HandleMdl( ST_MY_MDL * pModel, DWORD * pdwHeaderOffset )
{
	ST_XPR_CHUNK	stXprChunk;


	// Copy model chunk // 0x80000000
	fread( &stXprChunk, sizeof(ST_XPR_CHUNK), 1, g_pXprFile );
	if( stXprChunk.dwMagic != CHUNK_MODEL )
		return FALSE;
	// Copy model header
	ST_MDL_HEADER *pMdlHeader = new ST_MDL_HEADER;
	fread( pMdlHeader, sizeof(ST_MDL_HEADER), 1, g_pXprFile );
	///// DEBUG
	PrintDebug( pMdlHeader, ID_MDL_HEADER );

	pModel->dwNumObj  = pMdlHeader->dwNumObj;
	pModel->dwNumVBuf = pMdlHeader->dwNumIVBuf;
	pModel->dwNumIBuf = pMdlHeader->dwNumIVBuf;
	pModel->dwNumTxt  = pMdlHeader->dwNumTxt;
	*pdwHeaderOffset = sizeof(ST_XPR_HEADER) + pMdlHeader->dwSize + 8;

	delete pMdlHeader;


	return TRUE;
}



//-----------------------------------------------------------------------------
// Name: HandleObj()
// Desc: Handle object information
//-----------------------------------------------------------------------------
BOOL HandleObj( ST_MY_MDL * pModel, ST_MY_OBJ * pObject, DWORD * pdwIVBufNo )
{
	DWORD	pdwIVBufNoList[4];
	DWORD	pdwSubobjNoList[4];
	DWORD	dwIVBufInfoNo, dwSubobjNo, dwMatNo;
	DWORD	dwFilePos, dwTemp;


	// Copy object header
	ST_OBJ_HEADER *pObjHeader = new ST_OBJ_HEADER;
	fread( pObjHeader, sizeof(ST_OBJ_HEADER), 1, g_pXprFile );
	///// DEBUG
	PrintDebug( pObjHeader, ID_OBJ_HEADER );

	dwFilePos = ftell( g_pXprFile );

	// Find number of subobjects
	pObject->dwNumSubobj = 0;
	for( dwIVBufInfoNo = 0; dwIVBufInfoNo < 4; dwIVBufInfoNo++ )
	{
		if( pObjHeader->pIVBufInfo[dwIVBufInfoNo].dwNumIndices)
			pObject->dwNumSubobj++;
	}
	// Allocate subobjects
	pObject->pSubobjList = new ST_MY_SUBOBJ[pObject->dwNumSubobj];

	// Load Vertex and Index buffers
	dwSubobjNo = 0;
	for( dwIVBufInfoNo = 0; dwIVBufInfoNo < 4; dwIVBufInfoNo++ )
	{
		if( pObjHeader->pIVBufInfo[dwIVBufInfoNo].dwNumIndices)
		{
			pdwIVBufNoList[dwIVBufInfoNo]  = *pdwIVBufNo;
			pdwSubobjNoList[dwIVBufInfoNo] = dwSubobjNo;
			pObject->pSubobjList[dwSubobjNo].dwVBufNo = *pdwIVBufNo;
			dwSubobjNo++;

			// Allocate and store vertex buffer
			pModel->pVBufList[*pdwIVBufNo].dwVertexType  = pdwFVFType[dwIVBufInfoNo][pObjHeader->dwNumWeights]; // Vertex type
			pModel->pVBufList[*pdwIVBufNo].dwVertexSize  = pdwFVFSize[dwIVBufInfoNo][pObjHeader->dwNumWeights]; // Vertex size
			pModel->pVBufList[*pdwIVBufNo].dwNumVertices = pObjHeader->pIVBufInfo[dwIVBufInfoNo].dwNumVertices; // Number of vertices
			pModel->pVBufList[*pdwIVBufNo].pVertexList = new BYTE[pModel->pVBufList[*pdwIVBufNo].dwNumVertices * pModel->pVBufList[*pdwIVBufNo].dwVertexSize];

			fseek( g_pXprFile, pObjHeader->pIVBufInfo[dwIVBufInfoNo].dwVBufOffset, SEEK_SET );
			fread( pModel->pVBufList[*pdwIVBufNo].pVertexList, pModel->pVBufList[*pdwIVBufNo].dwVertexSize, pModel->pVBufList[*pdwIVBufNo].dwNumVertices, g_pXprFile );
			
			// Allocate and store index buffer
			pModel->pIBufList[*pdwIVBufNo].dwNumIndices  = pObjHeader->pIVBufInfo[dwIVBufInfoNo].dwNumIndices;  // Number of indices
			pModel->pIBufList[*pdwIVBufNo].pIndexList = new WORD[pModel->pIBufList[*pdwIVBufNo].dwNumIndices];

			fseek( g_pXprFile, pObjHeader->pIVBufInfo[dwIVBufInfoNo].dwIBufOffset, SEEK_SET );
			fread( pModel->pIBufList[*pdwIVBufNo].pIndexList, sizeof(WORD), pModel->pIBufList[*pdwIVBufNo].dwNumIndices, g_pXprFile );

			(*pdwIVBufNo)++;
		}
	}
	fseek( g_pXprFile, dwFilePos, SEEK_SET );

	delete pObjHeader;


	// Count number of materials for each subobjects
	// Reset number of material
	for( dwSubobjNo = 0; dwSubobjNo < pObject->dwNumSubobj; dwSubobjNo++ )
		pObject->pSubobjList[dwSubobjNo].dwNumMat = 0;
	// Count materials
	fread( &dwTemp, sizeof(DWORD), 1, g_pXprFile ); // Read chunk
	while( dwTemp & 0x80000000 )
	{
		fread( &dwTemp, sizeof(DWORD), 1, g_pXprFile ); // Read material size
		fseek( g_pXprFile, 24, SEEK_CUR );
		fseek( g_pXprFile, sizeof(ST_MAT_COLOR), SEEK_CUR );
		fread( &dwTemp, sizeof(DWORD), 1, g_pXprFile ); // Read number of textures
		fseek( g_pXprFile, 8, SEEK_CUR );
		fseek( g_pXprFile, dwTemp*sizeof(ST_MAT_TEXTURE), SEEK_CUR );
		fread( &dwTemp, sizeof(DWORD), 1, g_pXprFile ); // Read material owner
		pObject->pSubobjList[ pdwSubobjNoList[dwTemp>>16] ].dwNumMat++;
		fseek( g_pXprFile, 12, SEEK_CUR );

		fread( &dwTemp, sizeof(DWORD), 1, g_pXprFile ); // Read chunk
	}
	fseek( g_pXprFile, dwFilePos, SEEK_SET );


	// Handle materials
	for( dwSubobjNo = pObject->dwNumSubobj; dwSubobjNo > 0; dwSubobjNo-- )
	{
		// Allocate materials
		pObject->pSubobjList[dwSubobjNo-1].pMatList = new ST_MY_MAT[pObject->pSubobjList[dwSubobjNo-1].dwNumMat];
		for ( dwMatNo = 0; dwMatNo < pObject->pSubobjList[dwSubobjNo-1].dwNumMat; dwMatNo++ )
		{
			// Handle material
			if( !HandleMat( &pObject->pSubobjList[dwSubobjNo-1].pMatList[dwMatNo], pdwIVBufNoList ) )
				return FALSE;
		}
	}

	// Materials end with 0x00000000
	fread( &dwTemp, sizeof(DWORD), 1, g_pXprFile );
	if( dwTemp != 0x00000000 )
		return FALSE;

	// Index buffer data start with 0x12345678
	fread( &dwTemp, sizeof(DWORD), 1, g_pXprFile );
	if( dwTemp != 0x12345678 )
		return FALSE;


	return TRUE;
}



//-----------------------------------------------------------------------------
// Name: HandleMat()
// Desc: Handle material information
//-----------------------------------------------------------------------------
BOOL HandleMat( ST_MY_MAT * pMaterial, DWORD * pdwIVBufNoList )
{
	ST_XPR_CHUNK	stXprChunk;
	DWORD	dwTxtNo;


	// Copy material chunk // 0x80000000
	fread( &stXprChunk, sizeof(ST_XPR_CHUNK), 1, g_pXprFile );
	if( !(stXprChunk.dwMagic & CHUNK_MODEL))
		return FALSE;
	// Copy material header
	ST_MAT_HEADER *pMatHeader = new ST_MAT_HEADER;
	fread( pMatHeader, sizeof(ST_MAT_HEADER), 1, g_pXprFile );
	///// DEBUG
	PrintDebug( pMatHeader, ID_MAT_HEADER );

	// Material color
	memcpy( &pMaterial->stColor, &pMatHeader->stColor, sizeof(ST_MY_COLOR) );

	// Material textures
	pMaterial->dwNumTxt = pMatHeader->dwNumTxt;
	pMaterial->pdwTxtList = new DWORD[pMaterial->dwNumTxt];
	for( dwTxtNo = 0; dwTxtNo < pMaterial->dwNumTxt; dwTxtNo++ )
	{
		// Copy material texture information
		ST_MAT_TEXTURE *pMatTxt = new ST_MAT_TEXTURE;
		fread( pMatTxt, sizeof(ST_MAT_TEXTURE), 1, g_pXprFile );
		///// DEBUG
		PrintDebug( pMatTxt, ID_MAT_TEXTURE );
		
		pMaterial->pdwTxtList[dwTxtNo] = pMatTxt->dwTxtNo;

		delete pMatTxt;
	}

	// Copy material mesh information
	ST_MAT_MESH *pMatMesh = new ST_MAT_MESH;
	fread( pMatMesh, sizeof(ST_MAT_MESH), 1, g_pXprFile );
	///// DEBUG
	PrintDebug( pMatMesh, ID_MAT_MESH );

	pMaterial->dwNumStrip = 1; // Always 1 strip
	pMaterial->pdwStripList = new ST_MY_STRIP[pMaterial->dwNumStrip];
	pMaterial->dwIBufNo = pdwIVBufNoList[pMatMesh->wIVBufferNo];

	pMaterial->pdwStripList[0].dwIndexStart = pMatMesh->dwIndexStart;
	pMaterial->pdwStripList[0].dwIndexCount = pMatMesh->dwNumPrimitives;

	delete pMatMesh;

	delete pMatHeader;


	return TRUE;
}



//-----------------------------------------------------------------------------
// Name: HandleVBuf()
// Desc: Handle vertex buffer information
//-----------------------------------------------------------------------------
BOOL HandleVBuf( VOID )
{
	ST_XPR_CHUNK	stXprChunk;


	// Copy vertex buffer chunk // 0x00800001
	fread( &stXprChunk, sizeof(ST_XPR_CHUNK), 1, g_pXprFile );
	if( stXprChunk.dwMagic != CHUNK_VBUFFER )
		return FALSE;
	// Copy vertex buffer header
	ST_VBUF_HEADER *pVBufHeader = new ST_VBUF_HEADER;
	fread( pVBufHeader, sizeof(ST_VBUF_HEADER), 1, g_pXprFile );
	///// DEBUG
	PrintDebug( pVBufHeader, ID_VBUF_HEADER );

	delete pVBufHeader;


	return TRUE;
}



//-----------------------------------------------------------------------------
// Name: HandleTxt()
// Desc: Handle texture information
//-----------------------------------------------------------------------------
BOOL HandleTxt( ST_DDSTEXTURE * pTexture, DWORD dwDataOffset )
{
	ST_XPR_CHUNK	stXprChunk;
	DWORD	dwFilePos;

	
	// Copy texture chunk // 0x00040001
	fread( &stXprChunk, sizeof(ST_XPR_CHUNK), 1, g_pXprFile );
	if( stXprChunk.dwMagic != CHUNK_TEXTURE )
		return FALSE;
	// Copy texture header
	ST_TXT_HEADER *pTxtHeader = new ST_TXT_HEADER;
	fread( pTxtHeader, sizeof(ST_TXT_HEADER), 1, g_pXprFile );
	///// DEBUG
	PrintDebug( pTxtHeader, ID_TXT_HEADER );

	dwFilePos = ftell( g_pXprFile );
	
	fseek( g_pXprFile, dwDataOffset + pTxtHeader->dwOffset, SEEK_SET);
	DDS_Init( pTexture, pTxtHeader->dwType );
	pTexture->pbImageData = new BYTE[pTexture->dwImageSize];
	fread( pTexture->pbImageData, sizeof(BYTE), pTexture->dwImageSize, g_pXprFile );

	fseek( g_pXprFile, dwFilePos, SEEK_SET ); 

	delete pTxtHeader;


	return TRUE;
}


//-----------------------------------------------------------------------------
// Name: PrintDebug()
// Desc: Display debug information
//-----------------------------------------------------------------------------
VOID PrintDebug( VOID *pStruct, DWORD dwStructType )
{
	DWORD	i;
	CHAR	szName[5];

	switch( dwStructType )
	{
	case ID_XPR_HEADER:
		fprintf(g_pDebugFile, "\nXPR\n");
		fprintf(g_pDebugFile, "%08X\tCRC                   : %u\n", g_dwDebugOffset, ((ST_XPR_HEADER*)pStruct)->dwCRC);							g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\tCrypted XPR Size      : %u\n", g_dwDebugOffset, ((ST_XPR_HEADER*)pStruct)->dwXPRSize);						g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\tHeader Size           : %u\n", g_dwDebugOffset, ((ST_XPR_HEADER*)pStruct)->dwHeaderSize);					g_dwDebugOffset += 4;
		break;
	case ID_MDL_HEADER:
		fprintf(g_pDebugFile, "\nMODEL\n");
		szName[4]=0; for(i=0;i<4;i++) szName[i]=((ST_MDL_HEADER*)pStruct)->szMagic[i];
		g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\tSize                  : %u\n", g_dwDebugOffset, ((ST_MDL_HEADER*)pStruct)->dwSize);						g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\tMagic                 : %s\n", g_dwDebugOffset, szName);													g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\tNumber of objects     : %u\n", g_dwDebugOffset, ((ST_MDL_HEADER*)pStruct)->dwNumObj);						g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\tNumber of textures    : %u\n", g_dwDebugOffset, ((ST_MDL_HEADER*)pStruct)->dwNumTxt);						g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\tUnknown               : %u\n", g_dwDebugOffset, ((ST_MDL_HEADER*)pStruct)->dwUnknown0);					g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\tNumber of IV buffers  : %u\n", g_dwDebugOffset, ((ST_MDL_HEADER*)pStruct)->dwNumIVBuf);					g_dwDebugOffset += 4;
		break;
	case ID_OBJ_HEADER:
		dwDebugObj++;
		dwDebugMat = 0;
		fprintf(g_pDebugFile, "\n------- OBJECT[%d]\n", dwDebugObj);
		szName[4]=0; for(i=0;i<4;i++) szName[i]=((ST_OBJ_HEADER*)pStruct)->szMagic[i];
		fprintf(g_pDebugFile, "%08X\t\tMagic               : %s\n", g_dwDebugOffset, szName);													g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\tNumber of weights   : %u\n", g_dwDebugOffset, ((ST_OBJ_HEADER*)pStruct)->dwNumWeights);					g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\tUnknown0            : %u\n", g_dwDebugOffset, ((ST_OBJ_HEADER*)pStruct)->dwUnknown0);					g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\tNumber of indices   : %u\n", g_dwDebugOffset, ((ST_OBJ_HEADER*)pStruct)->dwNumIndices);					g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\tObject center x     : %f\n", g_dwDebugOffset, ((ST_OBJ_HEADER*)pStruct)->fCenterX);						g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\tObject center y     : %f\n", g_dwDebugOffset, ((ST_OBJ_HEADER*)pStruct)->fCenterY);						g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\tObject center z     : %f\n", g_dwDebugOffset, ((ST_OBJ_HEADER*)pStruct)->fCenterZ);						g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\tObject radius       : %f\n", g_dwDebugOffset, ((ST_OBJ_HEADER*)pStruct)->fRadius);						g_dwDebugOffset += 4;
		for(i=0;i<4;i++){
		fprintf(g_pDebugFile, "%08X\t\tNumber of vertices  : %u\n", g_dwDebugOffset, ((ST_OBJ_HEADER*)pStruct)->pIVBufInfo[i].dwNumVertices);	g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\tVertex buffer offset: %u\n", g_dwDebugOffset, ((ST_OBJ_HEADER*)pStruct)->pIVBufInfo[i].dwVBufOffset);	g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\tNumber of indices   : %u\n", g_dwDebugOffset, ((ST_OBJ_HEADER*)pStruct)->pIVBufInfo[i].dwNumIndices);	g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\tIndex buffer offset : %u\n", g_dwDebugOffset, ((ST_OBJ_HEADER*)pStruct)->pIVBufInfo[i].dwIBufOffset);	g_dwDebugOffset += 4;
		}
		for(i=0;i<16;i++){fprintf(g_pDebugFile, "%08X\t\tPad1[%02d]            : %u\n", g_dwDebugOffset, i, ((ST_OBJ_HEADER*)pStruct)->dwPad1[i]);	g_dwDebugOffset += 4;}
		break;
	case ID_MAT_HEADER:
		dwDebugMat++;
		g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "\n\t------- MATERIAL[%d_%d]\n", dwDebugObj, dwDebugMat);
		fprintf(g_pDebugFile, "%08X\t\t\tSize                  : %u\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->dwSize);					g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tUnknown0              : %u\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->dwUnknown0);				g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tUnknown1              : %u\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->dwUnknown1);				g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tSub-object center x   : %f\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->fCenterX);					g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tSub-object center y   : %f\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->fCenterY);					g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tSub-object center z   : %f\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->fCenterZ);					g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tSub-object radius     : %f\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->fRadius);					g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tDiffuse Red           : %f\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->stColor.stColorDiffuse.r);	g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tDiffuse Green         : %f\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->stColor.stColorDiffuse.g);	g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tDiffuse Blue          : %f\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->stColor.stColorDiffuse.b);	g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tDiffuse Alpha         : %f\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->stColor.stColorDiffuse.a);	g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tAmbient Red           : %f\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->stColor.stColorAmbient.r);	g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tAmbient Green         : %f\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->stColor.stColorAmbient.g);	g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tAmbient Blue          : %f\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->stColor.stColorAmbient.b);	g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tAmbient Alpha         : %f\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->stColor.stColorAmbient.a);	g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tSpecular Red          : %f\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->stColor.stColorSpecular.r);	g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tSpecular Green        : %f\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->stColor.stColorSpecular.g);	g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tSpecular Blue         : %f\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->stColor.stColorSpecular.b);	g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tSpecular Alpha        : %f\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->stColor.stColorSpecular.a);	g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tEmissive Red          : %f\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->stColor.stColorEmissive.r);	g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tEmissive Green        : %f\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->stColor.stColorEmissive.g);	g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tEmissive Blue         : %f\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->stColor.stColorEmissive.b);	g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tEmissive Alpha        : %f\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->stColor.stColorEmissive.a);	g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tSpecular power        : %f\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->stColor.fSpecularPower);	g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tNumber of textures    : %u\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->dwNumTxt);					g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tUnknown2              : %u\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->dwUnknown2);				g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tUnknown3              : %08X\n", g_dwDebugOffset, ((ST_MAT_HEADER*)pStruct)->dwUnknown3);				g_dwDebugOffset += 4;
		break;
	case ID_MAT_TEXTURE:
		fprintf(g_pDebugFile, "\n\t        MATERIAL TEXTURE\n");
		fprintf(g_pDebugFile, "%08X\t\t\tTexture number        : %u\n", g_dwDebugOffset, ((ST_MAT_TEXTURE*)pStruct)->dwTxtNo);					g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tUnknown0              : %u\n", g_dwDebugOffset, ((ST_MAT_TEXTURE*)pStruct)->dwUnknown0);				g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tUnknown1              : %u\n", g_dwDebugOffset, ((ST_MAT_TEXTURE*)pStruct)->dwUnknown1);				g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tUnknown2              : %u\n", g_dwDebugOffset, ((ST_MAT_TEXTURE*)pStruct)->dwUnknown2);				g_dwDebugOffset += 4;
		break;
	case ID_MAT_MESH:
		fprintf(g_pDebugFile, "\n\t        MATERIAL MESH\n");
		fprintf(g_pDebugFile, "%08X\t\t\tVertex buffer number  : %u\n", g_dwDebugOffset, ((ST_MAT_MESH*)pStruct)->wIVBufferNo);					g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tSize of one vertex    : %u\n", g_dwDebugOffset, ((ST_MAT_MESH*)pStruct)->wVertexSize);					g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tIndex start offset    : %u\n", g_dwDebugOffset, ((ST_MAT_MESH*)pStruct)->dwIndexStart);				g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tNumber of primitive   : %u\n", g_dwDebugOffset, ((ST_MAT_MESH*)pStruct)->dwNumPrimitives);				g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\t\t\tSize of one index     : %u\n", g_dwDebugOffset, ((ST_MAT_MESH*)pStruct)->dwIndexSize);					g_dwDebugOffset += 4;
		break;

	case ID_VBUF_HEADER:
		dwDebugVBuf++;
		g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "\nVBUF_HEADER [%d]\n", dwDebugVBuf);
		fprintf(g_pDebugFile, "%08X\tVertex buffer Offset: %u\n", g_dwDebugOffset, ((ST_VBUF_HEADER*)pStruct)->dwOffset);						g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\tPad1                : %u\n", g_dwDebugOffset, ((ST_VBUF_HEADER*)pStruct)->dwPad1);							g_dwDebugOffset += 4;
		break;
	case ID_TXT_HEADER:
		dwDebugTxt++;
		g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "\nTXT_HEADER [%d]\n", dwDebugTxt);
		fprintf(g_pDebugFile, "%08X\tTexture Offset      : %u\n", g_dwDebugOffset, ((ST_TXT_HEADER*)pStruct)->dwOffset);						g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\tPad1                : %u\n", g_dwDebugOffset, ((ST_TXT_HEADER*)pStruct)->dwPad1);							g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\tTexture Type        : %08X\n", g_dwDebugOffset, ((ST_TXT_HEADER*)pStruct)->dwType);						g_dwDebugOffset += 4;
		fprintf(g_pDebugFile, "%08X\tPad2                : %u\n", g_dwDebugOffset, ((ST_TXT_HEADER*)pStruct)->dwPad2);							g_dwDebugOffset += 4;
		break;
	}
}
