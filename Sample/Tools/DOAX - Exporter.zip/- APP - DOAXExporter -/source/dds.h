#ifndef _DDS_H_
#define _DDS_H_


#define DDSD_CAPS						0x00000001l
#define DDSD_HEIGHT						0x00000002l
#define DDSD_WIDTH						0x00000004l
#define DDSD_PIXELFORMAT				0x00001000l
#define DDSD_PITCH						0x00000008l
#define DDSD_LINEARSIZE					0x00080000l

#define DDPF_FOURCC						0x00000004l
#define DDPF_RGB						0x00000040l

#define DDSCAPS_TEXTURE					0x00001000l

#define D3DFORMAT_DIMENSION_MASK		0x000000F0
#define D3DFORMAT_DIMENSION_SHIFT		4
#define D3DFORMAT_FORMAT_MASK			0x0000FF00
#define D3DFORMAT_FORMAT_SHIFT			8
#define D3DFORMAT_MIPMAP_MASK			0x000F0000
#define D3DFORMAT_MIPMAP_SHIFT			16
#define D3DFORMAT_USIZE_MASK			0x00F00000
#define D3DFORMAT_USIZE_SHIFT			20
#define D3DFORMAT_VSIZE_MASK			0x0F000000
#define D3DFORMAT_VSIZE_SHIFT			24
#define D3DFORMAT_PSIZE_MASK			0xF0000000
#define D3DFORMAT_PSIZE_SHIFT			28

#define D3DFMT_X8R8G8B8					22
#define D3DFMT_DXT1						0x31545844
#define D3DFMT_DXT2						0x32545844
#define D3DFMT_DXT4						0x34545844


typedef struct {
	DWORD	dwSize;						// Size of structure. This member must be set to 32.
	DWORD	dwFlags;					// Flags to indicate valid fields. Uncompressed formats will usually use DDPF_RGB to indicate an RGB format, while compressed formats will use DDPF_FOURCC with a four-character code.
	DWORD	dwFourCC;					// This is the four-character code for compressed formats. dwFlags should include DDPF_FOURCC in this case. For DXTn compression, this is set to "DXT1", "DXT2", "DXT3", "DXT4", or "DXT5".
	DWORD	dwRGBBitCount;				// For RGB formats, this is the total number of bits in the format. dwFlags should include DDPF_RGB in this case. This value is usually 16, 24, or 32. For A8R8G8B8, this value would be 32.
	DWORD	dwRBitMask;					// For RGB formats, these three fields contain the masks for the red, green, and blue channels. For A8R8G8B8, these values would be 0x00ff0000, 0x0000ff00, and 0x000000ff respectively.
	DWORD	dwGBitMask;
	DWORD	dwBBitMask;
	DWORD	dwRGBAlphaBitMask;			// For RGB formats, this contains the mask for the alpha channel, if any. dwFlags should include DDPF_ALPHAPIXELS in this case. For A8R8G8B8, this value would be 0xff000000.
} ST_DDPIXELFORMAT;

typedef struct {
	DWORD	dwCaps1;					// DDS files should always include DDSCAPS_TEXTURE. If the file contains mipmaps, DDSCAPS_MIPMAP should be set. For any DDS file with more than one main surface, such as a mipmaps, cubic environment map, or volume texture, DDSCAPS_COMPLEX should also be set.
	DWORD	dwCaps2;					// For cubic environment maps, DDSCAPS2_CUBEMAP should be included as well as one or more faces of the map (DDSCAPS2_CUBEMAP_POSITIVEX, DDSCAPS2_CUBEMAP_NEGATIVEX, DDSCAPS2_CUBEMAP_POSITIVEY, DDSCAPS2_CUBEMAP_NEGATIVEY, DDSCAPS2_CUBEMAP_POSITIVEZ, DDSCAPS2_CUBEMAP_NEGATIVEZ). For volume textures, DDSCAPS2_VOLUME should be included.
	DWORD	dwReserved[2];
} ST_DDCAPS2;

typedef struct {
	DWORD	dwMagic;
	DWORD	dwSize;						// Size of structure. This member must be set to 124.
	DWORD	dwFlags;					// Flags to indicate valid fields. Always include DDSD_CAPS, DDSD_PIXELFORMAT, DDSD_WIDTH, DDSD_HEIGHT.
	DWORD	dwHeight;					// Height of the main image in pixels.
	DWORD	dwWidth;					// Width of the main image in pixels.
	DWORD	dwPitchOrLinearSize;		// For uncompressed formats, this is the number of bytes per scan line (DWORD> aligned) for the main image. dwFlags should include DDSD_PITCH in this case. For compressed formats, this is the total number of bytes for the main image. dwFlags should be include DDSD_LINEARSIZE in this case.
	DWORD	dwDepth;					// For volume textures, this is the depth of the volume. dwFlags should include DDSD_DEPTH in this case.
	DWORD	dwMipMapCount;				// For items with mipmap levels, this is the total number of levels in the mipmap chain of the main image. dwFlags should include DDSD_MIPMAPCOUNT in this case.
	DWORD	dwReserved1[11];  
	ST_DDPIXELFORMAT ddpfPixelFormat;	// 32-byte value that specifies the pixel format structure.
	ST_DDCAPS2 ddsCaps;					// 16-byte value that specifies the capabilities structure.
	DWORD	dwReserved2;
} ST_DDSURFACEDESC2;


typedef struct {
	DWORD	dwWidth;
	DWORD	dwHeight;
	DWORD	dwFormat;
	DWORD	dwImageSize;
	BYTE	*pbImageData;
} ST_DDSTEXTURE;



///// FUNCTION /////
BOOL DDS_Init( ST_DDSTEXTURE * pDdsTexture, DWORD dwType );
BOOL DDS_Write( ST_DDSTEXTURE * pDdsTexture, CHAR * szFileName );



#endif // _DDS_H_
