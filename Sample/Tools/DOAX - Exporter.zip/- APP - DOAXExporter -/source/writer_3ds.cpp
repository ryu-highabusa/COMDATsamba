
#include <windows.h>
#include <stdio.h>

#include "writer_3ds.h"
#include "chunk_3ds.h"


#define MASTER_SCALE_VALUE		100.0f


#define ID_COLOR_AMBIENT		0
#define ID_COLOR_DIFFUSE		1
#define ID_COLOR_SPECULAR		2

#define ID_RATIO_SHININESS		0
#define ID_RATIO_SHIN2PCT		1
#define ID_RATIO_TRANSPARENCY	2


// STRUCTURES
typedef struct {
	WORD	wId;
	DWORD	dwSize;
} ST_CHUNK_3DS;

typedef struct {
	BYTE	bRed;
	BYTE	bGreen;
	BYTE	bBlue;
} ST_COLOR_3DS;



typedef struct {
	CHAR	szMatName[16]; // 15+NULL
	CHAR	szTxtName[14]; // 12+NULL
	DWORD	dwMatNameSize;
	DWORD	dwTxtNameSize;
	DWORD	dwNumTxt;
	ST_WRITER_3DS_MATCOLOR	pColor;
} ST_MATERIAL_DATA;

typedef struct {
	CHAR	szMatName[16]; // 15+NULL
	DWORD	dwMatNameSize;
	DWORD	dwNumMatFaces;
	DWORD	dwMatFacesListSize;
	WORD	*pMatFacesList;
} ST_MESHMAT_DATA;

typedef struct {
	CHAR	szMeshName[12]; // 10+NULL
	DWORD	dwMeshNameSize;
	DWORD	dwNumVertices;
	DWORD	dwNumFaces;
	DWORD	dwNumMat;
	DWORD	dwVerCoordListSize;
	DWORD	dwTxtCoordListSize;
	DWORD	dwFaceListSize;
	DWORD	dwMatFacesSize;
	ST_WRITER_3DS_VERTEX	*pVerCoordList;
	ST_WRITER_3DS_TXTCOORD	*pTxtCoordList;
	ST_WRITER_3DS_FACE		*pFaceList;
	ST_MESHMAT_DATA			*pMatFacesList;
} ST_MESH_DATA;

typedef struct {
	DWORD	dwNumMat;
	DWORD	dwNumMesh;
	ST_MATERIAL_DATA		*pMatList;
	ST_MESH_DATA			*pMeshList;
} ST_MODEL_DATA;

// GLOBALS
static FILE		*g_pFile = NULL;
static ST_MODEL_DATA	*g_pM3dModel;
static DWORD	g_dwMatNo;
static DWORD	g_dwMeshNo;
static DWORD	g_dwMeshMatNo;



// FUNCTIONS
VOID WRITER_3DS_WriteChunk( ST_CHUNK_3DS *pstChunk3ds );
VOID WRITER_3DS_WriteMatColor( DWORD dwColorId, FLOAT fRed, FLOAT fGreen, FLOAT fBlue );
VOID WRITER_3DS_WriteMatRatio( DWORD dwRatioId, FLOAT fRatio );
VOID WRITER_3DS_WriteMatTxt( ST_MATERIAL_DATA * pMaterial );
VOID WRITER_3DS_WriteHeader( ST_MODEL_DATA * pModel );
VOID WRITER_3DS_WriteMaterial( ST_MATERIAL_DATA * pMaterial );
VOID WRITER_3DS_WriteMesh( ST_MODEL_DATA * pModel, ST_MESH_DATA * pMesh );



//-----------------------------------------------------------------------------
// Name: WRITER_3DS_Open()
// Desc: 
//-----------------------------------------------------------------------------
BOOL WRITER_3DS_Open( CHAR * szObjName, DWORD dwNumMesh, DWORD dwNumMat )
{
	g_pFile = fopen( szObjName, "wb" );
	if( !g_pFile )
		return FALSE;

	g_dwMatNo     = 0;
	g_dwMeshNo    = 0;

	g_pM3dModel = new ST_MODEL_DATA;
	g_pM3dModel->dwNumMat  = dwNumMat;
	g_pM3dModel->dwNumMesh = dwNumMesh;
	g_pM3dModel->pMatList  = new ST_MATERIAL_DATA[g_pM3dModel->dwNumMat];
	g_pM3dModel->pMeshList = new ST_MESH_DATA[g_pM3dModel->dwNumMesh];


	return TRUE;
}


//-----------------------------------------------------------------------------
// Name: WRITER_3DS_Open()
// Desc: 
//-----------------------------------------------------------------------------
BOOL WRITER_3DS_Close( VOID )
{
	DWORD	i, j, dwMatNo, dwMeshNo;


	if( g_pFile )
	{
		WRITER_3DS_WriteHeader( g_pM3dModel );
		for( dwMatNo = 0; dwMatNo < g_pM3dModel->dwNumMat; dwMatNo++ )
			WRITER_3DS_WriteMaterial( &g_pM3dModel->pMatList[dwMatNo] );
		for( dwMeshNo = 0; dwMeshNo < g_pM3dModel->dwNumMesh; dwMeshNo++ )
			WRITER_3DS_WriteMesh( g_pM3dModel, &g_pM3dModel->pMeshList[dwMeshNo] );


		fclose( g_pFile );

		for( i = 0; i < g_pM3dModel->dwNumMesh; i++ )
		{
			delete[] g_pM3dModel->pMeshList[i].pVerCoordList;
			delete[] g_pM3dModel->pMeshList[i].pTxtCoordList;
			delete[] g_pM3dModel->pMeshList[i].pFaceList;
			for( j = 0; j < g_pM3dModel->pMeshList[i].dwNumMat; j++ )
				delete[] g_pM3dModel->pMeshList[i].pMatFacesList[j].pMatFacesList;
			delete[] g_pM3dModel->pMeshList[i].pMatFacesList;
		}
		delete[] g_pM3dModel->pMeshList;
		delete[] g_pM3dModel->pMatList;
		delete g_pM3dModel;
	}


	return TRUE;
}


//-----------------------------------------------------------------------------
// Name: WRITER_3DS_SetMaterial()
// Desc: 
//-----------------------------------------------------------------------------
BOOL WRITER_3DS_SetMaterial( CHAR * szMatName, CHAR * szTxtName, ST_WRITER_3DS_MATCOLOR * pMatColor )
{
	ST_MATERIAL_DATA	*pMaterial;


	if( g_dwMatNo == g_pM3dModel->dwNumMat )
		return FALSE;

	pMaterial = &g_pM3dModel->pMatList[g_dwMatNo];
	g_dwMatNo++;

	if( szMatName )
	{
		pMaterial->dwMatNameSize = strlen(szMatName)+1;
		if( pMaterial->dwMatNameSize-1 > 15 )
			return FALSE;
		strcpy( pMaterial->szMatName, szMatName );
	}
	else
		return FALSE;

	if( szTxtName)
	{
		pMaterial->dwNumTxt = 1;
		pMaterial->dwTxtNameSize = strlen(szTxtName)+1;
		if( pMaterial->dwTxtNameSize-1 > 12 )
			return FALSE;
		strcpy( pMaterial->szTxtName, szTxtName );
	}
	else
	{
		pMaterial->dwNumTxt = 0;
		pMaterial->dwTxtNameSize = 0;
		pMaterial->szTxtName[0] = 0;
	}

	memcpy( &pMaterial->pColor, pMatColor, sizeof(ST_WRITER_3DS_MATCOLOR) );


	return TRUE;
}

//-----------------------------------------------------------------------------
// Name: WRITER_3DS_SetMesh()
// Desc: 
//-----------------------------------------------------------------------------
BOOL WRITER_3DS_SetMesh( CHAR * szMeshName, DWORD dwNumVertices, DWORD dwNumFaces, DWORD dwNumMat )
{
	ST_MESH_DATA	*pMesh;

	
	if( g_dwMeshNo == g_pM3dModel->dwNumMesh )
		return FALSE;

	g_dwMeshMatNo = 0;

	pMesh = &g_pM3dModel->pMeshList[g_dwMeshNo];
	g_dwMeshNo++;

	if( szMeshName )
	{
		pMesh->dwMeshNameSize = strlen(szMeshName)+1;
		if( pMesh->dwMeshNameSize-1 > 10 )
			return FALSE;
		strcpy( pMesh->szMeshName, szMeshName );
	}
	else
		return FALSE;

	pMesh->dwNumVertices = dwNumVertices;
	pMesh->dwNumFaces    = dwNumFaces;
	pMesh->dwNumMat      = dwNumMat;
	pMesh->dwVerCoordListSize = dwNumVertices * sizeof(ST_WRITER_3DS_VERTEX);
	pMesh->dwTxtCoordListSize = dwNumVertices * sizeof(ST_WRITER_3DS_TXTCOORD);
	pMesh->dwFaceListSize     = dwNumFaces * sizeof(ST_WRITER_3DS_FACE) + dwNumFaces * sizeof(WORD);
	pMesh->dwMatFacesSize     = 0;

	pMesh->pVerCoordList = new ST_WRITER_3DS_VERTEX[dwNumVertices];
	pMesh->pTxtCoordList = new ST_WRITER_3DS_TXTCOORD[dwNumVertices];
	pMesh->pFaceList     = new ST_WRITER_3DS_FACE[dwNumFaces];
	pMesh->pMatFacesList = new ST_MESHMAT_DATA[dwNumMat];


	return TRUE;
}

//-----------------------------------------------------------------------------
// Name: WRITER_3DS_SetVerCoord()
// Desc: 
//-----------------------------------------------------------------------------
BOOL WRITER_3DS_SetVerCoord( DWORD dwNumVerCoord, ST_WRITER_3DS_VERTEX * pVerCoordList )
{
	ST_MESH_DATA	*pMesh;

	
	pMesh = &g_pM3dModel->pMeshList[g_dwMeshNo-1];

	if( dwNumVerCoord != pMesh->dwNumVertices )
		return FALSE;

	memcpy( pMesh->pVerCoordList, pVerCoordList, pMesh->dwNumVertices*sizeof(ST_WRITER_3DS_VERTEX) );


	return TRUE;
}

//-----------------------------------------------------------------------------
// Name: WRITER_3DS_SetTxtCoord()
// Desc: 
//-----------------------------------------------------------------------------
BOOL WRITER_3DS_SetTxtCoord( DWORD dwNumTxtCoord, ST_WRITER_3DS_TXTCOORD * pTxtCoordList )
{
	ST_MESH_DATA	*pMesh;

	
	pMesh = &g_pM3dModel->pMeshList[g_dwMeshNo-1];

	if( dwNumTxtCoord != pMesh->dwNumVertices )
		return FALSE;

	memcpy( pMesh->pTxtCoordList, pTxtCoordList, pMesh->dwNumVertices*sizeof(ST_WRITER_3DS_TXTCOORD) );


	return TRUE;
}

//-----------------------------------------------------------------------------
// Name: WRITER_3DS_SetFaces()
// Desc: 
//-----------------------------------------------------------------------------
BOOL WRITER_3DS_SetFaces( DWORD dwNumFaces, ST_WRITER_3DS_FACE * pFaceList )
{
	ST_MESH_DATA	*pMesh;

	
	pMesh = &g_pM3dModel->pMeshList[g_dwMeshNo-1];

	if( dwNumFaces != pMesh->dwNumFaces )
		return FALSE;

	memcpy( pMesh->pFaceList, pFaceList, pMesh->dwNumFaces*sizeof(ST_WRITER_3DS_FACE) );


	return TRUE;
}
	
//-----------------------------------------------------------------------------
// Name: WRITER_3DS_SetMatFaces()
// Desc: 
//-----------------------------------------------------------------------------	
BOOL WRITER_3DS_SetMatFaces( CHAR * szMatName, DWORD dwNumMatFaces, WORD * pMatFacesList )
{
	ST_MESHMAT_DATA	*pMeshMat;

	
	pMeshMat = &g_pM3dModel->pMeshList[g_dwMeshNo-1].pMatFacesList[g_dwMeshMatNo];
	g_dwMeshMatNo++;

	pMeshMat->pMatFacesList = new WORD[dwNumMatFaces];

	if( szMatName )
	{
		pMeshMat->dwMatNameSize = strlen(szMatName)+1;
		if( pMeshMat->dwMatNameSize-1 > 15 )
			return FALSE;
		strcpy( pMeshMat->szMatName, szMatName );
	}
	else
		return FALSE;

	pMeshMat->dwNumMatFaces = dwNumMatFaces;
	pMeshMat->dwMatFacesListSize = pMeshMat->dwNumMatFaces*sizeof(WORD);
	memcpy( pMeshMat->pMatFacesList, pMatFacesList, pMeshMat->dwMatFacesListSize );

	// Update mesh information
	g_pM3dModel->pMeshList[g_dwMeshNo-1].dwMatFacesSize += pMeshMat->dwMatNameSize + pMeshMat->dwMatFacesListSize;


	return TRUE;
}


//-----------------------------------------------------------------------------
// Name: WRITER_3DS_WriteChunk()
// Desc: Write 3DS chunk
//-----------------------------------------------------------------------------
VOID WRITER_3DS_WriteChunk( ST_CHUNK_3DS *pstChunk3ds )
{
	fwrite( &pstChunk3ds->wId,    sizeof(WORD),  1, g_pFile );
	fwrite( &pstChunk3ds->dwSize, sizeof(DWORD), 1, g_pFile );
}


//-----------------------------------------------------------------------------
// Name: WRITER_3DS_WriteMatColor()
// Desc: Write a color
//-----------------------------------------------------------------------------
VOID WRITER_3DS_WriteMatColor( DWORD dwColorId, FLOAT fRed, FLOAT fGreen, FLOAT fBlue )
{
	ST_CHUNK_3DS stChunk3ds;
	ST_COLOR_3DS stColor3ds;
	

	stColor3ds.bRed   = (BYTE)( 255.0f * fRed );
	stColor3ds.bGreen = (BYTE)( 255.0f * fGreen );
	stColor3ds.bBlue  = (BYTE)( 255.0f * fBlue );

	switch( dwColorId )
	{
	case ID_COLOR_AMBIENT:
		stChunk3ds.wId = ID_CHUNK_MAT_AMBIENT;
		break;
	case ID_COLOR_DIFFUSE:
		stChunk3ds.wId = ID_CHUNK_MAT_DIFFUSE;
		break;
	case ID_COLOR_SPECULAR:
		stChunk3ds.wId = ID_CHUNK_MAT_SPECULAR;
		break;
	}
	stChunk3ds.dwSize = SIZE_CHUNK_MAT_COLOR;
	WRITER_3DS_WriteChunk( &stChunk3ds );

	stChunk3ds.wId = ID_CHUNK_COLOR24;
	stChunk3ds.dwSize = SIZE_CHUNK_COLOR24;
	WRITER_3DS_WriteChunk( &stChunk3ds );

	fwrite( &stColor3ds.bRed,   sizeof(BYTE), 1, g_pFile );
	fwrite( &stColor3ds.bGreen, sizeof(BYTE), 1, g_pFile );
	fwrite( &stColor3ds.bBlue,  sizeof(BYTE), 1, g_pFile );
}


//-----------------------------------------------------------------------------
// Name: WRITER_3DS_WriteMatRatio()
// Desc: Write a ratio
//-----------------------------------------------------------------------------
VOID WRITER_3DS_WriteMatRatio( DWORD dwRatioId, FLOAT fRatio )
{
	ST_CHUNK_3DS stChunk3ds;
	WORD wRatio;
	
	wRatio = (WORD)fRatio;

	switch( dwRatioId )
	{
	case ID_RATIO_SHININESS:
		stChunk3ds.wId = ID_CHUNK_MAT_SHININESS;
		break;
	case ID_RATIO_SHIN2PCT:
		stChunk3ds.wId = ID_CHUNK_MAT_SHIN2PCT;
		break;
	case ID_RATIO_TRANSPARENCY:
		stChunk3ds.wId = ID_CHUNK_MAT_TRANSPARENCY;
		break;
	}
	stChunk3ds.dwSize = SIZE_CHUNK_MAT_RATIO;
	WRITER_3DS_WriteChunk( &stChunk3ds );

	stChunk3ds.wId = ID_CHUNK_INT_PERCENTAGE;
	stChunk3ds.dwSize = SIZE_CHUNK_INT_PERCENTAGE;
	WRITER_3DS_WriteChunk( &stChunk3ds );

	fwrite( &wRatio, sizeof(WORD), 1, g_pFile );
}


//-----------------------------------------------------------------------------
// Name: WRITER_3DS_WriteHeader()
// Desc: Write 3DS file
//-----------------------------------------------------------------------------
VOID WRITER_3DS_WriteHeader( ST_MODEL_DATA * pModel )
{
	ST_CHUNK_3DS stChunk3ds;
	DWORD dwVersion;
	FLOAT fScale;
	DWORD	dwMatNo, dwMatSize;
	DWORD	dwMeshNo, dwMeshSize;


	dwMatSize = 0;
	for( dwMatNo = 0; dwMatNo < pModel->dwNumMat; dwMatNo++ )
	{
		dwMatSize += SIZE_CHUNK_MAT_ENTRY + pModel->pMatList[dwMatNo].dwMatNameSize;
		if( pModel->pMatList[dwMatNo].dwNumTxt )
			dwMatSize += SIZE_CHUNK_TXT_ENTRY + pModel->pMatList[dwMatNo].dwTxtNameSize;
	}
	dwMeshSize = 0;
	for( dwMeshNo = 0; dwMeshNo < pModel->dwNumMesh; dwMeshNo++ )
	{
		dwMeshSize += SIZE_CHUNK_NAMEDOBJ
			+ pModel->pMeshList[dwMeshNo].dwMeshNameSize
			+ pModel->pMeshList[dwMeshNo].dwVerCoordListSize
			+ pModel->pMeshList[dwMeshNo].dwTxtCoordListSize
			+ pModel->pMeshList[dwMeshNo].dwFaceListSize
			+ SIZE_CHUNK_OBJ_MATERIAL * pModel->pMeshList[dwMeshNo].dwNumMat
			+ pModel->pMeshList[dwMeshNo].dwMatFacesSize;
	}

	// M3D MAGIC
	stChunk3ds.wId = ID_CHUNK_M3D_MAGIC;
	stChunk3ds.dwSize = SIZE_CHUNK_M3D_MAGIC + dwMatSize + dwMeshSize;
	WRITER_3DS_WriteChunk( &stChunk3ds );

	// M3D VERSION
	stChunk3ds.wId = ID_CHUNK_M3D_VERSION;
	stChunk3ds.dwSize = SIZE_CHUNK_M3D_VERSION;
	WRITER_3DS_WriteChunk( &stChunk3ds );
	dwVersion = 3;
	fwrite( &dwVersion, sizeof(DWORD), 1, g_pFile );

	// MESH DATA
	stChunk3ds.wId = ID_CHUNK_MESH_DATA;
	stChunk3ds.dwSize = SIZE_CHUNK_MESH_DATA + dwMatSize + dwMeshSize;
	WRITER_3DS_WriteChunk( &stChunk3ds );

	// MESH VERSION
	stChunk3ds.wId = ID_CHUNK_MESH_VERSION;
	stChunk3ds.dwSize = SIZE_CHUNK_MESH_VERSION;
	WRITER_3DS_WriteChunk( &stChunk3ds );
	dwVersion = 3;
	fwrite( &dwVersion, sizeof(DWORD), 1, g_pFile );

	// MASTER SCALE
	stChunk3ds.wId = ID_CHUNK_MASTER_SCALE;
	stChunk3ds.dwSize = SIZE_CHUNK_MASTER_SCALE;
	WRITER_3DS_WriteChunk( &stChunk3ds );
	fScale = MASTER_SCALE_VALUE;
	fwrite( &fScale, sizeof(FLOAT), 1, g_pFile );
}


//-----------------------------------------------------------------------------
// Name: WRITER_3DS_WriteMaterial()
// Desc: Write material color
//-----------------------------------------------------------------------------
VOID WRITER_3DS_WriteMaterial( ST_MATERIAL_DATA * pMaterial )
{
	ST_CHUNK_3DS stChunk3ds;
	WORD wShading;


	// MATERIAL ENTRY
	stChunk3ds.wId = ID_CHUNK_MAT_ENTRY;
	stChunk3ds.dwSize = SIZE_CHUNK_MAT_ENTRY + pMaterial->dwMatNameSize;
	if( pMaterial->dwNumTxt )
		stChunk3ds.dwSize += SIZE_CHUNK_TXT_ENTRY + pMaterial->dwTxtNameSize;
	WRITER_3DS_WriteChunk( &stChunk3ds );

	// MATERIAL NAME
	stChunk3ds.wId = ID_CHUNK_MAT_NAME;
	stChunk3ds.dwSize = CHUNK_SIZE + pMaterial->dwMatNameSize;
	WRITER_3DS_WriteChunk( &stChunk3ds );
	fwrite( pMaterial->szMatName, sizeof(CHAR), pMaterial->dwMatNameSize, g_pFile );

	// MATERIAL COLOR AMBIENT
	WRITER_3DS_WriteMatColor( ID_COLOR_AMBIENT,  pMaterial->pColor.stAmbient.r, pMaterial->pColor.stAmbient.g, pMaterial->pColor.stAmbient.b );
	// MATERIAL COLOR DIFFUSE
	WRITER_3DS_WriteMatColor( ID_COLOR_DIFFUSE,  pMaterial->pColor.stDiffuse.r, pMaterial->pColor.stDiffuse.g, pMaterial->pColor.stDiffuse.b );
	// MATERIAL COLOR SPECULAR
	WRITER_3DS_WriteMatColor( ID_COLOR_SPECULAR, pMaterial->pColor.stSpecular.r, pMaterial->pColor.stSpecular.g, pMaterial->pColor.stSpecular.b );

	// MATERIAL SHININESS RATIO
	WRITER_3DS_WriteMatRatio( ID_RATIO_SHININESS, pMaterial->pColor.fSpecularPower );
	// MATERIAL SHININESS STRENGHT
	WRITER_3DS_WriteMatRatio( ID_RATIO_SHIN2PCT, 0.0f );
	// MATERIAL TRANSPARENCY
	WRITER_3DS_WriteMatRatio( ID_RATIO_TRANSPARENCY, 0.0f );

	// MATERIAL SHADING
	stChunk3ds.wId = ID_CHUNK_MAT_SHADING;
	stChunk3ds.dwSize = SIZE_CHUNK_MAT_SHADING;
	WRITER_3DS_WriteChunk( &stChunk3ds );
	wShading = 2; // Gouraud shading
	fwrite( &wShading, sizeof(WORD), 1, g_pFile );

	// MATERIAL TEXTURE
	WRITER_3DS_WriteMatTxt( pMaterial ); 
}


//-----------------------------------------------------------------------------
// Name: WRITER_3DS_WriteMatTxt()
// Desc: Write material texture
//-----------------------------------------------------------------------------
VOID WRITER_3DS_WriteMatTxt( ST_MATERIAL_DATA * pMaterial )
{
	ST_CHUNK_3DS stChunk3ds;
	WORD  wStrenght, wTiling;


	if( !pMaterial->dwNumTxt )
		return;

	// MATERIAL TEXTURE ENTRY
	stChunk3ds.wId = ID_CHUNK_TXT_ENTRY;
	stChunk3ds.dwSize = SIZE_CHUNK_TXT_ENTRY + pMaterial->dwTxtNameSize;
	WRITER_3DS_WriteChunk( &stChunk3ds );

	// MATERIAL TEXTURE STRENGHT
	stChunk3ds.wId = ID_CHUNK_INT_PERCENTAGE;
	stChunk3ds.dwSize = SIZE_CHUNK_INT_PERCENTAGE;
	WRITER_3DS_WriteChunk( &stChunk3ds );
	wStrenght = 100;
	fwrite( &wStrenght, sizeof(WORD), 1, g_pFile );

	// MATERIAL TEXTURE NAME
	stChunk3ds.wId = ID_CHUNK_TXT_NAME;
	stChunk3ds.dwSize = CHUNK_SIZE + pMaterial->dwTxtNameSize;
	WRITER_3DS_WriteChunk( &stChunk3ds );
	fwrite( pMaterial->szTxtName, sizeof(CHAR), pMaterial->dwTxtNameSize, g_pFile );

	// MATERIAL TEXTURE TILING
	stChunk3ds.wId = ID_CHUNK_TXT_TILING;
	stChunk3ds.dwSize = SIZE_CHUNK_TXT_TILING;
	WRITER_3DS_WriteChunk( &stChunk3ds );
	wTiling = 0;
	fwrite( &wTiling, sizeof(WORD), 1, g_pFile );
}


//-----------------------------------------------------------------------------
// Name: WRITER_3DS_WriteMesh()
// Desc: Write mesh
//-----------------------------------------------------------------------------
VOID WRITER_3DS_WriteMesh( ST_MODEL_DATA * pModel, ST_MESH_DATA * pMesh )
{
	ST_CHUNK_3DS stChunk3ds;
	DWORD	dwMatNo, dwFaceNo;
	WORD	wTemp;
	DWORD	dwMatFacesSize;

	
	dwMatFacesSize = (SIZE_CHUNK_OBJ_MATERIAL * pMesh->dwNumMat) + pMesh->dwMatFacesSize;

	// NAMED OBJECT
	stChunk3ds.wId = ID_CHUNK_NAMEDOBJ;
	stChunk3ds.dwSize = SIZE_CHUNK_NAMEDOBJ + pMesh->dwMeshNameSize + pMesh->dwVerCoordListSize + pMesh->dwTxtCoordListSize + pMesh->dwFaceListSize + dwMatFacesSize;
	WRITER_3DS_WriteChunk( &stChunk3ds );
	fwrite( pMesh->szMeshName, sizeof(CHAR), pMesh->dwMeshNameSize, g_pFile );

	// OBJECT MESH
	stChunk3ds.wId = ID_CHUNK_OBJ_MESH;
	stChunk3ds.dwSize = SIZE_CHUNK_OBJ_MESH + pMesh->dwVerCoordListSize + pMesh->dwTxtCoordListSize + pMesh->dwFaceListSize + dwMatFacesSize;
	WRITER_3DS_WriteChunk( &stChunk3ds );

	// OBJECT VERTICES
	stChunk3ds.wId = ID_CHUNK_OBJ_VERTICES;
	stChunk3ds.dwSize = SIZE_CHUNK_OBJ_VERTICES + pMesh->dwVerCoordListSize;
	WRITER_3DS_WriteChunk( &stChunk3ds );
	fwrite( &pMesh->dwNumVertices, sizeof(WORD), 1, g_pFile );
	fwrite( pMesh->pVerCoordList, sizeof(ST_WRITER_3DS_VERTEX), pMesh->dwNumVertices, g_pFile );

	// OBJECT TEXTURE
	stChunk3ds.wId = ID_CHUNK_OBJ_TEXTURE;
	stChunk3ds.dwSize = SIZE_CHUNK_OBJ_TEXTURE + pMesh->dwTxtCoordListSize;
	WRITER_3DS_WriteChunk( &stChunk3ds );
	fwrite( &pMesh->dwNumVertices, sizeof(WORD), 1, g_pFile );
	fwrite( pMesh->pTxtCoordList, sizeof(ST_WRITER_3DS_TXTCOORD), pMesh->dwNumVertices, g_pFile );

	// OBJECT FACES
	stChunk3ds.wId = ID_CHUNK_OBJ_FACES;
	stChunk3ds.dwSize = SIZE_CHUNK_OBJ_FACES + pMesh->dwFaceListSize + dwMatFacesSize;
	WRITER_3DS_WriteChunk( &stChunk3ds );
	fwrite( &pMesh->dwNumFaces, sizeof(WORD), 1, g_pFile );
	wTemp = 0x0007;
	for( dwFaceNo = 0; dwFaceNo < pMesh->dwNumFaces; dwFaceNo++ )
	{
		fwrite( &pMesh->pFaceList[dwFaceNo], sizeof(ST_WRITER_3DS_FACE), 1, g_pFile );
		fwrite( &wTemp, sizeof(WORD), 1, g_pFile );
	}

	// OBJECT MATERIAL
	for( dwMatNo = 0; dwMatNo < pMesh->dwNumMat; dwMatNo++ )
	{
		stChunk3ds.wId = ID_CHUNK_OBJ_MATERIAL;
		stChunk3ds.dwSize = SIZE_CHUNK_OBJ_MATERIAL + pMesh->pMatFacesList[dwMatNo].dwMatNameSize + pMesh->pMatFacesList[dwMatNo].dwMatFacesListSize;
		WRITER_3DS_WriteChunk( &stChunk3ds );
		fwrite( pMesh->pMatFacesList[dwMatNo].szMatName, sizeof(CHAR), pMesh->pMatFacesList[dwMatNo].dwMatNameSize, g_pFile );
		fwrite( &pMesh->pMatFacesList[dwMatNo].dwNumMatFaces, sizeof(WORD), 1, g_pFile );
		fwrite( pMesh->pMatFacesList[dwMatNo].pMatFacesList, sizeof(WORD), pMesh->pMatFacesList[dwMatNo].dwNumMatFaces, g_pFile );
	}

}
