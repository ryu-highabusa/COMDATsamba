// DOAX XPR
//
#ifndef _XPR_H_
#define _XPR_H_


#include "dds.h"


///// VERTEX FORMAT /////
typedef struct {  // D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1
	FLOAT	vx, vy, vz;
	FLOAT	nx, ny, nz;
	FLOAT	u, v;
} ST_VERTEXFORMAT0_0;

typedef struct {  // D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_TEX1
	FLOAT	vx, vy, vz;
	DWORD	dwDiffuse;
	FLOAT	u, v;
} ST_VERTEXFORMAT0_1;

typedef struct {  // D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX2
	FLOAT	vx, vy, vz;
	FLOAT	nx, ny, nz;
	FLOAT	u0, v0;
	FLOAT	u1, v1;
} ST_VERTEXFORMAT0_2;

typedef struct {  // D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_TEX2
	FLOAT	vx, vy, vz;
	DWORD	dwDiffuse;
	FLOAT	u0, v0;
	FLOAT	u1, v1;
} ST_VERTEXFORMAT0_3;

typedef struct {  // D3DFVF_XYZB1 | D3DFVF_NORMAL | D3DFVF_TEX1
	FLOAT	vx, vy, vz;
	FLOAT	fWeight0;
	FLOAT	nx, ny, nz;
	FLOAT	u, v;
} ST_VERTEXFORMAT1_0;

typedef struct {  // D3DFVF_XYZB2  | D3DFVF_NORMAL | D3DFVF_TEX1 
	FLOAT	vx, vy, vz;
	FLOAT	fWeight0;
	FLOAT	fWeight1;
	FLOAT	nx, ny, nz;
	FLOAT	u, v;
} ST_VERTEXFORMAT2_0;

typedef struct {  // D3DFVF_XYZB3 | D3DFVF_NORMAL | D3DFVF_TEX1
	FLOAT	vx, vy, vz;
	FLOAT	fWeight0;
	FLOAT	fWeight1;
	FLOAT	fWeight2;
	FLOAT	nx, ny, nz;
	FLOAT	u, v;
} ST_VERTEXFORMAT3_0;

typedef struct {  // D3DFVF_XYZB1 | D3DFVF_NORMAL | D3DFVF_TEX2
	FLOAT	vx, vy, vz;
	FLOAT	fWeight0;
	FLOAT	nx, ny, nz;
	FLOAT	u0, v0;
	FLOAT	u1, v1;
} ST_VERTEXFORMAT1_2;

typedef struct {  // D3DFVF_XYZB2 | D3DFVF_NORMAL | D3DFVF_TEX2
	FLOAT	vx, vy, vz;
	FLOAT	fWeight0;
	FLOAT	fWeight1;
	FLOAT	nx, ny, nz;
	FLOAT	u0, v0;
	FLOAT	u1, v1;
} ST_VERTEXFORMAT2_2;

typedef struct {  // D3DFVF_XYZB3 | D3DFVF_NORMAL | D3DFVF_TEX2
	FLOAT	vx, vy, vz;
	FLOAT	fWeight0;
	FLOAT	fWeight1;
	FLOAT	fWeight2;
	FLOAT	nx, ny, nz;
	FLOAT	u0, v0;
	FLOAT	u1, v1;
} ST_VERTEXFORMAT3_2;


typedef struct {
	FLOAT	r;
	FLOAT	g;
	FLOAT	b;
	FLOAT	a;
} ST_RGBA_COLOR;


///// HEADER /////
#define CHUNK_MODEL		0x80000000
#define CHUNK_TEXTURE	0x00040001
#define CHUNK_VBUFFER	0x00800001


typedef struct {
	DWORD	dwMagic;
} ST_XPR_CHUNK;

typedef struct {
	DWORD	dwCRC;						// CRC
	DWORD	dwXPRSize;					// Crypted XPR size
	DWORD	dwHeaderSize;				// Data bloc size including padding (in bytes), multiple of 4KBytes
} ST_XPR_HEADER;

typedef struct {
	DWORD	dwSize;						// Model size - 8 (in bytes) (model + objects + materials + index buffers)
	CHAR	szMagic[4];					// 'MDL'
	DWORD	dwNumObj;					// Number of objects
	DWORD	dwNumTxt;					// Number of textures
	DWORD	dwUnknown0;					// 
	DWORD	dwNumIVBuf;					// Number of indexed vertex buffer
} ST_MDL_HEADER;

typedef struct {
	DWORD	dwNumVertices;				// Number of vertices
	DWORD	dwVBufOffset;				// Vertex buffer offset from XPR start (in bytes)
	DWORD	dwNumIndices;				// Number of indices
	DWORD	dwIBufOffset;				// Index buffer offset from XPR start (in bytes)
} ST_IVBUFINFO;

typedef struct {
	CHAR	szMagic[4];					// 'OBJ'
	DWORD	dwNumWeights;				// Number of vertex weights
	DWORD	dwUnknown0;					// 4
	DWORD	dwNumIndices;				// Number of indices (total indices in IVBufInfo)
	FLOAT	fCenterX;					// Object center x
	FLOAT	fCenterY;					// Object center y
	FLOAT	fCenterZ;					// Object center z
	FLOAT	fRadius;					// Object radius
	ST_IVBUFINFO	pIVBufInfo[4];		// Indexed vertex buffers info
	DWORD	dwPad1[16];					// 0
} ST_OBJ_HEADER;

typedef struct {
	ST_RGBA_COLOR	stColorDiffuse;		// Diffuse color
	ST_RGBA_COLOR	stColorAmbient;		// Ambient color
	ST_RGBA_COLOR	stColorSpecular;	// Specular color
	ST_RGBA_COLOR	stColorEmissive;	// Emissive color
	FLOAT	fSpecularPower;				// Specular glow power
} ST_MAT_COLOR;

typedef struct {
	DWORD	dwSize;						// Material size - 8 (in bytes) (materials + mesh-subsets)
	DWORD	dwUnknown0;					// 
	DWORD	dwUnknown1;					// 
	FLOAT	fCenterX;					// Sub-object center x
	FLOAT	fCenterY;					// Sub-object center y
	FLOAT	fCenterZ;					// Sub-object center z
	FLOAT	fRadius;					// Sub-object radius
	ST_MAT_COLOR	stColor;			// Material color
	DWORD	dwNumTxt;					// Number of textures used by this material
	DWORD	dwUnknown2;					// 
	DWORD	dwUnknown3;					// 
} ST_MAT_HEADER;

typedef struct {
	DWORD	dwTxtNo;					// Texture number (texture used with this material)
	DWORD	dwUnknown0;					// 
	DWORD	dwUnknown1;					// 
	DWORD	dwUnknown2;					// 
} ST_MAT_TEXTURE;

typedef struct {
	WORD	wVertexSize;				// Size of one vertex (in bytes)
	WORD	wIVBufferNo;				// Indexed vertex buffer number (0-3)
	DWORD	dwIndexStart;				// Index buffer start offset (in indices)
	DWORD	dwNumPrimitives;			// Number of primitives
	DWORD	dwIndexSize;				// Size of one index (in bytes)
} ST_MAT_MESH;

typedef struct {
	DWORD	dwOffset;					// Texture offset from data bloc (in bytes)
	DWORD	dwPad1;						// 0
	DWORD	dwType;						// Texture type
	DWORD	dwPad2;						// 0
} ST_TXT_HEADER;

typedef struct {
	DWORD	dwOffset;					// Vertex buffer offset from data bloc (in bytes)
	DWORD	dwPad1;						// 0
} ST_VBUF_HEADER;


///// 
typedef struct {
	DWORD	dwVertexType;
	DWORD	dwVertexSize;
	DWORD	dwNumVertices;
	VOID	*pVertexList;
} ST_MY_VBUF;
typedef struct {
	DWORD	dwNumIndices;
	WORD	*pIndexList;
} ST_MY_IBUF;
typedef struct {
	ST_RGBA_COLOR	stColorDiffuse;
	ST_RGBA_COLOR	stColorAmbient;
	ST_RGBA_COLOR	stColorSpecular;
	ST_RGBA_COLOR	stColorEmissive;
	FLOAT	fSpecularPower;
} ST_MY_COLOR;
typedef struct {
	// Strip
	DWORD	dwIndexStart;
	DWORD	dwIndexCount;
} ST_MY_STRIP;
typedef struct {
	// Colors
	ST_MY_COLOR	stColor;
	// Textures
	DWORD		dwNumTxt;
	DWORD		*pdwTxtList;
	// Sub-object
	DWORD		dwIBufNo;
	DWORD		dwNumStrip;
	ST_MY_STRIP	*pdwStripList;
} ST_MY_MAT;
typedef struct {
	// Object
	DWORD		dwVBufNo;
	DWORD		dwNumMat;
	ST_MY_MAT	*pMatList;
} ST_MY_SUBOBJ;
typedef struct {
	// Subobject
	DWORD			dwNumSubobj;
	ST_MY_SUBOBJ	*pSubobjList;
} ST_MY_OBJ;
typedef struct {
	DWORD	dwNumObj;
	DWORD	dwNumVBuf;
	DWORD	dwNumIBuf;
	DWORD	dwNumTxt;
	ST_MY_OBJ		*pObjList;
	ST_MY_VBUF		*pVBufList;
	ST_MY_IBUF		*pIBufList;
	ST_DDSTEXTURE	*pTxtList;
} ST_MY_MDL;


///// FUNCTIONS /////
ST_MY_MDL * XPR_Open( CHAR *szFileName );
VOID XPR_Close( ST_MY_MDL *pModel );


#endif // _XPR_H_
