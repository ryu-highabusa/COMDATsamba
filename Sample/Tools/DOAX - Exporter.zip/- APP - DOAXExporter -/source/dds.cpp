
#include <windows.h>
#include "dds.h"

#include <stdio.h>


static DWORD exptbl[] = {1,2,4,8,16,32,64,128,256,512,1024,2048,4096,0,0,0,0,0,0};


BOOL DDS_Init( ST_DDSTEXTURE * pDdsTexture, DWORD dwType )
{
	pDdsTexture->dwWidth  = exptbl[(dwType&D3DFORMAT_USIZE_MASK)>>D3DFORMAT_USIZE_SHIFT];
	pDdsTexture->dwHeight = exptbl[(dwType&D3DFORMAT_VSIZE_MASK)>>D3DFORMAT_VSIZE_SHIFT];

	switch( (dwType&D3DFORMAT_FORMAT_MASK)>>D3DFORMAT_FORMAT_SHIFT )
	{
	case 0x00000006: // X8R8G8B8
		pDdsTexture->dwFormat = D3DFMT_X8R8G8B8;
		pDdsTexture->dwImageSize = (pDdsTexture->dwWidth * pDdsTexture->dwHeight) * 4;
		break;

	case 0x0000000C: // DXT1
		pDdsTexture->dwFormat = D3DFMT_DXT1;
		pDdsTexture->dwImageSize = (pDdsTexture->dwWidth * pDdsTexture->dwHeight) / 2;
		break;

	case 0x0000000E: // DXT2
		pDdsTexture->dwFormat = D3DFMT_DXT2;
		pDdsTexture->dwImageSize = pDdsTexture->dwWidth * pDdsTexture->dwHeight;
		break;

	case 0x0000000F: // DXT4
		pDdsTexture->dwFormat = D3DFMT_DXT4;
		pDdsTexture->dwImageSize = pDdsTexture->dwWidth * pDdsTexture->dwHeight;
		break;

	default:
		return FALSE;
	}
		
	
	return TRUE;
}


BOOL DDS_Write( ST_DDSTEXTURE * pDdsTexture, CHAR * szFileName )
{
	ST_DDSURFACEDESC2	*pDdsHeader;
	FILE *pFile;



	pDdsHeader = new ST_DDSURFACEDESC2;
	memset( pDdsHeader, 0, sizeof(ST_DDSURFACEDESC2) );

	pDdsHeader->dwMagic					= 0x20534444; // 0x20534444 'DDS '
	pDdsHeader->dwSize					= 124;
	pDdsHeader->ddpfPixelFormat.dwSize	= 32;
	pDdsHeader->dwFlags					= DDSD_CAPS | DDSD_PIXELFORMAT | DDSD_HEIGHT | DDSD_WIDTH;
	pDdsHeader->ddsCaps.dwCaps1			= DDSCAPS_TEXTURE;
	pDdsHeader->dwWidth					= pDdsTexture->dwWidth;
	pDdsHeader->dwHeight				= pDdsTexture->dwHeight;

	switch( pDdsTexture->dwFormat )
	{
	case D3DFMT_X8R8G8B8:	// X8R8G8B8
		pDdsHeader->dwFlags |= DDSD_PITCH;
		pDdsHeader->dwPitchOrLinearSize = pDdsHeader->dwWidth;
		pDdsHeader->ddpfPixelFormat.dwFlags           = DDPF_RGB;
		pDdsHeader->ddpfPixelFormat.dwRGBBitCount     = 32;
		pDdsHeader->ddpfPixelFormat.dwRBitMask        = 0x00ff0000;
		pDdsHeader->ddpfPixelFormat.dwGBitMask        = 0x0000ff00;
		pDdsHeader->ddpfPixelFormat.dwBBitMask        = 0x000000ff;
		pDdsHeader->ddpfPixelFormat.dwRGBAlphaBitMask = 0xff000000;
		break;

	case D3DFMT_DXT1: // DXT1
		pDdsHeader->dwFlags |= DDSD_LINEARSIZE;
		pDdsHeader->dwPitchOrLinearSize = pDdsTexture->dwImageSize;
		pDdsHeader->ddpfPixelFormat.dwFlags  = DDPF_FOURCC;
		pDdsHeader->ddpfPixelFormat.dwFourCC = 0x31545844; // 0x31545844 'DXT1'
		break;

	case D3DFMT_DXT2: // DXT2
		pDdsHeader->dwFlags |= DDSD_LINEARSIZE;
		pDdsHeader->dwPitchOrLinearSize = pDdsTexture->dwImageSize;
		pDdsHeader->ddpfPixelFormat.dwFlags  = DDPF_FOURCC;
		pDdsHeader->ddpfPixelFormat.dwFourCC = 0x32545844; // 0x32545844 'DXT2'
		break;

	case D3DFMT_DXT4: // DXT4
		pDdsHeader->dwFlags |= DDSD_LINEARSIZE;
		pDdsHeader->dwPitchOrLinearSize = pDdsTexture->dwImageSize;
		pDdsHeader->ddpfPixelFormat.dwFlags  = DDPF_FOURCC;
		pDdsHeader->ddpfPixelFormat.dwFourCC = 0x34545844; // 0x34545844 'DXT4'
		break;

	default:
		delete pDdsHeader;
		return FALSE;
	}
	

	pFile = fopen( szFileName, "wb" );
	if( !pFile )
	{
		delete pDdsHeader;
		return FALSE;
	}

	fwrite( pDdsHeader, sizeof(ST_DDSURFACEDESC2), 1, pFile );
	fwrite( pDdsTexture->pbImageData, pDdsTexture->dwImageSize, 1, pFile );
	fclose( pFile );

	delete pDdsHeader;


	return TRUE;
}
