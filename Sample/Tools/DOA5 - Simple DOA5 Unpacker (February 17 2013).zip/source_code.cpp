//simple doa5 unpacker source code; sorry for this mess :)
#include <iostream>
#include <windows.h>
#include <io.h>
#include <fcntl.h>
#include <string>
#include <stdio.h>
#include <set>
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <map>
#include <vector>
#include "zlib.h"
#include <vector>
//#include <d3d9types.h>
using namespace std;

int rld(unsigned int x){
    return (x>>24) | ((x<<8) & 0x00FF0000) | ((x>>8) & 0x0000FF00) | (x<<24);
}

unsigned short rlw(unsigned short x){
    return (x>>8) | (x<<8);
}

void decriptmahshit(byte * outbuf, byte * inbuf, int bufsize){
    byte dict[] = "Except as expressly authorized, it is strictly prohibited to reproduce, distribute, exhibit or modify this software and any of its contents, including audio and visual contents. By way of example, to capture, copy or download any of the contents in this software, including audio and visual contents, onto any hardware or other software source media for any purpose, by the Internet or any other source, is strictly prohibited. Reversed engineering, decompiling or disassembly of this software is also strictly prohibited.";
    int dcounter = 0;
    int ccounter = 0;
    int doffset = 0;
    while(doffset != bufsize){
      byte test = dict[dcounter];
      dcounter++;
      if(dcounter == 522)dcounter = 0;
      byte test2 = inbuf[ccounter];
      ccounter++;
      if(test2 != 0 && test2 != test){
        test2 ^= test;
      }
      outbuf[doffset] = test2;
      doffset++;
    }
}

static void make_directory(char *const file){
	byte ch, i = 0;
	while(true)
	{	// create all directories from name
		while(file[i] && file[i]!='/' && file[i]!='\\') ++i;// search for first '/'
		if(!file[i]) break;						// end of file name - exit
		ch = file[i]; file[i]=0;				// truncate name to here
		_mkdir(file);							// create directory
		file[i++]=ch;							// restore & point to next part of name
	}
}

void dummyfunk(){};

int main(){
  int watchtsize;
  string watchname = "";
  int watchtmclsize;
    cout << "simple DOA5 UNPACKER V4 based on chrrox's scripts\n\nrun me in the doa5 folder with bin and lnk files\npreview/extract the models using noesis tool with chrrox plugin\nclose this window to cancel the unpacking\n";
    system("pause");

  WIN32_FIND_DATAA findS;
	HANDLE findH = FindFirstFile("*.lnk", &findS);
	if(findH == INVALID_HANDLE_VALUE){
		MessageBox(0, "bin File not found", 0, 0);
		return 0;
	}
	try{
        do{
            //open cat
            string lnkName(findS.cFileName);
            string fName = lnkName;
            fName.resize(fName.size() - 3);
            string binName = fName;
            binName += "bin";
            int fh = _open(binName.c_str(), O_RDONLY | O_BINARY);
            if(fh == -1){
                MessageBox(0, "Can't open the \'archive_order.bin\'\nput me in the same directory as doa5 containers", "Error", MB_OK);
                continue;
            }
            int bufSize2 = _lseek(fh, 0, SEEK_END);
            byte* buf2 = (byte*)malloc(bufSize2);
            unsigned int* ibuf2 = (unsigned int*)buf2;
            WORD* Wbuf2 = (WORD*)buf2;
            _lseek(fh, 0, SEEK_SET);
            _read(fh, buf2, bufSize2);
            close(fh);

            if(ibuf2[0] != 'OMFL'){
              free(buf2);
              continue;
            }

            int filesNum = rld(ibuf2[2]);
            int archivesNum = rld(ibuf2[1]);
            int archid, fileid;
            int archfiles;
            char* filename, * archname;
            int arch = _open(lnkName.c_str(), O_RDONLY | O_BINARY);
            if(arch == -1){
                    cout << endl << "can't open " << lnkName.c_str() << endl;
                    cout << "put me in a directory with \'archive_order.bin\' and \'lnk\' files";
                    break;
            }
            _lseek(arch, 0xC, SEEK_SET);
            _read(arch, &archfiles, 0x4);
            archfiles = rld(archfiles);
            cout << endl << lnkName.c_str() << " files = " << filesNum << endl;

            DWORD* lnkhead = (DWORD*)malloc(0x20);
            byte* inbuf, * outbuf;
            for(int i = 0; i < filesNum; i++){
                archid = rld(ibuf2[i*3+0+rld(ibuf2[4])/4]);
                fileid = rld(ibuf2[i*3+1+rld(ibuf2[4])/4]);
                filename = (char*)(buf2 + rld(ibuf2[i*3+2+rld(ibuf2[4])/4]) + 1);
                archname = (char*)(buf2 + rld(ibuf2[8 + archid*2 + 1]));
                _lseek(arch, 0x20 + fileid*0x20, SEEK_SET);
                _read(arch, lnkhead, 0x20);
                _lseek(arch, rld(lnkhead[1]), SEEK_SET);
                int size = rld(lnkhead[3]);
                int zsize = rld(lnkhead[5]);
                inbuf = (byte*)malloc(zsize);
                _read(arch, inbuf, zsize);

                bool zipped = false;
                bool crypted = false;
                if(size != zsize){
                  outbuf = (byte*)malloc(size);
                  memset(outbuf, -1, size);
                  cout << "this one is zipped" << endl;
                  //unzipme(inbuf, zsize, outbuf, size);
                  free(inbuf);
                }else{
                  outbuf = inbuf;
                }

                if(rlw(*(WORD*)(outbuf+8)) == 0x789C){//if zipped
                  zipped = true;
                  int tsize = rld(*(DWORD*)(outbuf+0));
                  watchtsize = tsize;
                  int rem = tsize;


                  inbuf = outbuf;
                  outbuf = (byte*)malloc(tsize);

                  static z_stream m_zStream;
                  static bool inited;
                  m_zStream.next_in = inbuf;
                  m_zStream.next_out = outbuf;
                  m_zStream.avail_out = tsize;
                  if(!inited){
                      inflateInit2_(&m_zStream, 15 + 32, "1.2.5", 56);
                      inited = true;
                  }
                  //unzip
                  while(m_zStream.avail_out > 0){
                    inflateReset(&m_zStream);

                    int diff = ((DWORD)m_zStream.next_in - (DWORD)inbuf) % 16;
                    if(diff > 4){
                      m_zStream.next_in += (16 - diff);
                    }else{
                      m_zStream.next_in -= diff;
                    }
                    m_zStream.next_in += 4;

                    int zsize = rld(*(DWORD*)m_zStream.next_in);
                    if(zsize > 0x8000){
                      zsize -= 0x8000;

                      m_zStream.avail_in = zsize;
                      m_zStream.next_in += 4;

                      int m_nLastErr = inflate(&m_zStream, Z_SYNC_FLUSH);
                      if(m_nLastErr != 1){
                        cout << endl << "_pillsHere" << endl;
                      }
                    }else{
                      m_zStream.next_in += 4;
                      memcpy((void*)m_zStream.next_out, (void*)m_zStream.next_in, zsize);
                      m_zStream.next_out += zsize;
                      m_zStream.next_in += zsize;
                      m_zStream.avail_out -= zsize;
                    }
                  }
                  //decrypt

                  free(inbuf);
                  inbuf = outbuf;
                  outbuf = (byte*)malloc(tsize);
                  decriptmahshit(outbuf, inbuf, tsize);
                  free(inbuf);
                }else{//if not zipped check if it's crypted by checking the uncrypted regex
                  byte checkmytmc[4];
                  decriptmahshit(checkmytmc, outbuf, 4);
                  switch(*(DWORD*)checkmytmc){
                   case 'CMT': case 'DYHP': case 'rahc': case 'bce': case 'FNT': case 'GNAL':
                   case 'apdt': case '_L1G': case 'FSWX': case 'prps': case 'pilc': case 'NECS':
                   case 'DDNU': case 0x3000000: case 'cxet':
                    crypted = true;
                    outbuf = (byte*)malloc(size);
                    decriptmahshit(outbuf, inbuf, size);
                    free(inbuf);
                  }
                }

                //ini rename
                char* ininame = new char[255];
                GetPrivateProfileString("NAMES", filename, "", ininame, 255, ".\\doa5realnames.ini");
                string newname;
                if (ininame[0] == 0){
                  newname = filename;
                }else{
                  newname = ininame;
                }

                if(zipped){
                  size = watchtsize;
                  cout << "*";
                }else if(crypted){
                  cout << "#";
                }else{
                  cout << ".";
                }

                string dirpath = fName; // instead of the archname
                dirpath += "/";
                dirpath += newname;
                char* dpath = new char[dirpath.length()+1];
                memcpy(dpath, dirpath.c_str(), dirpath.length()+1);
                make_directory(dpath);

                DWORD bytesRead;
                HANDLE h = CreateFile(dpath, GENERIC_WRITE, 0, 0, CREATE_ALWAYS, 0, 0);//mixedmodel.xpr
                if(!h){
                    MessageBox(0,"Can't create file", "Error(Already exist?)", MB_OK);
                    return 0;
                }
                WriteFile(h, outbuf, size, &bytesRead, 0);
                CloseHandle(h);

                watchtsize = -1;

                free(outbuf);
                free(dpath);

            }
            free(buf2);

        }while(FindNextFile(findH, &findS));
        FindClose(findH);
	}catch(...){}

    system("pause");
    return 0;
}
